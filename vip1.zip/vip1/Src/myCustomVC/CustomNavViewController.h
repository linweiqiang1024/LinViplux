//
//  CustomNavViewController.h
//  huiyi
//
//  Created by 王振兴 on 14-12-11.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNavViewController : UINavigationController
{
    UILabel *titleLabel;
}
@property (nonatomic,strong)UILabel *titleLabel;
@end
