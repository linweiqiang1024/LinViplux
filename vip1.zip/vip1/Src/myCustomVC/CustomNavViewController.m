//
//  CustomNavViewController.m
//  huiyi
//
//  Created by 王振兴 on 14-12-11.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "CustomNavViewController.h"

@interface CustomNavViewController ()

@end

@implementation CustomNavViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.titleLabel = [[UILabel alloc]init];
//    self.titleLabel.frame = CGRectMake(110, 0, 100, 44);
//    self.titleLabel.textColor = [UIColor blackColor];
//    self.titleLabel.textAlignment = NSTextAlignmentCenter;
//    self.titleLabel.font = [UIFont boldSystemFontOfSize:18];
//    self.titleLabel.text = @"";
//    //titleLabel.backgroundColor = [UIColor whiteColor];
//    [self.navigationController.navigationBar addSubview:self.titleLabel];
    
    self.navigationController.navigationBar.backgroundColor =  SYETEMBACKGROUDCOLOR;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
