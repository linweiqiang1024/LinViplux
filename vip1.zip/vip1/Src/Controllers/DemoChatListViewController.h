//
//  DemoChatListViewController.h
//  iOS-IMKit-demo
//
//  Created by xugang on 8/30/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCChatListViewController.h"

@interface DemoChatListViewController : RCChatListViewController


@end
