//
//  DemoRichContentMessageViewController.h
//  iOS-IMKit-demo
//
//  Created by Gang Li on 10/20/14.
//  Copyright (c) 2014 RongCloud. All rights reserved.
//

#import "RCChatViewController.h"

@interface DemoRichContentMessageViewController : RCChatViewController

@end
