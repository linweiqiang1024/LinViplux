//
//  DemoChatViewController.m
//  iOS-IMKit-demo
//
//  Created by xugang on 8/30/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import "DemoChatViewController.h"
#import "DemoChatsettingViewController.h"
#import "DemoPreviewViewController.h"
#import "DemoLocationViewController.h"


@implementation DemoChatViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
//    if (IOS7) {
//        [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"navBGImage"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
//    }
//    else{
//        [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"xian1"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
//    }
//    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithHexString:@"#0ba1df"]];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"setupUnreadMessageCount" object:nil];
    
//     self.curPicker.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [[RCIMClient sharedRCIMClient] clearMessagesUnreadStatus:self.conversationType targetId:self.currentTarget];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"setupUnreadMessageCount" object:nil];
}




-(void)viewDidLoad
{
    [super viewDidLoad];
    
   
    self.enableUnreadBadge = NO;//导航上是否显示  左上角的 未读数量数字
    //移除右划手势
    [self.view removeGestureRecognizer:self.swipeRecognizer];
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = self.currentTargetName;
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleView;
    self.portraitStyle = RCUserAvatarRectangle;
    
    //自定义导航左右按钮
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    [leftButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.leftBarButtonItem = leftButton;

    
    
    if (!self.enableSettings) {
        self.navigationItem.rightBarButtonItem = nil;
    }else{
        //自定义导航左右按钮
        NSLog(@"%d",self.conversationType);
        UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
        right.frame = CGRectMake(0, 0, 44, 44);
        if (self.conversationType == ConversationType_GROUP) {
            [right setImage:[UIImage imageNamed:@"gourpicon"] forState:UIControlStateNormal];
        }
        else if(self.conversationType == ConversationType_PRIVATE){
            [right setImage:[UIImage imageNamed:@"singleUserPhoto"] forState:UIControlStateNormal];
        }
        else if(self.conversationType == ConversationType_DISCUSSION){
            [right setImage:[UIImage imageNamed:@"gourpicon"] forState:UIControlStateNormal];
        }
        else{
            
        }
        [right setImageEdgeInsets:UIEdgeInsetsMake(0, 20, 0, 0)];
        [right addTarget:self action:@selector(rightBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
        
        UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]initWithCustomView:right];
        [rightButton setTintColor:[UIColor whiteColor]];
        self.navigationItem.rightBarButtonItem = rightButton;
    }
}
- (BOOL)hidesBottomBarWhenPushed{
    return YES;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    if (self.conversationType == ConversationType_DISCUSSION) {
        //返回到指定的 VC
        NSInteger count = [self.navigationController.viewControllers count];//计算该导航中有多少对象
        if (count>=4) {
            UIViewController *vc = [self.navigationController.viewControllers objectAtIndex:count-4];//找到要返回的页面
            [self.navigationController popToViewController:vc animated:YES];//执行跳转操作
        }
        else{
            [super leftBarButtonItemPressed:sender];
        }
    }
    else{
        [super leftBarButtonItemPressed:sender];
    }
    
    
    
}
-(void)rightBarButtonItemPressed:(id)sender{
    DemoChatsettingViewController *temp = [[DemoChatsettingViewController alloc]init];
    temp.targetId = self.currentTarget;
    temp.conversationType = self.conversationType;
    temp.portraitStyle = RCUserAvatarRectangle;
    [self.navigationController pushViewController:temp animated:YES];
}

-(void)showPreviewPictureController:(RCMessage*)rcMessage{
    
    DemoPreviewViewController *temp=[[DemoPreviewViewController alloc]init];
    temp.rcMessage = rcMessage;
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:temp];
    
    //导航和原有的配色保持一直
    UIImage *image= [self.navigationController.navigationBar backgroundImageForBarMetrics:UIBarMetricsDefault];
    
    [nav.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    
    [self presentViewController:nav animated:YES completion:nil];
}
- (void)openLocationPicker:(id)sender{
    LocationPickerViewController *locationVC = [[LocationPickerViewController alloc]init];
    locationVC.delegate = self;
    [self.navigationController pushViewController:locationVC animated:YES];
    
}
- (void)openLocation:(CLLocationCoordinate2D)location locationName:(NSString *)locationName{
    DemoLocationViewController *locationView = [[DemoLocationViewController alloc]initWithLocation:location locationName:locationName];
    [self.navigationController pushViewController:locationView animated:YES];
}
- (void)locationPicker:(RCLocationPickerViewController *)locationPicker didSelectLocation:(CLLocationCoordinate2D)location locationName:(NSString *)locationName mapScreenShot:(UIImage *)mapScreenShot{
    [self sendLBSMessage:mapScreenShot location:location locationName:locationName];
    [locationPicker.navigationController popViewControllerAnimated:YES];
}
-(void)onBeginRecordEvent{
//    DebugLog(@"录音开始");
}
-(void)onEndRecordEvent{
//    DebugLog(@"录音结束");
}

@end
