//
//  DemoGroupViewController.m
//  iOS-IMKit-demo
//
//  Created by xugang on 9/7/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import "DemoGroupListViewController.h"
#import "DemoChatViewController.h"
#import "MyNoneContentView.h"
@interface DemoGroupListViewController ()
{
    MyNoneContentView *tableViewNoneView;
}
@end

@implementation DemoGroupListViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"setupUnreadMessageCount" object:nil];
}
- (BOOL)hidesBottomBarWhenPushed{
    return YES;
}
- (void)viewDidLoad
{
    [super viewDidLoad];

    
//    tableViewNoneView = [[MyNoneContentView alloc]init];
//    tableViewNoneView.frame = CGRectMake(0, 0, 320,self.conversationListView.frame.size.height);
//    tableViewNoneView.backgroundColor = [UIColor whiteColor];
//    tableViewNoneView.noneLabel.text = @"还没有消息哦~";
////    [self.view addSubview:tableViewNoneView];
//    UIView *views = self.view;
//    self.view.backgroundColor = [UIColor whiteColor];
//    NSLog(@"%@,%@",self.view.subviews,self.view.layer);
//    for(UIView *view in self.view.subviews){
//        NSLog(@"%@",view);
////        [view removeFromSuperview];
//        break;
//    }
//    [self.view.layer removeFromSuperlayer];
////    [self.conversationListView insertSubview:tableViewNoneView belowSubview:self.conversationListView];
//    [self.view addSubview:tableViewNoneView];
//    [self.view sendSubviewToBack:tableViewNoneView];
    
    
    
    [self.view removeGestureRecognizer:self.swipeRecognizer];
    // Do any additional setup after loading the view.
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = @"群组会话";
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleView;
    //自定义导航标题颜色
    //[self setNavigationTitle:@"会话" textColor:[UIColor blackColor]];
    
    //自定义导航左右按钮
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];

    self.navigationItem.leftBarButtonItem = leftButton;
    
}

-(void)leftBarButtonItemPressed:(id)sender
{
    [super leftBarButtonItemPressed:sender];
}

-(void)onSelectedTableRow:(RCConversation*)conversation{
    
    DemoChatViewController* chat = [self getChatController:conversation.targetId conversationType:conversation.conversationType];
    if (nil == chat) {
        chat =[[DemoChatViewController alloc]init];
        chat.portraitStyle = RCUserAvatarRectangle;
        [self addChatController:chat];
    }
    
    chat.currentTarget = conversation.targetId;
    chat.conversationType = conversation.conversationType;
    //chat.currentTargetName = curCell.userNameLabel.text;
    chat.currentTargetName = conversation.conversationTitle;
    [self.navigationController pushViewController:chat animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
