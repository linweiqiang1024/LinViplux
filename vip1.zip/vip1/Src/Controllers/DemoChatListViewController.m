//
//  DemoChatListViewController.m
//  iOS-IMKit-demo
//
//  Created by xugang on 8/30/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import "DemoChatListViewController.h"
#import "DemoChatViewController.h"
#import "DemoGroupListViewController.h"
#import "RCIM.h"
#import "FriendInfoViewController.h"
#import "MyNoneContentView.h"
@implementation DemoChatListViewController

{
    MyNoneContentView *tableViewNoneView;
}
- (void)viewWillAppear:(BOOL)animated{
    NSArray *array =  [[RCIM sharedRCIM]getConversationList];
    
    RCConversation *conversation = [array lastObject];
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.tintColor = [UIColor blueColor];
    self.navigationController.navigationBar.shadowImage = [[UIImage alloc] init];
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    tableViewNoneView = [[MyNoneContentView alloc]init];
    tableViewNoneView.frame = CGRectMake(0, 0, ScreenWidth,self.conversationListView.frame.size.height);
    tableViewNoneView.backgroundColor = [UIColor whiteColor];
    tableViewNoneView.imageView.image = [UIImage imageNamed:@"no_message"];
    tableViewNoneView.noneLabel.text = @"还没有消息哦";
    tableViewNoneView.otherLabel.text = @"快去跟你的伙伴聊一聊";//副标题
    [self.view addSubview:tableViewNoneView];
    [self.view sendSubviewToBack:tableViewNoneView];
    [self.view.layer removeFromSuperlayer];
    //自定义导航标题颜色
    [self.view removeGestureRecognizer:self.swipeRecognizer];
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = @"消息";
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleView;
    //更改头像形状
    self.portraitStyle = RCUserAvatarRectangle;
    //自定义导航标题颜色
    [self.navigationItem.rightBarButtonItem.customView setHidden:YES];
    //自定义导航左右按钮
    //左边的按钮
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 33, 30);
    if (IOS7) {
        leftBtn.imageEdgeInsets = UIEdgeInsetsMake((30-20.5)/2-2, -19, 0, 0);
    }
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    
    UIBarButtonItem *leftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBtnItem;
    //自定义导航左右按钮
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]initWithTitle:@"选择" style:UIBarButtonItemStyleBordered target:self action:@selector(rightBarButtonItemPressed:)];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = nil;
    //自定义头像点击
    [[RCIM sharedRCIM] setUserPortraitClickEvent:^(UIViewController *viewController, RCUserInfo *userInfo) {
        if (![userInfo.userId isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]) {
            FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
            friendInfoVC.user_id = userInfo.userId;
            [viewController.navigationController pushViewController:friendInfoVC animated:YES];
            NSLog(@"clicked!");
        }
    }];
}
- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
}
- (void)backClick{
    self.navigationController.navigationBarHidden = YES;
    [self.navigationController popViewControllerAnimated:YES];
}
- (BOOL)showCustomEmptyBackView{
    return YES;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    [super leftBarButtonItemPressed:sender];
}
/**
 *  重载右边导航按钮的事件
 *
 *  @param sender <#sender description#>
 */
-(void)rightBarButtonItemPressed:(id)sender
{
    //跳转好友列表界面，可是是融云提供的UI组件，也可以是自己实现的UI
    RCSelectPersonViewController *temp = [[RCSelectPersonViewController alloc]init];
    //控制多选
    temp.isMultiSelect = YES;
    temp.portaitStyle = RCUserAvatarCycle;
    UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:temp];
//    //导航和的配色保持一直
//    UIImage *image= [self.navigationController.navigationBar backgroundImageForBarMetrics:UIBarMetricsDefault];
//    [nav.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    temp.delegate = self;
    [self presentViewController:nav animated:YES completion:nil];
}

-(void)didSelectedPersons:(NSArray*)selectedArray viewController:(RCSelectPersonViewController *)viewController
{
    if(selectedArray == nil || selectedArray.count == 0)
    {
        return;
    }
    int count = (int)selectedArray.count;
    
    
    //只选择一个人得时候,创建单人聊天
    if (1 == count) {
        RCUserInfo* userInfo = selectedArray[0];
        [self startPrivateChat:userInfo];
    }
    //选择多个人得时候
    else if(count  > 1){
        [self startDiscussionChat:selectedArray];
    }
}
/**
 *  启动一对一聊天
 *
 *  @param userInfo
 */
-(void)startPrivateChat:(RCUserInfo*)userInfo{
    
    DemoChatViewController* chat = [self getChatController:userInfo.userId conversationType:ConversationType_PRIVATE];
    if (nil == chat) {
        chat =[[DemoChatViewController alloc]init];
        chat.portraitStyle = RCUserAvatarRectangle;
        [self addChatController:chat];
    }
    
    chat.currentTarget = userInfo.userId;
    chat.currentTargetName = userInfo.name;
    chat.conversationType = ConversationType_PRIVATE;
    [self.navigationController pushViewController:chat animated:YES];
}

/**
 *  启动讨论组
 *
 *  @param userInfos
 */
-(void)startDiscussionChat:(NSArray*)userInfos{
    
    NSMutableString *discussionName = [NSMutableString string] ;
    NSMutableArray *memberIdArray =[NSMutableArray array];
    NSInteger count = userInfos.count ;
    for (int i=0; i<count; i++) {
        RCUserInfo *userinfo = userInfos[i];
        //NSString *name = userinfo.name;
        if (i == userInfos.count - 1) {
            [discussionName appendString:userinfo.name];
        }else{
            [discussionName  appendString:[NSString stringWithFormat:@"%@%@",userinfo.name,@","]];
        }
        [memberIdArray addObject:userinfo.userId];
        
    }
    //创建讨论组
    [[RCIMClient sharedRCIMClient]createDiscussion:discussionName userIdList:memberIdArray completion:^(RCDiscussion *discussInfo) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            DemoChatViewController* chat = [self getChatController:discussInfo.discussionId conversationType:ConversationType_PRIVATE];
            if (nil == chat) {
                chat =[[DemoChatViewController alloc]init];
                chat.portraitStyle = RCUserAvatarRectangle;
                [self addChatController:chat];
            }
            
            chat.currentTarget = discussInfo.discussionId;
            chat.currentTargetName = discussInfo.discussionName;
            chat.conversationType = ConversationType_DISCUSSION;
            [self.navigationController pushViewController:chat animated:YES];
        });
    } error:^(RCErrorCode status) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            UIAlertView *alert= [[UIAlertView alloc]initWithTitle:@"" message:@"创建讨论组失败" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alert show];
        });
    }];
}
/**
 *  重载选择表格事件
 *
 *  @param conversation
 */
-(void)onSelectedTableRow:(RCConversation*)conversation{
    
    
    if(conversation.conversationType == ConversationType_GROUP)
    {
        DemoGroupListViewController* groupVC = [[DemoGroupListViewController alloc] init];
        self.currentGroupListView = groupVC;
        groupVC.portraitStyle = RCUserAvatarRectangle;
        [self.navigationController pushViewController:groupVC animated:YES];
        return;
    }
    //该方法目的延长会话聊天UI的生命周期
    DemoChatViewController* chat = [self getChatController:conversation.targetId conversationType:conversation.conversationType];
    if (nil == chat) {
        chat =[[DemoChatViewController alloc]init];
        chat.portraitStyle = RCUserAvatarRectangle;
        [self addChatController:chat];
    }
    chat.currentTarget = conversation.targetId;
    chat.conversationType = conversation.conversationType;
    //chat.currentTargetName = curCell.userNameLabel.text;
    chat.currentTargetName = conversation.conversationTitle;
    [self.navigationController pushViewController:chat animated:YES];
}
@end
