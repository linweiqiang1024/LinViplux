//
//  DemoLocationPickerViewController.m
//  huiyi
//
//  Created by 王振兴 on 14-12-25.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "DemoLocationPickerViewController.h"

@interface DemoLocationPickerViewController ()

@end

@implementation DemoLocationPickerViewController
- (instancetype)initWithDataSource:(id<RCLocationPickerViewControllerDataSource>)dataSource{
    self = [super initWithDataSource:dataSource];
    if (self) {
        //self.dataSource = dataSource;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = @"选取位置";
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor blackColor];
    self.navigationItem.titleView = titleView;
    
    //自定义导航左右按钮
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    [leftButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
    right.frame = CGRectMake(0, 0, 44, 44);
    [right setTitle:@"完成" forState:UIControlStateNormal];
    [right setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [right setImageEdgeInsets:UIEdgeInsetsMake(0, 20, 0, 0)];
    [right addTarget:self action:@selector(rightBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
        
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]initWithCustomView:right];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    // Do any additional setup after loading the view.
}
-(void)leftBarButtonItemPressed:(id)sender
{
    [super leftBarButtonItemPressed:sender];
}
- (void)rightBarButtonItemPressed:(id)sender{
    [super onFinishButtonClicked:sender];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
