//
//  DemoPreviewViewController.h
//  iOS-IMKit-demo
//
//  Created by xugang on 14-9-18.
//  Copyright (c) 2014年 Heq.Shinoda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCPreviewViewController.h"

@interface DemoPreviewViewController : RCPreviewViewController

@end
