//
//  DemoLocationMessage.h
//  huiyi
//
//  Created by 王振兴 on 14-12-25.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "RCLocationMessage.h"
@interface DemoLocationMessage : RCLocationMessage

@end
