//
//  ViewControllerDemo.m
//  huiyi
//
//  Created by 王振兴 on 15-3-12.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "ViewControllerDemo.h"

@interface ViewControllerDemo ()

@end

@implementation ViewControllerDemo

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
//        if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)])
//        {
//            [self setEdgesForExtendedLayout:UIRectEdgeBottom];
//        }
    // Do any additional setup after loading the view.
    UIView *views = [[UIView alloc]init];
    views.backgroundColor = [UIColor redColor];
    views.frame = CGRectMake(0, 0, 80, 100);
    [self.view addSubview:views];
}
- (void)viewWillAppear:(BOOL)animated{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
