//
//  DemoChatsettingViewController.h
//  iOS-IMKit-demo
//
//  Created by xugang on 8/30/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCChatSettingViewController.h"

#import "EMRemarkImageView.h"
#import "FatherViewController.h"
@interface ChatGroupContactView : EMRemarkImageView
{
    
    
}
@property (copy) void (^deleteContact)(NSInteger index);
@property (nonatomic,strong)UIButton *deleteButton;

@end

@interface DemoChatsettingViewController : RCChatSettingViewController<UIAlertViewDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSString *_groupID;
    NSMutableArray *_groupInfoArr;
    NSInteger _selecedIndex;
    NSString *_member_count;//群成员数量
    NSString *_group_name;//群组的名称
}
@property (nonatomic,strong)NSString *groupID;
@property (nonatomic,strong)NSString *member_count;//群成员的数量
@property (nonatomic,strong)NSString *group_name;
@property (nonatomic,strong)UITableView *tableView;
@end
