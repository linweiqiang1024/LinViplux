//
//  DemoGroupViewController.h
//  iOS-IMKit-demo
//
//  Created by xugang on 9/7/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCGroupListViewController.h"

@interface DemoGroupListViewController : RCGroupListViewController
@end
