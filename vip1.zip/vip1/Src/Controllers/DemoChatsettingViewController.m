//
//  DemoChatsettingViewController.m
//  iOS-IMKit-demo
//
//  Created by xugang on 8/30/14.
//  Copyright (c) 2014 Heq.Shinoda. All rights reserved.
//

#import "DemoChatsettingViewController.h"
#import "DemoRenameController.h"
#import "DemoChatViewController.h"

#import "MYWebImage.h"
#import "ChatGroupModel.h"
#import "UIImageView+WebCache.h"
#import "AddressIpa.h"
#import "DetailsInfoVC.h"
#import "ChatNavLabel.h"
#import "FriendInfoViewController.h"
#import "GroupInfoIpa.h"
#import "RCIMClient.h"
//#import "RCCommandNotificationMessage.h"



#pragma mark - ChatGroupContactView

@implementation ChatGroupContactView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _deleteButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
        [_deleteButton addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];
        [_deleteButton setImage:[UIImage imageNamed:@"/RongCloud.bundle/delete_member_tip"] forState:UIControlStateNormal];
        _deleteButton.hidden = YES;
        [self addSubview:_deleteButton];
    }
    
    return self;
}

- (void)setEditing:(BOOL)editing
{
    if (_editing != editing) {
        _editing = editing;
        _deleteButton.hidden = !_editing;
    }
}

- (void)deleteAction:(UIButton *)sender
{
    NSLog(@"sender.tag = %d",sender.tag);
    if (_deleteContact) {
        _deleteContact(sender.tag);
    }
}

@end

#pragma mark - ChatGroupDetailViewController

#define kColOfRow 4
#define kContactSize 75

@interface DemoChatsettingViewController ()<ChatNavLabelDelegate>

@property (strong, nonatomic) NSMutableArray *dataSource;
@property (strong, nonatomic) UIScrollView *scrollView;
@property (strong, nonatomic) UIButton *addButton;

@property (strong, nonatomic) UIView *footerView;
@property (strong, nonatomic) UIButton *clearButton;
@property (strong, nonatomic) UIButton *exitButton;
@property (strong, nonatomic) UIButton *dissolveButton;
@property (strong, nonatomic) UIButton *configureButton;
@property (strong, nonatomic) UIGestureRecognizer *hitpress;
@property (strong, nonatomic) UILongPressGestureRecognizer *longPress;
- (void)dissolveAction;
- (void)clearAction;
- (void)exitAction;
- (void)configureAction;

@end


@implementation DemoChatsettingViewController
{
    UIView *view;
    GroupInfoIpa *_groupInfoIpa;
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    [self.view removeGestureRecognizer:self.swipeRecognizer];
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = @"设置";
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleView;
    
    //自定义导航标题颜色
    //[self setNavigationTitle:@"设置" textColor:[UIColor whiteColor]];
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    [leftButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    if (self.conversationType == ConversationType_GROUP) {
        self.tableView.bounces = NO;
        [self.tableView.tableFooterView removeFromSuperview];
        view = [[UIView alloc]init];
        view.frame = CGRectMake(0, 0, 320, self.scrollView.frame.size.height + 20);
        self.tableView.tableHeaderView = view;
        
        [view addSubview:self.scrollView];
        _groupInfoIpa = [[GroupInfoIpa alloc]init];
        _groupInfoArr = [[NSMutableArray alloc]initWithCapacity:0];
        self.dataSource = [[NSMutableArray alloc]init];
        self.tableView.tableFooterView = self.footerView;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapView:)];
        tap.cancelsTouchesInView = NO;
        [self.view addGestureRecognizer:tap];
        [self getGroupDetailInfo];
    }
}
- (void)btnClick{
    view.frame = CGRectMake(0, 0, view.frame.size.width, view.frame.size.height+20);
    self.tableView.tableHeaderView = view;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    [super leftBarButtonItemPressed:sender];
}

-(void)renameDiscussionName:(RCConversationType)conversationType targetId:(NSString*)targetId oldName:(NSString*)oldName{
    
    RCRenameViewController *temp = [[RCRenameViewController alloc]init];
    temp.delegate = self;
    temp.targetId = targetId;
    temp.oldName = oldName;
    temp.conversationType =conversationType;
    
    UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:temp];
    
    //导航和原有的配色保持一直
    UIImage *image= [self.navigationController.navigationBar backgroundImageForBarMetrics:UIBarMetricsDefault];
    
    [nav.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    
    [self presentViewController:nav animated:YES completion:NULL];
}


-(void)onAddButtonClicked:(RCConversationType)conversationType{
    
    //单聊添加人员创建讨论组
    if (ConversationType_PRIVATE == conversationType) {
        RCSelectPersonViewController *temp = [[RCSelectPersonViewController alloc]init];
        //控制多选
        temp.isMultiSelect = YES;
        temp.useMode = CreateMode;
        temp.portaitStyle = RCUserAvatarCycle;
        temp.preSelectedUserIds = @[self.targetId];
        UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:temp];
        
        //导航和的配色保持一直
        UIImage *image= [self.navigationController.navigationBar backgroundImageForBarMetrics:UIBarMetricsDefault];
        
        [nav.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
        //[nav.navigationBar setBackgroundImage:self.navigationController.navigationBar. forBarMetrics:UIBarMetricsDefault];
        
        temp.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
    }
    //多人聊天添加更多人
    if ( ConversationType_DISCUSSION==conversationType) {
        RCSelectPersonViewController *temp = [[RCSelectPersonViewController alloc]init];
        //控制多选
        temp.isMultiSelect = YES;
        //选择联系人邀请模式
        temp.useMode = InviteMode;
        temp.portaitStyle = RCUserAvatarCycle;
        NSMutableArray* preArray = [[NSMutableArray alloc]initWithArray:self.discussionInfo.memberIdList];
        //已选人员排除自身
        for (NSInteger i =preArray.count-1; i>=0; i--) {
            NSString* userId = preArray[i];
            if ([userId isEqualToString:[self getCurrentUserId]]) {
                [preArray removeObjectAtIndex:i];
            }
            
        }
        
        temp.preSelectedUserIds = preArray;
        temp.discussionInfo_invite = self.discussionInfo;
        UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:temp];
        
        //导航和的配色保持一直
        UIImage *image= [self.navigationController.navigationBar backgroundImageForBarMetrics:UIBarMetricsDefault];
        
        [nav.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
        //[nav.navigationBar setBackgroundImage:self.navigationController.navigationBar. forBarMetrics:UIBarMetricsDefault];
        
        temp.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
    }
    
}

#pragma mark - selectPersonDelegate
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

-(void)didSelectedPersons:(NSArray *)selectedArray viewController:(RCSelectPersonViewController *)viewController
{
    //创建多人聊天
    if (viewController.useMode == CreateMode) {
        
        NSInteger selectedCount = viewController.selectedPersonList.count;
        NSMutableString *discussionName = [NSMutableString string] ;
        NSMutableArray *memberIdArray =[NSMutableArray array];
        
        
        //之前已经选择的Id
        NSString* userId=(viewController.preSelectedUserIds)[0];
        [memberIdArray addObject:userId];
        RCUserInfo *userInfo=[self getUserInfoWithUserId:userId];
        if (userInfo) {
            [discussionName appendString:userInfo.name];
            [discussionName appendString:@","];
        }
        
        
        //后获取选中的人员
        for (int i=0; i<viewController.selectedPersonList.count; i++) {
            RCUserInfo *userinfo = (viewController.selectedPersonList)[i];
            //NSString *name = userinfo.name;
            if (i == selectedCount - 1) {
                [discussionName appendString:userinfo.name];
            }else{
                [discussionName  appendString:[NSString stringWithFormat:@"%@%@",userinfo.name,@","]];
            }
            
            [memberIdArray addObject:userinfo.userId];
            
        }
        
        //创建讨论组
        [[RCIMClient sharedRCIMClient] createDiscussion:discussionName userIdList:memberIdArray completion:^(RCDiscussion* discussionInfo) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                //成功创建讨论组跳转
                //[weakSelf didCreateDiscussion:discussionInfo];
                
                DemoChatViewController* chat;
                chat =[[DemoChatViewController alloc]init];
                chat.portraitStyle = RCUserAvatarCycle;
                chat.currentTarget = discussionInfo.discussionId;
                chat.currentTargetName = discussionInfo.discussionName;
                chat.conversationType = ConversationType_DISCUSSION;
                [self.navigationController pushViewController:chat animated:YES];
                
            });
        } error:^(RCErrorCode status) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if (status == 0) {
                    NSLog(@"DISCUSSION_CREATE_SUCCEDD");
                    
                }else{
                    NSLog(@"DISCUSSION_INVITE_FAILED %d",(int)status);
                    UIAlertView *alert= [[UIAlertView alloc]initWithTitle:@"" message:@"创建讨论组失败" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                    [alert show];
                }
            });
            
        }];
        
    }
    
    if (viewController.useMode == InviteMode) {
        NSMutableArray *memberIdArray =[NSMutableArray array];
        for (int i=0; i<viewController.selectedPersonList.count; i++) {
            RCUserInfo *userinfo = (viewController.selectedPersonList)[i];
            
            [memberIdArray addObject:userinfo.userId];
        }
        //添加新的成员
        [[RCIMClient sharedRCIMClient] addMemberToDiscussion:self.discussionInfo.discussionId userIdList:memberIdArray completion:^(RCDiscussion *discussion) {
            
            dispatch_async(dispatch_get_main_queue(), ^{
                if (nil !=discussion) {
                    
                    //刷新讨论组设置
                    [self needUpdateDiscussionInfo:discussion];
                }
                else{
                    NSLog(@"%@",@"获取讨论组信息失败");
                }
            });
            
        } error:^(RCErrorCode status) {
            
        }];
    }
}
#pragma mark  关于群的相关操作
#pragma mark - getter

- (UIScrollView *)scrollView
{
    if (_scrollView == nil) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(10, 10, self.view.frame.size.width - 20, kContactSize)];
        _scrollView.backgroundColor = [UIColor colorWithHexString:@"d5d5d5"];
        _scrollView.layer.cornerRadius = 4;
        _scrollView.tag = 0;
        
        _addButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, kContactSize - 10, kContactSize - 10)];
        [_addButton setBackgroundImage:[UIImage imageNamed:@"/RongCloud.bundle/delete_members"] forState:UIControlStateNormal];
        _addButton.layer.cornerRadius = 5;
        _addButton.layer.masksToBounds = YES;
        [_addButton addTarget:self action:@selector(deleteContactBegin:) forControlEvents:UIControlEventTouchUpInside];
        _longPress.minimumPressDuration = 0.5;
    }
    return _scrollView;
}

- (UIButton *)clearButton
{
    if (_clearButton == nil) {
        _clearButton = [[UIButton alloc] init];
        [_clearButton setTitle:@"清空聊天记录" forState:UIControlStateNormal];
        [_clearButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_clearButton addTarget:self action:@selector(clearAction) forControlEvents:UIControlEventTouchUpInside];
        [_clearButton setBackgroundColor:[UIColor colorWithRed:87 / 255.0 green:186 / 255.0 blue:205 / 255.0 alpha:1.0]];
    }
    return _clearButton;
}

- (UIButton *)dissolveButton
{
    if (_dissolveButton == nil) {
        _dissolveButton = [[UIButton alloc] init];
        [_dissolveButton setTitle:@"解散该群" forState:UIControlStateNormal];
        [_dissolveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_dissolveButton addTarget:self action:@selector(dissolveAction) forControlEvents:UIControlEventTouchUpInside];
        [_dissolveButton setBackgroundColor: [UIColor colorWithRed:191 / 255.0 green:48 / 255.0 blue:49 / 255.0 alpha:1.0]];
    }
    return _dissolveButton;
}

- (UIButton *)exitButton
{
    if (_exitButton == nil) {
        _exitButton = [[UIButton alloc] init];
        [_exitButton setTitle:@"退出该群" forState:UIControlStateNormal];
        [_exitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_exitButton addTarget:self action:@selector(exitAction) forControlEvents:UIControlEventTouchUpInside];
        [_exitButton setBackgroundColor:[UIColor colorWithRed:191 / 255.0 green:48 / 255.0 blue:49 / 255.0 alpha:1.0]];
    }
    
    return _exitButton;
}

- (UIView *)footerView
{
    if (_footerView == nil) {
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, 75)];
        _footerView.backgroundColor = [UIColor clearColor];
        
        self.dissolveButton.frame = CGRectMake(20, 20, _footerView.frame.size.width - 40, 35);
        
        self.exitButton.frame = CGRectMake(20, 20, _footerView.frame.size.width - 40, 35);
    }
    return _footerView;
}
#pragma mark  整理数据源
- (void)getSourceData:(NSString *)jsonStr{
//    if ([[[[jsonStr JSONValue] objectForKey:@"content"] objectForKey:@"members"] isEqualToString:@""]) {
//        return;
//    }
    for(NSDictionary *sectionDic in [[[jsonStr JSONValue] objectForKey:@"content"] objectForKey:@"members"]){
        for(NSDictionary *dic in [sectionDic objectForKey:@"list"]){
            AddressIpa *ipa = [[AddressIpa alloc]init];
            ipa.ipaIndex = [dic objectForKey:@"index"];
            ipa.ipaCan_chat = [dic objectForKey:@"can_chat"];
            ipa.ipaEmail = [dic objectForKey:@"email"];
            ipa.ipaIco_file = [dic objectForKey:@"ico_url"];
            ipa.ipaIs_friend = [dic objectForKey:@"is_friend"];
            ipa.ipaName = [dic objectForKey:@"name"];
            ipa.ipaNew_msg = [dic objectForKey:@"new_msg"];
            ipa.ipaOrigin = [dic objectForKey:@"origin"];
            ipa.ipaSend_time = [dic objectForKey:@"send_time"];
            ipa.ipaState = [dic objectForKey:@"state"];
            ipa.ipaType = [dic objectForKey:@"type"];
            ipa.ipaUser_id = [dic objectForKey:@"user_id"];
            ipa.ipaShield_sw = [dic objectForKey:@"shield_sw"];
            ipa.ipaNotice_sw = [dic objectForKey:@"notice_sw"];
            AddressInfoIpa *infoIpa = [[AddressInfoIpa alloc]init];
            NSLog(@"info = 111%@111",[dic objectForKey:@"info"]);
            if (![[dic objectForKey:@"info"]isKindOfClass:[NSString class]]) {
                infoIpa.ipaCompany = [[dic objectForKey:@"info"] objectForKey:@"company"];
                infoIpa.ipaGender = [[dic objectForKey:@"info"] objectForKey:@"gender"];
                infoIpa.ipaSummary = [[dic objectForKey:@"info"] objectForKey:@"summary"];
                infoIpa.ipaTitle = [[dic objectForKey:@"info"] objectForKey:@"title"];
                infoIpa.ipaUser_id = [[dic objectForKey:@"info"] objectForKey:@"user_id"];
            }
            ipa.ipaInfo = infoIpa;
            [self.dataSource addObject:ipa];
        }
        
    }
    //[self.tableView reloadData];
}
#pragma mark - data  获取群的详细信息 接口调用
- (void)getGroupDetailInfo{
    NSLog(@"%@",self.targetId);
    NSDictionary *dic = @{@"group_id":self.targetId};
    [self showHudInView:self.view hint:@"加载数据..."];
    [MyDataService postPlatformContactGroupmembers:dic calllback:^(id data) {
        NSLog(@"data = %@",[data JSONString]);
        NSLog(@"%@",data);
        if ([[data objectForKey: @"code"] isEqualToString: @"200"]) {
            _groupInfoIpa.ipaUser_id = [[[data objectForKey:@"content"] objectForKey:@"groupinfo"] objectForKey:@"user_id"];
            _groupInfoIpa.ipaShield_sw = [[[data objectForKey:@"content"] objectForKey:@"groupinfo"] objectForKey:@"shield_sw"];
            _groupInfoIpa.ipaName = [[[data objectForKey:@"content"] objectForKey:@"groupinfo"] objectForKey:@"name"];
            _groupInfoIpa.ipaMember_count = [[[data objectForKey:@"content"] objectForKey:@"groupinfo"] objectForKey:@"member_count"];
            _groupInfoIpa.ipaIco_file = [[[data objectForKey:@"content"] objectForKey:@"groupinfo"] objectForKey:@"ico_file"];
            _groupInfoIpa.ipaGroup_id = [[[data objectForKey:@"content"] objectForKey:@"groupinfo"] objectForKey:@"group_id"];
            
            [self getSourceData:[data JSONString]];
            [self refreshFooterView];
            [self refreshScrollView];
            
        }
        [self hideHud];
    }];
}
- (void)reloadDataSource
{
    [self refreshFooterView];
}
#pragma mark --群成员列表UI搭建
- (void)refreshScrollView
{
    [self.scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    BOOL showAddButton = NO;
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] isEqualToString: _groupInfoIpa.ipaUser_id]) {
        
        [self.scrollView addSubview:self.addButton];
        showAddButton = YES;
    }
    
    int tmp = ([self.dataSource count] + 1) % kColOfRow;
    int row = ([self.dataSource count] + 1) / kColOfRow;
    row += tmp == 0 ? 0 : 1;
    self.scrollView.tag = row;
    self.scrollView.frame = CGRectMake(10, 10, self.tableView.frame.size.width - 20, row * kContactSize+14);
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width, row * kContactSize);
    view.frame = CGRectMake(0, 0, ScreenWidth, self.scrollView.frame.size.height + 20);
    self.tableView.tableHeaderView = view;
    
    int i = 0;
    int j = 0;
    BOOL isEnd = NO;
    for (i = 0; i < row; i++) {
        for (j = 0; j < kColOfRow; j++) {
            NSInteger index = i * kColOfRow + j;
            NSLog(@"index = %d",index);
            if (index < [self.dataSource count]) {
                AddressIpa *info = [self.dataSource objectAtIndex:index];
                ChatGroupContactView *contactView = [[ChatGroupContactView alloc] initWithFrame:CGRectMake((ScreenWidth-20-4*kContactSize)/5.0+j * (kContactSize+(ScreenWidth-20-4*kContactSize)/5.0), i * kContactSize, kContactSize, kContactSize+14)];
                contactView.userInteractionEnabled = YES;
                UITapGestureRecognizer* singleRecognizer;
                singleRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleRecognizer:)];
                singleRecognizer.numberOfTapsRequired = 1; // 单击
                [contactView addGestureRecognizer:singleRecognizer];
                
                contactView.index = i * kColOfRow + j;
                [contactView.imageView sd_setImageWithURL:[NSURL URLWithString:info.ipaIco_file] placeholderImage:[UIImage imageNamed:@"touxiang124"]];
                contactView.remark = info.ipaName;
                contactView.deleteButton.tag = i*kColOfRow+j;
                contactView.tag = 100+i * kColOfRow + j;
                __weak typeof(self) weakSelf = self;
                [contactView setDeleteContact:^(NSInteger index) {
                    
                    AddressIpa *ipa = [weakSelf.dataSource objectAtIndex:index];
                    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] length]==0) {
                        
                    }
                    else if([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"]isEqualToString:ipa.ipaUser_id]){
                        [weakSelf showHint:@"您是群主,不能删除!" yOffset:300];
                    }
                    else{
                        [weakSelf showHudInView:weakSelf.view hint:@"正在删除成员..."];
                        NSDictionary *params  = @{@"group_id":self.targetId,@"member_id":ipa.ipaUser_id};
                        [MyDataService postPlatformContactCelgroupmember:params callback:^(id data) {
                            [weakSelf hideHud];
                            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                                if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
                                    [weakSelf.dataSource removeObjectAtIndex:index];
                                    [weakSelf refreshScrollView];
                                }
                            }
                        }];
                        
                    }
                    
                }];
                
                [self.scrollView addSubview:contactView];
            }
            else{
                if(showAddButton && index == self.dataSource.count)
                {
                    self.addButton.frame = CGRectMake(j * kContactSize + 9, i * kContactSize + 9, kContactSize - 18, kContactSize - 18);
                }
                
                isEnd = YES;
                break;
            }
        }
        
        if (isEnd) {
            break;
        }
    }
    
    //[self.tableView reloadData];
}

- (void)refreshFooterView
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"]isEqualToString:_groupInfoIpa.ipaUser_id]) {
        [_exitButton removeFromSuperview];
        [_footerView addSubview:self.dissolveButton];
    }
    else{
        [_dissolveButton removeFromSuperview];
        [_footerView addSubview:self.exitButton];
    }
}

#pragma mark - action

- (void)tapView:(UITapGestureRecognizer *)tap
{
    if (tap.state == UIGestureRecognizerStateEnded)
    {
        if (self.addButton.hidden) {
            [self setScrollViewEditing:NO];
        }
    }
}
//删除群成员
- (void)deleteContactBegin:(UILongPressGestureRecognizer *)longPress
{
    if (longPress.state == UIGestureRecognizerStateBegan)
    {
        BOOL isEdit = self.addButton.hidden ? NO : YES;
        [self setScrollViewEditing:isEdit];
    }
}
- (void)singleRecognizer:(UITapGestureRecognizer *)longPress
{
    AddressIpa *ipa;
    ipa = [self.dataSource objectAtIndex:(longPress.view.tag - 100)];
    //判断是不是自己  如果是自己 不能聊天
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"]isEqualToString:ipa.ipaUser_id]) {
        return;
    }
    FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
    friendInfoVC.user_id = ipa.ipaUser_id;
    [self.navigationController pushViewController:friendInfoVC animated:YES];
    
}
- (void)setScrollViewEditing:(BOOL)isEditing
{
    
    for (ChatGroupContactView *contactView in self.scrollView.subviews)
    {
        if ([contactView isKindOfClass:[ChatGroupContactView class]]) {
            AddressIpa *ipa;
            ipa = [self.dataSource objectAtIndex:(contactView.tag - 100)];
            if ([ipa.ipaUser_id isEqualToString:_groupInfoIpa.ipaUser_id]) {
                continue;
            }
            
            [contactView setEditing:isEditing];
        }
    }
    
    self.addButton.hidden = isEditing;
}

//解散群组
- (void)dissolveAction
{
    __weak typeof(self) weakSelf = self;
    [self showHudInView:self.view hint:@"解散群组"];
        NSDictionary *params = @{@"group_id": self.targetId};
        [MyDataService postPlatformContactOvergroup:params callback:^(id data) {
            if ([[data objectForKey: @"code"] isEqualToString: @"200"]||[[data objectForKey: @"code"] isEqualToString: @"201"]) {
                [weakSelf showHint:@"已经解散群组"];
                //[self.navigationController popToRootViewControllerAnimated:YES];
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshGroupList" object:nil];
                NSInteger vcs = [self.navigationController.viewControllers count]-3;
                
                UIViewController *VC = [self.navigationController.viewControllers objectAtIndex:vcs];
                [self.navigationController popToViewController:VC animated:YES];
            }
            else{
                [weakSelf showHint:@"解散群组失败"];
            }
            [weakSelf hideHud];
            
        }];//如果是群主
        //[[NSNotificationCenter defaultCenter] postNotificationName:@"ExitGroup" object:nil];
}

//退出群组
- (void)exitAction
{
    __weak typeof(self) weakSelf = self;
    [self showHudInView:self.view hint:@"退出群组"];
        NSDictionary *params = @{@"group_id": self.targetId};
        [MyDataService  postPlatformContactLeavegroup:params callback:^(id data) {
            if ([[data objectForKey: @"code"] isEqualToString: @"200"]||[[data objectForKey: @"code"] isEqualToString: @"201"]) {
                [weakSelf showHint:@"已经退出群组"];
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshGroupList" object:nil];
                NSInteger vcs = [self.navigationController.viewControllers count]-3;
                UIViewController *VC = [self.navigationController.viewControllers objectAtIndex:vcs];
                [self.navigationController popToViewController:VC animated:YES];
            }
            else{
                [weakSelf showHint:@"退出群组失败"];
            }
            [weakSelf hideHud];
        }];//如果不是群主
        
        //[[NSNotificationCenter defaultCenter] postNotificationName:@"ExitGroup" object:nil];
    
}


@end
