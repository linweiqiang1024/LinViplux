//
//  DemoPreviewViewController.m
//  iOS-IMKit-demo
//
//  Created by xugang on 14-9-18.
//  Copyright (c) 2014年 Heq.Shinoda. All rights reserved.
//

#import "DemoPreviewViewController.h"

@implementation DemoPreviewViewController
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault];
}
#pragma mark 导航
- (void)customNav{
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = @"图片查看";
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleView;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    [leftButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
    right.frame = CGRectMake(0, 0, 44, 44);
    [right setImageEdgeInsets:UIEdgeInsetsMake(0, 20, 0, 0)];
    [right addTarget:self action:@selector(rightBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    [right setTitle:@"保存" forState:UIControlStateNormal];
    [right setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]initWithCustomView:right];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;
    
}
- (void)viewDidLoad{
    [super viewDidLoad];
    [self customNav];
}
@end
