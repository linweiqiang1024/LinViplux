//
//  Header.h
//  会议邦
//
//  Created by 赵中杰 on 14-7-11.
//  Copyright (c) 2014年 赵中杰. All rights reserved.
//
#import "CustomLabel.h"

//系统是否为iOS7以上
#define IS_IOS_7                            [[[UIDevice currentDevice]systemVersion]floatValue] >= 7.0? YES:NO

//CGRectmake(a,b,c,d)
#define FRAME(a,b,c,d)                      CGRectMake(a,b,c,d)


//颜色
#define COLOR_VAULE(vaule)                  [UIColor colorWithRed:vaule/255.0 green:vaule/255.0 blue:vaule/255.0 alpha:1.0]

//颜色
#define COLOR_VAULES(r,g,b,a)               [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

//导航颜色57 128 249
#define NAV_COLOR                           [UIColor colorWithRed:57.0/255.0 green:128.0/255.0 blue:249.0/255.0 alpha:1.0]

//字体//Heiti SC Thin  NimbusSanNovDSemBolCon
#define WORLD_FONT(a)                       [UIFont fontWithName:@"Arial" size:a]

//透明颜色
#define defaultColor                        [UIColor clearColor]

//imagename
#define IMAGENAMED(a)                        [UIImage imageNamed:a]

//  导航高度
#define _NAV_HEIGHT self.navheight + 44

#if TARGET_IPHONE_SIMULATOR
#define SIMULATOR 1
#elif TARGET_OS_IPHONE
#define SIMULATOR 0
#endif
