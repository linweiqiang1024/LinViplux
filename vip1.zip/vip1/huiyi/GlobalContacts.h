//
//  GlobalContacts.h
//  Yingco
//
//  Created by super on 13-9-17.
//  Copyright (c) 2013年 Slemon. All rights reserved.
//

#import "UIViewExt.h"
#import "LoadView.h"
#import "Dialog.h"
#import "MHShortCut.h"
#import "UIImage+Settings.h"

//#define debug
#ifdef DEBUG
//====================测试环境====================
#define NSLog(fmt, ...) NSLog((@"\n[文件名:%@]\n" "[函数名:%s]\n" "[行号:%d] \n" fmt), [@__FILE__ lastPathComponent], __FUNCTION__, __LINE__, ##__VA_ARGS__)

#define Base_URL                @"http://a2.huiyiabc.net/"
#define Base_CODE               @"http://a2.huiyiabc.net/"
#define Base_COMPANY_ADDR       @"v2.huiyiabc.net"
#define RONGCLOUD_IM_APPKEY     @"p5tvi9dst2m64"
//====================测试环境====================
#else
//====================正式环境====================
#define NSLog(...) do {} while (0)

#define Base_URL                @"https://a2.huiyiabc.com/"
#define Base_CODE               @"http://a2.huiyiabc.com/"
#define Base_COMPANY_ADDR       @"v2.huiyiabc.com"
#define RONGCLOUD_IM_APPKEY     @"n19jmcy59fli9"
//====================正式环境====================
#endif

#define COMPANY_ADDR  [[NSUserDefaults standardUserDefaults] objectForKey:@"companyAddr"]

//加载图片
#define PNGIMAGE(NAME)  [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(NAME) ofType:@"png"]]
#define JPGIMAGE(NAME)  [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(NAME) ofType:@"jpg"]]
#define IMAGE(NAME,EXT) [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(NAME) ofType:(EXT)]]

#define AppID          @"wx66a432fa42aa6daf"
#define AppSecret      @"6c18713e9667db0fe5d29512735146ab"

#define ShareSDK_APPID @"687ad111d180"

#define SINA_APPKEY    @"2182636822"
#define SINA_AppSecret @"9bf33a54240245092e2d2d73da8ceba3"
#define Ten_APPID      @"1103608817"
#define Ten_APPKEY     @"GvW0yqHNm8twOFec"

#define Main_Delegate (AppDelegate *)[[UIApplication sharedApplication] delegate]

/**
 *  -------------  内存设置  -------------
 */
#define kSafeRelease(object) [object release], object = nil

/**
 * -------------- 系统版本  --------------
 */
#define kSysVersion [[UIDevice currentDevice].systemVersion floatValue]

//*--------------Fram----------------------
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScreenWidth [UIScreen  mainScreen].bounds.size.width
#define kTabBarHeight           55
#define kStatusHeight           20
#define kNavgationHeight        44
#define kNavgationWidth         30
#define kNavgationTitleSize     18
#define kKeyboardHeight         216
#define kKeyboardChineseHeight  252

//#define CGRectMake(x,y,w,h) CGRectMake(x/(iphone6Plus?1.5:1),(iphone6Plus?1.5:1),(iphone6Plus?1.5:1),(iphone6Plus?1.5:1))

//定义颜色
#define kColor(r, g, b, a)  [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define RGBCOLOR(r,g,b)     [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]

//导航的背景颜色
#define SYETEMBACKGROUDCOLOR [UIColor colorWithHexString:@"#17b4eb"]


#define  SJDic(dic,nav,title,normal,selected);\
NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:\
title,kTitle,\
nav,KNaivaController,\
normal,kNormalFileKey,\
selected,kSelectedFielKey,\
nil];


#define kLog @""

#define AFHTTPCLIENTSHARE @"afHC"
#define APIURL @"api_url"
#define IMAGEURL @"image_url"
#define BaiduMap_APP_KEY @"MhkDt1pgMyO05oA3Hywxf9tH"

#define GLOBALIMAGE @"huiyiabc/Image/"

#define KEY_WINDOW  [[UIApplication sharedApplication]keyWindow]

#pragma mark - 是否为ios5,6,7-----------------------------------------------------------
#define IOS5 (([[UIDevice currentDevice].systemVersion doubleValue] < 6.0f)?YES:NO)
#define IOS6 (([[UIDevice currentDevice].systemVersion doubleValue] >= 6.0f&&[[UIDevice currentDevice].systemVersion doubleValue] < 7.0f)?YES:NO)
#define IOS7 (([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0f)?YES:NO)
#define IOS8 (([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0f)?YES:NO)

#define SET_NAV_HEIGHT if([[UIDevice currentDevice].systemVersion doubleValue] >= 7.0f)self.edgesForExtendedLayout = UIRectEdgeNone

#pragma mark - 是否为iphone5---------------------------------------------------------
#define iPhone4 ([UIScreen mainScreen].bounds.size.height==480 ? YES : NO)
#define iPhone5 ([UIScreen mainScreen].bounds.size.height==568 ? YES : NO)
#define iPhone6 ([UIScreen mainScreen].bounds.size.height==667 ? YES : NO)
#define iphone6Plus ([UIScreen mainScreen].bounds.size.height==736 ? YES : NO)

#pragma mark - 硬件高度和宽度
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth  [UIScreen mainScreen].bounds.size.width

#define StatusBarHeight 20.f
#define NavBarHeight    44.0f
#define TabBarHeight    49.0f

#define UIColorFromRGB(r,g,b)         [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
#define RGBACOLOR(r,g,b,a)  [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

/*背景颜色*/
#define BackGround16Color(OBJ,ColorStr);\
OBJ.backgroundColor = [UIColor colorWithHexString:ColorStr];

/*背景颜色*/
#define BackGroundColor(OBJ,Color);\
OBJ.backgroundColor = [UIColor Color];

#define kTablViewBackGroudColor     [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:239/255.0 alpha:1]
#define kControllerBackGroudColor   [UIColor colorWithRed:28.0/255.0 green:28.0/255.0 blue:28/255.0 alpha:1]

//字体颜色16位色值
#define TextColor(OBJ,ColorStr);\
OBJ.textColor = [UIColor colorWithHexString:ColorStr];

#define myTextColor(OBJ,Color);\
OBJ.textColor = [UIColor Color];

#define LINE_COLOR          [UIColor colorWithRed:221.0/255.0 green:221.0/255.0 blue:220.0/255.0 alpha:1.0]
#define BACKGRUNOD_COLOR    [UIColor colorWithRed:247.0/255.0 green:247.0/255.0 blue:248.0/255.0 alpha:1.0]

#define CGRM_InNav(x, y, w, h)      \
[[FitCGRect sharedInstance] fitCGRectInNavBy:(x+0.f) and:(y+0.f) and:(w+0.f) and:(h+0.f)]

#define CGRM_(x, y, w, h)           \
[[FitCGRect sharedInstance] fitCGRectBy:(x+0.f) and:(y+0.f) and:(w+0.f) and:(h+0.f)]

#define kTelType                 @"tel"
#define kSinaType                @"sina_uid"
#define kTencentType             @"tencent_uid"
#define kErrorCode               @"code"
#define kErrorMessage            @"error"

#define KTimeInterval            10
#define kNavigationBarHeight     44

#define kStatubarAndNavBarHeight 64

#define kTencentOAuthData        @"TencentOAuthData"
#define kSinaWeiboAuthData       @"SinaWeiboAuthData"

#define kAuthCode                @"code"
#define kExpiresTime             @"expires_time"
#define kUserInfo                @"userInfo"
#define kFeedInfo                @"feed"

#define kIslogin                 @"isLogin"
#define kHeadImage               @"headImg"
#define kBackImage               @"backImg"
#define kNoNetWork               @"KNONetWork"
#define kTencentSwitch           @"kTencentSwitch"
#define kSinaSwitch              @"kSinaSwitch"
#define kDeviceToken             @"kDeviceToken"

#define kUpdateHeadImg           @"TimeLineheadImg"
#define kUpdateBackImg           @"TimeLinebackImg"

#define kIsLocalSave             @"isLocalSave"
#define kIsUpdateInWifi          @"isUpdateInWifi"

#define kNoticeShareActionSheet  @"UPLOAD_VEDIO_SUCCESS"

#define NSStringFromInt(intValue) [NSString stringWithFormat:@"%d",intValue]

//随机数
#define ARC4RANDOM_MAX 0x100000000

#define OBJ_NAME(obj) [NSString stringWithUTF8String:object_getClassName(obj)]

//适配
//#define IS_IPHONE ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
//#define IS_IPHONE5 ([[UIScreen mainScreen] bounds].size.height == 568)
//#define IS_RETINA ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)
#define IS_IPHONESIZE [[UIScreen mainScreen] bounds].size
#define IS_IOS7       [[UIDevice currentDevice].systemVersion floatValue] >= 7.0

//字体
#define MYFONT(SIZE)    [UIFont fontWithName:@"FZJZJW--GB1-0" size:SIZE]//Didot-Bold Noteworthy-Bold Cocbin-boldItalic
#define YHUI(SIZE)      [UIFont fontWithName:@"HelveticaNeue" size:SIZE]//Didot-Bold Noteworthy-Bold Cocbin-boldItalic MicrosoftYaHei
#define YHUI_BOLD(SIZE) [UIFont fontWithName:@"HelveticaNeue-Bold" size:SIZE]
//#define PIXELToFontSize(PIXEL)

#define kUID           @"uid"

#define kPopupOfRemark 1
#define kPopupOfName   2

//聊天中的图片缩放比例
#define Image_Width    120.0
#define Image_Height   120.0

#define kMQTTServerHost @"112.126.65.236" //服务器地址
#define kTopic [NSString stringWithFormat:@"huiyibang/u/%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]] //个人聊天接收topic
#define GTopic(group_id) [NSString stringWithFormat:@"huiyibang/g/%@",group_id]
#define MYUSERID [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]

#define clientPort 1883 //端口号
