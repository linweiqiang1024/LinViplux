//
//  CheckFileVC.h
//  huiyi
//
//  Created by qstx2 on 14-7-7.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CheckFileVC : UIViewController

@end
