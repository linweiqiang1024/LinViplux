//
//  CheckFileListVC.h
//  huiyi
//
//  Created by qstx2 on 14-7-7.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuickLook/QuickLook.h>
@interface CheckFileListVC : UIViewController<UITableViewDataSource,UITableViewDelegate,QLPreviewControllerDataSource,QLPreviewControllerDelegate,UIDocumentInteractionControllerDelegate>


@end
