//
//  CheckFileListVC.m
//  huiyi
//
//  Created by qstx2 on 14-7-7.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "CheckFileListVC.h"

@interface CheckFileListVC ()
{
	 UITableView *readTable;
}

@property(nonatomic,strong)NSMutableArray *dirArray;
@property (nonatomic, strong) UIDocumentInteractionController *docInteractionController;
@end

@implementation CheckFileListVC


- (void)setupDocumentControllerWithURL:(NSURL *)url
{
    if (self.docInteractionController == nil)
    {
        self.docInteractionController = [UIDocumentInteractionController interactionControllerWithURL:url];
        self.docInteractionController.delegate = self;
    }
    else
    {
        self.docInteractionController.URL = url;
    }
}
//适配导航栏方法
- (void) customizeAboveToolbar
{
    UILabel * titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.font = [UIFont boldSystemFontOfSize:kNavgationTitleSize];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = @"资料下载";
    [titleLabel sizeToFit];
    titleLabel.textColor = [UIColor colorWithHexString:@"#ffffff"];
    self.navigationItem.titleView = titleLabel;
    
//    if (IOS7) {
//        [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"huiyi_toolbar_bg.png"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
//    }
//    else
//    {
//        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"huiyi_toolbar_bg.png"] forBarMetrics:UIBarMetricsDefault];
//    }
    //左边的按钮
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 33, 20);
    if (IOS7) {
        leftBtn.imageEdgeInsets = UIEdgeInsetsMake((30-20.5)/2, -18, 0, 0);
    }
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
    leftBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    
    UIBarButtonItem *leftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    self.navigationItem.leftBarButtonItem = leftBtnItem;
    
}
//导航返回
- (void)backClick{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    SET_NAV_HEIGHT;
    [self customizeAboveToolbar];
    //保存一张图片到设备document文件夹中 - by code4app小编
    UIImage *image = [UIImage imageNamed:@"loading.png"];
    NSData *jpgData = UIImageJPEGRepresentation(image,0.8);
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0]; //Get the docs directory
    NSString *filePath = [documentsPath stringByAppendingPathComponent:@"download/loading.png"]; //Add the file name
    [jpgData writeToFile:filePath atomically:YES]; //Write the file
    
    //保存一份txt文件到设备document文件夹中 - by code4app小编
    char *saves = "Code4App";
    NSData *data = [[NSData alloc] initWithBytes:saves length:8];
    filePath = [documentsPath stringByAppendingPathComponent:@"code4app.txt"];
    [data writeToFile:filePath atomically:YES];
    
    
	NSFileManager *fileManager = [NSFileManager defaultManager];
	//在这里获取应用程序Documents文件夹里的文件及文件夹列表
	NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentDir = [documentPaths objectAtIndex:0];
    NSString *downloadDir = [NSString stringWithFormat:@"%@/%@",documentDir,@"download"];
    NSLog(@"documentDir = %@",documentDir);
	NSError *error = nil;
	NSArray *fileList = [[NSArray alloc] init];
	//fileList便是包含有该文件夹下所有文件的文件名及文件夹名的数组
	fileList = [fileManager contentsOfDirectoryAtPath:downloadDir error:&error];
	
	//    以下这段代码则可以列出给定一个文件夹里的所有子文件夹名
	//	NSLog(@"------------------------%@",fileList);
	self.dirArray = [[NSMutableArray alloc] init];
	for (NSString *file in fileList)
	{
		[self.dirArray addObject:file];
	}
    NSLog(@"Every Thing in the dir:%@",fileList);
	
	readTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, ScreenHeight-64) style:UITableViewStyleGrouped];
    readTable.delegate = self;
    readTable.dataSource = self;
    [self.view addSubview:readTable];
	
	[readTable reloadData];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)handleLongPress:(UILongPressGestureRecognizer *)longPressGesture
{
    if (longPressGesture.state == UIGestureRecognizerStateBegan)
    {
        NSIndexPath *cellIndexPath = [readTable indexPathForRowAtPoint:[longPressGesture locationInView:readTable]];
		
		NSURL *fileURL;
		if (cellIndexPath.section == 0)
        {
            // for section 0, we preview the docs built into our app
            fileURL = [self.dirArray objectAtIndex:cellIndexPath.row];
		}
        else
        {
            // for secton 1, we preview the docs found in the Documents folder
            fileURL = [self.dirArray objectAtIndex:cellIndexPath.row];
		}
        self.docInteractionController.URL = fileURL;
		
		[self.docInteractionController presentOptionsMenuFromRect:longPressGesture.view.frame
                                                           inView:longPressGesture.view
                                                         animated:YES];
    }
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellName = @"CellName";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellName];
	if (cell == nil)
	{
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellName];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	}
	
	NSURL *fileURL= nil;
	NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentDir = [documentPaths objectAtIndex:0];
	NSString *path = [documentDir stringByAppendingPathComponent:[self.dirArray objectAtIndex:indexPath.row]];
	fileURL = [NSURL fileURLWithPath:path];
	
	[self setupDocumentControllerWithURL:fileURL];
	cell.textLabel.text = [self.dirArray objectAtIndex:indexPath.row];
	NSInteger iconCount = [self.docInteractionController.icons count];
    if (iconCount > 0)
    {
        cell.imageView.image = [self.docInteractionController.icons objectAtIndex:iconCount - 1];
    }
    
    NSString *fileURLString = [self.docInteractionController.URL path];
    NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:fileURLString error:nil];
    NSInteger fileSize = [[fileAttributes objectForKey:NSFileSize] intValue];
    NSString *fileSizeStr = [NSByteCountFormatter stringFromByteCount:fileSize
                                                           countStyle:NSByteCountFormatterCountStyleFile];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ - %@", fileSizeStr, self.docInteractionController.UTI];
	UILongPressGestureRecognizer *longPressGesture =
	[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
    [cell.imageView addGestureRecognizer:longPressGesture];
    cell.imageView.userInteractionEnabled = YES;    // this is by default NO, so we need to turn it on
    
	return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [self.dirArray count];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	QLPreviewController *previewController = [[QLPreviewController alloc] init];
    previewController.dataSource = self;
    previewController.delegate = self;
    
    // start previewing the document at the current section index
    previewController.currentPreviewItemIndex = 1;
    [[self navigationController] pushViewController:previewController animated:YES];
    //	[self presentViewController:previewController animated:YES completion:nil];
}



#pragma mark - UIDocumentInteractionControllerDelegate

- (NSString *)applicationDocumentsDirectory
{
	return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
}

- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)interactionController
{
    return self;
}


#pragma mark - QLPreviewControllerDataSource

// Returns the number of items that the preview controller should preview
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)previewController
{
    //    NSInteger numToPreview = 0;
    //
    //	numToPreview = [self.dirArray count];
    //
    //    return numToPreview;
	return 1;
}

- (void)previewControllerDidDismiss:(QLPreviewController *)controller
{
    // if the preview dismissed (done button touched), use this method to post-process previews
}

// returns the item that the preview controller should preview
- (id)previewController:(QLPreviewController *)previewController previewItemAtIndex:(NSInteger)idx
{
	//[previewController.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"click.png"] forBarMetrics:UIBarMetricsDefault];
    
    NSURL *fileURL = nil;
   // NSIndexPath *selectedIndexPath = [readTable indexPathForSelectedRow];
	NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentDir = [documentPaths objectAtIndex:0];
	NSString *path = [documentDir stringByAppendingPathComponent:[self.dirArray objectAtIndex:0]];
	fileURL = [NSURL fileURLWithPath:path];
    return fileURL;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
