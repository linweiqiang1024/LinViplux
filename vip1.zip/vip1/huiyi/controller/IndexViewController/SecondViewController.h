//
//  SecondViewController.h
//  会议广场
//
//  Created by songhongshuai on 15/5/12.
//  Copyright (c) 2015年 songhongshuai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface SecondViewController : FatherViewController

@end
