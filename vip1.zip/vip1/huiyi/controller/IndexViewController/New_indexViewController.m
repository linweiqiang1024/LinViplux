//
//  New_indexViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/3/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "New_indexViewController.h"
#import "RegistInfoViewController.h"
#import "ContactsViewController.h"
#import "NotificationCenterHeader.h"
#import "FirstPageControl.h"
#import "IndexEndView.h"
#import "IndexMidView.h"
#import "UIGridView.h"
#import "MYWebImage.h"
#import "Utils.h"
#import "New_IndexCell.h"
#import "OpenLoginTool.h"
#import "QRCodeReaderViewController.h"
#import "UIGridViewDelegate.h"
#import "SHSIndexModel.h"
#import "UIImageView+WebCache.h"
#import "MeetTypeViewController.h"
#import "IndexViewController.h"
#import "ChatListViewController.h"
#import "New_RecommendViewController.h"
#import "New_MyPublishViewController.h"
#import "New_myCellectViewController.h"
#import "New_SignUpInfoViewController.h" //详情页面
#import "MyInfoViewController.h" //我的界面
#import "LoginViewController.h"
#import <RongIMKit/RCIM.h>
#import <RongIMLib/RongIMLib.h>
#import <ShareSDK/ShareSDK.h>
#import "RCDataBaseManager.h"
#import "RCDRCIMDataSource.h"
#import "RCChatInfoManager.h"
#import "UserInfoIpa.h"
#import "AppUtil.h"
#import "FMDBManagers.h"

//四种类型的通知消息
#import "AddressIpa.h"
#import "skipManagerTool.h"
#import "SDWebImageManager.h"
#import "SDImageCache.h"
#import "New_MeetTypeViewController.h"

@interface New_indexViewController () <UITableViewDataSource,UITableViewDelegate,UIIndexEndViewDelegate,UIMidViewDelegate,UIScrollViewDelegate,UIAlertViewDelegate,QRCodeReaderDelegate,RCIMReceiveMessageDelegate,RCIMConnectionStatusDelegate>
{
    CGFloat headViewHeight;
    CGFloat midViewHeight;
    CGFloat endViewHeight;
    CGFloat pageControlY;
    CGFloat new_Nav_height;
    
    UIButton    * mesLB;
    UIImageView * _bgView;
    NSArray     * _btnClickedImages;
    
    //用户名称
    UserInfoIpa    * _ipa;
    NSMutableArray * indexMeetingList;
    NSString       * adUrl;
    BOOL isScaned;
}
@property (nonatomic,strong) UIView           *headView;
@property (nonatomic,strong) IndexMidView     *midView;
@property (nonatomic,strong) IndexEndView     *endView;
@property (nonatomic,strong) UITableView      *gridview;
@property (nonatomic,strong) FirstPageControl *pageControl;
@property (nonatomic,strong) UILabel          *titleView; //导航栏的标题
@property (nonatomic,strong) UIImageView      *companyIcon;
@end

@implementation New_indexViewController

- (void)createNav
{
    self.leftnavbtn.hidden = YES;
    
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [rightbtn setFrame:CGRectMake(ScreenWidth-59, _navheight, 44 , 44)];
    [rightbtn setImage:[UIImage imageNamed:@"index_03"] forState:UIControlStateNormal];
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightbtn];
    
    mesLB = [UIButton buttonWithType:UIButtonTypeCustom];
    [mesLB setFrame:CGRectMake(ScreenWidth-34, _navheight, 22, 22)];
    [mesLB setHidden:NO];
    [mesLB setBackgroundColor:[UIColor colorWithRed:240/255.0 green:31/255.0 blue:44/255.0 alpha:1.0]];
    [mesLB setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [mesLB.layer setBorderWidth:1.5];
    [mesLB.layer setBorderColor:[[UIColor whiteColor] CGColor]];
    [mesLB.layer setCornerRadius:CGRectGetHeight([mesLB bounds]) / 2];
    [mesLB.layer setMasksToBounds:YES];
    [mesLB.titleLabel setFont:[UIFont systemFontOfSize:10]];
    [mesLB.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [mesLB addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:mesLB];
    
    //[mesLB setBackgroundImage: [UIImage imageNamed:@"index_20"] forState:UIControlStateNormal];
}

- (void)rightBtnClicked
{
    /*
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        [self popToLoginView];
        return;
    }*/
    MyInfoViewController *newMyVC = [[MyInfoViewController alloc]init];
    [self.navigationController pushViewController:newMyVC animated:YES];
}

#pragma mark 生命周期函数
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"New_indexViewController"];
    [self.navigationController setNavigationBarHidden:YES];
    [self loadDB];
    
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        loginVc.isPush = YES;
        [self presentViewController:nav animated:NO completion:nil];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"New_indexViewController"];
}

- (void)changeCompanyIcon
{
    /*
    //企业简称
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"company_name"] length] != 0) {
        self.titlelabel.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"company_name"];
    }
    else {
        self.titlelabel.text = @"会议邦";
    }
    
    //企业logo
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"company_icon"] length] != 0) {
     
        //NSLog(@"%@",[[SDWebImageManager sharedManager] cacheKeyForURL:[NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:@"company_icon"]]]);
        //SDWebImageManager *manager = [SDWebImageManager sharedManager];
        //NSURL *imageURL = [NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:@"company_icon"]];
        //[manager downloadImageWithURL:imageURL options:0 progress:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {}];
        [self.companyIcon sd_setImageWithURL:[NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:@"company_icon"]] placeholderImage:[UIImage imageNamed:@"defulteIcon"]];
    }
    else {
        self.companyIcon.image = [UIImage imageNamed:@"Icon"];
    }*/
    
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        self.companyIcon.image = [UIImage imageNamed:@"Icon"];
        self.titlelabel.text = @"会议邦";
    }
    else
    {
        NSMutableArray * datas = [NSMutableArray arrayWithArray:LoginCompanyArray];
        NSDictionary * model = [datas lastObject];
        NSString * logoUrl = [model objectForKey:@"logo_url"];
        NSString * companyName = [model objectForKey:@"name"];
        NSString * companyCode = [model objectForKey:@"code"];
        NSString * companyBgUrl = [model objectForKey:@"bg_url"];
        [self.companyIcon sd_setImageWithURL:[NSURL URLWithString:logoUrl] placeholderImage:[UIImage imageNamed:@"defulteIcon"]];
        self.titlelabel.text = companyName;
        adUrl = companyBgUrl;
        if ([companyCode isEqualToString:@"huiyiabc"])
        {
            adUrl = @"";
        }
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeCompanyIcon) name:IndexViewChangeCompanyIconKey object:nil];
    
    if (![DBManager reachInternet]) {
        [[Dialog Instance] hideProgress];
        [[Dialog Instance] alert:@"没有可以连接的网络"];
    }
    
    /*
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"auth_session"] length] == 0) {
        self.companyIcon.image = [UIImage imageNamed:@"Icon"];
        self.titlelabel.text = @"会议邦";
    }
    else {
        //企业简称
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"company_name"] length] != 0) {
            self.titlelabel.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"company_name"];
        }
        else {
            self.titlelabel.text = @"会议邦";
        }
        //企业logo
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"company_icon"] length] != 0) {
            [self.companyIcon sd_setImageWithURL:[NSURL URLWithString:[[NSUserDefaults standardUserDefaults] objectForKey:@"company_icon"]] placeholderImage:[UIImage imageNamed:@"defulteIcon"]];
        }
        else {
            self.companyIcon.image = [UIImage imageNamed:@"Icon"];
        }
    }*/
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        self.companyIcon.image = [UIImage imageNamed:@"Icon"];
        self.titlelabel.text = @"会议邦";
    }
    else
    {
        NSMutableArray * datas = [NSMutableArray arrayWithArray:LoginCompanyArray];
        NSDictionary * model = [datas lastObject];
        NSString * logoUrl = [model objectForKey:@"logo_url"];
        NSString * companyName = [model objectForKey:@"name"];
        NSString * companyCode = [model objectForKey:@"code"];
        NSString * companyBgUrl = [model objectForKey:@"bg_url"];
        [self.companyIcon sd_setImageWithURL:[NSURL URLWithString:logoUrl] placeholderImage:[UIImage imageNamed:@"defulteIcon"]];
        self.titlelabel.text = companyName;
        adUrl = companyBgUrl;
        if ([companyCode isEqualToString:@"huiyiabc"])
        {
            adUrl = @"";
        }
    }
    
    indexMeetingList = [[NSMutableArray alloc]initWithCapacity:0];
    
    if (ScreenHeight <= 568) {
        endViewHeight = 160;
        midViewHeight = 60;
        new_Nav_height = 64;
    }
    else {
        endViewHeight = (ScreenWidth/320)*160;
        midViewHeight = (ScreenWidth/320)*60;
        new_Nav_height = 64;
    }
    self.navBGView.height = new_Nav_height;
    headViewHeight = ScreenHeight-self.navBGView.height-endViewHeight-midViewHeight;
    pageControlY   = self.navBGView.height+headViewHeight-20;
    
    [self createNav];
    
    [self.navBGView addSubview:self.companyIcon];
    
    [self.titlelabel setFont:YHUI_BOLD(25)];
    
    UILabel *lineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, self.navBGView.height-1, ScreenWidth, 1)];
    lineLB.alpha = 0.5;
    lineLB.backgroundColor = [UIColor colorWithHexString:@"#ddf3fa"];
    [self.navBGView addSubview:lineLB];
    
    self.headView = [[UIView alloc]initWithFrame:CGRectMake(0, self.navBGView.height, ScreenWidth, ScreenHeight-self.navBGView.height-endViewHeight-midViewHeight)];
    self.headView.backgroundColor = [UIColor colorWithHexString:@"#17b4eb"];
    
    [self.headView addSubview:self.gridview];
    
    [self.view addSubview:self.headView];
    [self.view addSubview:self.midView];
    [self.view addSubview:self.endView];
    [self.view addSubview:self.pageControl];
    
    [self createMainOperation];
}

- (void)createMainOperation
{
    //刷新 好友列表
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(notificationShowMeetingDetail:) name:IndexViewToDetailsKey object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(refrashFriendList) name:@"refrashFriendList" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getGruopData) name:@"refreashGetGruopData" object:nil];
    
    //好友变化的通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setupUntreatedApplyCount) name:@"checkFriendNumber" object:nil];
    
    //登录状态发生变化
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loginChange) name:@"loginChange" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(hideCountIcon) name:@"hideCountIcon" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applyMyMeetingCount) name:@"applyMyMeetingCount" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(applyTotalCount) name:@"applyTotalCount" object:nil];
    
    [self applyMyMeetingCount:NO];//如果是推送成功要调用一下该方法
    
    _ipa = [[UserInfoIpa alloc]init];
    
    //if 使tabBarController中管理的viewControllers都符合 UIRectEdgeNone
    if ([UIDevice currentDevice].systemVersion.floatValue >= 7) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    self.navigationItem.titleView = self.titleView;
    
    //获取点击登录界面的返回按钮
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loginDissmiss) name:@"loginDismiss" object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setupUnreadMessageCount) name:@"setupUnreadMessageCount" object:nil];
    
    [self hideCountIcon];
    [self setupUntreatedApplyCount];
    
    [RCIM sharedRCIM].connectionStatusDelegate = self;
    [RCIM sharedRCIM].receiveMessageDelegate = self;
    
    self.midView.creatNum = @"0场";
    self.midView.joinNum = @"0场";
    self.midView.storeNum = @"0场";
}

- (UIImageView *)companyIcon
{
    if (!_companyIcon) {
        CGFloat _YSpace,_iconHeight;
        if ([UIScreen mainScreen].bounds.size.height <= 568) {
            _iconHeight = 30;
        }
        else {
            _iconHeight = 30;
        }
        _YSpace = _navheight + (44-_iconHeight)/2;
        _companyIcon = [[UIImageView alloc]initWithFrame:CGRectMake(15, _YSpace, _iconHeight, _iconHeight)];
        _companyIcon.contentMode = UIViewContentModeScaleAspectFill;
        _companyIcon.backgroundColor = [UIColor clearColor];
        _companyIcon.layer.cornerRadius = 4;
        _companyIcon.clipsToBounds = YES;
    }
    return _companyIcon;
}

- (UILabel *)titleView
{
    if (!_titleView) {
        _titleView = [[UILabel alloc]init];
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.font = [UIFont boldSystemFontOfSize:18];
        _titleView.textColor = [UIColor whiteColor];
        _titleView.frame = CGRectMake(50, 0, ScreenWidth-100, 44);
        _titleView.textAlignment = NSTextAlignmentCenter;
    }
    return _titleView;
}

- (FirstPageControl *)pageControl
{
    if (!_pageControl) {
        _pageControl = [[FirstPageControl alloc]initWithFrame:CGRectMake((ScreenWidth)/4.0f, pageControlY, ScreenWidth/2, 20)];
        _pageControl.dotColorCurrentPage = [UIColor whiteColor];
        _pageControl.dotColorOtherPage = [UIColor colorWithHexString:@"#e6e6e6"];
        _pageControl.numberOfPages = 2;
        _pageControl.currentPage = 0;
    }
    return _pageControl;
}

- (UITableView *)gridview
{
    if (!_gridview) {
        _gridview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, headViewHeight)];
        _gridview.rowHeight = headViewHeight;
        _gridview.transform = CGAffineTransformMakeRotation(-M_PI /2);
        _gridview.frame = CGRectMake(0, 0, ScreenWidth, headViewHeight);
        _gridview.pagingEnabled = YES;
        _gridview.dataSource = self;
        _gridview.delegate = self;
        //gridview.backgroundColor = [UIColor colorWithHexString:@"#17b4eb"];
        _gridview.backgroundColor = [UIColor clearColor];
        _gridview.showsHorizontalScrollIndicator = NO;
        _gridview.showsVerticalScrollIndicator = NO;
        _gridview.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _gridview;
}

- (IndexEndView *)endView
{
    if (!_endView) {
        _endView = [[IndexEndView alloc]initWithFrame:CGRectMake(0, ScreenHeight-endViewHeight, ScreenWidth, endViewHeight)];
        _endView.delegate = self;
    }
    return _endView;
}

- (IndexMidView *)midView
{
    if (!_midView) {
        _midView = [[IndexMidView alloc]initWithFrame:CGRectMake(0, ScreenHeight-endViewHeight-midViewHeight, ScreenWidth, midViewHeight)];
        _midView.delegate = self;
    }
    return _midView;
}

/**
 *  距离某个时间多少天
 *
 *  @param theDate 接口返回的时间戳
 *
 *  @return 时间戳距离现在的天数
 */
- (NSString *)intervalSinceNow: (NSString *) theDate
{
    NSString *timeString = @"";
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *fromdate = [format dateFromString:theDate];
    NSTimeZone *fromzone = [NSTimeZone systemTimeZone];
    NSInteger frominterval = [fromzone secondsFromGMTForDate: fromdate];
    NSDate *fromDate = [fromdate  dateByAddingTimeInterval: frominterval];
    
    //获取当前时间
    NSDate *adate = [NSDate date];
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: adate];
    NSDate *localeDate = [adate  dateByAddingTimeInterval: interval];
    
    double intervalTime = [fromDate timeIntervalSinceReferenceDate] - [localeDate timeIntervalSinceReferenceDate];
    long lTime = labs((long)intervalTime);
    NSInteger iDays = lTime/60/60/24;
    timeString = [NSString stringWithFormat:@"%ld",(long)iDays];
    return timeString;
}

- (NSString*)weekDayStr:(NSString *)format
{
    NSString *weekDayStr = nil;
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    
    NSDate *now;
    
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    
    NSDateFormatter *formats=[[NSDateFormatter alloc] init];
    [formats setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *fromdate=[formats dateFromString:format];
    NSTimeZone *fromzone = [NSTimeZone systemTimeZone];
    NSInteger frominterval = [fromzone secondsFromGMTForDate: fromdate];
    now = [fromdate  dateByAddingTimeInterval: frominterval];
    comps = [calendar components:unitFlags fromDate:now];
    int week = [comps weekday];
    //week ++;
    switch (week) {
        case 1:
            weekDayStr = @"星期日";
            break;
        case 2:
            weekDayStr = @"星期一";
            break;
        case 3:
            weekDayStr = @"星期二";
            break;
        case 4:
            weekDayStr = @"星期三";
            break;
        case 5:
            weekDayStr = @"星期四";
            break;
        case 6:
            weekDayStr = @"星期五";
            break;
        case 7:
            weekDayStr = @"星期六";
            break;
        default:
            weekDayStr = @"";
            break;
    }
    return weekDayStr;
}

- (NSString *)string:(NSString *)string
{
    if (string.length == 0 || [string isEqualToString:@""] || string == nil) {
        return @"0";
    }
    else {
        return string;
    }
}

- (void)loadDB
{
    __weak typeof(self) weakSelf = self;

    NSString *topList = [NSString stringWithFormat:@"%@%@topList",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"],[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]];
    NSString *dbTopListStr = [[DBManager sharedInstance]getPublicDBData:topList];
    [self fromatData:[dbTopListStr JSONValue]];
    [self loadDate];
    NSString *dbNumOfUsersData = [[DBManager sharedInstance]getPublicDBData:[NSString stringWithFormat:@"%@%@indexNumData",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"],[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
    dispatch_async(dispatch_get_main_queue(), ^{
        weakSelf.midView.creatNum = [NSString stringWithFormat:@"%@场",[self string:[[[dbNumOfUsersData JSONValue] objectForKey:@"content"] objectForKey:@"launched"]]];
        weakSelf.midView.joinNum = [NSString stringWithFormat:@"%@场",[self string:[[[dbNumOfUsersData JSONValue]  objectForKey:@"content"] objectForKey:@"attended"]]];
        weakSelf.midView.storeNum = [NSString stringWithFormat:@"%@场",[self string:[[[dbNumOfUsersData JSONValue]  objectForKey:@"content"] objectForKey:@"favorite"]]];
    });
    [self getSomeCount];
}

- (void)fromatData:(NSDictionary *)data
{
    //adUrl = [[data objectForKey:@"content"] objectForKey:@"img_url"];
    [indexMeetingList removeAllObjects];
    for (NSDictionary *dic in [[data objectForKey:@"content"] objectForKey:@"list"]) {
        SHSIndexModel *model = [[SHSIndexModel alloc]initWithDictionary:dic];
        [indexMeetingList addObject:model];
    }
    _pageControl.numberOfPages = indexMeetingList.count+1;
    _pageControl.currentPage = 0;
    [_pageControl.layer setNeedsDisplay];
    
    if (_pageControl.numberOfPages == 1) {
        _pageControl.hidden = YES;
    }
    else {
        _pageControl.hidden = NO;
    }
    
    [self.gridview reloadData];
}

- (void)loadDate
{
    [MyDataService postIndexMeeting:nil callback:^(id data) {
        if ([[data objectForKey:@"code"]isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                NSString * topList = [NSString stringWithFormat:@"%@%@topList",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"],[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]];
                [[DBManager sharedInstance] deleteToPublicOneData:topList];
                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:topList];
                [self fromatData:data];
            }
        }
    }];
}

- (void)getSomeCount
{
    __weak typeof(self) weakSelf = self;
    NSDictionary *params = @{@"types":@"launched,attended,favorite,new_members,new_friends,new_messages"};
    [MyDataService postPlatfromV2meetingNewscounts:params calllback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"]isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                NSString *indexNumData = [NSString stringWithFormat:@"%@%@indexNumData",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"],[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]];
                [[DBManager sharedInstance]deleteToPublicOneData:indexNumData];
                [[DBManager sharedInstance]insertDataToPublicDB:[data JSONString] valueKey:indexNumData];
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.midView.creatNum = [NSString stringWithFormat:@"%@场",[self string:[[data objectForKey:@"content"] objectForKey:@"launched"]]];
                    weakSelf.midView.joinNum = [NSString stringWithFormat:@"%@场",[self string:[[data objectForKey:@"content"] objectForKey:@"attended"]]];
                    weakSelf.midView.storeNum = [NSString stringWithFormat:@"%@场",[self string:[[data objectForKey:@"content"] objectForKey:@"favorite"]]];
                    if ([[[data objectForKey:@"content"] objectForKey:@"new_members"]isEqualToString:@"0"]) {
                        [weakSelf.midView.messageCount setTitle:@"" forState:UIControlStateNormal];
                        weakSelf.midView.messageCount.hidden = YES;
                    }
                    else {
                        [weakSelf.midView.messageCount setTitle:[[data objectForKey:@"content"] objectForKey:@"new_members"] forState:UIControlStateNormal];
                        weakSelf.midView.messageCount.hidden = NO;
                    }
                });
            }
        }
    }];
}

//我参加的 创建的 收藏的按钮
- (void)midViewBtnClicked:(UIButton *)btn
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        [self popToLoginView];
        return;
    }
    
    if (btn.tag == 300) {
        //创建的活动
        New_MyPublishViewController *myPublishVC = [[New_MyPublishViewController alloc]init];
        myPublishVC.isMyPublish = YES;
        [self.navigationController pushViewController:myPublishVC animated:YES];
    }
    if (btn.tag == 301) {
        //参加的活动
        /*
        New_myCellectViewController *cellectVC = [[New_myCellectViewController alloc]init];
        cellectVC.isMyPartake = YES;
        [self.navigationController pushViewController:cellectVC animated:YES];*/
        New_MyPublishViewController *myPublishVC = [[New_MyPublishViewController alloc]init];
        myPublishVC.isMyPartake = YES;
        [self.navigationController pushViewController:myPublishVC animated:YES];
        
    }
    if (btn.tag == 302) {
        //收藏的活动
        /*
        New_myCellectViewController *cellectVC = [[New_myCellectViewController alloc]init];
        cellectVC.isMyCollect = YES;
        [self.navigationController pushViewController:cellectVC animated:YES];*/
        New_MyPublishViewController *myPublishVC = [[New_MyPublishViewController alloc]init];
        myPublishVC.isMyCollect = YES;
        [self.navigationController pushViewController:myPublishVC animated:YES];
    }
}

- (void)popToLoginView
{
    LoginViewController *loginVc = [[LoginViewController alloc]init];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
    loginVc.fromSignVC = YES;
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        loginVc.isPush = YES;
    }
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)endViewBtnClick:(NSInteger)btnIndex
{
    __weak typeof(self) weakSelf = self;
    if (btnIndex == 200) {
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
            [self popToLoginView];
            return;
        }
        //发布活动
        MeetTypeViewController *addmeetVC = [[MeetTypeViewController alloc]init];
        [self.navigationController pushViewController:addmeetVC animated:YES];
    }
    if (btnIndex == 201) {
        //推荐给朋友
        New_RecommendViewController *recomendVC = [[New_RecommendViewController alloc]init];
        [self.navigationController pushViewController:recomendVC animated:YES];
    }
    if (btnIndex == 202) {
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
            [self popToLoginView];
            return;
        }
        //我的消息
        ChatListViewController *chatListVC = [[ChatListViewController alloc]init];
        [self.navigationController pushViewController:chatListVC animated:YES];
    }
    if (btnIndex == 203) {
        
        isScaned=NO;
        
        if ([QRCodeReader supportsMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]]) {
            static QRCodeReaderViewController *reader = nil;
            static dispatch_once_t onceToken;
            
            dispatch_once(&onceToken, ^{
                reader                        = [QRCodeReaderViewController new];
                reader.modalPresentationStyle = UIModalPresentationFormSheet;
            });
            reader.delegate = self;
            //                    [reader setCompletionWithBlock:^(NSString *resultAsString) {
            //                        NSLog(@"Completion with result: %@", resultAsString);
            //                    }];
            [weakSelf presentViewController:reader animated:YES completion:NULL];
        }
        else {
            /*
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Reader not supported by the current device" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];*/
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无法启动相机" message:@"请为会议邦开放相机权限：手机设置->隐私->相机->会议邦（打开）" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
        }
    }
    if (btnIndex == 204) {
        //随便看看
        IndexViewController *indexVC = [[IndexViewController alloc]init];
        [self.navigationController pushViewController:indexVC animated:YES];
    }
}

- (void)reader:(QRCodeReaderViewController *)reader didScanResult:(NSString *)result
{
    __weak typeof(self) weakSelf = self;

    if (!isScaned) {
        isScaned = !isScaned;
        [[skipManagerTool shareInstence]getNewScanCode:@{@"url":result} skipBlcok:^(int skipID, SHSIndexModel *modelData, BOOL remov) {
            //            block(0)未登录
            //            block(1)匹配成功
            //            block(2) 平台会议 随意观
            //            block(3)未匹配成功 弹出alert  （1重新登录  2取消）
            //            block(4)会议邦登录 只能看会议邦会议   在当前版本 所有的会议可以随便看  为以后做兼容
            //            block(10)会议未发布
            if (skipID == 10) {
                
            }
            else {
                [weakSelf showMeetingDetailView:modelData];
            }
            /*
            NSLog(@"skipID=%d",skipID);
            if (skipID == 0 || skipID == 1 || skipID == 2 || skipID == 4) {
                
            }
            else if (skipID == 3) {
                UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入该会议的企业号并重新登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"重新登录", nil];
                alertview.tag = 3000;
                [alertview show];
            }*/
        }];
        [weakSelf dismissViewControllerAnimated:YES completion:^{
            
        }];
    }
}

- (void)showMeetingDetailView:(SHSIndexModel *)meetModel
{
    New_SignUpInfoViewController *signUPInfoVC = [[New_SignUpInfoViewController alloc]init];
    signUPInfoVC.meetID = meetModel.meetingId;
    signUPInfoVC.meetTitle = meetModel.title;
    
    signUPInfoVC.companyCode = meetModel.company_code;
    signUPInfoVC.companyName = meetModel.company_name;
    
    if (meetModel.imgUrl.length > 0) {
        signUPInfoVC.haveImage = YES;//判断有没有海报图片
    }
    else {
        signUPInfoVC.haveImage = NO;
    }
    
    if ([meetModel.is_yqx isEqualToString:@"1"]) {
        signUPInfoVC.meetPoster_url = meetModel.yqx_url;
    }
    else {
        signUPInfoVC.meetPoster_url = meetModel.posters_url;
    }
    
    signUPInfoVC.isPoster = meetModel.is_yqx;
    signUPInfoVC.meetTitle = meetModel.title;
    signUPInfoVC.meet_type = meetModel.type;
    [self.navigationController pushViewController:signUPInfoVC animated:YES];
}

- (void)notificationShowMeetingDetail:(NSNotification *)notification
{
    NSLog(@"self.navigationController.viewControllers=%@",self.navigationController.viewControllers);
    if ([notification.userInfo[@"removeController"]isEqualToString:@"1"]) {
        NSMutableArray *controllers = [[NSMutableArray alloc]initWithArray:self.navigationController.viewControllers];
        [controllers removeObjectAtIndex:(controllers.count-1)];
        [self.navigationController setViewControllers:controllers animated:YES];
    }
    SHSIndexModel *model = (SHSIndexModel *)notification.userInfo[@"meetingInfo"];
    [self showMeetingDetailView:model];
}

- (void)readerDidCancel:(QRCodeReaderViewController *)reader
{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth = self.view.frame.size.width;
    int page = floor((scrollView.contentOffset.y - pageWidth / 2) / pageWidth) + 1;
    _pageControl.currentPage = page;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return indexMeetingList.count+1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return ScreenWidth;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"TableViewCell";
    SHSIndexModel *model;
    if (indexPath.row < indexMeetingList.count) {
        model = [indexMeetingList objectAtIndex:indexPath.row];
    }
    
    New_IndexCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
    if (!cell) {
        cell = [[New_IndexCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
    }
    if (indexPath.row == indexMeetingList.count) {
        cell.BGImageView.hidden = NO;
        [MYWebImage OneImageView:cell.BGImageView SetImageWithURL:adUrl PlaceHolderImageName:[NSString stringWithFormat:@"index_10"] CacheOrNot:YES];
    }
    else {
        cell.nameLabel.text = model.title;
        [MYWebImage OneImageView:cell.meetImageView SetImageWithURL:model.imgUrl PlaceHolderImageName:[NSString stringWithFormat:@"index_meet_type_%@",model.type] CacheOrNot:YES];
        NSDate *adate = [NSDate date];
        NSTimeZone *zone = [NSTimeZone systemTimeZone];
        NSInteger interval = [zone secondsFromGMTForDate: adate];
        NSDate *localeDate = [adate  dateByAddingTimeInterval: interval];
        long  localeInterval = [localeDate timeIntervalSince1970];
        if (localeInterval > [model.beginTime integerValue]) {
            cell.dataView.hidden  = YES;
        }
        else {
            cell.dataView.hidden  = NO;
            cell.dataView.dateStr = [self intervalSinceNow:[self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:model.beginTime]];
        }
        cell.timeLable.text = [NSString stringWithFormat:@"开始时间:%@ %@",[self formatter:@"yyyy-MM-dd HH:mm" ToTime:model.beginTime],[self weekDayStr:[self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:model.beginTime]]];
        if ([model.userId isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]) {
            cell.partaked = model.partaked;
        }
        else {
            cell.state = model.state;
        }
        cell.BGImageView.hidden = YES;
        cell.meetImageView.hidden = NO;
    }
    cell.transform = CGAffineTransformMakeRotation(M_PI/2);
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row != [indexMeetingList count]) {
        SHSIndexModel *info = [indexMeetingList objectAtIndex:indexPath.row];
        New_SignUpInfoViewController *signUPInfoVC = [[New_SignUpInfoViewController alloc]init];
        signUPInfoVC.meetID = info.meetingId;
        signUPInfoVC.meetTitle = info.title;
        
        if (info.imgUrl.length > 0) {
            signUPInfoVC.haveImage = YES;//判断有没有海报图片
        }
        else {
            signUPInfoVC.haveImage = NO;
        }
        
        if ([info.is_yqx isEqualToString:@"1"]) {
            signUPInfoVC.meetPoster_url = info.yqx_url;
        }
        else {
            signUPInfoVC.meetPoster_url = info.posters_url;
        }
        
        signUPInfoVC.isPoster = info.is_yqx;
        signUPInfoVC.meetTitle = info.title;
        signUPInfoVC.meet_type = info.type;
        [self.navigationController pushViewController:signUPInfoVC animated:YES];
    }
}

//登录成功后
- (void)loginChange
{
    //提供所属群组给融云
    NSArray *array = [[RCDRCIMDataSource shareInstance] getAllGroupInfo:^{
        
    }];
    
    NSMutableArray *array1 = [[NSMutableArray alloc]init];
    for (int i = 0;i < [array1 count];i++){
        RCGroup *group = [array objectAtIndex:i];
        if (group.groupId.length > 0 && group.groupName.length > 0) {
            [array1 addObject:[array objectAtIndex:i]];
        }
    }
    [[RCIMClient sharedRCIMClient] syncGroups:array1 success:^{
        
    } error:^(RCErrorCode status) {
        
    }];
    
    //这里要添加获取好友列表的方法
    [self getFriendList];
    [self getGruopData];
}

#pragma mark 融云获取器
//获取好友列表的方法

#pragma mark 广播方法
//退出登录后 通知（返回到首页）
- (void)loginDissmiss
{
    [self.navigationController popToRootViewControllerAnimated:NO];
    self.navigationController.navigationBarHidden = YES;
    UIView *bgview = [self.view viewWithTag:999];
    for (UIView *view in bgview.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)view;
            if (btn.tag == 0) {
                btn.selected = YES;
                [btn setImage:[UIImage imageNamed:[_btnClickedImages objectAtIndex:btn.tag]] forState:UIControlStateSelected];
            }
            else {
                btn.selected = NO;
            }
        }
    }
}

//新报名的总数量getSomeCount
- (void)postGetApplyCount
{
    __weak typeof(self) weakSelf = self;

    [MyDataService postPlatformMeetingCteatetotleg:nil callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"]isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"]isEqualToString:@"200"]) {
                if ([[[data objectForKey:@"content"] objectForKey:@"total"]isEqualToString:@"0"]) {
                    weakSelf.midView.messageCount.hidden = YES;
                    [weakSelf.midView.messageCount setTitle:@"" forState:UIControlStateNormal];
                }
                else {
                    weakSelf.midView.messageCount.hidden = NO;
                    [weakSelf.midView.messageCount setTitle:[[data objectForKey:@"content"] objectForKey:@"total"] forState:UIControlStateNormal];
                }
            }
            else if ([[data objectForKey:@"code"] isEqualToString:@"201"]) {
                weakSelf.midView.messageCount.hidden = YES;
                [weakSelf.midView.messageCount setTitle:@"" forState:UIControlStateNormal];
            }
        }
    }];
}

- (void)hideCountIcon
{
    self.endView.messageCount.hidden = YES;
    mesLB.hidden = YES;
    self.midView.messageCount.hidden = YES;
}

//我发布的会议中新报名的未读的用户数量
- (void)applyMyMeetingCount:(BOOL)isNotifition
{
    [self postGetApplyCount];
    if (isNotifition) {
        
    }
}

//当切换用户登录 需要通知到的方法
- (void)applyMyMeetingCount
{
    [self postGetApplyCount];
}

- (void)applyTotalCount
{
    [self postGetApplyCount];
}

#pragma mark - 统计未读消息数
- (void)setupUnreadMessageCount
{
    __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
        NSInteger unreadCount = 0;
        unreadCount = [[RCIMClient sharedRCIMClient]getTotalUnreadCount];
        if (unreadCount > 0) {
            weakSelf.endView.messageCount.hidden = NO;
            [weakSelf.endView.messageCount setTitle:[NSString stringWithFormat:@"%ld",(long)unreadCount] forState:UIControlStateNormal];
        }
        else {
            weakSelf.endView.messageCount.hidden = YES;
        }
    });
}

//好友申请的 数量（通知）
- (void)setupUntreatedApplyCount
{
    [MyDataService postIsNoNewFriend:nil callback:^(id data) {
        NSLog(@"%@",data);
        NSString *code = [data objectForKey: @"code"];
        if ([code isEqualToString: @"200"]) {
            
            NSDictionary  *content = [data objectForKey: @"content"];
            NSString *num = [content objectForKey: @"count"];
            NSInteger unreadCount;
            
            if (![num isEqualToString: @"0"] && ![num isEqualToString: @""] && num != nil) {
                unreadCount = [num intValue];//这里要加好友的数量
                [[NSUserDefaults standardUserDefaults]setObject:[NSNumber numberWithInt:unreadCount] forKey:NOTIFICATIONUNREADNUM];
            }
            else {
                unreadCount = 0;
                [[NSUserDefaults standardUserDefaults]setObject:[NSNumber numberWithInt:unreadCount] forKey:NOTIFICATIONUNREADNUM];
            }
            
            if (unreadCount > 0) {
                mesLB.hidden = NO;
                if (unreadCount > 99) {
                    [mesLB setTitle:@"99+" forState:UIControlStateNormal];
                }
                else {
                    [mesLB setTitle:[NSString stringWithFormat:@"%ld",(long)unreadCount] forState:UIControlStateNormal];
                }
            }
            else {
                mesLB.hidden = YES;
            }
        }
    }];
}

- (void)onRCIMReceiveMessage:(RCMessage *)message left:(int)left
{
    NSLog(@"%@",message);
    __weak typeof(self) weakSelf = self;

    dispatch_async(dispatch_get_main_queue(), ^{
        
        if ([message.objectName isEqualToString:@"RC:DizNtf"]) {
            RCDiscussionNotificationMessage *delDiscussionMessage = (RCDiscussionNotificationMessage*)message.content;
        
            if (delDiscussionMessage.type == RCRemoveDiscussionMemberNotification && [[Utils formatUserId:delDiscussionMessage.extension]isEqualToString:MYUSERID]) {
                [[NSNotificationCenter defaultCenter]postNotificationName:SELFISDELFROMDISCUSSION object:nil];
                [[RCIMClient sharedRCIMClient]clearMessagesUnreadStatus:message.conversationType targetId:message.targetId];//清除改行的消息未读数量
            }
            if (delDiscussionMessage.type == RCInviteDiscussionNotification && [[Utils formatUserId:delDiscussionMessage.extension]isEqualToString:MYUSERID]){
                [[NSNotificationCenter defaultCenter]postNotificationName:SELFISADDDISCUSSION object:nil];
            }
        }
   
        if ([message.objectName isEqualToString:@"RC:ContactNtf"]) {
            RCContactNotificationMessage *textMessage = (RCContactNotificationMessage *)message.content;
            if (textMessage.extra) {
                if ([textMessage.extra isEqualToString:@"addfriend"]) {
                    //被加好友的通知
                    [self setupUntreatedApplyCount];
                }
                else if ([textMessage.extra isEqualToString:@"delfriend"]) {
                    //被删除好友的通知
                    [self getFriendList];
                }
                else if ([textMessage.extra isEqualToString:@"acceptaddfriend"]) {
                    //对方接受加好友的通知
                    [self getFriendList];
                    [[NSNotificationCenter defaultCenter]postNotificationName:SELFISDELFROMDISCUSSION object:nil];
                }
                else if ([textMessage.extra isEqualToString:@"delgroupmember"]) {
                    if ([[Utils formatUserId:textMessage.targetUserId]isEqualToString:MYUSERID]) {
                         [[NSNotificationCenter defaultCenter]postNotificationName:SELFISDELFROMDISCUSSION object:nil];
                    }
                }
                else if ([textMessage.extra isEqualToString:@"overgroup"]) {
                    
                }
                else if ([[textMessage.extra JSONValue]isKindOfClass:[NSDictionary class]]) {
                    //被加入群的通知
                    NSDictionary * ntfMessage = [textMessage.extra JSONValue];
                    RCGroup *group = [[RCGroup alloc]init];
                    group.groupId = ntfMessage[@"group_id"];
                    group.groupName = ntfMessage[@"group_name"];
                    group.portraitUri = ntfMessage[@""];
                    [[RCDataBaseManager shareInstance]insertGroupToDB:group];
                    
                    [weakSelf getFriendList];
                }
                else if ([textMessage.extra isEqualToString:@"joinmeeting"]) {
                    //收到新的报名通知
                    [weakSelf getSomeCount];
                }
                else if ([textMessage.extra isEqualToString:@"rovemeeting"]) {
                    //取消报名的通知
                    [weakSelf getSomeCount];
                }
            }
        }
        if ([message.objectName isEqualToString:@"RC:ProfileNtf"]) {
            RCProfileNotificationMessage *textMessage = (RCProfileNotificationMessage *)message.content;
            NSDictionary * ntfMessage = [textMessage.extra JSONValue];
            RCGroup *group = [[RCGroup alloc]init];
            group.groupId = ntfMessage[@"group_id"];
            group.groupName = ntfMessage[@"group_name"];
            group.portraitUri = ntfMessage[@""];
            [[RCDataBaseManager shareInstance]insertGroupToDB:group];
            //这里要重新获取好友的列表
            
            return ;
        }
    });
    if (0 == left) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [UIApplication sharedApplication].applicationIconBadgeNumber = [UIApplication sharedApplication].applicationIconBadgeNumber+1;
        });
    }
    [self setupUnreadMessageCount];
}

#pragma mark - 当被踢掉或链接超时的时候，提示操作事件
- (void)onRCIMConnectionStatusChanged:(RCConnectionStatus)status
{
    if (ConnectionStatus_KICKED_OFFLINE_BY_OTHER_CLIENT == status) {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertView *alert= [[UIAlertView alloc]initWithTitle:@"" message:@"您已下线，重新连接？" delegate:self cancelButtonTitle:@"取消" otherButtonTitles: @"确定",nil];
            alert.tag = 2000;
            [alert show];
        });
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 3000) {
        if (buttonIndex == 0) {
            [self popToLoginView];
        }
        if (buttonIndex == 1) {
            
        }
    }
    if (alertView.tag == 2000) {
        if (0 == buttonIndex) {
            [[OpenLoginTool sharedManager]loginOff];
            LoginViewController *reg = [[LoginViewController alloc]init];
            UINavigationController * nav = [[UINavigationController alloc]initWithRootViewController:reg];
            NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
            if (!LoginCompanyArray.count)
            {
                reg.isPush = YES;
            }
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
        if (1 == buttonIndex) {
            NSString *deviceToken = [[NSUserDefaults standardUserDefaults]objectForKey:@"rongyun_token"];
            if ([deviceToken length] != 0) {
                //使用DEMO注意：更换appkey，一定要更换对应的连接token，如果token未做变化，默认会从融云测试环境获取，照成appkey和token不一致
                [[RCIMClient sharedRCIMClient] connectWithToken:deviceToken success:^(NSString *userId) {
                    NSLog(@"%s:连接成功",__FUNCTION__);
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [[NSNotificationCenter defaultCenter]postNotificationName:@"setupUnreadMessageCount" object:nil];
                    });
                    
                } error:^(RCConnectErrorCode status) {
                    NSLog(@"%s:连接失败",__FUNCTION__);
                } tokenIncorrect:^{
                    
                }];
            }
            else {
                //如果是退出了登陆或者第一次登陆的时候，跳入该处
            }
        }
    }
}

- (void)refrashFriendList
{
    ContactsViewController * _contactsVC = [[ContactsViewController alloc]init];
    [_contactsVC reloadDataSource];
}

#pragma mark - 获取群组列表
- (void)getGruopData
{
    [[RCDRCIMDataSource shareInstance] syncGroups];
}

#pragma mark - 获取我的好友列表
- (void)getFriendList
{
    [[RCDRCIMDataSource shareInstance] syncFriendList:^(id friends) {
        
    }];
}

//释放通知
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
