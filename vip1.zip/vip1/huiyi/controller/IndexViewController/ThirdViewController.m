//
//  ThirdViewController.m
//  会议广场
//
//  Created by songhongshuai on 15/5/12.
//  Copyright (c) 2015年 songhongshuai. All rights reserved.
//

#import "ThirdViewController.h"
#import "IndexCell.h"
#import "MJRefresh.h"
#import "IndexModel.h"
#import "UIImageView+WebCache.h"
#import "New_SignUpInfoViewController.h"
#import "MyNoneContentView.h"
#import "NSString+Size.h"
@interface ThirdViewController ()<UITableViewDataSource,UITableViewDelegate,LabelsDelegate>
{
    NSMutableArray *_indexDataArr;
    NSMutableArray *_brandArr;
    int _myPublishPage;
    NSString *selectedID;
}
@property (nonatomic,strong) LabelsView        *optionView;
@property (nonatomic,strong) UITableView       *thridTableView;
@property (nonatomic,strong) MyNoneContentView *tableViewNoneView;
@property (nonatomic,strong) UIView            *tableHeadView;

@property (nonatomic       ) BOOL              headVIewIsOpen;
@end

@implementation ThirdViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navBGView.hidden = YES;
    _brandArr = [[NSMutableArray alloc]initWithCapacity:0];
    _indexDataArr = [[NSMutableArray alloc]initWithCapacity:0];
    _myPublishPage = 1;
   
    [self creatThirdUI];
    [self getNetOptions];
    // Do any additional setup after loading the view.
}
- (MyNoneContentView *)tableViewNoneView
{
    if (!_tableViewNoneView) {
        _tableViewNoneView = [[MyNoneContentView alloc]init];
        _tableViewNoneView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight-self.navlabel.frame.size.height);
        _tableViewNoneView.hidden = NO;
        _tableViewNoneView.noneLabel.text = @"暂无品牌内容";
//_tableViewNoneView.otherLabel.text = @"请浏览首页列表收藏活动";
    }
    return _tableViewNoneView;
}
- (void)creatThirdUI
{
    
    [self.view addSubview:self.thridTableView];
    
    UIView *tableHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 32)];
    tableHeadView.backgroundColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:244.0/255.0 alpha:1.0];
}

- (UITableView *)thridTableView
{
    if (!_thridTableView) {
        _thridTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-45-64)];
        _thridTableView.delegate = self;
        _thridTableView.dataSource = self;
        _thridTableView.backgroundColor = [UIColor clearColor];
        _thridTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_thridTableView addHeaderWithTarget:self action:@selector(headerRereshing)];
        [_thridTableView addFooterWithTarget:self action:@selector(footerRereshing)];
        _thridTableView.headerPullToRefreshText = @"下拉可以刷新了";
        _thridTableView.headerReleaseToRefreshText = @"松开马上刷新了";
        _thridTableView.headerRefreshingText = @"正在帮你刷新中";
        _thridTableView.footerPullToRefreshText = @"上拉可以加载更多数据了";
        _thridTableView.footerReleaseToRefreshText = @"松开马上加载更多数据了";
        _thridTableView.footerRefreshingText = @"正在帮你加载中";
    }
    return _thridTableView;
}
- (void)getNetOptions
{
    [MyDataService postBrandList:nil callback:^(id data) {
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]){
                NSLog(@"%@",[data JSONString]);
                [_brandArr addObjectsFromArray:[[[data objectForKey:@"content"] objectForKey:@"list"] objectForKey:@"lst"]];
                NSMutableArray *titleArr = [[NSMutableArray alloc]initWithCapacity:0];
                NSString *name = [[NSUserDefaults standardUserDefaults]objectForKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                for (NSDictionary *dic in _brandArr) {
                    [titleArr addObject:[dic objectForKey:@"brand_name"]];
                    if ([dic[@"brand_name"]isEqualToString:name]) {
                        selectedID = dic[@"brand_id"];
                    }
                }
                
                [self sort];
               
                //_optionView.hidden = NO;
                if (_brandArr.count != 0) {
                    if (selectedID.length == 0) {
                        selectedID = [_brandArr[0]objectForKey:@"brand_id"];
                        NSMutableArray *titleArr = [[NSMutableArray alloc]initWithCapacity:0];
                        for (NSDictionary *dic in _brandArr) {
                            [titleArr addObject:[dic objectForKey:@"brand_name"]];
                        }
                        [[NSUserDefaults standardUserDefaults]setObject:_brandArr[0][@"brand_name"] forKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
        
                        _optionView.labelsArray = titleArr;
                            //_optionView.hidden = NO;
                        _optionView.frame = CGRectMake(0, 0, ScreenWidth, _optionView.height+32 );
                        
                    }else{
                        self.optionView.frame = CGRectMake(0, 0, ScreenWidth,32 );
                    }
                    self.thridTableView.tableHeaderView =self.optionView;
                    [self getMeetsData];
                }
            }
        }
    }];
}
- (NSMutableArray *)sort{
    int i,j;
    if (_brandArr.count>0) {
        
        self.thridTableView.tableHeaderView = self.optionView;
        //self.thridTableView.tableFooterView = nil;
        for(i=0;i<_brandArr.count-1;i++)
        {
            for(j=i+1;j<_brandArr.count;j++) /*注意循环的上下限*/
            {
                NSString *sortStr = [_brandArr[i] objectForKey:@"sort"];
                NSString *nextSortStr = [_brandArr[j] objectForKey:@"sort"];
                if([sortStr integerValue]<[nextSortStr integerValue]) {
                    NSDictionary * temp= [NSDictionary dictionaryWithDictionary:_brandArr[i]];
                    [_brandArr replaceObjectAtIndex:i withObject:_brandArr[j]];
                    [_brandArr replaceObjectAtIndex:j withObject:temp];;
                }
            }
        }
    }else{
        self.thridTableView.tableHeaderView = self.tableViewNoneView;
    }
    return _brandArr;
}
- (void)formateData:(NSDictionary *)jsonDic
{
    for (NSDictionary *dic in [[jsonDic objectForKey:@"content"] objectForKey:@"list"]) {
        IndexModel *indexmodel = [[IndexModel alloc]init];
        indexmodel.meetName = [dic objectForKey:@"name"];
        indexmodel.meetAddress = [dic objectForKey:@"location"];
        indexmodel.meetSTime = [dic objectForKey:@"begin_date"];
        indexmodel.meetNTime = [dic objectForKey:@"end_date"];
        indexmodel.meet_id = [dic objectForKey:@"meeting_id"];
        indexmodel.meetCnt = [dic objectForKey:@"cnt_reader"];
        indexmodel.meetBmnum = [dic objectForKey:@"bmtotal"];
        indexmodel.meetType = [dic objectForKey:@"type"];
        indexmodel.isPoster = [dic objectForKey:@"is_yqx"];
        indexmodel.meetPosters_url = [dic objectForKey:@"posters_url"];
        indexmodel.yqx_url = [dic objectForKey:@"yqx_url"];
        indexmodel.meetStatus = [dic objectForKey:@"meeting_status"];
        if ([[dic objectForKey:@"img_url"] length]>0||[[dic objectForKey:@"pic_list"] count]>0) {//判断有没有海报图片
            indexmodel.haveImage = YES;
        }
        else{
            indexmodel.haveImage = NO;
        }
        NSArray *imageArray = [dic objectForKey:@"pic_list"];
        if ([imageArray count]>0) {
            
            NSMutableArray *imageUrls = [[NSMutableArray alloc]init];
            for (NSDictionary *imageDic in imageArray) {
                NSString *imageUrl = [imageDic objectForKey:@"img_file"];
                imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
                [imageUrls addObject:imageUrl];
            }
            
            indexmodel.meetImageUrl = [imageUrls objectAtIndex:0];
            indexmodel.meetPic_list = imageUrls;
        }
        else if([[dic objectForKey:@"img_url"] length]>0){
            indexmodel.meetImageUrl = [dic objectForKey:@"img_url"];
            NSString *imageUrl = [dic objectForKey:@"img_url"];
            imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
            indexmodel.meetPic_list = [NSMutableArray arrayWithObjects:imageUrl, nil];
        }
        else{
            
        }
        CGSize nameSize = [indexmodel.meetName stringSizeWithFont:[UIFont boldSystemFontOfSize:17] constrainedToSize:CGSizeMake(203, 200)];
        indexmodel.meetNameHeight = nameSize.height;
        [_indexDataArr addObject:indexmodel];
    }
    [self.thridTableView reloadData];
}
- (void)getDataFromDB
{
    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
    if (dataStr.length != 0&&[[[dataStr JSONValue] objectForKey:@"content"] isKindOfClass:[NSDictionary class]]) {
        [self formateData:[dataStr JSONValue]];
        
    }
    [self getNetOptions];
}

- (void)headerRereshing
{
    _myPublishPage = 1;
    if(!selectedID ){
        selectedID = @"";
    }
    [MyDataService postMeettingList:@{@"page":@"1",@"brand_id":selectedID} callback:^(id data) {
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                NSString *jsonGame = [data JSONString];
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [[DBManager sharedInstance] insertDataToPublicDB:jsonGame valueKey:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
                [self formateData:data];
            }
            if ([[data objectForKey:@"code"] isEqualToString:@"201"]){
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
            }
        }
        [self.thridTableView headerEndRefreshing];
    }];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
}
- (void)postMeetingMyPublishMeeting:(NSInteger)page{
    if (!selectedID) {
        selectedID = @"";
    }
    NSDictionary *dic = @{@"page":[NSString stringWithFormat:@"%ld",(long)page],@"brand_id":selectedID};
    [MyDataService postMeettingList:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                [self formateData:data];
                [self.thridTableView footerEndRefreshing];
            }
            if([[data objectForKey:@"code"] isEqualToString:@"201"])
            {
                self.thridTableView.footerRefreshingText = @"没有更多内容了";
                [self performSelector:@selector(endRefreshing) withObject:nil afterDelay:0.5];
            }
        }
    }];
    
    if (![DBManager reachInternet]) {
        [self.thridTableView footerEndRefreshing];
    }
}
- (void)endRefreshing
{
    [self.thridTableView footerEndRefreshing];
}
- (void)footerRereshing
{
    _myPublishPage = _myPublishPage+1;
    [self postMeetingMyPublishMeeting:_myPublishPage];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
}
// 刷新结束
- (void)getMeetsData
{
    if (selectedID.length == 0) {
        return;
    }
    // [[Dialog Instance]showCenterProgressWithLabel:@"加载中..."];
    
    [MyDataService postMeettingList:@{@"page":@"1",@"brand_id":selectedID} callback:^(id data) {
        NSLog(@"%@",data);
       // [[Dialog Instance]hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
                [self formateData:data];
            }
        }
            if ([[data objectForKey:@"code"]isEqual:@"201"]) {
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@indexList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
            }
        
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 74;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _indexDataArr.count;
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"fristViewTableViewCell";
    IndexCell*cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell= [[IndexCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    IndexModel *index = (IndexModel *)[_indexDataArr objectAtIndex:indexPath.row];
    cell.nameLb.text = index.meetName;
    index.meetImageUrl = [index.meetImageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
    [cell.contentImageView sd_setImageWithURL:[NSURL URLWithString:index.meetImageUrl] placeholderImage:[UIImage imageNamed:[NSString stringWithFormat:@"index_meet_type_%@@2x",index.meetType]]];
    cell.timeLb.text = [NSString stringWithFormat:@"%@",[Dialog formatterToTime:index.meetSTime]];
    if([index.meetStatus isEqualToString:@"pending"])
    {
        cell.statusImageView.image = [UIImage imageNamed:@"meetstatus1"];
    
    }
    if([index.meetStatus isEqualToString:@"starting"]){
        cell.statusImageView.image = [UIImage imageNamed:@"meetstatus1"];
    }
    if([index.meetStatus isEqualToString:@"ended"]){
        cell.statusImageView.image = [UIImage imageNamed:@"meetstatus2"];
    }
    cell.cellBmnum.text = index.meetBmnum;
    cell.cellCnt.text = index.meetCnt;
    cell.addressLb.text = index.meetAddress;
    
    return cell;
}
- (void)showMoreInfo:(UIButton *)btn{
    _headVIewIsOpen = !_headVIewIsOpen;
    NSMutableArray *titleArr = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary *dic in _brandArr) {
        [titleArr addObject:[dic objectForKey:@"brand_name"]];
    }
    [UIView animateWithDuration:0.05 animations:^{
        if (_headVIewIsOpen) {
            [btn setTitle:@"收起" forState:UIControlStateNormal];
            _optionView.labelsArray = titleArr;
            //_optionView.hidden = NO;
            if (_brandArr.count==0) {
                _optionView.frame = CGRectMake(0, 0, ScreenWidth, 32 );
            }else
                _optionView.frame = CGRectMake(0, 0, ScreenWidth, _optionView.height+32);
        }else{
            [btn setTitle:@"更多品牌" forState:UIControlStateNormal];
            _optionView.frame = CGRectMake(0, 0, ScreenWidth, 32);
            _optionView.labelsArray = @[];
            //_optionView.hidden = YES;
        }
        self.thridTableView.tableHeaderView = _optionView;
    }];
    
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    IndexModel *index = (IndexModel *)[_indexDataArr objectAtIndex:indexPath.row];
    New_SignUpInfoViewController *signUpVC = [[New_SignUpInfoViewController alloc]init];
    self.hidesBottomBarWhenPushed = YES;
    [[NSNotificationCenter defaultCenter]postNotificationName:@"hidenTabar" object:nil];
    signUpVC.meetID = index.meet_id;
    if ([index.isPoster isEqualToString:@"1"]) {
        signUpVC.meetPoster_url =index.yqx_url;
    }else{
        signUpVC.meetPoster_url =index.meetPosters_url;
    }
    signUpVC.isPoster = index.isPoster;
    signUpVC.meet_type = index.meetType;
    signUpVC.meetTitle = index.meetName;
    signUpVC.photoArray = index.meetPic_list;
    signUpVC.haveImage = index.haveImage;//判断有没有海报图片
    [self.navigationController pushViewController:signUpVC animated:YES];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (LabelsView *)optionView
{
    if (!_optionView) {
        _optionView = [[LabelsView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 32)];
        _optionView.delegate = self;
        _optionView.clipsToBounds = YES;
        _optionView.backgroundColor = [UIColor whiteColor];
    }
    return _optionView;
}
- (void)LabelClicked:(NSInteger)index
{
    selectedID = [_brandArr[index]objectForKey:@"brand_id"];
    [self getMeetsData];
    [[NSUserDefaults standardUserDefaults]setObject:[_brandArr[index] objectForKey:@"brand_name"] forKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
    [UIView animateWithDuration:0.05 animations:^{
        _optionView.frame = CGRectMake(0, 0, ScreenWidth, 32);
        _optionView.labelsArray = @[];
        self.thridTableView.tableHeaderView = _optionView;
        [_optionView.showMoreBtn setTitle:@"更多品牌" forState:UIControlStateNormal];
    }];
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
