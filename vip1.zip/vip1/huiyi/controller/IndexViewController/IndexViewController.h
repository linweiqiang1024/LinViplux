//
//  IndexViewController.h
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>

@protocol TestJSExport <JSExport>


- (void)jumpToMeeting:(NSString *)qs :(NSString *)ws :(NSString *)es :(NSString *)rs :(NSString *)ts :(NSString *)ys;


@end


@interface IndexViewController : FatherViewController
{
    NSMutableArray * _dataMutAry;
}
@property (nonatomic,strong)NSMutableArray * dataMutAry;
@property (nonatomic)BOOL isMyPublish;
@end
