//
//  IndexCell.m
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "IndexCell.h"

@interface IndexCell (){

}
@property (nonatomic,strong)UIImageView *cellCntIcon;
@property (nonatomic,strong)UIImageView *cellBmnumIcon;
@property (nonatomic,strong)UIView *cellSeparateLine;

@end
@implementation IndexCell

@synthesize addressLb = _addressLb,nameLb = _nameLb,timeLb = _timeLb,contentImageView = _contentImageView;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = [UIColor whiteColor];
        self.selected = NO;
        [self.contentView addSubview:self.contentImageView];
        [self.contentView addSubview:self.nameLb];
        [self.contentView addSubview:self.addressLb];
        [self.contentView addSubview:self.timeLb];
        [self.contentView addSubview:self.cellCntIcon];
        //阅读人数
        [self.contentView addSubview:self.cellCnt];
        [self.contentView addSubview:self.cellBmnumIcon];
        //报名人数
        [self.contentView addSubview:self.cellBmnum];
        [self.contentView addSubview:self.statusImageView];
        [self.contentView addSubview:self.cellNewApplyCount];
        //分割线
        [self.contentView addSubview:self.cellSeparateLine];
        
    }
    return self;
}
- (UIImageView *)statusImageView
{
    if (!_statusImageView) {
        _statusImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth - 30, 7.5, 27, 30)];
        _statusImageView.backgroundColor = [UIColor clearColor];
        _statusImageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _statusImageView;
}
- (UIImageView *)contentImageView
{
    if (!_contentImageView) {
        _contentImageView = [[UIImageView alloc]initWithFrame:CGRectMake(6.5, 7.5, 100, 59)];
        _contentImageView.backgroundColor = [UIColor clearColor];
    }
    return _contentImageView;
}
- (UILabel *)nameLb
{
    if (!_nameLb) {
        _nameLb = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+7.5, 10, ScreenWidth-140, 17)];
        _nameLb.backgroundColor = [UIColor clearColor];
        _nameLb.font = YHUI_BOLD(17);
        _nameLb.textColor = [UIColor colorWithHexString:@"#000000"];
    }
    return _nameLb;
}
- (UILabel *)addressLb
{
    if(!_addressLb){
        _addressLb = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+7.5, CGRectGetMaxY(self.nameLb.frame)+9.5, ScreenWidth-117, 14)];
        _addressLb.textColor = [UIColor colorWithHexString:@"#5b5b5b"];
        _addressLb.font = YHUI(12);
        BackGroundColor(_addressLb, clearColor);
    }
    return _addressLb;
}
- (UILabel *)timeLb
{
    if (!_timeLb) {
        _timeLb = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+7.5, CGRectGetMaxY(self.addressLb.frame)+5.5, 203, 12)];
        _timeLb.backgroundColor = [UIColor clearColor];
        _timeLb.font = YHUI(12);
        _timeLb.textColor = [UIColor colorWithHexString:@"#999999"];
        _timeLb.backgroundColor = [UIColor clearColor];
    }
    return _timeLb;
}
- (UIImageView *)cellCntIcon
{
    if (!_cellCntIcon) {
        _cellCntIcon = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-77-11.5, CGRectGetMaxY(self.addressLb.frame)+8, 11.5, 7.5)];
        _cellCntIcon.image = PNGIMAGE(@"indexReadCountIcon@2x");
        BackGroundColor(_cellCntIcon, clearColor);
    }
    return _cellCntIcon;
}
- (UILabel *)cellCnt
{
    if (!_cellCnt) {
        _cellCnt = [[UILabel alloc]init];
        _cellCnt.backgroundColor = [UIColor clearColor];
        _cellCnt.frame = CGRectMake(CGRectGetMaxX(self.cellCntIcon.frame)+2, CGRectGetMaxY(self.addressLb.frame)+7, 35, 10);
        _cellCnt.textColor = [UIColor colorWithHexString:@"#999999"];
        _cellCnt.font = [UIFont systemFontOfSize:10];
    }
    return _cellCnt;
}
- (UIImageView *)cellBmnumIcon
{
    if (!_cellBmnumIcon) {
        _cellBmnumIcon = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.cellCnt.frame)-3, CGRectGetMaxY(self.addressLb.frame)+7, 7.5,9.5)];
        _cellBmnumIcon.image = PNGIMAGE(@"indexApplyCountIcon@2x");
        BackGroundColor(_cellBmnumIcon, clearColor);
    }
    return _cellBmnumIcon;
}
- (UILabel *)cellBmnum
{
    if (!_cellBmnum) {
        _cellBmnum = [[UILabel alloc]init];
        _cellBmnum.backgroundColor = [UIColor clearColor];
        _cellBmnum.frame = CGRectMake(CGRectGetMaxX(self.cellBmnumIcon.frame)+2, CGRectGetMaxY(self.addressLb.frame)+7, 35, 10);
        _cellBmnum.textColor = [UIColor colorWithHexString:@"#999999"];
        _cellBmnum.font = [UIFont systemFontOfSize:10];
    }
    return _cellBmnum;
}
- (UIButton *)cellNewApplyCount
{
    if (!_cellNewApplyCount) {
        _cellNewApplyCount = [UIButton buttonWithType:UIButtonTypeCustom];
        [_cellNewApplyCount setBackgroundImage:[UIImage imageNamed:@"new_apply_count"] forState:UIControlStateNormal];
        _cellNewApplyCount.frame = CGRectMake(95, 3, 20, 20);
        _cellNewApplyCount.adjustsImageWhenHighlighted = NO;
        [_cellNewApplyCount setTitle:@"12" forState:UIControlStateNormal];
        _cellNewApplyCount.titleLabel.font = [UIFont systemFontOfSize:10];
        _cellNewApplyCount.hidden = YES;
    }
    return _cellNewApplyCount;
}
- (UIView *)cellSeparateLine
{
    if (!_cellSeparateLine) {
        _cellSeparateLine = [[UIView alloc]init];
        _cellSeparateLine.frame = CGRectMake(0, 74-0.5, ScreenWidth, 0.5);
        _cellSeparateLine.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    }
    return _cellSeparateLine;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
