//
//  IndexHeadView.h
//  huiyi
//
//  Created by songhongshuai on 15/3/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndexHeadView : UIView

@end
