//
//  IndexEndView.h
//  huiyi
//
//  Created by songhongshuai on 15/3/25.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UIIndexEndViewDelegate <NSObject>

- (void)endViewBtnClick:(NSInteger )btnIndex;

@end

@interface IndexEndView : UIView

@property (nonatomic,strong) UIButton *messageCount;
@property (nonatomic,weak)   id <UIIndexEndViewDelegate> delegate;

@end
