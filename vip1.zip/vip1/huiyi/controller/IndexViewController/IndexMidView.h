//
//  IndexMidView.h
//  huiyi
//
//  Created by songhongshuai on 15/3/25.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol UIMidViewDelegate <NSObject>

- (void)midViewBtnClicked:(UIButton *)btn;

@end

@interface IndexMidView : UIView
@property(nonatomic,strong)UIButton *messageCount;
@property(nonatomic,strong)NSString *creatNum;
@property(nonatomic,strong)NSString *joinNum;
@property(nonatomic,strong)NSString *storeNum;
@property(nonatomic,weak)id<UIMidViewDelegate>delegate;
@end
