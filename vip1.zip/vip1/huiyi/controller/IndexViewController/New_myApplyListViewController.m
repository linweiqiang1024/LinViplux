//
//  New_myApplyListViewController.m
//  huiyi
//
//  Created by 王振兴 on 15-2-10.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "New_myApplyListViewController.h"
#import "SignUpTypeViewController.h"
#import "New_myApplyListCell.h"
#import "SDTicketModel.h"
#import "SDTableView.h"
#import "SignUpConfigTool.h"
#import "UpViewController.h"
#import "BriefViewController.h"
#import "UpInfoViewController.h"
#import "SubPersonInfoViewController.h"
#import "EduExpViewController.h"
#import "SignUpStatusViewController.h"
#import "MyNoneContentView.h"//当没有内容时候界面
#import "skipManagerTool.h"

@interface New_myApplyListViewController () <SDTableViewDelegate,reloadReplaceData>
{
    UITableView *_tableView;
    NSMutableArray *dataSource;
    MyNoneContentView *_tableViewNoneView;//如果没有数据显示该一面
    NSMutableArray * _ticketArr;//票的基本信息
    NSIndexPath *ticketIndexPath;//选中什么票
    NSDictionary *_nextViewDic;//下一页配置
    SDTableView * _sdTableView;
}
@property (nonatomic,strong)UIButton *signUpBtn;
@property (nonatomic,strong)UIButton *replceSignUpBtn;
@property (nonatomic) BOOL replceSignUpBtnClicked;
@end

@implementation New_myApplyListViewController
@synthesize meeting_id = _meeting_id;

- (UIButton *)signUpBtn
{
    if (!_signUpBtn) {
        _signUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_signUpBtn setTitle:@"我要报名" forState:UIControlStateNormal];
        _signUpBtn.adjustsImageWhenHighlighted = NO;
        [_signUpBtn.layer setNeedsDisplay];
        _signUpBtn.tag = 100;
        _signUpBtn.backgroundColor = [UIColor colorWithHexString:@"#17b4eb"];
        _signUpBtn.frame = CGRectMake(0,  ScreenHeight-50, ScreenWidth/3*2, 50);
        [_signUpBtn addTarget:self action:@selector(signUpBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _signUpBtn;
}

- (UIButton *)replceSignUpBtn
{
    if (!_replceSignUpBtn) {
        _replceSignUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_replceSignUpBtn setTitle:@"代人报名" forState:UIControlStateNormal];
        _replceSignUpBtn.adjustsImageWhenHighlighted = NO;
        [_replceSignUpBtn.layer setNeedsDisplay];
        _replceSignUpBtn.backgroundColor = [UIColor colorWithHexString:@"#c6c5ca"];
        _replceSignUpBtn.frame = CGRectMake(ScreenWidth/3*2,  ScreenHeight-50, ScreenWidth/3, 50);
        _replceSignUpBtn.tag = 1000;
        [_replceSignUpBtn addTarget:self action:@selector(signUpBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _replceSignUpBtn;
}

- (void)createUI
{
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT-50) style:UITableViewStylePlain];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    
    _tableViewNoneView = [[MyNoneContentView alloc]init];
    _tableViewNoneView.frame = CGRectMake(0, 30, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT-50-30);
    _tableViewNoneView.hidden = YES;
    _tableViewNoneView.imageView.image = [UIImage imageNamed:@"no_myReplaceSignUp"];
    _tableViewNoneView.noneLabel.text = @"还没有代人报名";
    _tableViewNoneView.otherLabel.text = @"快去代你的小伙伴报名啦";
    [_tableView addSubview:_tableViewNoneView];
    
    _tableView.tableHeaderView = [self headerView];
    
    UIView *footView = [[UIView alloc]init];
    footView.frame  = CGRectMake(0, 0, ScreenWidth, 12.5);
    footView.backgroundColor = [UIColor clearColor];
    _tableView.tableFooterView = footView;
    
    [self.view addSubview:self.signUpBtn];
    [self.view addSubview:self.replceSignUpBtn];

    if ([_signUpstate isEqualToString:@"1"]) {
        [_signUpBtn setTitle:@"我要报名" forState:UIControlStateNormal];
    }
    if ([_signUpstate isEqualToString:@"2"]) {
        [_signUpBtn setTitle:@"等待回执" forState:UIControlStateNormal];
    }
    if ([_signUpstate isEqualToString:@"3"]) {
        [_signUpBtn setTitle:@"报名未通过" forState:UIControlStateNormal];
    }
    if ([_signUpstate isEqualToString:@"4"]) {
        [_signUpBtn setTitle:@"报名审核中" forState:UIControlStateNormal];
    }
    if ([_signUpstate isEqualToString:@"5"] || [_signUpstate isEqualToString:@"11"]) {
        [_signUpBtn setTitle:@"签到码/修改报名信息" forState:UIControlStateNormal];
    }
}

- (void)reloadReplace
{
    [self getNetData];
}

- (void)goToSignUpStatusView:(BOOL)isHost
{
    for (NSDictionary *nextViewDic12 in [_configDictionary objectForKey:@"block_list"]) {
        if ([[nextViewDic12 objectForKey:@"block_id"]isEqualToString:_blockID]) {
            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"10"]) {
                //显示报名状态跟踪
                NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
                [ticket setObject:[nextViewDic12 objectForKey:@"name"] forKey:@"name"];
                [ticket setObject:[nextViewDic12 objectForKey:@"price"] forKey:@"price"];
                
                [ticket setObject:[self formatter:@"yyyy.MM.dd HH:mm" ToTime:[nextViewDic12 objectForKey:@"partake_end_time"]] forKey:@"partake_end_time"];
                [ticket setObject:[nextViewDic12 objectForKey:@"note"] forKey:@"note"];
                [self writePlistToDucment:@"ticketinfo" With:ticket];
                SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                //stateVC.delegate = self;
                stateVC.isCheck = NO;
                stateVC.isHost = isHost;
                stateVC.name = [[NSUserDefaults standardUserDefaults] objectForKey:@"name"];
                stateVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                stateVC.meetID = _meeting_id;
                stateVC.user_id = [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"];
                stateVC.configDic = _configDictionary;
                stateVC.type = [nextViewDic12 objectForKey:@"type"];
                stateVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                [self.navigationController pushViewController:stateVC animated:YES];
            }
        }
    }
}

/*
- (void)signUpBtnClicked:(UIButton *)btn
{
    for (SDTicketModel *model in _ticketArr){
        double time = [model.int_partake_end_time longLongValue];
        NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
        NSTimeInterval a=[dat timeIntervalSince1970];
        if ((int)a>time){
            model.meetEnd = YES;
        }else{
            model.meetEnd = NO;
        }
    }
    if (btn.tag == 100) {
        _replceSignUpBtnClicked = NO;
        if (![_signUpstate isEqualToString:@"1"]&&![_signUpstate isEqualToString:@"10"]) {
            [self goToSignUpStatusView];
        }else{
//            if ([_timeAndAddIpa.ipaUser_id isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]) {
//                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您是会议创建者，不用报名" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
//                [alert show];
//                return;
//            }
//            else{
                if (_ticketArr.count == 1) {
                    NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
                    SDTicketModel * info = [_ticketArr firstObject];
                    [ticket setObject:info.name forKey:@"name"];
                    [ticket setObject:info.price forKey:@"price"];
                    [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
                    [ticket setObject:info.note forKey:@"note"];
                    [ticket setObject:info.block_id forKey:@"block_id"];
                    [ticket setObject:info.visible forKey:@"visible"];
                    [self writePlistToDucment:@"ticketinfo" With:ticket];
                    [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
                    [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
                    if (info.meetEnd == YES) {
                        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议报名截止" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                        [alert show];
                        return;
                    }
                    SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
                    tool.signUpstate = _signUpstate;
                    tool.controller = self;
                    tool.meeting_id = _meeting_id;
                    tool.blockID = _blockID;
                    tool.configDic = _configDic;
                    [tool manageConfig];
                    
                }else{
                    if (!_sdTableView.isShow) {
                        _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                        _sdTableView.dataSourceArr = _ticketArr;
                        _sdTableView.meeting_title = _shareTitle;
                        if (self.photoArray.count == 0) {
                            _sdTableView.posterImageUrl = nil;
                        }else{
                            _sdTableView.posterImageUrl = [self.photoArray objectAtIndex:0];
                        }
                        if (ticketIndexPath) {
                            _sdTableView.indexPath = ticketIndexPath;
                        }
                        [_sdTableView showInView:self.view];
                    }
                }
            }
        }
//    }
    if (btn.tag == 1000) {
        _replceSignUpBtnClicked = YES;
        if (_ticketArr.count == 1) {
            NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
            SDTicketModel * info = [_ticketArr firstObject];
            [ticket setObject:info.name forKey:@"name"];
            [ticket setObject:info.price forKey:@"price"];
            [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
            [ticket setObject:info.note forKey:@"note"];
            [ticket setObject:info.block_id forKey:@"block_id"];
            [ticket setObject:info.visible forKey:@"visible"];
            [self writePlistToDucment:@"ticketinfo" With:ticket];
            [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
            [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
            if (info.meetEnd == YES) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议报名截止" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alert show];
                return;
            }
            
            SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
            //        tool.signUpstate = _signUpstate;
            tool.controller = self;
            tool.meeting_id = _meeting_id;
            tool.blockID = _blockID;
            tool.configDic = _configDic;
            [tool manageSubConfigWithSameTicket:ticketIndexPath.row];
        }else{
            if (!_sdTableView.isShow) {
                _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                _sdTableView.dataSourceArr = _ticketArr;
                _sdTableView.meeting_title = _shareTitle;
                if (self.photoArray.count == 0) {
                    _sdTableView.posterImageUrl = nil;
                }else{
                    _sdTableView.posterImageUrl = [self.photoArray objectAtIndex:0];
                }
                if (ticketIndexPath) {
                    _sdTableView.indexPath = ticketIndexPath;
                }
                [_sdTableView showInFatherView:self.view];
            }
        }
    }
}*/

- (void)signUpBtnClicked:(UIButton *)btn
{
    if ([btn isEqual:self.signUpBtn]) {
        _replceSignUpBtnClicked = NO;
        if (![_signUpstate isEqualToString:@"1"] && ![_signUpstate isEqualToString:@"10"]) {
            [self goToSignUpStatusView:YES];
        }
        else {
            for (SDTicketModel *model in _ticketArr) {
                double time = [model.int_partake_end_time longLongValue];
                NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
                NSTimeInterval a = [dat timeIntervalSince1970];
                if ((int)a > time) {
                    model.meetEnd = YES;
                }
                else {
                    model.meetEnd = NO;
                }
            }
            
            if (self.meetIsEnd) {
                 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"报名已结束" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                 [alert show];
                //[Dialog toastCenter:@"报名已结束"];
                return;
            }
            
            if (!_sdTableView.isShow) {
                _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                _sdTableView.dataSourceArr = _ticketArr;
                _sdTableView.meeting_title = _shareTitle;
                if (self.photoArray.count == 0) {
                    _sdTableView.posterImageUrl = nil;
                }
                else {
                    _sdTableView.posterImageUrl = [self.photoArray objectAtIndex:0];
                }
                if (ticketIndexPath) {
                    _sdTableView.indexPath = ticketIndexPath;
                }
                [_sdTableView showInFatherView:self.view];
            }
            
            /*
            if (_ticketArr.count == 1) {
                NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
                SDTicketModel * info = [_ticketArr firstObject];
                
                if (info.meetEnd == YES) {
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议报名截止" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    [alert show];
                    return;
                }
                
                [ticket setObject:info.name forKey:@"name"];
                [ticket setObject:info.price forKey:@"price"];
                [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
                [ticket setObject:info.note forKey:@"note"];
                [ticket setObject:info.block_id forKey:@"block_id"];
                [ticket setObject:info.visible forKey:@"visible"];
                [self writePlistToDucment:@"ticketinfo" With:ticket];
                [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
                [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
                SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
                tool.signUpstate = _signUpstate;
                tool.controller = self;
                tool.meeting_id = _meeting_id;
                tool.blockID = _blockID;
                tool.configDic = _configDic;
                [tool manageConfig];
            }
            else {
                if (!_sdTableView.isShow) {
                    _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                    _sdTableView.dataSourceArr = _ticketArr;
                    _sdTableView.meeting_title = _shareTitle;
                    if (self.photoArray.count == 0) {
                        _sdTableView.posterImageUrl = nil;
                    }
                    else {
                        _sdTableView.posterImageUrl = [self.photoArray objectAtIndex:0];
                    }
                    if (ticketIndexPath) {
                        _sdTableView.indexPath = ticketIndexPath;
                    }
                    [_sdTableView showInView:self.view];
                }
            }*/
        }
    }
    
    if ([btn isEqual:self.replceSignUpBtn]) {
        _replceSignUpBtnClicked = YES;
        for (SDTicketModel *model in _ticketArr) {
            double time = [model.int_partake_end_time longLongValue];
            NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
            NSTimeInterval a = [dat timeIntervalSince1970];
            if ((int)a > time) {
                model.meetEnd = YES;
            }
            else {
                model.meetEnd = NO;
            }
        }
        
        if (self.meetIsEnd) {
             UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"报名已结束" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
             [alert show];
             //[Dialog toastCenter:@"报名已结束"];
            return;
        }
        
        if (!_sdTableView.isShow) {
            _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
            _sdTableView.dataSourceArr = _ticketArr;
            _sdTableView.meeting_title = _shareTitle;
            if (self.photoArray.count == 0) {
                _sdTableView.posterImageUrl = nil;
            }
            else {
                _sdTableView.posterImageUrl = [self.photoArray objectAtIndex:0];
            }
            if (ticketIndexPath) {
                _sdTableView.indexPath = ticketIndexPath;
            }
            [_sdTableView showInFatherView:self.view];
        }
        
        /*
        if (_ticketArr.count == 1) {
            NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
            SDTicketModel * info = [_ticketArr firstObject];
            if (info.meetEnd == YES) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议报名截止" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alert show];
                return;
            }
            
            [ticket setObject:info.name forKey:@"name"];
            [ticket setObject:info.price forKey:@"price"];
            [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
            [ticket setObject:info.note forKey:@"note"];
            [ticket setObject:info.block_id forKey:@"block_id"];
            [ticket setObject:info.visible forKey:@"visible"];
            [self writePlistToDucment:@"ticketinfo" With:ticket];
            [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
            [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
            SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
            tool.signUpstate = _signUpstate;
            tool.controller = self;
            tool.meeting_id = _meeting_id;
            tool.blockID = _blockID;
            tool.configDic = _configDic;
            [tool manageSubConfig];
        }
        else {
            if (!_sdTableView.isShow) {
                _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                _sdTableView.dataSourceArr = _ticketArr;
                _sdTableView.meeting_title = _shareTitle;
                if (self.photoArray.count == 0) {
                    _sdTableView.posterImageUrl = nil;
                }
                else {
                    _sdTableView.posterImageUrl = [self.photoArray objectAtIndex:0];
                }
                if (ticketIndexPath) {
                    _sdTableView.indexPath = ticketIndexPath;
                }
                [_sdTableView showInView:self.view];
            }
        }*/
    }
}

- (UIView *)headerView
{
    UIView *headerView = [[UIView alloc]init];
    headerView.frame  = CGRectMake(0, 0, ScreenWidth, 10);
    //headerView.frame  = CGRectMake(0, 0, ScreenWidth, 12.5+55);
    headerView.backgroundColor = [UIColor clearColor];
    return headerView;
}

#pragma mark - SDTableViewDelegate
- (void)sureClicked:(id)btn
{
    SDTicketModel * info = [_ticketArr objectAtIndex:ticketIndexPath.row];
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%ld",(long)ticketIndexPath.row] forKey:@"ticketIndex"];
    NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
    [ticket setObject:info.name forKey:@"name"];
    [ticket setObject:info.block_id forKey:@"block_id"];
    [ticket setObject:info.price forKey:@"price"];
    [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
    [ticket setObject:info.note forKey:@"note"];
    [ticket setObject:info.visible forKey:@"visible"];
    [self writePlistToDucment:@"ticketinfo" With:ticket];
    [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
    [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
    
    if (_replceSignUpBtnClicked == YES) {
        if (info.meetEnd == NO) {
            SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
            tool.signUpstate = _signUpstate;
            tool.controller = self;
            tool.meeting_id = _meeting_id;
            tool.blockID = _blockID;
            tool.configDic = _configDic;
            [tool manageSubConfigWithSameTicket:ticketIndexPath.row];
        }
        else {
            //[Dialog toastCenter:@"报名已结束"];
            [Dialog toastCenter:@"报名已截止"];
        }
    }
    else {
        if (info.meetEnd == NO) {
            SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
            tool.signUpstate = _signUpstate;
            tool.controller = self;
            tool.meeting_id = _meeting_id;
            tool.blockID = _blockID;
            tool.configDic = _configDic;
            [tool manageConfigWithSameTicket:ticketIndexPath.row];
        }
        else {
            //[Dialog toastCenter:@"报名已结束"];
            [Dialog toastCenter:@"报名已截止"];
        }
    }
}

- (void)backClicked
{
    [_sdTableView tappedCancel];
}

- (void)selectAtIndex:(NSIndexPath *)indexPath
{
    ticketIndexPath = indexPath;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.titlelabel.text = @"入场券";
    _ticketArr = [[NSMutableArray alloc]initWithCapacity:0];
    dataSource = [[NSMutableArray alloc]initWithCapacity:0];
    
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    NSArray *arr = [NSArray arrayWithArray:[_configDic objectForKey:@"block_list"]];
    
    for (NSDictionary *dic in arr) {
        SDTicketModel *model = [[SDTicketModel alloc]init];
        model.name = [dic objectForKey:@"name"];
        model.price = [dic objectForKey:@"price"];
        double time = [[dic objectForKey:@"partake_end_time"] longLongValue];
        model.block_id = [dic objectForKey:@"block_id"];
        NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
        NSTimeInterval a = [dat timeIntervalSince1970];
        if ((int)a > time) {
            model.meetEnd = YES;
        }
        else {
            model.meetEnd = NO;
        }
        
        model.partake_end_time = [self formatter:@"yyyy.MM.dd HH:mm" ToTime:[dic objectForKey:@"partake_end_time"]];
         model.int_partake_end_time = [dic objectForKey:@"partake_end_time"];
        model.note = [dic objectForKey:@"note"];
        model.visible = [dic objectForKey:@"visible"];
        [_ticketArr addObject:model];
    }
    
    [self createUI];
    [self getNetData];
}

//approved  0未审核 1审核未过 2审核通过 3补充材料
- (void)getNetData
{
    [[Dialog Instance]showHSHUDWithController:self];
    NSDictionary *params = @{@"user_id":[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"],@"meeting_id":_meeting_id};
    [MyDataService postPlatfromMeetingMemberInfoFromMe:params calllback:^(id data) {
        NSLog(@"%@",data);
        [[Dialog Instance] hiddenHSHUD];
        if ([[data objectForKey:@"code"]isEqualToString:@"200"]) {
            NSMutableArray *muNetArr = [[NSMutableArray alloc]initWithCapacity:0];
            [muNetArr addObjectsFromArray:[data objectForKey:@"content"]];
            for (NSDictionary *param in muNetArr) {
                if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"]isEqualToString:[param objectForKey:@"user_id"]]) {
                    New_myApplyListModel * info = [[New_myApplyListModel alloc]init];
                    info.name =  [NSString stringWithFormat:@"%@",[param objectForKey:@"name"]];
                    info.partake_time = [param objectForKey:@"partake_time"];
                    info.user_id = [param objectForKey:@"user_id"];
                    if ([[param objectForKey:@"approved"]isEqualToString:@"3"]) {
                        info.approved = @"0";
                    }
                    else {
                        info.approved = [param objectForKey:@"approved"];
                    }
                    info.block_id = [param objectForKey:@"block_id"];
                    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"]isEqualToString:[param objectForKey:@"user_id"]]) {
                        info.is_create = YES;
                    }
                    else {
                        info.is_create = NO;
                    }
                    [dataSource addObject:info];
                    [muNetArr removeObject:param];
                    break;
                }
            }
            for (NSDictionary *param in muNetArr) {
                New_myApplyListModel * info = [[New_myApplyListModel alloc]init];
                info.name = [NSString stringWithFormat:@"%@（代报名）",[param objectForKey:@"name"]];
                info.partake_time = [param objectForKey:@"partake_time"];
                info.user_id = [param objectForKey:@"user_id"];
                if ([[param objectForKey:@"approved"]isEqualToString:@"3"]) {
                    info.approved = @"0";
                }
                else {
                    info.approved = [param objectForKey:@"approved"];
                }
                info.block_id = [param objectForKey:@"block_id"];
                if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"]isEqualToString:[param objectForKey:@"user_id"]]) {
                    info.is_create = YES;
                }
                else {
                    info.is_create = NO;
                }
                [dataSource addObject:info];
            }
            [_tableView reloadData];
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
            }
        }
        
        if ([dataSource count] == 0) {
            _tableViewNoneView.hidden = NO;
        }
        else {
            _tableViewNoneView.hidden = YES;
        }
    }];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellName = @"cellName";
    New_myApplyListModel *info = [dataSource objectAtIndex:indexPath.row];
    New_myApplyListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellName];
    if (!cell) {
        cell = [[New_myApplyListCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName];
    }
    if (info.is_create == YES) {
        NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:info.name];
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,info.name.length)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,info.name.length)];
        cell.cellName.attributedText = tittle_str;
    }
    else {
        NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:info.name];
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,info.name.length-5)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,info.name.length-5)];
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(info.name.length-5,5)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(info.name.length-4,4)];
        cell.cellName.attributedText = tittle_str;
    }
    cell.cellApplyTime.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:info.partake_time];
    cell.cellStateType = info.approved;//报名状态
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    New_myApplyListModel *info = [dataSource objectAtIndex:indexPath.row];
    for (NSDictionary *nextViewDic12 in [_configDictionary objectForKey:@"block_list"]) {
        for (NSDictionary *nextViewDic13 in [nextViewDic12 objectForKey:@"block_list"]) {
            if ([[nextViewDic13 objectForKey:@"block_id"] isEqualToString:info.block_id]) {
                if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"10"]) {
                    //显示报名状态跟踪
                    NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
                    [ticket setObject:[nextViewDic12 objectForKey:@"name"] forKey:@"name"];
                    [ticket setObject:[nextViewDic12 objectForKey:@"price"] forKey:@"price"];
                    
                    [ticket setObject:[self formatter:@"yyyy.MM.dd HH:mm" ToTime:[nextViewDic12 objectForKey:@"partake_end_time"]] forKey:@"partake_end_time"];
                    [ticket setObject:[nextViewDic12 objectForKey:@"note"] forKey:@"note"];
                    [self writePlistToDucment:@"ticketinfo" With:ticket];
                    SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                    if (info.is_create == YES) {
                        stateVC.isHost = YES;
                    }
                    else {
                        stateVC.isHost = NO;
                    }
                    stateVC.delegate = self;
                    stateVC.isCheck = YES;
                    stateVC.name = info.name;
                    stateVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                    stateVC.meetID = _meeting_id;
                    stateVC.user_id = info.user_id;
                    stateVC.configDic = _configDictionary;
                    stateVC.type = [nextViewDic12 objectForKey:@"type"];
                    stateVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                    [self.navigationController pushViewController:stateVC animated:YES];
                }
            }
        }
    }
}

- (NSMutableAttributedString *)getRequreString:(NSString *)Str withBool:(BOOL)requre
{
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:Str];
    if (requre == YES) { 
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,Str.length-4)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,Str.length-4)];
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(Str.length-4,4)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(Str.length-4,4)];
    }
    else {
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,Str.length)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,Str.length)];
    }
    return tittle_str;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
