//
//  New_myApplyListViewController.h
//  huiyi
//
//  Created by 王振兴 on 15-2-10.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "FatherViewController.h"
#import "TimeAndAddressIpa.h"
@interface New_myApplyListViewController : FatherViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSString *_meeting_id;
}


@property (nonatomic,strong) NSString *shareTitle;
@property (nonatomic,strong) NSArray *photoArray;
@property (nonatomic,strong) NSString *meeting_id;
@property (nonatomic,strong) NSString *blockID;
@property (nonatomic,strong) NSDictionary *configDic;
@property (nonatomic,strong) NSDictionary *configDictionary;
@property (nonatomic,strong) NSString *signUpstate;
@property (nonatomic,strong) TimeAndAddressIpa *timeAndAddIpa;//时间和地址方面的数据源
@property (nonatomic,assign) BOOL meetIsEnd;
@end
