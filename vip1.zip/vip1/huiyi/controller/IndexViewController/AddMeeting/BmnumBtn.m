//
//  BmnumBtn.m
//  huiyi
//
//  Created by 王振兴 on 15-2-11.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "BmnumBtn.h"

@implementation BmnumBtn

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (CGRect)titleRectForContentRect:(CGRect)contentRect{
    return CGRectMake(15, 44-16-20-3, 24, 12);
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect{
    return CGRectMake(15, 44-16-20-3, 26, 16);
}
- (CGRect)backgroundRectForBounds:(CGRect)bounds{
    return CGRectMake(bounds.size.width/2.0f-25/2.0f-5, bounds.size.height/2.0f-14.5/2.0f+1, 25, 11.5);
}
@end
