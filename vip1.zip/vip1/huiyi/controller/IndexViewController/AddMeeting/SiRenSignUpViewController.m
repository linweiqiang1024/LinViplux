//
//  SiRenSignUpViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SiRenSignUpViewController.h"
#import "EnjoyTableViewCell.h"
#import "UserInfoTableViewCell.h"
#import "UIOptionButton.h"
#import "FirstPageControl.h"
#import "UIBottomBtn.h"
#import "MYWebImage.h"
#import "WXApi.h"
#import "Cell.h"
#import "GTMBase64.h"
#import "UIContentView_04.h"
#import "UIImageView+WebCache.h"
#import "HPGrowingTextView.h"
#import "StringToHtml.h"
#import "ChatViewController.h"
#import "UIContentVIew.h"
#import "UIContentView_01.h"
#import "UIContentVIew_02.h"
#import "UIContentView_03.h"
#import "UIContentView_05.h"
#import <MessageUI/MessageUI.h>
#import "CheckInViewController.h"
#import "GuestViewController.h"
#import "DataDownLoadViewController.h"
#import "articleViewController.h"
#import "ScheduleViewController.h"
#import "MapViewController.h"
#import "SignUpTypeViewController.h"
#import "SignUpStatusViewController.h"
#import "BriefViewController.h"
#import "UpViewController.h"
#import "UpInfoViewController.h"
#import "PersonalInfoController.h"
#import "EduExpViewController.h"
#import "LoginViewController.h"
#import "SDShareActionSheet.h"
#import "UIButton+WebCache.h"
#import "WebViewTableViewCell.h"
#import "MoreUserViewController.h"
#import "New_signUpInfoListVC.h"
#import<MessageUI/MFMailComposeViewController.h>

@interface SiRenSignUpViewController ()<UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate,ShareActionDelegate,reloadDelegate,UIAlertViewDelegate,MFMessageComposeViewControllerDelegate,MFMailComposeViewControllerDelegate,HPGrowingTextViewDelegate,SendMessageDelegate>
{
    UIImage *shareIcon;
    NSString *shareTitle;
    NSString *shareMessage;
    NSString *message;
    //==================
    NSMutableArray *_likeArr;
    NSMutableArray *_bmListArr;
    NSMutableArray *_nameArr;
    NSMutableArray *_imageArr;
    NSMutableArray *_gridArr;
    NSMutableArray *_stateArr;
    
    NSDictionary *_configDic;//当前会议配置
    NSDictionary *_nextViewDic;//下一页配置
    NSMutableDictionary *_meetDic;
    
    NSString *_version;
    NSString *_session;
    NSString *_signUpstate;
    BOOL _firstConfig;
    BOOL _configEnd;
    BOOL _infoEnd;
    BOOL _isLike;//是否点赞
    BOOL _bmEnd;
    BOOL _isLoad;//是否已经加载；
    UITableView *newSignUpInfoView;
    NSMutableArray *_optionsArr;
    UIView *headView;
    UIScrollView *optionScrollView;
    UIImageView *headImageView;
    UIView *titleView;
    
    UIContentVIew * meetInfoView;
    UIContentVIew_02 * _timeView;
    UIContentView_01 * _addressView;
    UIContentView_04 * _meetTyepView;
    UIContentView_03 * _meetHostView;
    UIContentView_05 * _costView;
    
    NSMutableArray *_meetTypeMuArr;
    
    UIView *optionView;//插件
    UILabel *_titleLB;
    UILabel *_timeRangeLB;
    UILabel *_sourceLB;
    UILabel *_timeLB;
    UILabel *_shareNumLB;
    UILabel *_readNumLB;
    UILabel *_adressLB;
    UILabel *contentlabel;
    FirstPageControl *_pageControl;
    CGFloat _contentInfoViewHeight;
    CGFloat itemviewheight;
    CGFloat difHeight;
    NSString * _bmCount;
    UIButton *_signUpBtn;
    UIView *contentView;
    UIWebView *mainWebView;
    NSIndexPath *webCellIndexPath;
    SDShareActionSheet *shareSheet;
    BOOL viewdidload;
    
    NSString *_personal_data_sw;//是否显示已报名成员列表状态
    NSString *_createUser_id;//创建该会议的用户id
    NSString *_createUser_name;//创建该会议的用户名
}
@property (nonatomic,strong)NSMutableArray *optionsArr;
@property (nonatomic,retain)FirstPageControl *pageControl;


@end

@implementation SiRenSignUpViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [self RefreshState];
    [MobClick beginLogPageView:@"New_SignUpInfoViewController"];
    
    
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    viewdidload = NO;
    if (shareSheet.isShow) {
        [shareSheet tappedCancel];
    }
    [MobClick endLogPageView:@"New_SignUpInfoViewController"];
}

- (void)createRightNavItme
{
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth-44-5, self.navheight, 44, 44);
    rightBtn.adjustsImageWhenHighlighted = NO;
    [rightBtn setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(navRightBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    rightBtn.tag = 2;
    [self.view addSubview:rightBtn];
    
}
- (void)navRightBtnClick
{
    if(!shareSheet.isShow){
        shareSheet = [[SDShareActionSheet alloc]initWithTitle:@"" delegate:self];
        [shareSheet showInView:self.view];
    }
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}
#pragma mark --- shareDelegate
- (void)cancelClicked
{
    [shareSheet tappedCancel];
}
- (void)nextClicked:(id)btn
{
//    UIButton *button = (UIButton * )btn;
//    switch (button.tag -2000) {
//        case 0:
//            //微信朋友
//            if(![WXApi isWXAppInstalled])
//            {
//                UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"您没有安装微信客户端" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
//                [av show];
//            }else{
//                [[ShareEngine sharedInstance] sendAppContentWithTitle:shareTitle Message:shareMessage WithUrl:[NSString stringWithFormat:@"http://www.huiyiabc.com/meet/meetinginfo?meeting_id=%@",_meetID] Icon:shareIcon WithScene:weChat];
//            }
//            break;
//        case 1:
//            //微信朋友圈
//            if(![WXApi isWXAppInstalled])
//            {
//                UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"您没有安装微信客户端" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
//                [av show];
//            }else{
//                
//                [[ShareEngine sharedInstance] sendAppContentWithTitle:shareTitle Message:shareMessage WithUrl:[NSString stringWithFormat:@"http://www.huiyiabc.com/meet/meetinginfo?meeting_id=%@",_meetID] Icon:shareIcon WithScene:weChatFriend];
//            }
//            break;
//        case 2:
//            //短息
//            [self showSMSPicker];
//            break;
//        case 3:
//            //链接
//            [Dialog toastCenter:@"该会议的地址已经复制到剪切板"];
//            [[UIPasteboard generalPasteboard] setPersistent:YES];
//            [[UIPasteboard generalPasteboard] setString:[NSString stringWithFormat:@"http://www.huiyiabc.com/meet/meetinginfo?meeting_id=%@",_meetID]];
//            
//            break;
//        default:
//            break;
//    }
}
-(void)showSMSPicker {
    //  The MFMessageComposeViewController class is only available in iPhone OS 4.0 or later.
    //  So, we must verify the existence of the above class and log an error message for devices
    //  running earlier versions of the iPhone OS. Set feedbackMsg if device doesn't support
    //      MFMessageComposeViewController API.
    Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
    if (messageClass != nil) {
        // Check whether the current device is configured for sending SMS messages
        if ([messageClass canSendText]) {
            [self displaySMSComposerSheet];
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"设备没有短信功能" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            
        }
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"iOS版本过低,iOS4.0以上才支持程序内发送短信" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
    }
}
-(void)displaySMSComposerSheet
{
    MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
    picker.messageComposeDelegate = self;
    NSString *absUrl = [NSString stringWithFormat:@"http://www.huiyiabc.com/meet/meetinginfo?meeting_id=%@",_meetID];
    picker.body=[NSString stringWithFormat:@"欢迎了解本次大会%@",absUrl];
    
    [self presentViewController:picker animated:YES completion:^{
        
    }];
    
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result {
    switch (result)
    {
        case MessageComposeResultCancelled:
            //        LOG_EXPR(@"Result: SMS sending canceled");
            if (shareSheet.isShow) {
                [shareSheet tappedCancel];
            }
            break;
        case MessageComposeResultSent:
            //        LOG_EXPR(@"Result: SMS sent");
            break;
        case MessageComposeResultFailed:{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"短息发送失败" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
        }
            
            break;
        default:
            //        LOG_EXPR(@"Result: SMS not sent");
            break;
    }
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}
- (void)compareMeetTpye:(NSArray *)arr
{
    if (arr.count == 1) {
        _meetTyepView.meetTypeBtn1.hidden = NO;
        for (NSString *meetType in arr) {
            if ([meetType isEqualToString:@"1"]) {
                [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
                [_meetTyepView.meetTypeBtn1 setTitle:@"聚餐" forState:UIControlStateNormal];
            }
            if ([meetType isEqualToString:@"2"]) {
                [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
                [_meetTyepView.meetTypeBtn1 setTitle:@"娱乐" forState:UIControlStateNormal];
            }
            if ([meetType isEqualToString:@"3"]) {
                [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
                [_meetTyepView.meetTypeBtn1 setTitle:@"运动" forState:UIControlStateNormal];
            }
        }
    }
    if (arr.count == 2) {
        NSString *type1 = [arr objectAtIndex:0];
        NSString *type2 = [arr objectAtIndex:1];
        if ([type1 isEqualToString:@"1"]) {
            [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn1 setTitle:@"聚餐" forState:UIControlStateNormal];
        }
        if ([type1 isEqualToString:@"2"]) {
            [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn1 setTitle:@"娱乐" forState:UIControlStateNormal];
        }
        if ([type1 isEqualToString:@"3"]) {
            [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn1 setTitle:@"运动" forState:UIControlStateNormal];
        }
        if ([type2 isEqualToString:@"1"]) {
            [_meetTyepView.meetTypeBtn2 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn2 setTitle:@"聚餐" forState:UIControlStateNormal];
        }
        if ([type2 isEqualToString:@"2"]) {
            [_meetTyepView.meetTypeBtn2 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn2 setTitle:@"娱乐" forState:UIControlStateNormal];
        }
        if ([type2 isEqualToString:@"3"]) {
            [_meetTyepView.meetTypeBtn2 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn2 setTitle:@"运动" forState:UIControlStateNormal];
        }
        
        _meetTyepView.meetTypeBtn1.hidden = NO;
        _meetTyepView.meetTypeBtn2.hidden = NO;
    }
    if (arr.count == 3) {
        NSString *type1 = [arr objectAtIndex:0];
        NSString *type2 = [arr objectAtIndex:1];
        NSString *type3 = [arr objectAtIndex:2];
        if ([type1 isEqualToString:@"1"]) {
            [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn1 setTitle:@"聚餐" forState:UIControlStateNormal];
        }
        if ([type1 isEqualToString:@"2"]) {
            [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn1 setTitle:@"娱乐" forState:UIControlStateNormal];
        }
        if ([type1 isEqualToString:@"3"]) {
            [_meetTyepView.meetTypeBtn1 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn1 setTitle:@"运动" forState:UIControlStateNormal];
        }
        if ([type2 isEqualToString:@"1"]) {
            [_meetTyepView.meetTypeBtn2 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn2 setTitle:@"聚餐" forState:UIControlStateNormal];
        }
        if ([type2 isEqualToString:@"2"]) {
            [_meetTyepView.meetTypeBtn2 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn2 setTitle:@"娱乐" forState:UIControlStateNormal];
        }
        if ([type2 isEqualToString:@"3"]) {
            [_meetTyepView.meetTypeBtn3 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn3 setTitle:@"运动" forState:UIControlStateNormal];
        }
        if ([type3 isEqualToString:@"1"]) {
            [_meetTyepView.meetTypeBtn3 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn3 setTitle:@"聚餐" forState:UIControlStateNormal];
        }
        if ([type3 isEqualToString:@"2"]) {
            [_meetTyepView.meetTypeBtn3 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn3 setTitle:@"娱乐" forState:UIControlStateNormal];
        }
        if ([type3 isEqualToString:@"3"]) {
            [_meetTyepView.meetTypeBtn3 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
            [_meetTyepView.meetTypeBtn3 setTitle:@"运动" forState:UIControlStateNormal];
        }
        
        _meetTyepView.meetTypeBtn1.hidden = NO;
        _meetTyepView.meetTypeBtn2.hidden = NO;
        _meetTyepView.meetTypeBtn3.hidden = NO;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createRightNavItme];
    _createUser_name = @" ";
    _createUser_id = @" ";
    _personal_data_sw = @" ";
    itemviewheight = 0;
    viewdidload = YES;
    difHeight = 0;//数据与初始化ui size.height大小的差
    _bmListArr = [[NSMutableArray alloc]initWithCapacity:0];
    _likeArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    _session=[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"];
    self.titlelabel.text = _meetTitle;
    
    _meetTypeMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    [_meetTypeMuArr addObject:@"0"];
    [_meetTypeMuArr addObject:@"0"];
    [_meetTypeMuArr addObject:@"0"];
    _version = @"0";
    _meetDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    _nameArr = [[NSMutableArray alloc]initWithCapacity:0];
    _imageArr = [[NSMutableArray alloc]initWithCapacity:0];
    _gridArr = [[NSMutableArray alloc]initWithCapacity:0];
    _stateArr = [[NSMutableArray alloc]initWithCapacity:0];
    [_imageArr addObjectsFromArray:@[@"meetInfo1@2x",@"meetInfo2@2x",@"meetInfo3@2x",@"meetInfo4@2x",@"meetInfo5@2x"]];
    [_nameArr addObjectsFromArray:@[@"大会简介",@"日程",@"地图",@"签到",@"资料下载",@"嘉宾"]];
    self.view.backgroundColor = [UIColor whiteColor];
    self.titlelabel.text = @"详情";
    _optionsArr = [[NSMutableArray alloc]initWithCapacity:0];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 463+44)];
    BackGround16Color(headView, @"#eeeeee");
    
    headView.backgroundColor = [UIColor clearColor];
    UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line, @"#c8c7cc");
    [headView  addSubview:line];
    
    
    headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0.5, ScreenWidth, 115)];
    headImageView.backgroundColor = [UIColor whiteColor];
    headImageView.contentMode = UIViewContentModeScaleAspectFit;
    [headView addSubview:headImageView];
    
    titleView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headImageView.frame), ScreenWidth, 128)];
    BackGroundColor(titleView, whiteColor);
    [headView addSubview:titleView];
    
    UILabel *line1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line1, @"#c8c7cc");
    [titleView  addSubview:line1];
    
    
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 10.5, ScreenWidth-30, 32.5)];
    _titleLB.font = YHUI(17);
    _titleLB.numberOfLines = 0;
    //_titleLB.textColor = [UIColor colorWithHexString:@"#8e8e8e"];
    _titleLB.lineBreakMode = NSLineBreakByCharWrapping;
    _titleLB.backgroundColor = [UIColor clearColor];
    [titleView addSubview:_titleLB];
    
    _timeLB = [[UILabel alloc]initWithFrame:CGRectMake(15, CGRectGetMaxY(_titleLB.frame)+25, 40, 13)];
    _timeLB.font = YHUI(12);
    _timeLB.textColor = [UIColor colorWithHexString:@"#8e8e8e"];
    _timeLB.backgroundColor = [UIColor clearColor];
    [titleView addSubview:_timeLB];
    
    
    
    _readNumLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_timeLB.frame) + 6, CGRectGetMaxY(_sourceLB.frame)+5, 150, 13)];
    _readNumLB.backgroundColor = [UIColor clearColor];
    _readNumLB.font = YHUI(12);
    _readNumLB.textColor = [UIColor colorWithHexString:@"#8e8e8e"];
    [titleView addSubview:_readNumLB];
    

    
    meetInfoView = [[UIContentVIew alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(titleView.frame)+10, ScreenWidth, 238)];
    meetInfoView.backgroundColor = [UIColor whiteColor];
    [headView addSubview:meetInfoView];
    
    _timeView = [[UIContentVIew_02 alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 69)];
    _timeView.nameLB.text = @"活动时间";
    [meetInfoView addSubview:_timeView];
    
    _addressView = [[UIContentView_01 alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_timeView.frame), ScreenWidth, 41)];
    _addressView.backgroundColor = [UIColor clearColor];
    _addressView.nameLB.text = @"地点";
    [meetInfoView addSubview:_addressView];
    
    _meetTyepView = [[UIContentView_04 alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_addressView.frame), ScreenWidth, 41)];
    _meetTyepView.backgroundColor = [UIColor clearColor];
    
    _meetTyepView.nameLB.text = @"活动类型";
    [meetInfoView addSubview:_meetTyepView];
    
    _meetHostView = [[UIContentView_03 alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_meetTyepView.frame), ScreenWidth, 41)];
    _meetHostView.delegate = self;
    _meetHostView.backgroundColor = [UIColor clearColor];
    _meetHostView.nameLB.text = @"发起者";
    
    [meetInfoView addSubview:_meetHostView];
    
    _costView  = [[UIContentView_05 alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_meetHostView.frame), ScreenWidth, 41)];
    _costView.backgroundColor = [UIColor clearColor];
    _costView.nameLB.text = @"费用";
    [meetInfoView addSubview:_costView];
    
    
    optionView = [[UIView alloc]initWithFrame:CGRectMake(0,CGRectGetMaxY(meetInfoView.frame)+10, ScreenWidth, 189)];
    UILabel *line4 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line4, @"#c8c7cc");
    [optionView  addSubview:line4];
    
    UILabel *line5 = [[UILabel alloc]initWithFrame:CGRectMake(0, 188.5, ScreenWidth, 0.5)];
    BackGround16Color(line5, @"#c8c7cc");
    [optionView  addSubview:line5];
    
    BackGroundColor(optionView, whiteColor);
    
    optionScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 188)];
    optionScrollView.delegate = self;
    optionScrollView.backgroundColor = [UIColor clearColor];
    [optionView addSubview:optionScrollView];
    [headView addSubview:optionView];
    
    if (!contentView) {
        contentView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(optionView.frame)+10, ScreenWidth, 44)];
        [headView addSubview:contentView];
        UIView *sectionHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0.5, ScreenWidth, 43)];
        sectionHeadView.backgroundColor = [UIColor whiteColor];
        [contentView addSubview:sectionHeadView];
        
        UILabel *headLineLB  = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [sectionHeadView  addSubview:headLineLB];
        
        UILabel *contentTitle = [[UILabel alloc]initWithFrame:CGRectMake(11, 0.5, ScreenWidth, 43)];
        contentTitle.font = YHUI(16);
        contentTitle.text = @"会议详情";
        contentTitle.backgroundColor = [UIColor clearColor];
        [sectionHeadView addSubview:contentTitle];
        
        UILabel *endLineLB  = [[UILabel alloc]initWithFrame:CGRectMake(0, 43+0.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [sectionHeadView  addSubview:endLineLB];
        
    }
    if (!mainWebView) {
        mainWebView = [[UIWebView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(contentView.frame), ScreenWidth, 0)];
        mainWebView.delegate = self;
        //[mainWebView setScalesPageToFit:YES];
        mainWebView.scrollView.bounces = NO;
        mainWebView.scrollView.scrollEnabled = NO;
        [headView addSubview:mainWebView];
        
    }
    
    contentlabel = [[UILabel alloc]initWithFrame:CGRectMake(0, headView.frame.size.height-10, ScreenWidth, 0.5)];
    BackGround16Color(contentlabel, @"#c8c7cc");
    [headView addSubview:contentlabel];
    NSMutableArray *_imageArrs;
    [_imageArrs addObjectsFromArray:@[@"meetInfo1@2x",@"meetInfo2@2x",@"meetInfo3@2x",@"meetInfo4@2x",@"meetInfo5@2x"]];
    newSignUpInfoView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight - 64-50) style:UITableViewStyleGrouped];
    newSignUpInfoView.sectionHeaderHeight = 12;
    //    newSignUpInfoView.sectionFooterHeight = 0;
    newSignUpInfoView.delegate = self;
    newSignUpInfoView.dataSource = self;
    newSignUpInfoView.backgroundColor = [UIColor clearColor];
    newSignUpInfoView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:newSignUpInfoView];
    newSignUpInfoView.tableHeaderView = headView;
    _signUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _signUpBtn.frame = CGRectMake(0,  ScreenHeight-50, 320, 50);
    _signUpBtn.backgroundColor = [UIColor colorWithHexString:@"#4797FB"];
    //[_signUpBtn setTitle:@"立即报名" forState:UIControlStateNormal];
    [_signUpBtn addTarget:self action:@selector(signUpBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view  addSubview:_signUpBtn];
    [self.view bringSubviewToFront:_signUpBtn];
    
    [self getDBMeetInfo];

    // Do any additional setup after loading the view.
}
- (void)sentMessage{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];

        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    
    NSString *user_id = _createUser_id;
    ChatViewController* groupVC = [[ChatViewController alloc] init];
    groupVC.conversationType = ConversationType_PRIVATE;
    groupVC.navigationController.navigationBarHidden = NO;
    groupVC.targetId = user_id;
    groupVC.chatUserName = _createUser_name;
    [self.navigationController pushViewController:groupVC animated:YES];

}
- (void)creatPluginUI:(NSArray *)arr;
{
    if (!optionScrollView) {
        optionScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0)];
        optionScrollView.delegate = self;
        optionScrollView.backgroundColor = [UIColor clearColor];
        [optionView addSubview:optionScrollView];
    }
    
    
    if (arr.count != 0) {
        UILabel *line4 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(line4, @"#c8c7cc");
        [optionView  addSubview:line4];
        int pages = [arr count]/8+1;
        int maxRow = 2;
        int maxCol = 4;
        CGFloat itemWidth = 80;
        CGFloat itemHeight = 80;
        
        if (arr.count>8) {
            itemviewheight = 188;
        }else if (arr.count>4&&arr.count<=8)
        {
            itemviewheight = 168;
        }else if (arr.count<=4&&arr.count>0){
            itemviewheight = 98;
            
        }
        else{
            
            itemviewheight = 0;
            
        }
        
        
        //headView.frame
        
        optionView.frame = CGRectMake(optionView.frame.origin.x, optionView.frame.origin.y, optionView.frame.size.width,itemviewheight+1);
        [contentView setNeedsLayout];
        [headView setNeedsLayout];
        [newSignUpInfoView beginUpdates];
        [newSignUpInfoView setTableHeaderView:headView];
        [newSignUpInfoView endUpdates];
        optionScrollView.frame = CGRectMake(optionScrollView.frame.origin.x, optionScrollView.frame.origin.y, optionScrollView.frame.size.width,itemviewheight);
        [optionScrollView setNeedsLayout];
        optionScrollView.contentSize = CGSizeMake(pages*ScreenWidth, itemviewheight);
        optionScrollView.pagingEnabled = YES;
        optionScrollView.showsHorizontalScrollIndicator = NO;
        optionScrollView.showsVerticalScrollIndicator = NO;
        for (UIView *view in optionScrollView.subviews) {
            [view removeFromSuperview];
        }
        for(int page =0;page<pages;page++){
            for (int row = 0; row < maxRow; row++) {
                for (int col = 0; col < maxCol; col++) {
                    if ((row * maxCol+page*maxCol*(maxRow-1) + col)<arr.count) {
                        gridInfo *info = [_gridArr objectAtIndex:(row * maxCol+page*maxCol*(maxRow-1) + col)];
                        UIOptionButton *button = [UIOptionButton buttonWithType:UIButtonTypeCustom];
                        [button setBackgroundColor:[UIColor clearColor]];
                        [button setFrame:CGRectMake(col * itemWidth+page*ScreenWidth, row * itemHeight, itemWidth, itemHeight)];
                        [button sd_setImageWithURL:[NSURL URLWithString:info.urlStr]forState:UIControlStateNormal];
                        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                        [button setTitle:info.title forState:UIControlStateNormal];
                        //
                        button.tag = (row * maxCol+page*maxCol*(maxRow-1) + col);
                        [button addTarget:self action:@selector(pluginSelected:) forControlEvents:UIControlEventTouchUpInside];
                        
                        [optionScrollView addSubview:button];
                        [button setNeedsLayout];
                    }else{
                        break;
                    }
                    NSLog(@"%D",row * maxCol+page*maxCol*(maxRow-1) + col);
                }
            }
        }
        
        if (pages != 1) {
            _pageControl = [[FirstPageControl alloc]initWithFrame:CGRectMake(120, 188 - 30, 100, 20)];
            _pageControl.dotColorCurrentPage = [UIColor colorWithHexString:@"#6e6e6e"];
            _pageControl.dotColorOtherPage = [UIColor colorWithHexString:@"#cfcfcf"];
            _pageControl.numberOfPages = pages;
            _pageControl.currentPage = 0;
            [optionView addSubview:_pageControl];
        }
        UILabel *line5 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(optionView.frame)-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line5, @"#c8c7cc");
        [optionView  addSubview:line5];
        
    }else{
        optionView.frame = CGRectMake(0,CGRectGetMaxY(meetInfoView.frame), ScreenWidth, 0);;
        for (UIView *view in optionView.subviews) {
            [view removeFromSuperview];
        }
        headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height-188+10);
        contentView.frame = CGRectMake(0, CGRectGetMaxY(optionView.frame)+10, ScreenWidth, 44);
        mainWebView.frame = CGRectMake(0, CGRectGetMaxY(contentView.frame)+10, ScreenWidth, _contentInfoViewHeight);
        [newSignUpInfoView beginUpdates];
        [newSignUpInfoView setTableHeaderView:headView];
        [newSignUpInfoView endUpdates];
        
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth = self.view.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    _pageControl.currentPage = page;
    
}
#define HeadViewHeight 43.5

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 66;
    }
    if (indexPath.section == 1) {
        if (indexPath.row==_bmListArr.count) {
            if(_bmListArr.count==10){
                return 60;
            }else
                return 0;
        }else{
            return 52;
        }
    }
    if (indexPath.section == 3) {
        return 0
        ;
    }
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    if (section == 2) {
        return 96;
    }else{
        return 43.5;
    }
    return 0;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 2) {
        UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, -1, ScreenWidth, 96)];
        //footView.backgroundColor = [UIColor whiteColor];
        BackGround16Color(footView, @"#eeeeee");
        
        
        
        UILabel *line2 = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, ScreenWidth, 0.5)];
        BackGround16Color(line2, @"#c8c7cc");
        [footView  addSubview:line2];
        UIView *bgview = [[UIView alloc]initWithFrame:CGRectMake(0, 10.5, ScreenWidth, 76)];
        bgview.backgroundColor = [UIColor whiteColor];
        [footView addSubview:bgview];
        
        UIBottomBtn *shareButton = [UIBottomBtn buttonWithType:UIButtonTypeCustom];
        shareButton.frame = CGRectMake(15, 20, 295, 36);
        [shareButton setBackgroundImage:[UIImage imageNamed:@"shareButton"] forState:UIControlStateNormal];
        [shareButton addTarget:self action:@selector(navRightBtnClick) forControlEvents:UIControlEventTouchUpInside];
        shareButton.titleLabel.font = YHUI(16);
        [shareButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [shareButton setTitle:@"分享给好友" forState:UIControlStateNormal];
        [bgview addSubview:shareButton];
        
        UILabel *line3 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(shareButton.frame)+20, ScreenWidth, 0.5)];
        BackGround16Color(line3, @"#c8c7cc");
        [bgview  addSubview:line3];
        
        return footView;
        
    }else{
        UIView *sectionHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, HeadViewHeight)];
        sectionHeadView.backgroundColor = [UIColor whiteColor];
        UILabel *headLineLB  = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [sectionHeadView  addSubview:headLineLB];
        
        UILabel *endLineLB  = [[UILabel alloc]initWithFrame:CGRectMake(0, HeadViewHeight-0.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [sectionHeadView  addSubview:endLineLB];
        
        UILabel *headTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(11, 0.5, ScreenWidth, HeadViewHeight-1)];
        headTitleLB.font = YHUI(16);
        headTitleLB.backgroundColor = [UIColor clearColor];
        UIButton * likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        likeBtn.frame=CGRectMake(ScreenWidth-54, 11, 37, 23);
        [likeBtn addTarget:self action:@selector(likeBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        if (_isLike) {
            likeBtn.selected = YES;
        }else{
            likeBtn.selected = NO;
        }
        [likeBtn setImage:[UIImage imageNamed:@"zan-icon02"] forState:UIControlStateNormal];
        [likeBtn setImage:[UIImage imageNamed:@"zan-icon01"] forState:UIControlStateSelected];
        
        switch (section) {
                //        case 0:
                //            headTitleLB.text = @"会议详情";
                //            break;
            case 0:
                headTitleLB.text = [NSString stringWithFormat:@"我喜欢(%d)",_likeArr.count  ];
                [sectionHeadView addSubview:likeBtn];
                break;
            case 1:
                headTitleLB.text = [NSString stringWithFormat:@"已报名(%@)",_bmCount ];
                break;
            default:
                break;
        }
        [sectionHeadView addSubview:headTitleLB];
        return sectionHeadView;
    }
    return nil;
}
#pragma mark -
#pragma mark 报名配置接口
-(void)getMeetConfigData
{
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"partake_%@",_meetID]] length]!=0) {
        _version = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"partake_%@",_meetID]];
    }else{
        _version = @"0";
    }
    NSDictionary *dic;
    dic = @{@"meeting_id": _meetID,@"partake_version":_version};
    [MyDataService postMeetingconfig:dic callback:^(id data) {
        NSLog(@"%@",data);
        
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"]floatValue]==200) {
                [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"firstConfig"];
                _version = [[data objectForKey:@"content"] objectForKey:[NSString stringWithFormat:@"version"]];
                [[NSUserDefaults standardUserDefaults] setObject:_version forKey:[NSString stringWithFormat:@"partake_%@",_meetID]];
                [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                if ([[[data objectForKey:@"content"] objectForKey:@"state"] isEqualToString:@"1"]) {
                    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@config",_meetID]];
                    [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"%@config",_meetID]];
                    
                    NSArray *arr = [NSArray arrayWithArray:[[data objectForKey:@"content"] objectForKey:@"block_list"]];
                    NSMutableArray *mutArr = [NSMutableArray array];
                    for (NSDictionary *dic in arr) {
                        if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                            [mutArr addObject:dic];
                        }
                    }
                    [[data objectForKey:@"content"] setObject:mutArr forKey:@"block_list"];
                    
                    _configDic = [data objectForKey:@"content"];
                    [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isCache"];//当配置文件发生改变时  以后的缓存全都废弃 1发生了改变 0没有发生改变  （没有他  当配置文件发生改变时  后面的页面会宕掉）
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                }else{
                    //读文件
                    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isCache"];
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                    
                    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@config",_meetID]];
                    
                    NSMutableDictionary *configDic = [NSMutableDictionary dictionaryWithDictionary:[[dataStr JSONValue] objectForKey:@"content"]];
                    
                    NSArray *arr = [NSArray arrayWithArray:[configDic objectForKey:@"block_list"]];
                    NSMutableArray *mutArr = [NSMutableArray array];
                    for (NSDictionary *dic in arr) {
                        if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                            [mutArr addObject:dic];
                        }
                    }
                    [configDic setObject:mutArr forKey:@"block_list"];
                    
                    _configDic = configDic;
                    
                }
                if ([[_configDic objectForKey:@"type"] isEqualToString:@"4"]) {
                    NSDictionary *dic1 = @{@"meeting_id": _meetID,@"block_id": [_configDic objectForKey:@"block_id"]};
                    [MyDataService postPartakeState:dic1 callback:^(id data) {
                        NSLog(@"%@",data);//0未填,1不完整,2完整,3可选的未填，4可选的不完整
                        _configEnd = YES;
                        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                                NSString *keyStr = [NSString stringWithFormat:@"%@_%@_meetInfoState",_session,[_configDic objectForKey:@"block_id"]];
                                [[NSUserDefaults standardUserDefaults] setObject:[_configDic objectForKey:@"block_id"] forKey:@"block_id"];
                                
                                [[NSUserDefaults standardUserDefaults] setObject:[[data objectForKey:@"content"] objectForKey:@"state"] forKey:@"state"];
                                [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                                
                                [[DBManager sharedInstance] deleteToPublicOneData:keyStr];
                                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:keyStr];
                                _signUpstate = [[data objectForKey:@"content"] objectForKey:@"state"];//1尚未报名 5完成报名 4报名完成等待审核 3审核未通过 2审核通过等待回执 10报名截止未报名 11报名截止已报名
                                
                                if ([_signUpstate isEqualToString:@"10"]) {
                                    _bmEnd = YES;
                                }else{
                                    _bmEnd = NO;
                                }
                                if ([[[data objectForKey:@"content"] objectForKey:@"list"]isKindOfClass:[NSArray class]]&&[[data objectForKey:@"content"] count]!=0)
                                {
                                    NSArray *arr = [[data objectForKey:@"content"] objectForKey:@"list"];
                                    for (int i = 0; i<[[_configDic objectForKey:@"block_list"] count]; i++) {
                                        for (int j = 0; j<arr.count; j++) {
                                            if ([[[[_configDic objectForKey:@"block_list"] objectAtIndex:i] objectForKey:@"block_id"]isEqualToString:[[arr objectAtIndex:j] objectForKey:@"block_id"]]) {
                                                if (![[[arr objectAtIndex:j] objectForKey:@"state"] isEqualToString:@"0"]) {
                                                    _blockID = [[arr objectAtIndex:j] objectForKey:@"block_id"];
                                                }
                                            }
                                        }
                                    }
                                }

                            }
                        }
                    }];
                }
            }
        }
    }];
}

#pragma mark -
#pragma mark 会议插件
- (void)likeBtnClicked:(UIButton *)btn
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];

        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    NSString *uid = [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"];
    NSString *status ;
    if (_isLike == YES) {
        status = @"0";
    }else {
        status = @"1";
    }
    NSDictionary *dic = @{@"meeting_id":_meetID,@"user_id":uid,@"like_state":status};
   
        [MyDataService postMeetingLikeAdd:dic callback:^(id data) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"]isEqualToString:@"200"]) {
                btn.selected = !btn.selected;
        
                _isLike = !_isLike;
                NSString *icoUrl;
                if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"ico_file"] length]==0) {
                    icoUrl = @"";
                }else{
                    icoUrl = [[NSUserDefaults standardUserDefaults]objectForKey:@"ico_file"];
                }
                NSString *name =  [[NSUserDefaults standardUserDefaults] objectForKey:@"name"];
                
                if ([status isEqualToString:@"0"]) {
                    for (NSDictionary *dic  in _likeArr) {
                        NSString *myName = [dic objectForKey:@"name"];
                        if ([myName isEqualToString:name]) {
                            [_likeArr removeObject:dic];
                        }
                    }
                }else{
                    NSDictionary *dic = @{@"name":name,@"ico_file":icoUrl};
                    [_likeArr addObject:dic];
                }

                [newSignUpInfoView reloadData];
            }
            //            if ([[data objectForKey:@"code"]isEqualToString:@"800101"]) {
            //                [Dialog toastCenter:@"已赞"];
            //                NSLog(@"已赞");
            //            }
        }];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex ==1) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];

        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        [self presentViewController:nav animated:YES completion:^{
        }];
        
    }
}
- (BOOL)authority:(NSString *)authority
{
    int type = [authority integerValue];
    switch (type) {
        case 7:{
            return YES;
        }
            
            break;
        case 6:{
            if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]!=0) {
                return YES;
            }
        }
        case 4:
            if ([_signUpstate isEqualToString:@"5"]||[_signUpstate isEqualToString:@"2"]||[_signUpstate isEqualToString:@"11"]) {
                return YES;
            }else{
                return NO;
            }
            break;
        default:
            return NO;
            break;
            
    }
    return NO;
}
- (void)authorityAlertView:(int)status
{
    switch (status) {
        case 1:{
            
        }
            break;
        case 3:{
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"改插件登录后可以查看" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [av show];
        }
            break;
        case 7:{
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"改插件报名后才可以查看" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [av show];
        }
            break;
        default:
            break;
    }
}

- (void)pluginSelected:(UIOptionButton *)btn
{
    //    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]!=0) {
    gridInfo *info = (gridInfo *)[_gridArr objectAtIndex:btn.tag];
    if (info.authority) {
        if ([info.pluginType isEqualToString:@"map"]) {//地图
            MapViewController *mapVC = [[MapViewController alloc]init];
            mapVC.meetID = _meetID;
            mapVC.navTitle = info.title;
            mapVC.pluginID = info.pluginID;
            mapVC.pluginType = info.pluginType;
            [self.navigationController pushViewController:mapVC animated:YES];
        }
        
        if ([info.pluginType isEqualToString:@"schedule"]) {//日程
            ScheduleViewController *schVC = [[ScheduleViewController alloc]init];
            schVC.navTitle = info.title;
            schVC.meetID = _meetID;
            schVC.pluginType = info.pluginType;
            schVC.pluginID = info.pluginID;
            [self.navigationController pushViewController:schVC animated:YES];
            
        }
        if ([info.pluginType isEqualToString:@"section"]) {//列表
            New_signUpInfoListVC *listWebVC = [[New_signUpInfoListVC alloc]init];
            listWebVC.meetint_id = _meetID;
            listWebVC.plugin_id = info.pluginID;
            listWebVC.titleName = info.title;
            listWebVC.plugin_type = info.pluginType;
            [self.navigationController pushViewController:listWebVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"article"]) {//图文
            articleViewController *articleVC = [[articleViewController alloc]init];
            articleVC.titleStr = info.title;
            articleVC.meetID = _meetID;
            articleVC.pluginID = info.pluginID;
            articleVC.pluginType = @"article";
            [self.navigationController pushViewController:articleVC animated:YES];
        }
        
        if ([info.pluginType isEqualToString:@"articleURL"]) {//图文URL
            articleViewController *articleVC = [[articleViewController alloc]init];
            articleVC.titleStr = info.title;
            articleVC.meetID = _meetID;
            articleVC.pluginID = info.pluginID;
            articleVC.pluginType = @"articleURL";
            [self.navigationController pushViewController:articleVC animated:YES];
        }
        
        if ([info.pluginType isEqualToString:@"download"]) {//资料下载
            DataDownLoadViewController *dataVC = [[DataDownLoadViewController alloc]init];
            dataVC.navTitle = info.title;
            dataVC.meeting_id = _meetID;
            dataVC.plugin_id = info.pluginID;
            [self.navigationController pushViewController:dataVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"guests"]) {//嘉宾
            GuestViewController *gvc = [[GuestViewController alloc]init];
            gvc.navTitle = info.title;
            gvc.meetID = _meetID;
            gvc.pluginID = info.pluginID;
            [self.navigationController pushViewController:gvc animated:YES];
        }
        if ([info.pluginType isEqualToString:@"signIn"]) {//签到
            CheckInViewController *CheckVC = [[CheckInViewController alloc]init];
            CheckVC.navTitle = info.title;
            CheckVC.meetID = _meetID;
            [self.navigationController pushViewController:CheckVC animated:YES];
        }
    }else{
        [self authorityAlertView:[info.authoritystatus intValue]];
        
    }
    //    }else{
    //        LoginViewController *loginVc = [[LoginViewController alloc]init];
    //        loginVc.fromSignVC = YES;
    //        loginVc.isPush = YES;
    //        loginVc.delegate = self;
    //        [self presentViewController:loginVc animated:YES completion:^{
    //
    //
    //        }];
    //    }
    
}
- (void)reload
{
    [self getMeetConfigData];
}
- (void)RefreshState
{
    NSDictionary *dic = @{@"meeting_id": _meetID};
    [MyDataService postMeetingInfo:dic callback:^(id data) {
        _infoEnd = YES;
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            //[self hideHUD];
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"]floatValue] ==200) {
                NSLog(@"%@",data);
                [_signUpBtn setTitle:[[data objectForKey:@"content"]objectForKey:@"singup_state_txt"] forState:UIControlStateNormal];
                [_signUpBtn.layer setNeedsDisplay];
                
            }
        }
    }];
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"block_id"] length]!=0) {
        NSDictionary *dic = @{@"meeting_id": _meetID,@"block_id":[[NSUserDefaults standardUserDefaults] objectForKey:@"block_id"]};
        [MyDataService postPartakeState:dic callback:^(id data) {
            _infoEnd = YES;
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                //[self hideHUD];
                NSLog(@"%@",data);
                if ([[data objectForKey:@"code"]floatValue] ==200) {
                    NSLog(@"%@",data);
                    _signUpstate = [[data objectForKey:@"content"] objectForKey:@"state"];//1尚未报名 5完成报名 4报名完成等待审核 3审核未通过 2审核通过等待回执 10报名截止未报名 11报名截止已报名
                    [[NSUserDefaults standardUserDefaults] setObject:[[data objectForKey:@"content"] objectForKey:@"state"] forKey:@"state"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                }else{
                    
                }
            }
        }];
        
    }
}
- (void)getNetData
{
    _isLoad = YES;
    [self getMeetConfigData];
    [self getMeetInfoData];
}
#pragma mark -
#pragma mark UITableViewDataSource and UITableViewDelegate Methods
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 1||section == 2) {
        return 1;
    }
    else{
        return 10;
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 3;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    switch (section) {
            //        case 0:
            //            return 1;
            //            break;
        case 0:
            if (_likeArr.count==0) {
                return 0;
            }else{
                return 1;
            }
            break;
        case 1:
            if (_bmListArr.count==10) {
                return _bmListArr.count+1;
            }else{
                return _bmListArr.count;
            }
            
            break;
            break;
        case 2:
            return 0;
            break;
        default:
            break;
    }
    return 0;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier2 = @"supportCell";
    
    if (indexPath.section == 0) {
        EnjoyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier2];
        if (cell == nil) {
            cell = [[EnjoyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier2];
            cell.enjoyUsers = _likeArr;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
    if (indexPath.section == 1) {
        if(indexPath.row <_bmListArr.count){
            //            UserInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier3];
            //            if (cell == nil) {
            UserInfoTableViewCell *cell;
            if ([_personal_data_sw isEqualToString:@"0"]) {
                cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil andIsShowCompany:NO];
            }
            else if ([_personal_data_sw isEqualToString:@"1"]){
                cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil andIsShowCompany:YES];
            }
            else{
                cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil andIsShowCompany:NO];
            }
            
            [MYWebImage OneImageView:cell.headImageView SetImageWithURL:[[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"ico_file"] PlaceHolderImageName:@"touxiang80" CacheOrNot:YES] ;
            cell.nameLB.text = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"name"];
            cell.companyAndPosition.text = [NSString stringWithFormat:@"%@%@",[[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"company"],[[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"position"]];
            NSString *time = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"partake_time"];
            cell.timeLB.text = [self mdate:time];
            //            }
            if (_bmListArr.count<10) {
                if (indexPath.row == _bmListArr.count-1) {
                    cell.isEnd = YES;
                }
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
            
        }
        if (indexPath.row >= _bmListArr.count)
        {
            
            UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if(_bmListArr.count>=10){
                UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 157)];
                footView.backgroundColor = [UIColor whiteColor];
                
                UIBottomBtn *button = [UIBottomBtn buttonWithType:UIButtonTypeCustom];
                button.frame = CGRectMake(13, 10, 295.5, 37);
                [button setBackgroundImage:[UIImage imageNamed:@"moreButton"] forState:UIControlStateNormal];
                [button setTitleColor:[UIColor colorWithHexString:@"#a5a5a5"] forState:UIControlStateNormal];
                button.titleLabel.font = YHUI(16);
                [button addTarget:self action:@selector(moreClicked) forControlEvents:UIControlEventTouchUpInside];
                [button setTitle:@"更多" forState:UIControlStateNormal];
                [footView addSubview:button];
                [cell.contentView addSubview:footView];
                UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(button.frame)+13.5, ScreenWidth, 0.5)];
                BackGround16Color(line, @"#c8c7cc");
                [cell.contentView  addSubview:line];
            }
            cell.contentView.backgroundColor = [UIColor clearColor];
            cell.contentView.clipsToBounds= YES;
            return cell;
        }
    }
    return nil;
}
//by wang zhenxing
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];

        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    
    if (indexPath.section == 1) {
        if ([_bmListArr count]>=indexPath.row) {
            NSString *user_id = [[_bmListArr objectAtIndex:indexPath.row]objectForKey:@"user_id"];
            ChatViewController* chat = [[ChatViewController alloc]init];
            chat.targetId = user_id;
            chat.navigationController.navigationBarHidden = NO;
            chat.conversationType = ConversationType_PRIVATE;
            //chat.currentTargetName = curCell.userNameLabel.text;
            chat.chatUserName = [[_bmListArr objectAtIndex:indexPath.row]objectForKey:@"name"];
            [self.navigationController pushViewController:chat animated:YES];
            
        }
        
    }
}

#pragma mark 点击加载更多  event
- (void)moreClicked
{
    MoreUserViewController *more = [[MoreUserViewController alloc]init];
    more.meetID = _meetID;
    more.personal_data_sw = _personal_data_sw;
    [self.navigationController pushViewController:more animated:YES];
}
- (void)makeHUDView
{
    [[Dialog Instance]showProgress:self withLabel:@"加载中..."];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if (viewdidload) {
        _contentInfoViewHeight = 0;
        
        [webView stringByEvaluatingJavaScriptFromString: @"document.documentElement.style.webkitUserSelect='none';"];
        // 非常重要
        CGRect frame = webView.frame;
        frame.size.height = 1;
        webView.frame = frame;
        CGSize fittingSize = [webView sizeThatFits:CGSizeZero];
        frame.size = fittingSize;
        _contentInfoViewHeight = fittingSize.height;
        
        if (itemviewheight == 188) {
            headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+_contentInfoViewHeight+163);
            
        }
        if (itemviewheight == 168) {
            headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+_contentInfoViewHeight+142);
        }
        if (itemviewheight == 98) {
            headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+_contentInfoViewHeight+72);
        }
        if (itemviewheight == 0) {
            headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+142+_contentInfoViewHeight);
        }
        
        //
        //    headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+_contentInfoViewHeight+10);
        contentView.frame = CGRectMake(0, CGRectGetMaxY(optionView.frame)+10, ScreenWidth, 44);
        mainWebView.frame = CGRectMake(0, CGRectGetMaxY(contentView.frame), ScreenWidth, _contentInfoViewHeight);
        contentlabel.frame = CGRectMake(0, CGRectGetMaxY(mainWebView.frame), ScreenWidth, 0.5);
        [headView setNeedsLayout];
        UIView *view = newSignUpInfoView.tableHeaderView;
        view.frame = CGRectMake(0, headView.frame.origin.y, headView.frame.size.width, headView.frame.size.height);
        newSignUpInfoView.tableHeaderView = view;
        
    }
    //    [newSignUpInfoView beginUpdates];
    //    [newSignUpInfoView setTableHeaderView:headView];
    //    [newSignUpInfoView endUpdates];
    
    //    [newSignUpInfoView reloadRowsAtIndexPaths:@[webCellIndexPath] withRowAnimation:UITableViewRowAnimationNone];
    
}
- (void)getDBMeetInfo
{
    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@config",_meetID]];
    if ([dataStr length]==0) {
        
    }else{
        _configDic = [[dataStr JSONValue] objectForKey:@"content"];
        _configEnd = YES;
    }
    
    NSString *keyStr = [NSString stringWithFormat:@"%@_%@_meetInfoState",_session,[_configDic objectForKey:@"block_id"]];
    
    
    NSDictionary *data = [[[DBManager sharedInstance]getPublicDBData:keyStr] JSONValue];
    if ([[data JSONString] length]==0) {
        //[self showHUD];
    }
    if ([[[data objectForKey:@"content"] objectForKey:@"list"]isKindOfClass:[NSArray class]]&&[[data objectForKey:@"content"] count]!=0)
    {
        NSArray *arr = [[data objectForKey:@"content"] objectForKey:@"list"];
        for (int i = 0; i<[[_configDic objectForKey:@"block_list"] count]; i++) {
            for (int j = 0; j<arr.count; j++) {
                if ([[[[_configDic objectForKey:@"block_list"] objectAtIndex:i] objectForKey:@"block_id"]isEqualToString:[[arr objectAtIndex:j] objectForKey:@"block_id"]]) {
                    if (![[[arr objectAtIndex:j] objectForKey:@"state"] isEqualToString:@"0"]) {
                        _blockID = [[arr objectAtIndex:j] objectForKey:@"block_id"];
                    }
                }
            }
        }
    }
    
    
    NSString *keyStr2 = [NSString stringWithFormat:@"%@_meetInfo",_meetID];
    NSDictionary * data2 = [[[DBManager sharedInstance]getPublicDBData:keyStr2] JSONValue];
    
    [_meetDic removeAllObjects];
    [_meetDic addEntriesFromDictionary:[data2 objectForKey:@"content"]];
    if ([[data2 JSONString] length]!=0) {
        
        _titleLB.text = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
        NSString *begin_time = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"begin_time"];
        NSString *end_time = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"end_time"];
        _timeRangeLB.text = [NSString stringWithFormat:@"%@-%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time],[self formatter:@"yyyy.MM.dd HH:mm" ToTime:end_time]];
        
        //        _timeRangeLB.text = [NSString stringWithFormat:@"%@-%@",[Dialog formatterToTime:begin_time],[Dialog formatterToTime:end_time]];
        [_timeRangeLB setNeedsDisplay];
        _timeLB.text = [self formatter:@"MM-dd" ToTime:[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"update_time"]];
        [_timeLB setNeedsDisplay];
        NSString *readCount = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"read_count"];
        
        _readNumLB.text = [NSString stringWithFormat:@"阅读 %@",readCount];
        [_readNumLB setNeedsDisplay];
        _sourceLB.text = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company"];
        [_sourceLB setNeedsDisplay];
        _adressLB.text = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"location"];
        [_adressLB setNeedsDisplay];
        //[MYWebImage OneImageView:headImageView SetImageWithURL:url PlaceHolderImageName:@"meet@2x" CacheOrNot:YES];
        NSArray *arr = [[data2 objectForKey:@"content"]objectForKey:@"plugin_list"];
        
        shareTitle =  [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
        shareMessage =  [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"summary_font_share"];
        if (shareMessage.length >=20) {
            shareMessage = [shareMessage substringToIndex:20];
        }
        message = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"summary"];
        _personal_data_sw = [[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"personal_data_sw"] ;
        _createUser_id = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"user_id"];
        _createUser_name = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"name"];
        if ([[[[data2 objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"is_like"] isEqualToString:@"1"]) {
            _isLike = YES;
        }else{
            _isLike = NO;
        }
        _likeArr = [[[data2 objectForKey:@"content"]objectForKey:@"like"] objectForKey:@"list"];
        _bmCount = [[[data2 objectForKey:@"content"]objectForKey:@"bmlist"] objectForKey:@"cnt"];
        _bmListArr = [[[data2 objectForKey:@"content"]objectForKey:@"bmlist"] objectForKey:@"list"];
        [newSignUpInfoView reloadData];
        [_signUpBtn setTitle:[[data2 objectForKey:@"content"]objectForKey:@"singup_state_txt"] forState:UIControlStateNormal];
        [_signUpBtn.layer setNeedsDisplay];
        
    }
    [self getNetData];
}
-(void)getMeetInfoData
{
    //[self showHUD];
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    NSDictionary *dic = @{@"meeting_id": _meetID};
    [MyDataService postMeetingInfo:dic callback:^(id data) {
        _infoEnd = YES;
        [[Dialog Instance]hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            //[self hideHUD];
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"]floatValue] ==200) {
                NSLog(@"%@",data);
                
                NSString *keyStr = [NSString stringWithFormat:@"%@_meetInfo",_meetID];
                [[DBManager sharedInstance] deleteToPublicOneData:keyStr];
                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:keyStr];
                
                [_meetDic removeAllObjects];
                [_meetDic addEntriesFromDictionary: [data objectForKey:@"content"]];
                NSString * creatorUrl = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"ico_file"];
                [_meetHostView.desImageView sd_setImageWithURL:[NSURL URLWithString:creatorUrl] placeholderImage:[UIImage imageNamed:@"username"]];
                NSString *creatorName = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"name"];
                _createUser_id = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"user_id"];
                _createUser_name = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"name"];
                _meetHostView.contentLB.text = creatorName;
                NSString *url = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"img_url"];
                
                shareTitle =  [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
        
                shareMessage =  [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"summary_font_share"];
                
                   NSArray * meetType = [[[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"activity"] componentsSeparatedByString:@","];
                [self compareMeetTpye:meetType];
                NSString *expenses = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"expenses"];
                if ([expenses isEqualToString:@""]) {
                    _costView.costBtn.hidden = YES;
                }
                if ([expenses isEqualToString:@"1"]) {
                    [_costView.costBtn setTitle:@"我请客" forState:UIControlStateNormal];
                }
                if ([expenses isEqualToString:@"2"]) {
                    [_costView.costBtn setTitle:@"AA" forState:UIControlStateNormal];
                }
                if ([expenses isEqualToString:@"3"]) {
                    [_costView.costBtn setTitle:@"有活动经费" forState:UIControlStateNormal];
                }
                if ([expenses isEqualToString:@"4"]) {
                    [_costView.costBtn setTitle:@"待定" forState:UIControlStateNormal];
                }
                //shareMessage = shareMessage r
                if (shareMessage.length >=20) {
                    shareMessage = [shareMessage substringToIndex:20];
                }
                message = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"summary"] ;
                _personal_data_sw = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"personal_data_sw"] ;
                if (url.length == 0) {
                    NSString *title = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
                    
                    CGSize titlesize = [title sizeWithFont:YHUI(17) constrainedToSize:CGSizeMake(ScreenWidth-30, 2000) lineBreakMode:NSLineBreakByCharWrapping];
                    difHeight += (titlesize.height - 32.5);
                    _titleLB.text = title;
                    _titleLB.frame = CGRectMake(_titleLB.frame.origin.x, _titleLB.frame.origin.y, _titleLB.frame.size.width, titlesize.height);
                    
                    NSString *begin_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"begin_time"];
                    NSString *end_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"end_time"];
                    if (end_time.length == 0) {
                        _timeView.sTimeLB.text = [NSString stringWithFormat:@"开始   %@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time]];
                        _timeView.eTimeLB.text = [NSString stringWithFormat:@"结束   --"];

                        _timeRangeLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time]];
                    }else {
                        _timeView.sTimeLB.text = [NSString stringWithFormat:@"开始   %@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time]];
                        _timeView.eTimeLB.text = [NSString stringWithFormat:@"结束   %@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:end_time]];
                        _timeRangeLB.text = [NSString stringWithFormat:@"%@-%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time],[self formatter:@"yyyy.MM.dd HH:mm" ToTime:end_time]];
                    }
                    _timeRangeLB.frame = CGRectMake(15, CGRectGetMaxY(_titleLB.frame)+5, 200, 0);
                    [_timeRangeLB setNeedsDisplay];
                    
                    //                _timeRangeLB.text = [NSString stringWithFormat:@"%@-%@",[Dialog formatterToTime:begin_time],[Dialog formatterToTime:end_time]];
                    //                [_timeRangeLB setNeedsDisplay];
                    _timeLB.text = [self formatter:@"MM-dd" ToTime:[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"update_time"]];
                    [_timeLB setNeedsDisplay];
                    
                    NSString *readCount = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"read_count"];
                    _readNumLB.text = [NSString stringWithFormat:@"阅读 %@",readCount];
                    [_readNumLB setNeedsDisplay];
                    if ([[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company"] length]==0) {
                        _sourceLB.frame = CGRectMake(15, CGRectGetMaxY(_timeRangeLB.frame)+5, ScreenWidth-30, 0);
                        difHeight+=13;
                        _sourceLB.text = @"";
                    }else{
                        NSString *location = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company"];
                        
                        CGSize locationsize = [location sizeWithFont:YHUI(12) constrainedToSize:CGSizeMake(ScreenWidth-50, 2000) lineBreakMode:NSLineBreakByCharWrapping];
                        difHeight += (locationsize.height - 13);
                        _addressView.contentLB.text = location;
                        
                        _sourceLB.frame = CGRectMake(15, CGRectGetMaxY(_timeRangeLB.frame)+5, ScreenWidth-30, locationsize.height);
                        [_sourceLB setNeedsDisplay];
                    }
                    
                    _timeLB.frame = CGRectMake(15, CGRectGetMaxY(_titleLB.frame)+5, 40, 13);
                    _readNumLB.frame = CGRectMake(CGRectGetMaxX(_timeLB.frame) + 6, CGRectGetMaxY(_titleLB.frame)+5, 150, 13);
                    UILabel *line2 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_timeLB.frame)+5, ScreenWidth, 0.5)];
                    BackGround16Color(line2, @"#c8c7cc");
                    [titleView  addSubview:line2];
                    
                    NSString *address = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"location"];
                    
                    CGSize addresssize = [address sizeWithFont:YHUI(14) constrainedToSize:CGSizeMake(ScreenWidth-50, 2000) lineBreakMode:NSLineBreakByCharWrapping];
                    difHeight += (addresssize.height - 40);
                    

                    _adressLB.text = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"location"];
                    [_adressLB setNeedsDisplay];
                    _addressView.contentLB.textColor = [UIColor colorWithHexString:@"#144685"];
                     _addressView.contentLB.text = address;
                    
                    NSArray *arr = [[data objectForKey:@"content"]objectForKey:@"plugin_list"];
                    [_gridArr removeAllObjects];
                    for (int i = 0; i<arr.count; i++) {
                        gridInfo *info = [[gridInfo alloc]init];
                        info.urlStr = [[arr objectAtIndex:i] objectForKey:@"ico_url"];
                        info.title = [[arr objectAtIndex:i] objectForKey:@"name"];
                        info.pluginID = [[arr objectAtIndex:i] objectForKey:@"plugin_id"];
                        info.pluginType = [[arr objectAtIndex:i] objectForKey:@"plugin_type"];
                        info.authority = [self authority:[[arr objectAtIndex:i] objectForKey:@"authority"]];
                        if (info.authority == YES) {
                            [_gridArr addObject:info];
                        }
                        
                    }
                    [mainWebView loadHTMLString:[StringToHtml stringToHtml:message] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] resourcePath]]];
                    
                    headImageView.frame = CGRectMake(0, 0.5, ScreenWidth, 0);
                    headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+difHeight-80);
                    [headView setNeedsLayout];
                    [newSignUpInfoView beginUpdates];
                    [newSignUpInfoView setTableHeaderView:headView];
                    [newSignUpInfoView endUpdates];
                    titleView.frame = CGRectMake(0, CGRectGetMaxY(headImageView.frame), ScreenWidth, CGRectGetMaxY(_timeLB.frame)+5.5);
                    meetInfoView.frame = CGRectMake(0, CGRectGetMaxY(titleView.frame)+10, ScreenWidth, 238);
                    //_adressLB.backgroundColor     = [UIColor blueColor];
                    optionView.frame = CGRectMake(0,CGRectGetMaxY(meetInfoView.frame)+10, ScreenWidth, 189);
                    [self creatPluginUI:_gridArr];
                    [newSignUpInfoView setNeedsLayout];
                    
                    
                }else{
                    [headImageView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:[UIImage imageNamed:@"meet"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                        //scale = ScreenWidth/image.size.width;
                        CGSize size;
                        if (image == nil) {
                            size =  CGSizeMake(ScreenWidth, 0/image.size.width*ScreenWidth);
                        }else
                        {
                            size =  CGSizeMake(ScreenWidth, image.size.height/image.size.width*ScreenWidth);
                            difHeight += (size.height-115);
                        }
                        
                        
                        
                        headImageView.frame = CGRectMake(headImageView.frame.origin.x, 0, size.width,size.height);
                        headImageView.backgroundColor = [UIColor blueColor];
                        
                        titleView.frame = CGRectMake(0, size.height, ScreenWidth, headView.size.height);
                        NSString *title = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
                        
                        CGSize titlesize = [title sizeWithFont:YHUI(17) constrainedToSize:CGSizeMake(ScreenWidth-30, 2000) lineBreakMode:NSLineBreakByCharWrapping];
                        difHeight += (titlesize.height - 32.5);
                        _titleLB.text = title;
                        _titleLB.frame = CGRectMake(_titleLB.frame.origin.x, _titleLB.frame.origin.y, _titleLB.frame.size.width, titlesize.height);
                        
                        NSString *begin_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"begin_time"];
                        NSString *end_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"end_time"];
                        if (end_time.length == 0) {
                             _timeView.sTimeLB.text = [NSString stringWithFormat:@"开始   %@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time]];
                            _timeRangeLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time]];
                        }else{
                            _timeRangeLB.text = [NSString stringWithFormat:@"%@-%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time],[self formatter:@"yyyy.MM.dd HH:mm" ToTime:end_time]];
                            _timeRangeLB.frame = CGRectMake(15, CGRectGetMaxY(_titleLB.frame)+5, 200, 0);
                        }
                        [_timeRangeLB setNeedsDisplay];
                        
                        //                _timeRangeLB.text = [NSString stringWithFormat:@"%@-%@",[Dialog formatterToTime:begin_time],[Dialog formatterToTime:end_time]];
                        //                [_timeRangeLB setNeedsDisplay];
                        _timeLB.text = [self formatter:@"MM-dd" ToTime:[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"update_time"]];
                        [_timeLB setNeedsDisplay];
                        
                        NSString *readCount = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"read_count"];
                        _readNumLB.text = [NSString stringWithFormat:@"阅读 %@",readCount];
                        [_readNumLB setNeedsDisplay];
                        if ([[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company"] length]==0) {
                            _sourceLB.frame = CGRectMake(15, CGRectGetMaxY(_timeRangeLB.frame)+5, ScreenWidth-30, 0);
                            difHeight-=13;
                            _sourceLB.text = @"";
                        }else{
                            NSString *company = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company"];
                            
                            CGSize locationsize = [company sizeWithFont:YHUI(12) constrainedToSize:CGSizeMake(ScreenWidth-50, 2000) lineBreakMode:NSLineBreakByCharWrapping];
                            difHeight += (locationsize.height - 13);
//                            _sourceLB.text = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company"];
//                            _sourceLB.frame = CGRectMake(15, CGRectGetMaxY(_timeRangeLB.frame)+5, ScreenWidth-30, locationsize.height);
//                            
//                            [_sourceLB setNeedsDisplay];
                        }
                        
                        
                        _timeLB.frame = CGRectMake(15, CGRectGetMaxY(_titleLB.frame)+25, 40, 13);
                        _readNumLB.frame = CGRectMake(CGRectGetMaxX(_timeLB.frame) + 6, CGRectGetMaxY(_titleLB.frame)+25, 150, 13);
                        UILabel *line2 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_timeLB.frame)+5, ScreenWidth, 0.5)];
                        BackGround16Color(line2, @"#c8c7cc");
                        [titleView  addSubview:line2];
                        
                        NSString *address = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"location"];
                        
                        CGSize addresssize = [address sizeWithFont:YHUI(14) constrainedToSize:CGSizeMake(ScreenWidth-50, 2000) lineBreakMode:NSLineBreakByCharWrapping];
                        difHeight += (addresssize.height - 40);
                        

                        
                
                        
                        NSArray *arr = [[data objectForKey:@"content"]objectForKey:@"plugin_list"];
                        [_gridArr removeAllObjects];
                        for (int i = 0; i<arr.count; i++) {
                            gridInfo *info = [[gridInfo alloc]init];
                            info.urlStr = [[arr objectAtIndex:i] objectForKey:@"ico_url"];
                            info.title = [[arr objectAtIndex:i] objectForKey:@"name"];
                            info.pluginID = [[arr objectAtIndex:i] objectForKey:@"plugin_id"];
                            info.pluginType = [[arr objectAtIndex:i] objectForKey:@"plugin_type"];
                            info.authority = [self authority:[[arr objectAtIndex:i] objectForKey:@"authority"]];
                            info.authoritystatus = [[arr objectAtIndex:i] objectForKey:@"authority"];
                            [_gridArr addObject:info];
                        }
                        
                        
                        
                        _adressLB.text = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"location"];
                        [_adressLB setNeedsDisplay];
                        
                        headView.frame = CGRectMake(0, 0, ScreenWidth, headView.size.height+difHeight+60);
                        titleView.frame = CGRectMake(0, CGRectGetMaxY(headImageView.frame), ScreenWidth, CGRectGetMaxY(_timeLB.frame)+5.5);
                        optionView.frame = CGRectMake(0,CGRectGetMaxY(meetInfoView.frame)+10, ScreenWidth, 189);
                        [self creatPluginUI:_gridArr];
                        [mainWebView loadHTMLString:[StringToHtml stringToHtml:message] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] resourcePath]]];
                        //headImageView.image = nil;
                        //改变frame
                        contentView.frame = CGRectMake(0, CGRectGetMaxY(optionView.frame)+10+difHeight, ScreenWidth, 44);
                        mainWebView.frame = CGRectMake(0, CGRectGetMaxY(contentView.frame), ScreenWidth,mainWebView.size.height);
                        contentlabel.frame = CGRectMake(0, CGRectGetMaxY(mainWebView.frame), ScreenWidth, 0.5);
                        
                        [headView setNeedsLayout];
                        [newSignUpInfoView beginUpdates];
                        [newSignUpInfoView setTableHeaderView:headView];
                        [newSignUpInfoView endUpdates];
                    }];
                    //[MYWebImage OneImageView:headImageView SetImageWithURL:url PlaceHolderImageName:@"meet@2x" CacheOrNot:YES];
                }
                for (UIView *view in titleView.subviews) {
                    view.frame = CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, view.frame.size.height);
                }
                
                //                NSString*filePath=[[NSBundle mainBundle] pathForResource:@"会议邦短信群发服务条款"ofType:@"html"];
                //
                //                NSString*str=[[NSString alloc] initWithContentsOfFile:filePath];
                
                
                //[mainWebView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:filePath]]];
                
                if ([[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"is_like"] isEqualToString:@"1"]) {
                    _isLike = YES;
                }else{
                    _isLike = NO;
                }
                _likeArr = [[[data objectForKey:@"content"]objectForKey:@"like"] objectForKey:@"list"];
                _bmCount = [[[data objectForKey:@"content"]objectForKey:@"bmlist"] objectForKey:@"cnt"];
                _bmListArr = [[[data objectForKey:@"content"]objectForKey:@"bmlist"] objectForKey:@"list"];
                [newSignUpInfoView reloadData];
                NSString *signUpstate = [[data objectForKey:@"content"]objectForKey:@"signup_state"];//最外层 M层的状态 1尚未报名 5完成报名 4报名完成等待审核 3审核未通过 2审核通过等待回执 10报名结束
                [_signUpBtn setTitle:[[data objectForKey:@"content"]objectForKey:@"singup_state_txt"] forState:UIControlStateNormal];
                [_signUpBtn.layer setNeedsDisplay];
                
            }else{
                
            }
        }
    }];
    
}
- (void)isCloseMeeting
{
    NSDictionary *dic = @{@"meeting_id": _meetID,@"block_id": [_configDic objectForKey:@"block_id"]};
    [MyDataService postPartakeState:dic callback:^(id data) {
        NSLog(@"%@",data);//0未填,1不完整,2完整,3可选的未填，4可选的不完整
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                
                
            }
        }
    }];
}

- (void)signUpBtnClicked:(UIButton *)btn
{
    
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];

        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    if (_bmEnd) {
        UIAlertView *av = [[UIAlertView alloc]initWithTitle:nil message:@"报名已结束" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [av show];
    }
    else{
        if (_configEnd == YES) {
            if ([[_configDic objectForKey:@"type"] isEqualToString:@"4"]) {
                if ([[_configDic objectForKey:@"block_list"] count] == 1) {//type 4  一定会有报名状态跟踪
                    NSDictionary *nextViewDic0 = [[_configDic objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"10"]) {
                        if ([_signUpstate isEqualToString:@"1"]) {
                            NSDictionary *nextViewDic1 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"3"]) {
                                if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                    NSDictionary *nextViewDic2 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic2 objectForKey:@"type"]isEqualToString:@"2"]) {
                                        if ([[nextViewDic2 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                                            NSDictionary *nextViewDic3 = [[nextViewDic2 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0) {
                                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                eduVC.addName = [nextViewDic3 objectForKey:@"name"];
                                                eduVC.meetID = _meetID;
                                                eduVC.blockID =  [nextViewDic3 objectForKey:@"block_id"];
                                                eduVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:eduVC animated:YES];
                                            }
                                            if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0 ) {
                                                if (![[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                    perInfoVC.meetID = _meetID;
                                                    perInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                                    perInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:perInfoVC animated:YES];
                                                }
                                                if ([[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                    upInfoVC.upInfoTitle = [nextViewDic3  objectForKey:@"name"];
                                                    upInfoVC.meetID = _meetID;
                                                    upInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                                    upInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:upInfoVC animated:YES];
                                                }
                                            }
                                            
                                            
                                        }else{//显示2
                                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                                            briefVC.meetID = _meetID;
                                            briefVC.briefDic = nextViewDic2;
                                            briefVC.blockID =  [nextViewDic2 objectForKey:@"block_id"];
                                            briefVC.configArr = [nextViewDic2 objectForKey:@"block_list"];
                                            [self.navigationController pushViewController:briefVC animated:YES];
                                        }
                                        
                                    }
                                }else{//显示3
                                    UpViewController *upVC = [[UpViewController alloc]init];
                                    upVC.meetID = _meetID;
                                    upVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                                    upVC.configArr = [nextViewDic1 objectForKey:@"block_list"];//3正常跳转 传4
                                    [self.navigationController pushViewController:upVC animated:YES];
                                }
                            }
                            if ([[nextViewDic1 objectForKey:@"type"]isEqualToString:@"2"]) {
                                if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {
                                    NSDictionary *nextViewDic8 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic8  objectForKey:@"field_list"]count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic8 objectForKey:@"name"];
                                        eduVC.meetID = _meetID;
                                        eduVC.blockID =  [nextViewDic8 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                        [self.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic8 objectForKey:@"field_list"]count]!=0) {
                                        if (![[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                            perInfoVC.meetID = _meetID;
                                            perInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                            [self.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic8  objectForKey:@"name"];
                                            upInfoVC.meetID = _meetID;
                                            upInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                            [self.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                }else{
                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                    briefVC.meetID = _meetID;
                                    briefVC.briefDic = nextViewDic0;
                                    briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                                    briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                                    [self.navigationController pushViewController:briefVC animated:YES];
                                }
                            }
                            if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic1 objectForKey:@"field_list"] count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic1 objectForKey:@"name"];
                                eduVC.meetID = _meetID;
                                eduVC.blockID =  [nextViewDic1 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                                [self.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic1 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meetID;
                                    perInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                                    [self.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic1  objectForKey:@"name"];
                                    upInfoVC.meetID = _meetID;
                                    upInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                                    [self.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                        }else{//显示报名状态跟踪
                            SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                            stateVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                            stateVC.meetID = _meetID;
                            stateVC.type = [nextViewDic0 objectForKey:@"type"];
                            stateVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                            [self.navigationController pushViewController:stateVC animated:YES];
                        }
                    }else{
                        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"3"]) {
                            if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                NSDictionary * nextViewDic5 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                                if ([[nextViewDic5 objectForKey:@"type"]isEqualToString:@"2"]) {
                                    if ([[nextViewDic5 objectForKey:@"block_list"] count] == 1) {
                                        NSDictionary *nextViewDic6 = [[nextViewDic5 objectForKey:@"block_list"] objectAtIndex:0];
                                        if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic6 objectForKey:@"field_list"] count]!=0) {
                                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                            eduVC.addName = [nextViewDic6 objectForKey:@"name"];
                                            eduVC.meetID = _meetID;
                                            eduVC.blockID =  [nextViewDic6 objectForKey:@"block_id"];
                                            eduVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                            [self.navigationController pushViewController:eduVC animated:YES];
                                        }
                                        if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic6  objectForKey:@"field_list"] count]!=0) {
                                            if (![[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                perInfoVC.meetID = _meetID;
                                                perInfoVC.blockID = [nextViewDic6 objectForKey:@"block_id"];
                                                perInfoVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:perInfoVC animated:YES];
                                            }
                                            if ([[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                upInfoVC.upInfoTitle = [_nextViewDic  objectForKey:@"name"];
                                                upInfoVC.meetID = _meetID;
                                                upInfoVC.blockID = [_nextViewDic objectForKey:@"block_id"];
                                                upInfoVC.configArr = [_nextViewDic objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:upInfoVC animated:YES];
                                            }
                                            
                                        }
                                        
                                    }else{
                                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                                        briefVC.meetID = _meetID;
                                        briefVC.briefDic = nextViewDic5;
                                        briefVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                                        briefVC.configArr = [nextViewDic5 objectForKey:@"block_list"];
                                        [self.navigationController pushViewController:briefVC animated:YES];
                                    }
                                    
                                }
                                if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"1"]) {
                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                    eduVC.addName = [nextViewDic5 objectForKey:@"name"];
                                    eduVC.meetID = _meetID;
                                    eduVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                                    eduVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                    [self.navigationController pushViewController:eduVC animated:YES];
                                }
                                if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic5 objectForKey:@"field_list"]count]!=0) {
                                    if (![[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                        perInfoVC.meetID = _meetID;
                                        perInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                                        perInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                        [self.navigationController pushViewController:perInfoVC animated:YES];
                                    }
                                    if ([[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                        upInfoVC.upInfoTitle = [nextViewDic5  objectForKey:@"name"];
                                        upInfoVC.meetID = _meetID;
                                        upInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                                        upInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                        [self.navigationController pushViewController:upInfoVC animated:YES];
                                    }
                                }
                                
                            }else{
                                UpViewController *upVC = [[UpViewController alloc]init];
                                upVC.meetID = _meetID;
                                upVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                                upVC.configArr = [nextViewDic0 objectForKey:@"block_list"];//3正常跳转 传4
                                [self.navigationController pushViewController:upVC animated:YES];
                            }
                            
                        }
                        if ([[nextViewDic0 objectForKey:@"type"]isEqualToString:@"2"]) {
                            if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {
                                NSDictionary *nextViewDic4 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                                if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                    eduVC.addName = [nextViewDic4 objectForKey:@"name"];
                                    eduVC.meetID = _meetID;
                                    eduVC.blockID =  [nextViewDic4 objectForKey:@"block_id"];
                                    eduVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                    [self.navigationController pushViewController:eduVC animated:YES];
                                }
                                if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                                    if (![[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                        perInfoVC.meetID = _meetID;
                                        perInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                                        perInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                        [self.navigationController pushViewController:perInfoVC animated:YES];
                                    }
                                    if ([[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                        upInfoVC.upInfoTitle = [nextViewDic4  objectForKey:@"name"];
                                        upInfoVC.meetID = _meetID;
                                        upInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                                        upInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                        [self.navigationController pushViewController:upInfoVC animated:YES];
                                    }
                                }
                            }else{
                                BriefViewController *briefVC = [[BriefViewController alloc]init];
                                briefVC.meetID = _meetID;
                                briefVC.briefDic = nextViewDic0;
                                briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                                briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                                [self.navigationController pushViewController:briefVC animated:YES];
                            }
                        }
                        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic0 objectForKey:@"name"];
                            eduVC.meetID = _meetID;
                            eduVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                            [self.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                            if (![[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                perInfoVC.meetID = _meetID;
                                perInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                                [self.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [nextViewDic0  objectForKey:@"name"];
                                upInfoVC.meetID = _meetID;
                                upInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                                upInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                                [self.navigationController pushViewController:upInfoVC animated:YES];
                            }
                        }
                    }
                }
                
                else{
                    if (_blockID.length != 0 ){
                        
                        for (NSDictionary *nextViewDic12 in [_configDic objectForKey:@"block_list"]) {
                            if ([[nextViewDic12 objectForKey:@"block_id"] isEqualToString:_blockID]) {
                                if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"10"]) {
                                    if ([_signUpstate isEqualToString:@"1"]) {
                                        NSDictionary *nextViewDic13 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                        if ([[nextViewDic13 objectForKey:@"type"] isEqualToString:@"3"]) {
                                            if ([[nextViewDic13 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                                NSDictionary *nextViewDic14 = [[nextViewDic13 objectForKey:@"block_list"] objectAtIndex:0];
                                                if ([[nextViewDic14 objectForKey:@"type"]isEqualToString:@"2"]) {
                                                    if ([[nextViewDic14 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                                                        NSDictionary *nextViewDic15 = [[nextViewDic14 objectForKey:@"block_list"] objectAtIndex:0];
                                                        if ([[nextViewDic15 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic15  objectForKey:@"field_list"]count]!=0) {
                                                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                            eduVC.addName = [nextViewDic15 objectForKey:@"name"];
                                                            eduVC.meetID = _meetID;
                                                            eduVC.blockID =  [nextViewDic15 objectForKey:@"block_id"];
                                                            eduVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                            [self.navigationController pushViewController:eduVC animated:YES];
                                                        }
                                                        if ([[nextViewDic15 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic15  objectForKey:@"field_list"]count]!=0 ) {
                                                            if (![[[[nextViewDic15  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                                perInfoVC.meetID = _meetID;
                                                                perInfoVC.blockID = [nextViewDic15 objectForKey:@"block_id"];
                                                                perInfoVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                                [self.navigationController pushViewController:perInfoVC animated:YES];
                                                            }
                                                            if ([[[[nextViewDic15  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                                upInfoVC.upInfoTitle = [nextViewDic15  objectForKey:@"name"];
                                                                upInfoVC.meetID = _meetID;
                                                                upInfoVC.blockID = [nextViewDic15 objectForKey:@"block_id"];
                                                                upInfoVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                                [self.navigationController pushViewController:upInfoVC animated:YES];
                                                            }
                                                        }
                                                        
                                                        
                                                    }else{//显示2
                                                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                                                        briefVC.meetID = _meetID;
                                                        briefVC.briefDic = nextViewDic14;
                                                        briefVC.blockID =  [nextViewDic14 objectForKey:@"block_id"];
                                                        briefVC.configArr = [nextViewDic14 objectForKey:@"block_list"];
                                                        [self.navigationController pushViewController:briefVC animated:YES];
                                                    }
                                                    
                                                }
                                            }else{//显示3
                                                UpViewController *upVC = [[UpViewController alloc]init];
                                                upVC.meetID = _meetID;
                                                upVC.blockID = [nextViewDic13 objectForKey:@"block_id"];
                                                upVC.configArr = [nextViewDic13 objectForKey:@"block_list"];//3正常跳转 传4
                                                [self.navigationController pushViewController:upVC animated:YES];
                                            }
                                        }
                                        if ([[nextViewDic12 objectForKey:@"type"]isEqualToString:@"2"]) {
                                            if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {
                                                NSDictionary *nextViewDic16 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                                if ([[nextViewDic16 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic16  objectForKey:@"field_list"]count]!=0) {
                                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                    eduVC.addName = [nextViewDic16 objectForKey:@"name"];
                                                    eduVC.meetID = _meetID;
                                                    eduVC.blockID =  [nextViewDic16 objectForKey:@"block_id"];
                                                    eduVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:eduVC animated:YES];
                                                }
                                                if ([[nextViewDic16 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic16 objectForKey:@"field_list"]count]!=0) {
                                                    if (![[[[nextViewDic16  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                        PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                        perInfoVC.meetID = _meetID;
                                                        perInfoVC.blockID = [nextViewDic16 objectForKey:@"block_id"];
                                                        perInfoVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                                        [self.navigationController pushViewController:perInfoVC animated:YES];
                                                    }
                                                    if ([[[[nextViewDic16  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                        upInfoVC.upInfoTitle = [nextViewDic16  objectForKey:@"name"];
                                                        upInfoVC.meetID = _meetID;
                                                        upInfoVC.blockID = [nextViewDic16 objectForKey:@"block_id"];
                                                        upInfoVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                                        [self.navigationController pushViewController:upInfoVC animated:YES];
                                                    }
                                                }
                                            }else{
                                                BriefViewController *briefVC = [[BriefViewController alloc]init];
                                                briefVC.meetID = _meetID;
                                                briefVC.briefDic = nextViewDic12;
                                                briefVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                                briefVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                                [self.navigationController pushViewController:briefVC animated:YES];
                                            }
                                        }
                                        if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic12 objectForKey:@"field_list"] count]!=0) {
                                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                            eduVC.addName = [nextViewDic12 objectForKey:@"name"];
                                            eduVC.meetID = _meetID;
                                            eduVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                            eduVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                            [self.navigationController pushViewController:eduVC animated:YES];
                                        }
                                        if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                            if (![[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                perInfoVC.meetID = _meetID;
                                                perInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                                perInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:perInfoVC animated:YES];
                                            }
                                            if ([[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                upInfoVC.upInfoTitle = [nextViewDic12  objectForKey:@"name"];
                                                upInfoVC.meetID = _meetID;
                                                upInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                                upInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:upInfoVC animated:YES];
                                            }
                                        }
                                    }else{//显示报名状态跟踪
                                        SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                                        stateVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                        stateVC.meetID = _meetID;
                                        stateVC.type = [nextViewDic12 objectForKey:@"type"];
                                        stateVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                        [self.navigationController pushViewController:stateVC animated:YES];
                                    }
                                }else{
                                    if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"3"]) {
                                        if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                            NSDictionary * nextViewDic17 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic17 objectForKey:@"type"]isEqualToString:@"2"]) {
                                                if ([[nextViewDic17 objectForKey:@"block_list"] count] == 1) {
                                                    NSDictionary *nextViewDic18 = [[nextViewDic17 objectForKey:@"block_list"] objectAtIndex:0];
                                                    if ([[nextViewDic18 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic18 objectForKey:@"field_list"] count]!=0) {
                                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                        eduVC.addName = [nextViewDic18 objectForKey:@"name"];
                                                        eduVC.meetID = _meetID;
                                                        eduVC.blockID =  [nextViewDic18 objectForKey:@"block_id"];
                                                        eduVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                        [self.navigationController pushViewController:eduVC animated:YES];
                                                    }
                                                    if ([[nextViewDic18 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic18  objectForKey:@"field_list"] count]!=0) {
                                                        if (![[[[nextViewDic18  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                            perInfoVC.meetID = _meetID;
                                                            perInfoVC.blockID = [nextViewDic18 objectForKey:@"block_id"];
                                                            perInfoVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                            [self.navigationController pushViewController:perInfoVC animated:YES];
                                                        }
                                                        if ([[[[nextViewDic18  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                            upInfoVC.upInfoTitle = [nextViewDic18  objectForKey:@"name"];
                                                            upInfoVC.meetID = _meetID;
                                                            upInfoVC.blockID = [nextViewDic18 objectForKey:@"block_id"];
                                                            upInfoVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                            [self.navigationController pushViewController:upInfoVC animated:YES];
                                                        }
                                                        
                                                    }
                                                    
                                                }else{
                                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                                    briefVC.meetID = _meetID;
                                                    briefVC.briefDic = nextViewDic17;
                                                    briefVC.blockID =  [nextViewDic17 objectForKey:@"block_id"];
                                                    briefVC.configArr = [nextViewDic17 objectForKey:@"block_list"];
                                                    [self.navigationController pushViewController:briefVC animated:YES];
                                                }
                                            }
                                            if ([[nextViewDic17 objectForKey:@"type"] isEqualToString:@"1"]) {
                                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                eduVC.addName = [nextViewDic17 objectForKey:@"name"];
                                                eduVC.meetID = _meetID;
                                                eduVC.blockID =  [nextViewDic17 objectForKey:@"block_id"];
                                                eduVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:eduVC animated:YES];
                                            }
                                            if ([[nextViewDic17 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic17 objectForKey:@"field_list"]count]!=0) {
                                                if (![[[[nextViewDic17  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                    perInfoVC.meetID = _meetID;
                                                    perInfoVC.blockID = [nextViewDic17 objectForKey:@"block_id"];
                                                    perInfoVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:perInfoVC animated:YES];
                                                }
                                                if ([[[[nextViewDic17  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                    upInfoVC.upInfoTitle = [nextViewDic17  objectForKey:@"name"];
                                                    upInfoVC.meetID = _meetID;
                                                    upInfoVC.blockID = [nextViewDic17 objectForKey:@"block_id"];
                                                    upInfoVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:upInfoVC animated:YES];
                                                }
                                            }
                                            
                                        }else{
                                            UpViewController *upVC = [[UpViewController alloc]init];
                                            upVC.meetID = _meetID;
                                            upVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                            upVC.configArr = [nextViewDic12 objectForKey:@"block_list"];//3正常跳转 传4
                                            [self.navigationController pushViewController:upVC animated:YES];
                                        }
                                        
                                    }
                                    if ([[nextViewDic12 objectForKey:@"type"]isEqualToString:@"2"]) {
                                        if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {
                                            NSDictionary *nextViewDic19 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic19 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic19 objectForKey:@"field_list"]count]!=0) {
                                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                eduVC.addName = [nextViewDic19 objectForKey:@"name"];
                                                eduVC.meetID = _meetID;
                                                eduVC.blockID =  [nextViewDic19 objectForKey:@"block_id"];
                                                eduVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                                [self.navigationController pushViewController:eduVC animated:YES];
                                            }
                                            if ([[nextViewDic19 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic19 objectForKey:@"field_list"]count]!=0) {
                                                if (![[[[nextViewDic19  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                    perInfoVC.meetID = _meetID;
                                                    perInfoVC.blockID = [nextViewDic19 objectForKey:@"block_id"];
                                                    perInfoVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:perInfoVC animated:YES];
                                                }
                                                if ([[[[nextViewDic19  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                    upInfoVC.upInfoTitle = [nextViewDic19  objectForKey:@"name"];
                                                    upInfoVC.meetID = _meetID;
                                                    upInfoVC.blockID = [nextViewDic19 objectForKey:@"block_id"];
                                                    upInfoVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                                    [self.navigationController pushViewController:upInfoVC animated:YES];
                                                }
                                            }
                                        }else{
                                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                                            briefVC.meetID = _meetID;
                                            briefVC.briefDic = nextViewDic12;
                                            briefVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                            briefVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                            [self.navigationController pushViewController:briefVC animated:YES];
                                        }
                                    }
                                    if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic12 objectForKey:@"name"];
                                        eduVC.meetID = _meetID;
                                        eduVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                        [self.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                        if (![[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                            perInfoVC.meetID = _meetID;
                                            perInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                            [self.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic12  objectForKey:@"name"];
                                            upInfoVC.meetID = _meetID;
                                            upInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                            [self.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                }
                                
                            }
                        }
                    }
                    else{
                        _blockID = [_configDic objectForKey:@"block_id"];
                        SignUpTypeViewController *typeVC = [[SignUpTypeViewController alloc]init];
                        typeVC.meetID = _meetID;
                        typeVC.blockID = [_configDic objectForKey:@"block_id"];
                        typeVC.configDic = _configDic;
                        [self.navigationController pushViewController:typeVC animated:YES];
                    }
                }
            }
            if ([[_configDic objectForKey:@"type"] isEqualToString:@"3"]) {
                if ([[_configDic objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                    NSDictionary *nextViewDic9 = [[_configDic objectForKey:@"block_list"] objectAtIndex:0];
                    
                    if ([[nextViewDic9 objectForKey:@"type"]isEqualToString:@"2"]) {
                        if ([[nextViewDic9 objectForKey:@"block_list"] count] == 1) {
                            NSDictionary *nextViewDic10 = [[nextViewDic9 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic10 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic10 objectForKey:@"field_list"] count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic10 objectForKey:@"name"];
                                eduVC.meetID = _meetID;
                                eduVC.blockID =  [nextViewDic10 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                                [self.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic10 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic10 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic10  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meetID;
                                    perInfoVC.blockID = [nextViewDic10 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                                    [self.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic10  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic10  objectForKey:@"name"];
                                    upInfoVC.meetID = _meetID;
                                    upInfoVC.blockID = [nextViewDic10 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                                    [self.navigationController pushViewController:upInfoVC animated:YES];
                                }
                                
                            }
                            
                        }else{
                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                            briefVC.meetID = _meetID;
                            briefVC.briefDic = nextViewDic9;
                            briefVC.blockID =  [nextViewDic9 objectForKey:@"block_id"];
                            briefVC.configArr = [nextViewDic9 objectForKey:@"block_list"];
                            [self.navigationController pushViewController:briefVC animated:YES];
                        }
                        
                    }
                    
                }else{
                    UpViewController *upVC = [[UpViewController alloc]init];
                    upVC.meetID = _meetID;
                    upVC.blockID = [_configDic objectForKey:@"block_id"];
                    upVC.configArr = [_configDic objectForKey:@"block_list"];//3正常跳转 传4
                    [self.navigationController pushViewController:upVC animated:YES];
                }
            }
            if ([[_configDic objectForKey:@"type"]isEqualToString:@"2"]) {
                if ([[_nextViewDic objectForKey:@"block_list"] count] == 1) {
                    NSDictionary * nextViewDic11 = [[_nextViewDic objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic11 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic11 objectForKey:@"field_list"] count]!=0) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic11 objectForKey:@"name"];
                        eduVC.meetID = _meetID;
                        eduVC.blockID =  [nextViewDic11 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                        [self.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic11 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic11 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic11  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                            perInfoVC.meetID = _meetID;
                            perInfoVC.blockID = [nextViewDic11 objectForKey:@"block_id"];
                            perInfoVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                            [self.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic11  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic11  objectForKey:@"name"];
                            upInfoVC.meetID = _meetID;
                            upInfoVC.blockID = [nextViewDic11 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                            [self.navigationController pushViewController:upInfoVC animated:YES];
                        }
                        
                    }
                    
                    
                }else{
                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                    briefVC.meetID = _meetID;
                    briefVC.briefDic = _nextViewDic;
                    briefVC.blockID =  [_nextViewDic objectForKey:@"block_id"];
                    briefVC.configArr = [_nextViewDic objectForKey:@"block_list"];
                    [self.navigationController pushViewController:briefVC animated:YES];
                }
            }
            if ([[_configDic objectForKey:@"type"] isEqualToString:@"1"]&&[[_configDic objectForKey:@"field_list"]count]!=0) {//第一层  type1
                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                eduVC.addName = [_configDic objectForKey:@"name"];
                eduVC.meetID = _meetID;
                eduVC.blockID =  [_configDic objectForKey:@"block_id"];
                eduVC.configArr = [_configDic objectForKey:@"field_list"];
                [self.navigationController pushViewController:eduVC animated:YES];
            }
            if ([[_configDic objectForKey:@"type"] isEqualToString:@"0"]&&[[_configDic objectForKey:@"field_list"] count]!=0) {
                if (![[[[_configDic  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {//第一层  type1 且跳转到普通页
                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                    perInfoVC.meetID = _meetID;
                    perInfoVC.blockID = [_configDic objectForKey:@"block_id"];
                    perInfoVC.configArr = [_configDic objectForKey:@"field_list"];
                    [self.navigationController pushViewController:perInfoVC animated:YES];
                }
                if ([[[[_configDic  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {//第一层  type1 且跳转到上传图片
                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                    upInfoVC.upInfoTitle = [_configDic  objectForKey:@"name"];
                    upInfoVC.meetID = _meetID;
                    upInfoVC.blockID = [_configDic objectForKey:@"block_id"];
                    upInfoVC.configArr = [_configDic objectForKey:@"field_list"];
                    [self.navigationController pushViewController:upInfoVC animated:YES];
                }
            }
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
