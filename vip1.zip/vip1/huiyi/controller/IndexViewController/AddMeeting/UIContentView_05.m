//
//  UIContentView_05.m
//  huiyi
//
//  Created by songhongshuai on 15/1/9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIContentView_05.h"

@implementation UIContentView_05

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 60, 41)];
        self.nameLB.backgroundColor = [UIColor clearColor];
        self.nameLB.textAlignment = NSTextAlignmentLeft;
        self.nameLB.font = YHUI(15);
        [self  addSubview:self.nameLB];
        
        UIImage *buttonImageselected = [UIImage imageNamed:@"new_07"];
        buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImageselected.size.width/2) topCapHeight:floorf(buttonImageselected.size.height/2)];
        _costBtn = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
        _costBtn.frame = CGRectMake(CGRectGetMaxX(self.nameLB.frame)+15, 9, 76, 24);
        _costBtn.hidden = NO;
        [_costBtn setTitleColor:[UIColor colorWithHexString:@"#7082c7"] forState:UIControlStateNormal];
        [_costBtn setBackgroundImage:buttonImageselected forState:UIControlStateNormal];
        [self addSubview:_costBtn];

    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
