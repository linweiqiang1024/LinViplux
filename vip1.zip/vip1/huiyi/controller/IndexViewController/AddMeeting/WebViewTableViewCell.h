//
//  WebViewTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewTableViewCell : UITableViewCell
@property (nonatomic)int webHeight;
@property (nonatomic,strong)UIWebView *infoWebView;
@end
