//
//  UIContentView_04.m
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIContentView_04.h"

@implementation UIContentView_04

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 60, 41)];
        self.nameLB.backgroundColor = [UIColor clearColor];
        self.nameLB.textAlignment = NSTextAlignmentLeft;
        self.nameLB.font = YHUI(15);
        [self  addSubview:self.nameLB];
        
        _meetTypeBtn1 = [UITypeButton buttonWithType:UIButtonTypeCustom];
        _meetTypeBtn1.frame = CGRectMake(CGRectGetMaxX(self.nameLB.frame) + 15, 5, 65, 26);
        _meetTypeBtn1.tag = 50+1;
        _meetTypeBtn1.isShow = YES;
        _meetTypeBtn1.backgroundColor = [UIColor clearColor];
        _meetTypeBtn1.titleLabel.font = YHUI(14);
        [_meetTypeBtn1 setTitle:@"聚餐" forState:UIControlStateNormal];
        [_meetTypeBtn1 setTitleColor:[UIColor
                                      colorWithHexString:@"#676767"] forState:UIControlStateNormal];
        
        [self addSubview:_meetTypeBtn1];
        
        _meetTypeBtn2 = [UITypeButton buttonWithType:UIButtonTypeCustom];
        _meetTypeBtn2.frame = CGRectMake(CGRectGetMaxX(_meetTypeBtn1.frame)+10, 5, 65, 26);
        _meetTypeBtn2.tag = 50+2;
        _meetTypeBtn2.titleLabel.font = YHUI(14);
        _meetTypeBtn2.isShow = YES;
        [_meetTypeBtn2 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
        [self addSubview:_meetTypeBtn2];
        
        _meetTypeBtn3 = [UITypeButton buttonWithType:UIButtonTypeCustom];
        _meetTypeBtn3.frame = CGRectMake(CGRectGetMaxX(_meetTypeBtn2.frame)+10, 5, 65, 26);
        _meetTypeBtn3.tag = 50+3;
        _meetTypeBtn3.isShow = YES;
        [_meetTypeBtn3 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
        _meetTypeBtn3.titleLabel.font = YHUI(14);
        [self addSubview:_meetTypeBtn3];
        
        UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(15, frame.size.height-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line, @"#c8c7cc");
        [self  addSubview:line];

    }
    return self;
}

@end
