//
//  AddMeetSectionBtn.m
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "AddMeetSectionBtn.h"

@implementation AddMeetSectionBtn

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
    }
    return self;
}
- (CGRect)titleRectForContentRect:(CGRect)contentRect{
    return CGRectMake( 15, 1.5, ScreenWidth-40, 38);
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect{
    return CGRectMake(ScreenWidth-28, 12.5, 18,18);
}
@end
