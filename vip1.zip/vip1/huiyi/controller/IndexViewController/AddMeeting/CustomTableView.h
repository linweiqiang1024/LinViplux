//
//  CustomTableView.h
//  huiyi
//
//  Created by 王振兴 on 15-2-9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableView : UIView<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
}
@property (nonatomic,strong)UITableView *tableView;
@end
