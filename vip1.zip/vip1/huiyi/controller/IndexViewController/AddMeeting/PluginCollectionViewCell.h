//
//  PluginCollectionViewCell.h
//  huiyi
//
//  Created by songhongshuai on 16/1/21.
//  Copyright © 2016年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cell.h"

@interface PluginCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong)gridInfo *pluginInfo;
@end
