//
//  New_myApplyListCell.m
//  huiyi
//
//  Created by 王振兴 on 15-2-10.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "New_myApplyListCell.h"

@implementation New_myApplyListModel

- (id)init{
    if (self = [super init]) {
        _name = @"";
        _partake_time = @"";
        _user_id = @"";
        _approved = @"";
        _block_id = @"";
        _is_create = NO;
    }
    return self;
}

@end

@implementation New_myApplyListCell
@synthesize cellName = _cellName,cellApplyTime = _cellApplyTime,cellImageView = _cellImageView,cellState = _cellState;
- (void)createContentUI{
    
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];
        
        _cellImageView = [[UIImageView alloc]init];
        _cellImageView.frame = CGRectMake(15, 0, ScreenWidth-30, 67);
        _cellImageView.image = [UIImage imageNamed:@"signUp_apply_rejectBG"];
        _cellImageView.userInteractionEnabled = YES;
        [self.contentView addSubview:_cellImageView];
        
        _cellName = [[UILabel alloc]init];
        _cellName.frame = CGRectMake(24, 14.5, ScreenWidth-150, 18);
        _cellName.backgroundColor = [UIColor clearColor];
        _cellName.font = [UIFont systemFontOfSize:17];
        _cellName.textColor = [UIColor blackColor];
        [_cellImageView addSubview:_cellName];
        
        _cellApplyTime = [[UILabel alloc]init];
        _cellApplyTime.frame = CGRectMake(24, CGRectGetMaxY(_cellName.frame)+10.5f, 200, 14);
        _cellApplyTime.font = [UIFont systemFontOfSize:12.5];
        _cellApplyTime.backgroundColor = [UIColor clearColor];
        _cellApplyTime.textColor = [UIColor colorWithHexString:@"#afafaf"];
        [_cellImageView addSubview:_cellApplyTime];
        
        _cellState = [UIButton buttonWithType:UIButtonTypeCustom];
        _cellState.frame = CGRectMake(ScreenWidth-45-69.5, 26, 69.5, 21);
        _cellState.backgroundColor = [UIColor clearColor];
        [_cellState setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _cellState.adjustsImageWhenHighlighted = NO;
        _cellState.titleLabel.font = [UIFont systemFontOfSize:15];
        [_cellImageView addSubview:_cellState];
    }
    return self;
}
- (void)setCellStateType:(NSString *)cellStateType{
    if ([cellStateType isEqualToString:@"2"]) {
        _cellImageView.image = [UIImage imageNamed:@"signUp_apply_passBG"];
        [_cellState setBackgroundImage:[UIImage imageNamed:@"signUp_apply_pass"] forState:UIControlStateNormal];
        [_cellState setTitle:@"报名成功" forState:UIControlStateNormal];
    }
    if([cellStateType isEqualToString:@"0"]){
        _cellImageView.image = [UIImage imageNamed:@"signUp_apply_waitreviewBG"];
        [_cellState setBackgroundImage:[UIImage imageNamed:@"signUp_apply_waitreview"] forState:UIControlStateNormal];
        [_cellState setTitle:@"待审核" forState:UIControlStateNormal];
    }
    if([cellStateType isEqualToString:@"1"]){
        _cellImageView.image = [UIImage imageNamed:@"signUp_apply_rejectBG"];
        [_cellState setBackgroundImage:[UIImage imageNamed:@"signUp_apply_reject"] forState:UIControlStateNormal];
        [_cellState setTitle:@"未通过" forState:UIControlStateNormal];
    }
}
- (void)setFrame:(CGRect)frame{
    frame.size.height -= 10;
    [super setFrame:frame];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
