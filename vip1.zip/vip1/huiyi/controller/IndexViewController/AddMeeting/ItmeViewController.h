//
//  ItmeViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface ItmeViewController : FatherViewController
{
    NSString *_meet_type;
    NSString *_meeting_id;
}
@property (nonatomic,strong)NSString *meet_type;
@property (nonatomic,strong)NSString *meeting_id;
@end
