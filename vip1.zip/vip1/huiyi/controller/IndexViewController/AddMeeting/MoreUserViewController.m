//
//  MoreUserViewController.m
//  huiyi
//
//  Created by songhongshuai on 14/11/18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MoreUserViewController.h"
#import "UserInfoTableViewCell.h"
#import "MineSubCellIpa.h"
#import "MYWebImage.h"
#import "LoginViewController.h"
#import "FriendInfoViewController.h"
@interface MoreUserViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *userInfoTableView;
    NSMutableArray *userInfoArr;
    NSInteger _page;//翻页的页数
}
@end

@implementation MoreUserViewController
@synthesize personal_data_sw = _personal_data_sw;
//导航
- (void)createNavUI{
    self.titlelabel.text = @"更多";
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [MobClick beginLogPageView:@"MoreUserViewController"];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"MoreUserViewController"];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createNavUI];
    _page = 1;
    userInfoArr = [[NSMutableArray alloc]init];
    
    userInfoTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    userInfoTableView.dataSource = self;
    userInfoTableView.delegate = self;

    [userInfoTableView addHeaderWithTarget:self action:@selector(headerRereshing)];
    [userInfoTableView addFooterWithTarget:self action:@selector(footerRereshing)];
    userInfoTableView.headerPullToRefreshText = @"下拉可以刷新了";
    userInfoTableView.headerReleaseToRefreshText = @"松开马上刷新了";
    userInfoTableView.headerRefreshingText = @"正在帮你刷新中";
    userInfoTableView.footerPullToRefreshText = @"上拉可以加载更多数据了";
    userInfoTableView.footerReleaseToRefreshText = @"松开马上加载更多数据了";
    userInfoTableView.footerRefreshingText = @"正在帮你加载中";
    userInfoTableView.backgroundColor = [UIColor clearColor];
    userInfoTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:userInfoTableView];
//    [self showHUD];
    [self getNetDataWithMeetId:_meetID andPage:1];
    // Do any additional setup after loading the view.
}

- (void)networkButtonAction
{
    [self.networkView removeFromSuperview];
    [self getNetDataWithMeetId:_meetID andPage:1];
}

#define HeadViewHeight 55

#pragma mark 获取网络数据
- (void)getNetDataWithMeetId:(NSString *)meetID andPage:(NSInteger)page
{
    [[Dialog Instance]showHSHUDWithController:self];
    NSDictionary *params = @{@"meeting_id": _meetID,@"status_val":@"2",@"num_status":@"1",@"page":[NSString stringWithFormat:@"%ld",(long)page]};
    [MyDataService postPlatformMeetingMetbmnum:params callback:^(id data) {
        [[Dialog Instance]hiddenHSHUD];
        if (![NetworkSingleten shared].isNetwork) {
            [self.view addSubview:self.networkView];
        }
        NSLog(@"%s:%@",__func__,data);
        NSLog(@"%s:%@",__func__,[data JSONString]);
        [self hideHUD];
        if ([[data objectForKey:@"code"]isEqualToString:@"200"]) {
            if (_page == 1) {
                
            }
            if (_page == 1) {
                [userInfoTableView headerEndRefreshing];
                [userInfoArr removeAllObjects];
            }
            else{
                [userInfoTableView footerEndRefreshing];
            }
            for (NSDictionary *dic in [[data objectForKey:@"content"] objectForKey:@"list"]){
                MineSubCellIpa *ipa = [[MineSubCellIpa alloc]init];
                ipa.ipaIsOpen = NO;
                ipa.ipaUserCheckState = [dic objectForKey:@"approved"];//0,未审核，1，未通过，2，已经通过
                ipa.ipaUserHeaderUrl = [dic objectForKey:@"ico_file"];
                ipa.ipaUserIs_cat = [dic objectForKey:@"is_cat"];
                if (![[dic objectForKey:@"email"]isEqualToString:@""]) {
                    ipa.ipaUserEmail = [dic objectForKey:@"email"];
                }
                else{
                    ipa.ipaUserEmail = @"无";
                }
                ipa.ipaUserCompany = [dic objectForKey:@"company"];
                ipa.ipaUserPosition = [dic objectForKey:@"position"];
                ipa.ipaUserName = [dic objectForKey:@"name"];
                if (![[dic objectForKey:@"phone"]isEqualToString:@""]) {
                    ipa.ipaUserPhone = [dic objectForKey:@"phone"];
                }
                else{
                    ipa.ipaUserPhone = @"无";
                }
                ipa.ipaUserTime = [dic objectForKey:@"partake_time"];
                ipa.ipaUserId = [dic objectForKey:@"user_id"];
                [userInfoArr addObject:ipa];
            }
            [userInfoTableView reloadData];
            
        }
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return HeadViewHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [userInfoArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellName = @"cellName";
    UserInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellName];
    MineSubCellIpa *ipa = [userInfoArr objectAtIndex:indexPath.row];
    if (!cell) {
        if ([_personal_data_sw isEqualToString:@"0"]) {
            cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName andIsShowCompany:NO];
        }
        else if ([_personal_data_sw isEqualToString:@"1"]){
            cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName andIsShowCompany:YES];
        }
        else{
            cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName andIsShowCompany:NO];
        }
    }
    [MYWebImage OneImageView:cell.headImageView SetImageWithURL:ipa.ipaUserHeaderUrl  PlaceHolderImageName:@"touxiang262" CacheOrNot:YES] ;
    
    if ([_personal_data_sw isEqualToString:@"1"]) {
        cell.nameLB.text = [NSString stringWithFormat:@"%@  %@",ipa.ipaUserName,ipa.ipaUserPosition];
        
        if (ipa.ipaUserPosition.length) {
            NSMutableAttributedString *string = [[NSMutableAttributedString alloc]initWithString:cell.nameLB.text];
            UIColor *color = [UIColor lightGrayColor];
            [string addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(ipa.ipaUserName.length+2, ipa.ipaUserPosition.length)];
            [string addAttribute:NSFontAttributeName value:YHUI(13) range:NSMakeRange(ipa.ipaUserName.length+2, ipa.ipaUserPosition.length)];
            [cell.nameLB setAttributedText:string];
        }
    }
    else if ([_personal_data_sw isEqualToString:@"2"]) {
        NSString *name = @"";
        int count = [ipa.ipaUserName length];
        for(int i = 0; i < count; i++)
        {
            if (i == 0) {
                name = [ipa.ipaUserName substringToIndex:1];
            }
            else {
                name = [name stringByAppendingFormat:@"%@",@"*"];
            }
        }
        cell.nameLB.text = name;
    }
    else {
        cell.nameLB.text = ipa.ipaUserName;
    }
    
    NSString *time = ipa.ipaUserTime;
    //cell.companyAndPosition.text = [NSString stringWithFormat:@"%@  %@",ipa.ipaUserCompany,ipa.ipaUserPosition];
    cell.companyAndPosition.text = ipa.ipaUserCompany;
    cell.timeLB.text = [self mdate:time];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    /*
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        loginVc.isPush = YES;
        //loginVc.delegate = self;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    MineSubCellIpa *ipa = [userInfoArr objectAtIndex:indexPath.row];
    NSString *user_id = ipa.ipaUserId;
    FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
    friendInfoVC.user_id = user_id;
    [self.navigationController pushViewController:friendInfoVC animated:YES];*/
}
#pragma mark 开始进入刷新状态
- (void)headerRereshing
{
    _page = 1;
    [self getNetDataWithMeetId:_meetID andPage:_page];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
}
- (void)footerRereshing
{
    _page ++;
    [self getNetDataWithMeetId:_meetID andPage:_page];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
