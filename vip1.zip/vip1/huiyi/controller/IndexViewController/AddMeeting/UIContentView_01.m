//
//  UIContentView_01.m
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIContentView_01.h"

@implementation UIContentView_01

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 60, 41)];
        self.nameLB.backgroundColor = [UIColor clearColor];
        self.nameLB.textAlignment = NSTextAlignmentLeft;
        self.nameLB.font = YHUI(15);
        [self  addSubview:self.nameLB];
        
        
        self.contentLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_nameLB.frame)+28, 0, ScreenWidth-100, frame.size.height-0.5)];
        self.contentLB.backgroundColor = [UIColor clearColor];
        self.contentLB.textAlignment = NSTextAlignmentLeft;
        self.contentLB.numberOfLines = 0;
        self.contentLB.lineBreakMode = NSLineBreakByWordWrapping;
        self.contentLB.font = YHUI(15);
        [self  addSubview:self.contentLB];
        
        _line = [[UILabel alloc]initWithFrame:CGRectMake(15, frame.size.height-0.5, ScreenWidth, 0.5)];
        BackGround16Color(_line, @"#c8c7cc");
        [self  addSubview:_line];
        
    }
    return self;
}


@end
