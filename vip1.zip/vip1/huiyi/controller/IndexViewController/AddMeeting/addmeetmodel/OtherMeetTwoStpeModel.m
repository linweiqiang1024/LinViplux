//
//  OtherMeetTwoStpeModel.m
//  huiyi
//
//  Created by songhongshuai on 15/1/22.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "OtherMeetTwoStpeModel.h"

@implementation OtherMeetTwoStpeModel
- (id)init{
    if (self = [super init]) {
        _money = @"";
        _title = @"";
        _showMoreInfo = NO;
        _showTicketPrice = NO;
        _sureTicketType = YES;
    }
    return self;
    
}
@end
