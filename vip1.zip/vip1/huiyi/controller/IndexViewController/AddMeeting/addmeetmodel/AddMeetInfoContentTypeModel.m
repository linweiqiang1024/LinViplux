//
//  AddMeetInfoContentTypeModel.m
//  huiyi
//
//  Created by qstx1 on 14-10-28.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "AddMeetInfoContentTypeModel.h"

@implementation AddMeetInfoContentTypeModel

@end
