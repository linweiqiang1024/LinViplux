//
//  OtherMeetTwoStpeModel.h
//  huiyi
//
//  Created by songhongshuai on 15/1/22.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OtherMeetTwoStpeModel : NSObject
@property (nonatomic,strong) NSString * title;
@property (nonatomic,strong) NSString * money;
@property (nonatomic) BOOL showMoreInfo;
@property (nonatomic) BOOL showTicketPrice;
@property (nonatomic) BOOL sureTicketType;
@end
