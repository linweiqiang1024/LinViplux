//
//  MeetTicketOptionModel.m
//  huiyi
//
//  Created by songhongshuai on 15/1/24.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "MeetTicketOptionModel.h"

@implementation MeetTicketOptionModel
- (id)init
{
    if (self = [super init]) {
        _title = @"";
        _required = @"0";
        _type = @"textField";
        _postKey = @"";
        _extr = @"";
        _profile_id = @"";
        _selectOption = NO;
        _sureOption = NO;
    }
    return self;
}
@end
