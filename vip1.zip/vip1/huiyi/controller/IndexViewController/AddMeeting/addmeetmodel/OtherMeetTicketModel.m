//
//  OtherMeetTicketModel.m
//  huiyi
//
//  Created by songhongshuai on 15/1/22.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "OtherMeetTicketModel.h"

@implementation OtherMeetTicketModel
- (id)init{
    if (self = [super init]) {
        _partake_counts = @"";
        _visible = @"";
        _ticketType = @"";
        _ticketInfo = @"";
        _titleKey = @"";
        _content = @"";
        _cost = @"";
        _profile_id = @"";
        _signUpEndTime = @"";
        _isCheck = NO;
        _fields = nil;
    }
    return self;
}

@end
