//
//  MeetTicketOptionModel.h
//  huiyi
//
//  Created by songhongshuai on 15/1/24.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MeetTicketOptionModel : NSObject
/**
 *  字段名称
 */
@property (nonatomic,strong)NSString *title;
/**
 *  提交服务器用的key
 */
@property (nonatomic,strong)NSString *postKey;
/**
 *  是否审核 0不审核  1审核
 */
@property (nonatomic,strong)NSString *required;
/**
 *  用户报名是所填信息的类型  默认（app只有）textField
 */
@property (nonatomic,strong)NSString *type;
/**
 *  该字段在报名时显示的顺序
 */
@property (nonatomic,strong)NSString *sn;
/**
 *  扩展
 */
@property (nonatomic,strong)NSString *extr;
/**
 *  字段id
 */
@property (nonatomic,strong)NSString *profile_id;
@property (nonatomic)BOOL selectOption;
@property (nonatomic)BOOL sureOption;
@end
