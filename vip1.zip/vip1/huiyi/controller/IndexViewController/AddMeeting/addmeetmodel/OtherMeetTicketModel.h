//
//  OtherMeetTicketModel.h
//  huiyi
//
//  Created by songhongshuai on 15/1/22.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OtherMeetTicketModel : NSObject

@property (nonatomic,strong) NSString * partake_counts;
@property (nonatomic,strong) NSString * visible;
@property (nonatomic,strong) NSString * titleKey;
@property (nonatomic,strong) NSString * content;
/**
 *  会议名称
 */
@property (nonatomic,strong) NSString * ticketType;
/**
 *  票的id
 */
@property (nonatomic,strong) NSString * profile_id;
/**
 *  票价 默认免费票
 */
@property (nonatomic,strong) NSString * cost;
/**
 *  描述
 */
@property (nonatomic,strong) NSString * ticketInfo;
/**
 *  报名截止时间
 */
@property (nonatomic,strong) NSString * signUpEndTime;
/**
 *  是否审核
 */
@property (nonatomic) BOOL  isCheck;
/**
 *  报名字段
 */
@property (nonatomic,strong) NSDictionary * fields;
/**
 *  报名字段顺序
 */
@property (nonatomic,strong) NSString * sn;
@end
