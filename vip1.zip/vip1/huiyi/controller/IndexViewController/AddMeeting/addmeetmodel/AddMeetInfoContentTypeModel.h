//
//  AddMeetInfoContentTypeModel.h
//  huiyi
//
//  Created by qstx1 on 14-10-28.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum  _AddMeetInfoInputType {
    TextInput = 1,        //输入框
    ChooseInput = 2,     //点击跳到下一个界面
    TimeInput = 3,       //时间选择
    TextInputView = 4,  //文本域
    OthersInput,         //其他
}InputType;
@interface AddMeetInfoContentTypeModel : NSObject
{
    
}
@property (strong,nonatomic) NSString *postKey;
@property (strong,nonatomic) NSString *placeholder;
@property (strong,nonatomic) NSString *content;
@property (strong,nonatomic) NSString *time;//记录时间戳
@property (strong,nonatomic) NSString *iChange;
@property (nonatomic,assign) InputType iType;

@end
