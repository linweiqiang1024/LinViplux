//
//  MeetTypeCollectionViewCell.h
//  huiyi
//
//  Created by 林伟强 on 16/7/28.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^SendViewBlock)(id sender);

@interface MeetTypeCollectionViewCell : UICollectionViewCell

@property (nonatomic, copy) SendViewBlock sendBlock;
@property (nonatomic, strong) UIButton  * titleButton;

@end
