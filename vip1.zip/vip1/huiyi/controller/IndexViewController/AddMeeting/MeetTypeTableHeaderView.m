//
//  MeetTypeTableHeaderView.m
//  huiyi
//
//  Created by 林伟强 on 16/7/29.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "MeetTypeTableHeaderView.h"
#import "UICollectionViewLeftAlignedLayout.h"
#import "MeetTypeCollectionViewCell.h"
#import "MeetTypeCollectionHeaderView.h"

#define kControllerHeaderViewHeight                40
#define kCollectionViewCellsHorizonMargin          10
#define kCollectionViewCellHeight                  30

#define kCollectionViewToLeftMargin                15
#define kCollectionViewToTopMargin                 0
#define kCollectionViewToRightMargin               (([UIScreen mainScreen].bounds.size.height==667 || [UIScreen mainScreen].bounds.size.height==736) ? 15 : 0)
#define kCollectionViewToBottomtMargin             10

#define kCellBtnCenterToBorderMargin               20

typedef void(^ISLimitWidth)(BOOL yesORNo,id data);

static NSString * const kCellIdentifier           = @"MCellIdentifier";
static NSString * const kHeaderViewCellIdentifier = @"MHeaderViewCellIdentifier";

@interface MeetTypeTableHeaderView ()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic, strong) UIButton  * selectedBtn;
@property (nonatomic, assign) NSInteger   selected;
@property (nonatomic, strong) NSMutableArray   *meetIDArray;

@end

@implementation MeetTypeTableHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.meetIDArray = [NSMutableArray array];
        [[NSUserDefaults standardUserDefaults] setObject:self.meetIDArray forKey:@"meetTag"];
        self = [self sharedInit];
    }
    return self;
}

- (id)initWithCoder: (NSCoder *)aDecoder {
    self = [super initWithCoder: aDecoder];
    if (self) {
        self = [self sharedInit];
    }
    return self;
}

- (id)sharedInit {
    self.selected = 200;
    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"meetType"];
    
    CGRect collectionViewFrame = CGRectMake(0, 0, ScreenWidth, 160);
    UICollectionViewLeftAlignedLayout * layout = [[UICollectionViewLeftAlignedLayout alloc] init];
    self.collectionView = [[UICollectionView alloc] initWithFrame:collectionViewFrame collectionViewLayout:layout];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[MeetTypeCollectionViewCell class] forCellWithReuseIdentifier:kCellIdentifier];
    self.collectionView.allowsMultipleSelection = YES;
    
    [self.collectionView registerClass:[MeetTypeCollectionHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kHeaderViewCellIdentifier];
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.showsVerticalScrollIndicator = NO;
    self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.collectionView.scrollsToTop = YES;
    self.collectionView.scrollEnabled = NO;
    [self addSubview:self.collectionView];
    
    self.bottomLineView = [[UIImageView alloc] initWithFrame:CGRectMake(0, collectionViewFrame.size.height-0.5, ScreenWidth, 0.5)];
    self.bottomLineView.hidden = YES;
    [self.bottomLineView setBackgroundColor:[UIColor colorWithHexString:@"#E3E3E3"]];
    [self addSubview:self.bottomLineView];
    
    return self;
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return [self.dataSource count];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSMutableArray * array = self.dataSource[section];
    return array.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MeetTypeCollectionViewCell *cell = (MeetTypeCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:kCellIdentifier forIndexPath:indexPath];
    cell.titleButton.frame = CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height);

    NSMutableArray * array = self.dataSource[indexPath.section];
    
    if (self.isType) {
        NSString *text = array[indexPath.row];
        [cell.titleButton setTag:indexPath.row+200];
        [cell.titleButton setBackgroundColor:[UIColor clearColor]];
        [cell.titleButton setTitle:text forState:UIControlStateNormal];
        [cell.titleButton setSelected:NO];
        [cell.titleButton.layer setBorderColor:[[UIColor colorWithHexString:@"#686868"] CGColor]];
        if (cell.titleButton.tag == self.selected) {
            [cell.titleButton setSelected:YES];
            [cell.titleButton.layer setBorderColor:[[UIColor colorWithHexString:@"#0aaa08"] CGColor]];
        }
        
        cell.sendBlock = ^(id sender)
        {
            if (self.delegate && [self.delegate respondsToSelector:@selector(endEdit)]) {
                [self.delegate endEdit];
            }
            
            UIButton *clickButton = (UIButton *)sender;
            self.selected = clickButton.tag;
            [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d",(int)clickButton.tag-200] forKey:@"meetType"];
            [self.collectionView reloadData];
        };

    }
    else {
        NSString *text = array[indexPath.row][@"name"];
        [cell.titleButton setTag:indexPath.row+200];
        [cell.titleButton setBackgroundColor:[UIColor clearColor]];
        [cell.titleButton setTitle:text forState:UIControlStateNormal];
        cell.sendBlock = ^(id sender)
        {
            if (self.delegate && [self.delegate respondsToSelector:@selector(endEdit)]) {
                [self.delegate endEdit];
            }
            
            UIButton *clickButton = (UIButton *)sender;
            
            //NSString *str = [[NSUserDefaults standardUserDefaults] objectForKey:@"newMeetEdit"];
            NSMutableArray *meetTagArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"meetTag"];
            NSMutableArray *newMeetTagArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"newMeetTag"];
            
            NSMutableArray *newMeetArr = [NSMutableArray array];
            for (int i = 0; i < newMeetTagArr.count; i++) {
                if (![newMeetTagArr[i] isEqualToString:@""]) {
                    [newMeetArr addObject:newMeetTagArr[i]];
                }
            }
            int count = meetTagArr.count + newMeetArr.count;
            /*if ([str isEqualToString:@"1"]) {
                count = count+1;
            }*/
            
            if (count >= 4 && clickButton.selected == NO) {
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"会议标签最多可以支持4个" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alertView show];
            }
            else {
                NSString *meetID = array[clickButton.tag-200][@"id"];
                
                clickButton.selected = !clickButton.selected;
                if (clickButton.selected) {
                    [clickButton.layer setBorderColor:[[UIColor colorWithHexString:@"#0aaa08"] CGColor]];
                    /*
                     BOOL haveMeetID = NO;
                     for (NSString *meetid in self.meetIDArray) {
                     if ([meetid isEqualToString:meetID]) {
                     haveMeetID = YES;
                     }
                     }
                     if (!haveMeetID) {
                     [self.meetIDArray addObject:meetID];
                     }*/
                    [self.meetIDArray addObject:meetID];
                    [[NSUserDefaults standardUserDefaults] setObject:self.meetIDArray forKey:@"meetTag"];
                }
                else {
                    [clickButton.layer setBorderColor:[[UIColor colorWithHexString:@"#686868"] CGColor]];
                    for (int i = 0; i < self.meetIDArray.count; i++) {
                        if ([self.meetIDArray[i] isEqualToString:meetID]) {
                            [self.meetIDArray removeObjectAtIndex:i];
                        }
                    }
                    [[NSUserDefaults standardUserDefaults] setObject:self.meetIDArray forKey:@"meetTag"];
                    
                }
                
            }
        };
    }
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqual:UICollectionElementKindSectionHeader]) {
        MeetTypeCollectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kHeaderViewCellIdentifier forIndexPath:indexPath];
        headerView.titleLabel.text = self.title;
        return (UICollectionReusableView *)headerView;
    }
    return nil;
}

- (float)getCollectionCellWidthText:(NSString *)text{
    float cellWidth;
    CGSize size = [text sizeWithAttributes:
                   @{NSFontAttributeName:
                         [UIFont systemFontOfSize:12.0]}];
    if (iPhone6 || iphone6Plus) {
        size = [text sizeWithAttributes:
                @{NSFontAttributeName:
                      [UIFont systemFontOfSize:13.0]}];
    }
    cellWidth = ceilf(size.width) + kCellBtnCenterToBorderMargin;
    cellWidth = [self checkCellLimitWidth:cellWidth isLimitWidth:nil];
    return cellWidth;
}

- (float)checkCellLimitWidth:(float)cellWidth isLimitWidth:(ISLimitWidth)isLimitWidth {
    float limitWidth = (CGRectGetWidth(self.collectionView.frame)-kCollectionViewToLeftMargin-kCollectionViewToRightMargin);
    if (cellWidth >= limitWidth) {
        cellWidth = limitWidth;
        isLimitWidth?isLimitWidth(YES,@(cellWidth)):nil;
        return cellWidth;
    }
    isLimitWidth?isLimitWidth(NO,@(cellWidth)):nil;
    return cellWidth;
}

#pragma mark - UICollectionViewDelegateLeftAlignedLayout

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // cell 的宽
    NSMutableArray * array = self.dataSource[indexPath.section];
    NSString *text;
    if (self.isType) {
        text = array[indexPath.row];
    }
    else {
        text = array[indexPath.row][@"name"];
    }
    float cellWidth = [self getCollectionCellWidthText:text];
    return CGSizeMake(cellWidth, kCollectionViewCellHeight);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return kCollectionViewCellsHorizonMargin;//cell之间的间隔
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake([UIScreen mainScreen].bounds.size.width, kControllerHeaderViewHeight);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    //四周边距
    return UIEdgeInsetsMake(kCollectionViewToTopMargin, kCollectionViewToLeftMargin, kCollectionViewToBottomtMargin, kCollectionViewToRightMargin);
}

@end
