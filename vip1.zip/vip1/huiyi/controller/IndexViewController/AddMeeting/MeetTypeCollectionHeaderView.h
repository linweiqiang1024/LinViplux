//
//  MeetTypeCollectionHeaderView.h
//  huiyi
//
//  Created by 林伟强 on 16/7/28.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeetTypeCollectionHeaderView : UICollectionReusableView

@property (nonatomic,strong) UILabel * titleLabel;

@end
