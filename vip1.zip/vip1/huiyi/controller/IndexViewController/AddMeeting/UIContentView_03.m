//
//  UIContentView_03.m
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIContentView_03.h"

@implementation UIContentView_03

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 60, 41)];
        self.nameLB.backgroundColor = [UIColor clearColor];
        self.nameLB.textAlignment = NSTextAlignmentLeft;
        self.nameLB.font = YHUI(15);
        [self  addSubview:self.nameLB];
        
        
        self.desImageView = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_nameLB.frame)+15, 9, 26, 26)];
        self.desImageView.backgroundColor = [UIColor clearColor];
        _desImageView.layer.cornerRadius = _desImageView.frame.size.width/2;
        
        _desImageView.layer.masksToBounds= YES;
        [self addSubview:_desImageView];
        
        self.contentLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_desImageView.frame)+7, 0, ScreenWidth-60-CGRectGetMaxX(_desImageView.frame)-7, 40.5)];
        self.contentLB.backgroundColor = [UIColor clearColor];
        self.contentLB.textAlignment = NSTextAlignmentLeft;
        self.contentLB.font = YHUI(15);
        self.contentLB.textColor = [UIColor colorWithHexString:@"8e8e8e"];
        [self addSubview:self.contentLB];
        
        _mesBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _mesBtn.frame = CGRectMake(260, 10, 48, 21);
        [_mesBtn setBackgroundImage:[UIImage imageNamed:@"chat_button-bg"] forState:UIControlStateNormal];
        [_mesBtn addTarget:self action:@selector(chatBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [_mesBtn setTitle:@"聊天" forState:UIControlStateNormal];
        _mesBtn.titleLabel.font = YHUI(16);
        [self addSubview:_mesBtn];
        _line = [[UILabel alloc]initWithFrame:CGRectMake(15, frame.size.height-0.5, ScreenWidth, 0.5)];
        BackGround16Color(_line, @"#c8c7cc");
        [self  addSubview:_line];
        
    }
    return self;
}
- (void)chatBtnClick
{
    [_delegate sentMessage];
}

@end
