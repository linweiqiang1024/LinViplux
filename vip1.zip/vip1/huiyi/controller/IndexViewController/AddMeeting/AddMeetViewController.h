//
//  AddMeetViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-14.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface AddMeetViewController : FatherViewController
{
    UITableView *_createMeetTV;
}
@property (nonatomic, retain) NSArray *photos;
@property (nonatomic, strong) NSMutableArray *thumbs;
@end
