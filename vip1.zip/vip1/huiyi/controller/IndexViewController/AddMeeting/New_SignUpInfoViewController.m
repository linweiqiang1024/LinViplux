//
//  New_SignUpInfoViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-31.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "New_SignUpInfoViewController.h"
#import "EnjoyTableViewCell.h"
#import "UserInfoTableViewCell.h"
#import "UIOptionButton.h"
#import "FirstPageControl.h"
#import "UIBottomBtn.h"
#import "MYWebImage.h"
#import "WXApi.h"
#import "Cell.h"
#import "SignUpConfigTool.h"
#import "MyShareTool.h"
#import "GTMBase64.h"
#import "UIImageView+WebCache.h"
#import "HPGrowingTextView.h"
#import "OpenLoginTool.h"
#import "StringToHtml.h"
#import "UIContentView_01.h"
#import "UIContentVIew_02.h"
#import "UIContentView_03.h"
#import <MessageUI/MessageUI.h>
#import "CheckInViewController.h"
#import "GuestViewController.h"
#import "DataDownLoadViewController.h"
#import "articleViewController.h"
#import "ScheduleViewController.h"
#import "MapViewController.h"
#import "SignUpTypeViewController.h"
#import "SignUpStatusViewController.h"
#import "BriefViewController.h"
#import "UpViewController.h"
#import "UpInfoViewController.h"
#import "PersonalInfoController.h"
#import "EduExpViewController.h"
#import "LoginViewController.h"
#import "SDShareActionSheet.h"
#import "SDTableView.h"
#import "VoteListViewController.h"
#import "UIButton+WebCache.h"
#import "WebViewTableViewCell.h"
#import "MoreUserViewController.h"
#import "New_signUpInfoListVC.h"
#import <MessageUI/MFMailComposeViewController.h>
#import "New_myApplyListViewController.h"
#import <ShareSDK/ShareSDK.h>
#import "ChatViewController.h"
#import "FriendInfoViewController.h"
#import "BlackTransView.h"
#import "MoreButtonView.h"
#import "NSString+Size.h"
#import "TimeAndAddress.h"
#import "TimeAndAddressIpa.h"
#import "DateFormat.h"
#import "Dialog.h"
#import "SDTicketModel.h"
#import "BmnumBtn.h"
#import "skipManagerTool.h"
#import "NotificationCenterHeader.h"
#import "MyScheduleViewController.h"
#import "ManagerAssessViewController.h"
#import "HintAlertView.h"

static CGFloat ImageHeight  = 220.0;//定义图片的高度

@interface New_SignUpInfoViewController () <UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate,ShareActionDelegate,reloadDelegate,UIAlertViewDelegate,MFMessageComposeViewControllerDelegate,MFMailComposeViewControllerDelegate,HPGrowingTextViewDelegate,MWPhotoBrowserDelegate,SDTableViewDelegate,timeAndAddressDelegate,UIActionSheetDelegate,HintAlertViewDelegate>
{
    UIImage *shareIcon;
    NSString *shareTitle;
    NSString *shareMessage;
    NSString *message;
    //==================
    NSMutableArray *_likeArr;
    NSMutableArray *_bmListArr;
    NSMutableArray *_nameArr;
    NSMutableArray *_imageArr;
    NSMutableArray *_gridArr;
    NSMutableArray *_stateArr;

    NSDictionary *_configDic;//当前会议配置
    NSDictionary *_nextViewDic;//下一页配置
    NSDictionary *_configDictionary;

    NSString *_version;
    NSString *_session;
    NSString *_signUpstate;
    BOOL _firstConfig;
    BOOL _configEnd;
    BOOL _infoEnd;
    BOOL _isLike;//是否点赞
    BOOL _bmEnd;
    BOOL _isLoad;//是否已经加载；
    UITableView *newSignUpInfoView;
    NSMutableArray *_optionsArr;
    UIView *headView;

    UIView *_optionView;//插件
    UILabel *_titleLB;
    UILabel *_timeRangeLB;
    UILabel *_sourceLB;
    UILabel *_timeLB;
    UILabel *_shareNumLB;
    UILabel *_readNumLB;
    UILabel *_adressLB;
    UIView *contentlabel;

    CGFloat _contentInfoViewHeight;
    CGFloat itemviewheight;
    NSString * _bmCount;
    UIButton *_signUpBtn;//我要报名  按钮
    UIButton *_replceSignUpBtn;//带人报名  按钮
    UIView *_signUpBG;//底部的两个连个按钮的父视图

    NSIndexPath *webCellIndexPath;
    SDShareActionSheet *shareSheet;
    SDTableView *_sdTableView;
    BOOL viewdidload;
    //by wang zhenxing
    NSString *_personal_data_sw;//是否显示已报名成员列表状态
    UIImageView *_navBGView1;//nav的背景图
    UILabel *_titlelabel1;//nav的标题

    UIImageView *_backBGImageView;//返回按钮的背景色
    UIImageView *_collectBG;//收藏的背景色
    UIImageView *_shareBG;//分享的背景色
    UIImageView *_bmCountBG;//我报名的数量按钮
    UIButton *_stateButton;//会议进行的状态

    TimeAndAddressIpa *_timeAndAddIpa;//时间和地址方面的数据源

    FirstPageControl *_imagePageControl;//页码控件

    NSMutableArray * _ticketArr;//票的基本信息
    NSIndexPath *ticketIndexPath;//选中什么票
    UIButton *_goTopView;//回到第一行
    NSString *tickte_title;

    CGPoint startPoint;
    NSString *_heOrShePhone;
    
    BOOL _showPluginStatus;
    int showPluginStatusNmb;
    
    NSString *meetBeginTime;
    NSString *meetEndTime;
    
    NSString *yqxBackUrl;
}
@property (nonatomic,strong) NSMutableArray   *optionsArr;
@property (nonatomic,strong) FirstPageControl *pageControl;
@property (nonatomic,strong) NSMutableArray   *photos;
@property (nonatomic,strong) BlackTransView   *blacktransImageView;//半透明的View--顶部
@property (nonatomic,strong) UIButton         *collectBtn;//收藏按钮
@property (nonatomic,strong) UIWebView        *mainWebView;
@property (nonatomic,strong) UITableViewCell  *webCell;//单独的WebCell
@property (nonatomic,strong) TimeAndAddress   *timeAndAddressView;//时间和地址方面的View
@property (nonatomic,strong) BmnumBtn         *bmCountBtn;
@property (nonatomic,strong) UIWebView        *meetPosterWebView;
@property (nonatomic,strong) UIButton         *replceSignUpBtn;
@property (nonatomic,strong) UIButton         *signUpBtn;
@property (nonatomic       ) BOOL             replceSignUpBtnClicked;
@property (nonatomic,strong) NSString         *company_code;
@property (nonatomic,strong) UIScrollView     *optionScrollView;
@property (nonatomic,strong) UIView           *optionView;//插件
@property (nonatomic,strong) UIAlertView      *alertView;
@property (nonatomic,strong) HintAlertView    *hintAlertView;
@end

@implementation New_SignUpInfoViewController
@synthesize haveImage = _haveImage;//有没有海报图片
@synthesize meet_type = _meet_type;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _showPluginStatus = YES;

    _heOrShePhone = @" ";
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    
    self.titlelabel.text = @"详情";
    
    self.haveImage = NO;
    
    //[self createRightNavItme];//创建导航右边的按钮
    _session = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"];
    //self.titlelabel.text = _meetTitle;
    _version = @"0";
    _timeAndAddIpa = [[TimeAndAddressIpa alloc]init];
    itemviewheight = 0;
    viewdidload = YES;
    _bmListArr = [[NSMutableArray alloc]initWithCapacity:0];
    _likeArr = [[NSMutableArray alloc]initWithCapacity:0];
    _nameArr = [[NSMutableArray alloc]initWithCapacity:0];
    _imageArr = [[NSMutableArray alloc]initWithCapacity:0];
    _gridArr = [[NSMutableArray alloc]initWithCapacity:0];
    _stateArr = [[NSMutableArray alloc]initWithCapacity:0];
    _ticketArr = [[NSMutableArray alloc]initWithCapacity:0];
    [_imageArr addObjectsFromArray:@[@"meetInfo1@2x",@"meetInfo2@2x",@"meetInfo3@2x",@"meetInfo4@2x",@"meetInfo5@2x"]];
    [_nameArr addObjectsFromArray:@[@"大会简介",@"日程",@"地图",@"签到",@"资料下载",@"嘉宾"]];
    _optionsArr = [[NSMutableArray alloc]initWithCapacity:0];
    NSMutableArray *_imageArrs;
    [_imageArrs addObjectsFromArray:@[@"meetInfo1@2x",@"meetInfo2@2x",@"meetInfo3@2x",@"meetInfo4@2x",@"meetInfo5@2x"]];
    
    if (![DBManager reachInternet]) {
        //[[Dialog Instance] hideProgress];
        [[Dialog Instance] hiddenHSHUD];
        //[[Dialog Instance] alert:@"没有可以连接的网络"];
        [self.view addSubview:self.networkView];
        return;
    }
    //[self getDBMeetInfo];
}

- (void)networkButtonAction
{
    [self.networkView removeFromSuperview];
    [self getDBMeetInfo];
}

- (UIButton *)signUpBtn
{
    if (!_signUpBtn) {
        _signUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_signUpBtn setTitle:@"我要报名" forState:UIControlStateNormal];
        _signUpBtn.adjustsImageWhenHighlighted = NO;
        [_signUpBtn.layer setNeedsDisplay];
        _signUpBtn.backgroundColor = [UIColor colorWithHexString:@"#17b4eb"];
        _signUpBtn.frame = CGRectMake(0,  0, ScreenWidth/3*2, 50);
        [_signUpBtn addTarget:self action:@selector(signUpBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _signUpBtn;
}

- (UIButton *)replceSignUpBtn
{
    if (!_replceSignUpBtn) {
        _replceSignUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_replceSignUpBtn setTitle:@"代人报名" forState:UIControlStateNormal];
        _replceSignUpBtn.adjustsImageWhenHighlighted = NO;
        [_replceSignUpBtn.layer setNeedsDisplay];
        _replceSignUpBtn.backgroundColor = [UIColor colorWithHexString:@"#c6c5ca"];
        _replceSignUpBtn.frame = CGRectMake(ScreenWidth/3*2,  0, ScreenWidth/3, 50);
        [_replceSignUpBtn addTarget:self action:@selector(signUpBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _replceSignUpBtn;
}

- (UIWebView *)meetPosterWebView
{
    if (!_meetPosterWebView) {
        _meetPosterWebView = [[UIWebView alloc]initWithFrame:self.view.bounds];
        _meetPosterWebView.delegate = self;
        [_meetPosterWebView setMediaPlaybackRequiresUserAction:NO];
    }
    return _meetPosterWebView;
}

- (BmnumBtn *)bmCountBtn
{
    if (!_bmCountBtn) {
        _bmCountBtn = [BmnumBtn buttonWithType:UIButtonTypeCustom];
        _bmCountBtn.frame = CGRectMake(54, self.navheight, 44, 44);
        [_bmCountBtn setBackgroundImage:[UIImage imageNamed:@"new_info_piao"] forState:UIControlStateNormal];
        //[_bmCountBtn setImage:[UIImage imageNamed:@"new_info_count"] forState:UIControlStateNormal];
        [_bmCountBtn setTitle:@"" forState:UIControlStateNormal];
        _bmCountBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        _bmCountBtn.titleLabel.font = [UIFont systemFontOfSize:12];
        _bmCountBtn.titleLabel.backgroundColor = [UIColor clearColor];
        [_bmCountBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _bmCountBtn.adjustsImageWhenHighlighted = NO;
        [_bmCountBtn addTarget:self action:@selector(bmCountBtnClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _bmCountBtn;
}

- (FirstPageControl *)pageControl
{
    if (!_pageControl) {
        _pageControl = [[FirstPageControl alloc]initWithFrame:CGRectMake((ScreenWidth-100)/2.0f, 188 - 30, 100, 20)];
        _pageControl.dotColorCurrentPage = [UIColor colorWithHexString:@"#6e6e6e"];
        _pageControl.dotColorOtherPage = [UIColor colorWithHexString:@"#cfcfcf"];
        _pageControl.currentPage = 0;
    }
    return _pageControl;
}

- (TimeAndAddress *)timeAndAddressView
{
    if (!_timeAndAddressView) {
        _timeAndAddressView = [[TimeAndAddress alloc]initWithType:_meet_type];
        _timeAndAddressView.delegate = self;
        _timeAndAddressView.clipsToBounds = YES;
        _timeAndAddressView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    return _timeAndAddressView;
}

- (UIButton *)collectBtn
{
    if (!_collectBtn) {
        _collectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _collectBtn.frame = CGRectMake(ScreenWidth-44-5-44, self.navheight, 44, 44);
        [_collectBtn setImage:[UIImage imageNamed:@"meetInfo_noBGcollect"] forState:UIControlStateNormal];
        [_collectBtn setImage:[UIImage imageNamed:@"new_cellected"] forState:UIControlStateSelected];
        _collectBtn.adjustsImageWhenHighlighted = NO;
        [_collectBtn addTarget:self action:@selector(navRightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [_collectBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _collectBtn.tag = 112;
    }
    return _collectBtn;
}

- (BlackTransView *)blacktransImageView
{
    if (!_blacktransImageView) {
        _blacktransImageView = [[BlackTransView alloc]initWithTitle:nil andTime:nil andReadCount:nil andState:nil andIsShowBlackTrans:YES andIsShowSwitch:NO];
        UIImage *blacktransImage = [UIImage imageNamed:@"meetInfo_blacktrans"];
        UIImage *blacktransImageed;
        if (IOS5) {
            blacktransImageed = [blacktransImage resizableImageWithCapInsets:UIEdgeInsetsMake(10, 100, 10, 40)];
        }
        else {
            blacktransImageed = [blacktransImage resizableImageWithCapInsets:UIEdgeInsetsMake(10, 100, 10, 40)resizingMode:UIImageResizingModeStretch];
        }
        _blacktransImageView.image = blacktransImageed;
        _blacktransImageView.frame = CGRectMake(0, ImageHeight-59, ScreenWidth, 59);
    }
    return _blacktransImageView;
}

- (UIScrollView *)optionScrollView
{
    if (!_optionScrollView) {
        _optionScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0)];
        _optionScrollView.delegate = self;
        _optionScrollView.backgroundColor = [UIColor clearColor];
        if (@available(iOS 11.0, *))
        {
            _optionScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    return _optionScrollView;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getMeetStatus];
    [MobClick beginLogPageView:@"New_SignUpInfoViewController"];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getMeetConfigData) name:IndexViewToDetailsFailureKey object:nil];
    [[UINavigationBar appearance] setBarTintColor:[UIColor blackColor]];
    [self getDBMeetInfo];
}

- (void)dealloc
{
    NSLog(@"New_SignUpInfoViewController dealloc");
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    viewdidload = NO;
    if (shareSheet.isShow) {
        [shareSheet tappedCancel];
    }
    if (_sdTableView.isShow) {
        _sdTableView.isShow = NO;
        [_sdTableView tappedCancel];
    }
    [MobClick endLogPageView:@"New_SignUpInfoViewController"];
}

- (NSMutableArray *)photoMutableArray
{
    if (_photoMutableArray == nil) {
        _photoMutableArray = [[NSMutableArray alloc]init];
    }
    return _photoMutableArray;
}

- (void)createRightNavItme
{
    if (_haveImage) {
        _backBGImageView = [[UIImageView alloc]initWithFrame:CGRectMake(10, self.navheight+5, 34, 34)];
        _backBGImageView.image = [UIImage imageNamed:@"meetInfo_BG"];
        [self.view addSubview:_backBGImageView];
    }
    self.leftnavbtn.hidden = YES;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(5, self.navheight, 44, 44);
    leftBtn.backgroundColor = [UIColor clearColor];
    leftBtn.adjustsImageWhenHighlighted = NO;
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn addTarget:self action:@selector(navRightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [leftBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    leftBtn.tag = 111;
    [self.view addSubview:leftBtn];
    
    if (_haveImage) {
        _bmCountBG = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxY(_backBGImageView.frame), self.navheight+5, 34, 34)];
        _bmCountBG.image = [UIImage imageNamed:@"meetInfo_BG"];
    }
    [self.view addSubview:self.bmCountBtn];
    
    if (_haveImage) {
        _collectBG = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-44-5-44+5, self.navheight+5, 34, 34)];
        _collectBG.image = [UIImage imageNamed:@"meetInfo_BG"];
        [self.view addSubview:_collectBG];
    }
    [self.view addSubview:self.collectBtn];
    
    if (_haveImage) {
        _shareBG = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-44-5+5, self.navheight+5, 34, 34)];
        _shareBG.image = [UIImage imageNamed:@"meetInfo_BG"];
        [self.view addSubview:_shareBG];
    }
    
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth-44-5, self.navheight, 44, 44);
    rightBtn.adjustsImageWhenHighlighted = NO;
    [rightBtn setImage:[UIImage imageNamed:@"meetInfo_noBGshare"] forState:UIControlStateNormal];
    [rightBtn addTarget:self action:@selector(navRightBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    rightBtn.tag = 2;
    [self.view addSubview:rightBtn];
}

- (void)hintAlertViewAction {
    [[OpenLoginTool sharedManager]loginOff];
    LoginViewController *loginVc = [[LoginViewController alloc]init];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
    loginVc.fromSignVC = YES;
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        loginVc.isPush = YES;
    }
    loginVc.delegate = self;
    loginVc.companyCode = self.companyCode;
    [self presentViewController:nav animated:YES completion:^{
        
    }];
}

- (BOOL)compareCompanyCode
{
    NSString *login_company_code = [[[NSUserDefaults standardUserDefaults]objectForKey:@"login_company_code"] lowercaseString];
    login_company_code =  [login_company_code stringByReplacingOccurrencesOfString:@" " withString:@""];
    self.company_code = [self.company_code stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (self.company_code.length != 0) {
        if ((login_company_code.length && ![login_company_code isEqualToString:[self.company_code lowercaseString]]) || (!login_company_code.length && ![[self.company_code lowercaseString] isEqualToString:@"huiyiabc"]))                                                                                                                                                                                          {
            /*
            UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入该会议的企业号并重新登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"重新登录", nil];
            alertview.tag = 3000;
            [alertview show];*/
            
            NSString *companyMessage = [NSString stringWithFormat:@"您扫描了『%@』公司的活动二维码，如确认要参加此活动，请重新登录并在企业号中输入：%@", self.companyName, self.companyCode];
            self.hintAlertView = [[HintAlertView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
            self.hintAlertView.delegate = self;
            [self.hintAlertView reloadViewWithTitle:@"提示" message:companyMessage range:NSMakeRange(companyMessage.length-self.companyCode.length, self.companyCode.length) cancelButtonTitle:@"取消" otherButtonTitle:@"重新登录"  messageAlignment:NSTextAlignmentLeft];
            [self.hintAlertView show];
            
            return YES;
        }
        else {
            return NO;
        }
    }
    else {
        return NO;
    }
}

- (BOOL)compareAuthSession
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        [[NSUserDefaults standardUserDefaults]setObject:_company_code forKey:@"company_code"];
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return YES;
    }
    else {
        return NO;
    }
}

- (void)navRightBtnClick:(UIButton *)btn
{
    if (btn.tag == 111) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if (btn.tag == 112) {
        if ([self compareAuthSession]) {
            return;
        }
        if ([self compareCompanyCode]) {
            return;
        }
        NSString *collect_state = @"0";
        if (self.collectBtn.selected) {
            collect_state = @"0";
            [[Dialog Instance] showCenterProgressWithText:@"取消收藏"];
        }
        else{
            collect_state = @"1";
            [[Dialog Instance] showCenterProgressWithText:@"添加收藏"];
        }
        NSString *user_id = [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"];
        if (user_id.length ==0) {
            user_id = @" ";
        }
        NSDictionary *params = @{@"user_id":user_id,@"meeting_id":_meetID,@"collect_state":collect_state};
        [MyDataService postPlatformCollectCollectadd:params calllback:^(id data) {
            NSLog(@"%s:%@",__func__,data);
            [[Dialog Instance] hideProgress];
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                if ([data[@"code"] isEqualToString:@"200"] || [data[@"code"] isEqualToString:@"201"]) {
                    self.collectBtn.selected = !self.collectBtn.selected;
                    [self performSelector:@selector(delayMethod) withObject:nil afterDelay:0.6f];
                }
                else if ([data[@"code"] isEqualToString:@"203013"]){
                    /*
                    UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入该会议的企业号并重新登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"重新登录", nil];
                    alertview.tag = 3000;
                    [alertview show];*/
                    NSString *companyMessage = [NSString stringWithFormat:@"您扫描了『%@』公司的活动二维码，如确认要参加此活动，请重新登录并在企业号中输入：%@", self.companyName, self.companyCode];
                    self.hintAlertView = [[HintAlertView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
                    self.hintAlertView.delegate = self;
                    [self.hintAlertView reloadViewWithTitle:@"提示" message:companyMessage range:NSMakeRange(companyMessage.length-self.companyCode.length, self.companyCode.length) cancelButtonTitle:@"取消" otherButtonTitle:@"重新登录"  messageAlignment:NSTextAlignmentLeft];
                    [self.hintAlertView show];
                }
            }
        }];
    }
    else {
        [MyShareTool sharedManager].controller = self;
        [MyShareTool sharedManager].content = [NSString stringWithFormat:@"Hi,我觉得这个活动『%@』很符合你的兴趣，邀请你来报个名吧！",shareTitle];
        [[MyShareTool sharedManager]shareMeetingWith:shareMessage MeetingTitle:shareTitle MeetingId:_meetID WithView:btn];
    }
}

- (void)delayMethod
{
    if (self.collectBtn.selected) {
        [self showPopView:@"已收藏" andFrameY:ScreenHeight/2+30];
    }
    else {
        [self showPopView:@"已取消收藏" andFrameY:ScreenHeight/2+30];
    }
}

#pragma mark SDtableView delegate

- (void)backClicked
{
    [_sdTableView tappedCancel];
}

- (void)sureClicked:(id)btn
{
    SDTicketModel * info = [_ticketArr objectAtIndex:ticketIndexPath.row];
    [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%ld",(long)ticketIndexPath.row] forKey:@"ticketIndex"];
    NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
    [ticket setObject:info.name forKey:@"name"];
    [ticket setObject:info.block_id forKey:@"block_id"];
    [ticket setObject:info.price forKey:@"price"];
    [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
    [ticket setObject:info.note forKey:@"note"];
    [ticket setObject:info.visible forKey:@"visible"];
    [self writePlistToDucment:@"ticketinfo" With:ticket];
    [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
    [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
    
    if (_replceSignUpBtnClicked == YES) {
        if (info.meetEnd == NO) {
            SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
            tool.signUpstate = _signUpstate;
            tool.controller = self;
            tool.meeting_id = _meetID;
            tool.blockID = _blockID;
            tool.configDic = _configDic;
            [tool manageSubConfigWithSameTicket:ticketIndexPath.row];
        }
        else {
            //[Dialog toastCenter:@"报名已结束"];
            [Dialog toastCenter:@"报名已截止"];
        }
    }
    else {
        if (info.meetEnd == NO) {
            SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
            tool.signUpstate = _signUpstate;
            tool.controller = self;
            tool.meeting_id = _meetID;
            tool.blockID = _blockID;
            tool.configDic = _configDic;
            [tool manageConfigWithSameTicket:ticketIndexPath.row];
        }
        else {
            //[Dialog toastCenter:@"报名已结束"];
            [Dialog toastCenter:@"报名已截止"];
        }
    }
}

#pragma mark --- shareDelegate

- (void)returnShareInfo:(NSDictionary *)dic
{
    
}

- (void)cancelClicked
{
    [shareSheet tappedCancel];
}

- (void)nextClicked:(id)btn
{
    
}

- (void)showSMSPicker
{
    //  The MFMessageComposeViewController class is only available in iPhone OS 4.0 or later.
    //  So, we must verify the existence of the above class and log an error message for devices
    //  running earlier versions of the iPhone OS. Set feedbackMsg if device doesn't support
    //      MFMessageComposeViewController API.
    Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
    if (messageClass != nil) {
        // Check whether the current device is configured for sending SMS messages
        if ([messageClass canSendText]) {
            [self displaySMSComposerSheet];
        }
        else {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"设备没有短信功能" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
        }
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"iOS版本过低,iOS4.0以上才支持程序内发送短信" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
    }
}

- (void)displaySMSComposerSheet
{
    MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
    picker.messageComposeDelegate = self;
    NSString *absUrl = [NSString stringWithFormat:@"http://%@/meet/meetinginfo?meeting_id=%@",COMPANY_ADDR,_meetID];
    picker.body=[NSString stringWithFormat:@"欢迎了解本次大会%@",absUrl];
    
    [self presentViewController:picker animated:YES completion:^{
        
    }];
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    switch (result)
    {
        case MessageComposeResultCancelled:
            //LOG_EXPR(@"Result: SMS sending canceled");
            if (shareSheet.isShow) {
                [shareSheet tappedCancel];
            }
            break;
        case MessageComposeResultSent:
            //LOG_EXPR(@"Result: SMS sent");
            break;
        case MessageComposeResultFailed:{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"短息发送失败" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
        }
            break;
        default:
            //LOG_EXPR(@"Result: SMS not sent");
            break;
    }
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (void)navCustomView
{
    _navBGView1 = [[UIImageView alloc]init];
    _navBGView1.frame = CGRectMake(0, 0, ScreenWidth, 44+self.navheight);
    _navBGView1.userInteractionEnabled = YES;
    _navBGView1.backgroundColor = [UIColor clearColor];
    
    if (_haveImage) {
        _navBGView1.alpha = 0;
    }
    else {
        _navBGView1.alpha = 1;
    }
    
    if (IOS7) {
        _navBGView1.image = [UIImage imageNamed:@"navBGImage"];
    }
    else {
        _navBGView1.image = [UIImage imageNamed:@"xian1"];
    }
    
    [self.view addSubview:_navBGView1];
    
    _titlelabel1 = [[UILabel alloc]initWithFrame:FRAME(50, self.navheight, ScreenWidth-100, 44)];
    _titlelabel1.text = @"详情";
    _titlelabel1.textAlignment = NSTextAlignmentCenter;
    _titlelabel1.textColor = COLOR_VAULE(255);
    _titlelabel1.backgroundColor = defaultColor;
    _titlelabel1.font = [UIFont boldSystemFontOfSize:18];
    [_navBGView1 addSubview:_titlelabel1];
}

#pragma mark 上边加上轮播图

- (void)addTopImages
{
    int tag = 0;
    for (UIView *view in self.imgContainer.subviews) {
        [view removeFromSuperview];
    }
    for (NSString *url in self.photoMutableArray) {
        UIImageView *imageView  = [[UIImageView alloc] init];
        [imageView setContentMode:UIViewContentModeScaleAspectFill];
        imageView.clipsToBounds = YES;
        imageView.image = [UIImage imageNamed:@"banner"];
        [imageView sd_setImageWithURL:[NSURL URLWithString:url]];
        imageView.frame = CGRectMake(ScreenWidth*tag, 0, ScreenWidth, ImageHeight+20);
        imageView.tag = tag + 10;
        tag++;
        [self.imgContainer addSubview:imageView];
    }
    self.imgContainer.contentSize = CGSizeMake([self.photoMutableArray count]*ScreenWidth, ScreenHeight);
    self.wrapperScroll.contentSize = CGSizeMake([self.photoMutableArray count]*ScreenWidth, ImageHeight);
}

- (void)createTopScrollView
{
    if (self.haveImage)
    {
        //imgContainer
        self.imgContainer = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        self.imgContainer.backgroundColor = [UIColor clearColor];
        self.imgContainer.showsHorizontalScrollIndicator = NO;
        self.imgContainer.showsVerticalScrollIndicator = NO;
        [self.view insertSubview:self.imgContainer belowSubview:newSignUpInfoView];
        
        //wrapperscroll
        self.wrapperScroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ImageHeight)];
        self.wrapperScroll.backgroundColor = [UIColor clearColor];
        self.wrapperScroll.delegate = self;
        self.wrapperScroll.pagingEnabled = YES;
        self.wrapperScroll.showsVerticalScrollIndicator = YES;
        self.wrapperScroll.showsHorizontalScrollIndicator = YES;
        [headView addSubview: self.wrapperScroll];
        
        UITapGestureRecognizer *singletapGesture = [[UITapGestureRecognizer alloc]init];
        [singletapGesture addTarget:self action:@selector(singletapGestureHandle:)];//点击点击事件
        [singletapGesture setNumberOfTapsRequired:1];
        [singletapGesture setNumberOfTouchesRequired:1];
        [self.wrapperScroll addGestureRecognizer:singletapGesture];
        
        if (@available(iOS 11.0, *))
        {
            self.imgContainer.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            self.wrapperScroll.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
        
        //添加 半透明 view
        [headView addSubview:self.blacktransImageView];
        
        _imagePageControl = [[FirstPageControl alloc]initWithFrame:CGRectMake((ScreenWidth-100)/2.0f, 188 - 60, 100, 20)];
        _imagePageControl.dotColorCurrentPage = [UIColor colorWithHexString:@"#ffffff"];
        _imagePageControl.dotColorOtherPage = [UIColor colorWithHexString:@"#adb0b4"];
        if ([self.photoArray count] > 1) {
            _imagePageControl.numberOfPages = [self.photoArray count];
        }
        _imagePageControl.currentPage = 0;
        [headView addSubview:_imagePageControl];
    }
    else {
        _blacktransImageView = [[BlackTransView alloc]initWithTitle:nil andTime:nil andReadCount:nil andState:nil andIsShowBlackTrans:NO andIsShowSwitch:NO];
        _blacktransImageView.backgroundColor = [UIColor whiteColor];
        _blacktransImageView.frame = CGRectMake(0, 0, ScreenWidth, 59);
        [headView addSubview:_blacktransImageView];
    }
}

#pragma mark self.wraScroll 的点击事件

- (void)singletapGestureHandle:(UITapGestureRecognizer *)gesture
{
    /*
     * (NSInteger)(self.wrapperScroll.contentOffset.x/ScreenWidth);计算当前是第几张
     *    或 _imagePageControl.currentPage;用页码来区分
     */
    NSMutableArray *photos = [[NSMutableArray alloc] init];
    BOOL displayActionButton = NO;
    BOOL displaySelectionButtons = NO;
    BOOL displayNavArrows = NO;
    BOOL enableGrid = NO;
    BOOL startOnGrid = NO;
    for (int i = 0; i<self.photoMutableArray.count; i++) {
        MWPhoto *photo = [MWPhoto photoWithURL:[NSURL URLWithString:[self.photoMutableArray objectAtIndex:i]]];
        photo.caption = [NSString stringWithFormat:@"%d/%ld \n",i+1,(unsigned long)self.photoMutableArray.count];
        [photos addObject:photo];
    }
    self.photos = photos;
    MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
    browser.rightNavButtonIsHiden = YES;
    browser.displayActionButton = displayActionButton;
    browser.displayNavArrows = displayNavArrows;
    browser.displaySelectionButtons = displaySelectionButtons;
    browser.alwaysShowControls = displaySelectionButtons;
    browser.navTitle = @"活动海报";
    browser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
    browser.wantsFullScreenLayout = YES;
#endif
    browser.enableGrid = enableGrid;
    browser.startOnGrid = startOnGrid;
    browser.enableSwipeToDismiss = YES;
    [browser setCurrentPhotoIndex:_imagePageControl.currentPage];
    [self.navigationController pushViewController:browser animated:YES];
}

#pragma mark MWPhotoBrowserDelegate

- (void)deleteImage:(NSInteger)index
{
    
}

- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser
{
    return self.photos.count;
}

- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index
{
    if (index < self.photos.count)
        return [self.photos objectAtIndex:index];
    return nil;
}

- (UITableViewCell *)webCell
{
    if (!_webCell) {
        _webCell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        _webCell.contentView.clipsToBounds = YES;
    }
    return _webCell;
}

- (UIWebView *)mainWebView
{
    if (!_mainWebView) {
        _mainWebView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0)];
        _mainWebView.delegate = self;
        _mainWebView.scrollView.bounces = NO;
        _mainWebView.scrollView.scrollEnabled = NO;
    }
    return _mainWebView;
}

#pragma mark - webCell

- (void)createWebCell
{
    _mainWebView = nil;
    self.webCell = nil;
    [self.view addSubview:self.mainWebView];
}

#pragma mark 创建UI

- (void)createContentUI
{
    if (_haveImage) {
        newSignUpInfoView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight -50) style:UITableViewStyleGrouped];
    }
    else {
        newSignUpInfoView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight -50-self.F_NAV_HEIGHT) style:UITableViewStyleGrouped];
    }
    newSignUpInfoView.sectionHeaderHeight = 12;
    newSignUpInfoView.delegate = self;
    newSignUpInfoView.dataSource = self;
    newSignUpInfoView.backgroundColor = [UIColor clearColor];
    newSignUpInfoView.separatorStyle = UITableViewCellSeparatorStyleNone;
    newSignUpInfoView.estimatedRowHeight = 0;
    newSignUpInfoView.estimatedSectionHeaderHeight = 0;
    newSignUpInfoView.estimatedSectionFooterHeight = 0;
    [self.view insertSubview:newSignUpInfoView aboveSubview:self.navBGView];
    //tablefootView
    UIView *footView = [[UIView alloc]init];
    footView.frame = CGRectMake(0, 0, ScreenWidth, 60);
    footView.backgroundColor = [UIColor clearColor];
    newSignUpInfoView.tableFooterView = footView;
    //headview 是tableView的headView
    if (self.haveImage) {
        headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ImageHeight)];
        headView.backgroundColor = [UIColor clearColor];
        headView.clipsToBounds = YES;
    }
    else {
        headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0)];
        headView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
        headView.clipsToBounds = YES;
    }
    newSignUpInfoView.tableHeaderView = headView;
    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line, @"#c8c7cc");
    line.hidden = YES;//如果没有轮播图 就显示
    [headView addSubview:line];
    
    [self createTopScrollView];//创建头部的视图
    
    if (self.haveImage) {
        self.timeAndAddressView.frame = CGRectMake(0, CGRectGetMaxY(_blacktransImageView.frame), ScreenWidth, 0);
    }
    else {
        self.timeAndAddressView.frame = CGRectMake(0, CGRectGetMaxY(_blacktransImageView.frame)+10, ScreenWidth, 0);
    }
    [headView addSubview:self.timeAndAddressView];
    
    self.optionView = [[UIView alloc]initWithFrame:CGRectMake(0,CGRectGetMaxY(self.timeAndAddressView.frame)+10, ScreenWidth, 0)];
    UIView *line4 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line4, @"#eeeeee");
    [self.optionView  addSubview:line4];
    BackGroundColor(self.optionView, whiteColor);
    self.optionScrollView.frame = CGRectMake(0, 0, ScreenWidth, 188);
    [self.optionView addSubview:self.optionScrollView];
    [headView addSubview:self.optionView];
    
    _signUpBG = [[UIView alloc]init];
    _signUpBG.frame = CGRectMake(0, ScreenHeight-50, ScreenWidth, 50);
    _signUpBG.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_signUpBG];
    
    UIImage *newSignUpBtnImage;
    if (IOS5) {
        newSignUpBtnImage = [[UIImage imageNamed:@"new_signUpBtn"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 40, 15, 40)];
    }
    else {
        newSignUpBtnImage = [[UIImage imageNamed:@"new_signUpBtn"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 40, 15, 40)resizingMode:UIImageResizingModeStretch];
    }
    
    [_signUpBG addSubview:self.signUpBtn];
    [_signUpBG addSubview:self.replceSignUpBtn];
    _goTopView = [UIButton buttonWithType:UIButtonTypeCustom];
    _goTopView.frame = CGRectMake(ScreenWidth-56, ScreenHeight-106, 46, 46);
    [_goTopView setBackgroundImage:[UIImage imageNamed:@"Info_top"] forState:UIControlStateNormal];
    _goTopView.hidden = YES;
    [_goTopView setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _goTopView.adjustsImageWhenHighlighted = NO;
    [_goTopView addTarget:self action:@selector(goTopBtnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_goTopView];
    //隐藏UI
    [self operateUI:NO];
}

- (void)goTopBtnClick
{
    [newSignUpInfoView scrollRectToVisible:CGRectMake(0, 0, 10, 10) animated:YES];
}

#pragma timeAndAddressDelegate sendPhone and sendChat

- (void)sendPhone:(NSString *)phone
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
         UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    _heOrShePhone = phone;
    NSLog(@"打电话");
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"联系发起者", nil];
    [actionSheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        BOOL canOpen = [[UIApplication sharedApplication]
                        canOpenURL:[NSURL URLWithString:@"tel://"]];
        if (canOpen) {
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",_heOrShePhone]]];
        }
        else {
            [Dialog toastCenter:@"该设备不支持打电话功能或没有安装SIM卡"];
        }
        _heOrShePhone = @" ";
    }
    else {
        
    }
}

- (void)sendChat:(NSString *)user_id andUserName:(NSString *)name
{
    //__weak typeof(self) weakSelf = self;
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]==0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
         UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    /*
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"login_company_code"] length]!=0) {
        NSArray *array = [user_id componentsSeparatedByString:@":"];
        user_id = array[0];
    }*/

    if ([user_id isEqualToString:MYUSERID]) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"不可以和自己聊天" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        return;
    }
    //[self.navigationController popViewControllerAnimated:YES];
    ChatViewController* chat = [[ChatViewController alloc]init];
    chat.targetId = user_id;
    chat.conversationType = ConversationType_PRIVATE;
    chat.chatUserName = name;
    chat.fromSignView = YES;
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:chat];
    [self presentViewController:nav animated:YES completion:nil];
    //[self.navigationController pushViewController:nav animated:YES];
}

- (void)sendGroup:(NSString *)group_id andUserName:(NSString *)GroupName
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
         UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    ChatViewController* chat = [[ChatViewController alloc]init];
    chat.targetId = group_id;
    chat.fromSignView = YES;
    chat.conversationType = ConversationType_GROUP;
    chat.chatUserName = GroupName;
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:chat];
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)bmCountBtnClick
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    BOOL meetIsEnd;
    //NSTimeInterval begin_time_inter = [meetBeginTime longLongValue];
    NSTimeInterval end_time_inter = [meetEndTime longLongValue];
    NSTimeInterval timeInter = [[NSDate date] timeIntervalSince1970];
    if (meetEndTime.length > 0) {
        if (timeInter > end_time_inter) {
            meetIsEnd = YES;
        }
        else {
            meetIsEnd = NO;
        }
    }
    else {
        meetIsEnd = NO;
    }
    NSLog(@"点击了我报名的按钮");
    New_myApplyListViewController *myApplyListVC = [[New_myApplyListViewController alloc]init];
    myApplyListVC.blockID = _blockID;
    myApplyListVC.signUpstate = _signUpstate;
    myApplyListVC.timeAndAddIpa = _timeAndAddIpa;
    myApplyListVC.shareTitle = shareTitle;
    myApplyListVC.photoArray = self.photoArray;
    myApplyListVC.configDic = _configDic;
    myApplyListVC.configDictionary = _configDictionary;
    myApplyListVC.meeting_id = _meetID;
    myApplyListVC.meetIsEnd = meetIsEnd;
    [self.navigationController pushViewController:myApplyListVC animated:YES];
}

#pragma mark - UI操作

- (void)operateUI:(BOOL)isShow
{
    if (isShow) {
        newSignUpInfoView.hidden = NO;
        _signUpBG.hidden =NO;
        self.imgContainer.hidden = NO;
    }
    else {
        newSignUpInfoView.hidden = YES;
        _signUpBG.hidden =YES;
        self.imgContainer.hidden = YES;
    }
}

- (void)creatPluginUI:(NSArray *)arr;
{
    [self.optionView addSubview:self.optionScrollView];
    if (arr.count != 0) {
        UIView *line4 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(line4, @"#c8c7cc");
        [self.optionView  addSubview:line4];
        int pages;
        NSInteger pluginCount = [arr count];
        if (pluginCount%8 == 0) {
            pages = pluginCount/8;
        }
        else {
            pages = pluginCount/8+1;
        }
        int maxRow = 2;
        int maxCol = 4;
        CGFloat itemWidth = 80;
        CGFloat itemHeight = 80;
        if (arr.count >= 8) {
            itemviewheight = 188;
        }
        else if (arr.count > 4 && arr.count < 8) {
            itemviewheight = 168;
        }
        else if (arr.count <= 4 && arr.count > 0) {
            itemviewheight = 98;
        }
        else {
            itemviewheight = 0;
        }
        self.optionView.frame = CGRectMake(self.optionView.frame.origin.x, self.optionView.frame.origin.y, self.optionView.frame.size.width,itemviewheight+1);
        headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height+itemviewheight+2);
        [headView setNeedsLayout];
        
        self.optionScrollView.frame = CGRectMake(self.optionScrollView.frame.origin.x, self.optionScrollView.frame.origin.y, self.optionScrollView.frame.size.width,itemviewheight);
        [self.optionScrollView setNeedsLayout];
        self.optionScrollView.contentSize = CGSizeMake(pages*ScreenWidth, itemviewheight);
        self.optionScrollView.pagingEnabled = YES;
        self.optionScrollView.showsHorizontalScrollIndicator = NO;
        self.optionScrollView.showsVerticalScrollIndicator = NO;
        for (UIView *view in self.optionScrollView.subviews) {
            [view removeFromSuperview];
        }
        for(int page =0;page<pages;page++) {
            for (int row = 0; row < maxRow; row++) {
                for (int col = 0; col < maxCol; col++) {
                    NSLog(@"%D",row * maxCol+page*maxCol*(maxRow) + col);
                    if (((row)*maxCol + page*maxCol*maxRow + col)<arr.count) {
                        gridInfo *info = [_gridArr objectAtIndex:(row * maxCol+page*maxCol*(maxRow) + col)];
                        UIOptionButton *button = [UIOptionButton buttonWithType:UIButtonTypeCustom];
                        [button setBackgroundColor:[UIColor clearColor]];
                        [button setFrame:CGRectMake((ScreenWidth-320)/5.0f+col * (itemWidth+(ScreenWidth-320)/5.0f)+page*ScreenWidth, row * itemHeight, itemWidth, itemHeight)];
                        [button sd_setImageWithURL:[NSURL URLWithString:info.urlStr]forState:UIControlStateNormal];
                        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                        [button setTitle:info.title forState:UIControlStateNormal];
                        button.tag = (row * maxCol+page*maxCol*maxRow + col);
                        [button addTarget:self action:@selector(pluginSelected:) forControlEvents:UIControlEventTouchUpInside];
                        [self.optionScrollView addSubview:button];
                        [button setNeedsLayout];
                    }
                    else {
                        break;
                    }
                }
            }
        }
        if (pages != 1) {
            self.pageControl.numberOfPages = pages;
            [self.optionView addSubview:self.pageControl];
        }
        UIView *line5 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.optionView.frame)-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line5, @"#c8c7cc");
        [self.optionView  addSubview:line5];
    }
    else {
        self.optionView.frame = CGRectMake(0,CGRectGetMaxY(self.timeAndAddressView.frame), ScreenWidth, 0);
        for (UIView *view in self.optionView.subviews) {
            [view removeFromSuperview];
        }
        headView.frame = CGRectMake(0, 0, ScreenWidth, headView.frame.size.height-9);
    }
    [newSignUpInfoView setTableHeaderView:headView];
}

//当滑动tableView或 scrollView的时候触发的方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@" %@-----%f",scrollView,scrollView.contentOffset.y);
    if (scrollView == newSignUpInfoView){
        if (scrollView.contentOffset.y<-60) {
            [self.meetPosterWebView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:self.meetPoster_url]]];
            
            [UIView animateWithDuration:0.5 animations:^{
                self.meetPosterWebView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight);
            }];
        }
    }
    if (scrollView == newSignUpInfoView || self.wrapperScroll == scrollView) {
        if (scrollView.contentOffset.y>ScreenHeight) {
            _goTopView.hidden = NO;
            if (scrollView.contentOffset.y>ScreenHeight && scrollView.contentOffset.y<ScreenHeight+_goTopView.frame.size.height) {
                _goTopView.alpha = (scrollView.contentOffset.y-ScreenHeight)/_goTopView.frame.size.height;
            }
        }
        else {
            _goTopView.hidden = YES;
        }
        
        if (!_haveImage) {
            return;
        }
        _navBGView1.alpha = 0+(scrollView.contentOffset.y-30)/44;//改变上边导航的透明度
        _bmCountBG.alpha  = 1-(scrollView.contentOffset.y-30)/44;
        _backBGImageView.alpha = 1-(scrollView.contentOffset.y-30)/44;
        _collectBG.alpha = 1-(scrollView.contentOffset.y-30)/44;
        _shareBG.alpha = 1-(scrollView.contentOffset.y-30)/44;
        
        //轮播图变化
        CGFloat yOffset   = scrollView.contentOffset.y;
        CGFloat xOffset   = self.wrapperScroll.contentOffset.x;
        //NSLog(@"yOffset = %f",yOffset);
        _imagePageControl.currentPage = xOffset/ScreenWidth;
        if (yOffset < 0) {
            CGFloat pageWidth = self.wrapperScroll.frame.size.width;
            int page = floor((self.wrapperScroll.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
            UIImageView *imgTmp;
            for (UIView *view in self.imgContainer.subviews) {
                if ([view isKindOfClass:[UIImageView class]]) {
                    if (view.tag == 10+ page) {
                        imgTmp = (UIImageView*)view;
                    }
                }
            }
            CGFloat factor = ((ABS(yOffset) + ImageHeight )*ScreenWidth)/ ImageHeight;
            CGRect f = CGRectMake((-(factor-ScreenWidth)/2) + ScreenWidth *page, 0, ScreenWidth, ImageHeight);
            f.size.height = ImageHeight+ABS(yOffset);
            f.size.width = factor;
            imgTmp.frame = f;
            CGRect frame = self.imgContainer.frame;
            frame.origin.y = 0;
            self.imgContainer.frame = frame;
        }
        else {
            self.imgContainer.contentOffset = CGPointMake(xOffset, 0);
            CGRect frame = self.imgContainer.frame;
            frame.origin.y = -yOffset;
            self.imgContainer.frame = frame;
        }
    }
    else {
        CGFloat pageWidth = self.view.frame.size.width;
        int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
        self.pageControl.currentPage = page;
    }
}

#define HeadViewHeight 43.5

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        return _contentInfoViewHeight;
    }
    if (indexPath.section == 1)
    {
        return 66;
    }
    if (indexPath.section == 2)
    {
        if (_showPluginStatus)
        {
            if (indexPath.row == _bmListArr.count)
            {
                if(_bmListArr.count == 10)
                {
                    return 48.5;
                }
                else
                {
                    return 0;
                }
            }
            else
            {
                return 52;
            }
        }
        else
        {
            return 52;
        }
    }
    if (indexPath.section == 3)
    {
        return 0;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 3) {
        return 0.01f;//96;
    }
    else if (section == 2) {
        if ([_personal_data_sw isEqualToString:@"-1"]) {
            return 0.01;
        }
        else {
            return 43.5;
        }
    }
    else {
        return 43.5;
    }
    return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 3) {
        
    }
    else if (section == 2) {
        if (![_personal_data_sw isEqualToString:@"-1"]) {
            UIView *sectionHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, HeadViewHeight)];
            sectionHeadView.backgroundColor = [UIColor whiteColor];
            UIView *headLineLB  = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
            BackGround16Color(headLineLB, @"#c8c7cc");
            [sectionHeadView  addSubview:headLineLB];
            
            UIView *endLineLB  = [[UIView alloc]initWithFrame:CGRectMake(0, HeadViewHeight-0.5, ScreenWidth, 0.5)];
            BackGround16Color(endLineLB, @"#c8c7cc");
            [sectionHeadView  addSubview:endLineLB];
            
            UILabel *headTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(11, 0.5, ScreenWidth, HeadViewHeight-1)];
            headTitleLB.font = YHUI_BOLD(16);
            headTitleLB.backgroundColor = [UIColor clearColor];
            headTitleLB.text = [NSString stringWithFormat:@"已报名(%@)",_bmCount];
            [sectionHeadView addSubview:headTitleLB];
            return sectionHeadView;
        }
    }
    else {
        UIView *sectionHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, HeadViewHeight)];
        sectionHeadView.backgroundColor = [UIColor whiteColor];
        UIView *headLineLB  = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [sectionHeadView  addSubview:headLineLB];
        
        UIView *endLineLB  = [[UIView alloc]initWithFrame:CGRectMake(0, HeadViewHeight-0.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [sectionHeadView  addSubview:endLineLB];
        
        UILabel *headTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(11, 0.5, ScreenWidth, HeadViewHeight-1)];
        headTitleLB.font = YHUI_BOLD(16);
        headTitleLB.backgroundColor = [UIColor clearColor];
        UIButton * likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        likeBtn.frame=CGRectMake(ScreenWidth-54, 11, 37, 23);
        [likeBtn addTarget:self action:@selector(likeBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        if (_isLike) {
            likeBtn.selected = YES;
        }
        else {
            likeBtn.selected = NO;
        }
        [likeBtn setImage:[UIImage imageNamed:@"zan-icon02"] forState:UIControlStateNormal];
        [likeBtn setImage:[UIImage imageNamed:@"zan-icon01"] forState:UIControlStateSelected];
        
        switch (section) {
            case 0:
                headTitleLB.text = @"会议详情";
                break;
            case 1:
                headTitleLB.text = [NSString stringWithFormat:@"我喜欢(%lu)",(unsigned long)_likeArr.count];
                [sectionHeadView addSubview:likeBtn];
                break;
            case 2:
                headTitleLB.text = [NSString stringWithFormat:@"已报名(%@)",_bmCount];
                break;
            default:
                break;
        }
        [sectionHeadView addSubview:headTitleLB];
        return sectionHeadView;
    }
    return nil;
}

- (void)getMeetStatus
{
    if ([[_configDictionary objectForKey:@"type"] isEqualToString:@"4"]) {
        NSDictionary *dic1;
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"] length] != 0) {
            dic1 = @{@"meeting_id": _meetID,@"block_id": [_configDictionary objectForKey:@"block_id"],@"user_id":[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]};
        }
        else {
            dic1 = @{@"meeting_id": _meetID,@"block_id": [_configDictionary objectForKey:@"block_id"],@"user_id":@""};
        }
        
        //[[Dialog Instance] showHSHUDWithController:self];
        [MyDataService postPartakeState:dic1 callback:^(id data) {
            NSLog(@"%@",data);//0未填,1不完整,2完整,3可选的未填，4可选的不完整
            //[[Dialog Instance] hiddenHSHUD];
            _configEnd = YES;
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                    NSString *keyStr = [NSString stringWithFormat:@"%@_%@_meetInfoState",_session,[_configDictionary objectForKey:@"block_id"]];
                    [[NSUserDefaults standardUserDefaults] setObject:[_configDictionary objectForKey:@"block_id"] forKey:@"block_id"];
                    [[NSUserDefaults standardUserDefaults] setObject:[[data objectForKey:@"content"] objectForKey:@"state"] forKey:@"state"];
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                    
                    [[DBManager sharedInstance] deleteToPublicOneData:keyStr];
                    [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:keyStr];
                    _signUpstate = [[data objectForKey:@"content"] objectForKey:@"state"];//1尚未报名 5完成报名 4报名完成等待审核 3审核未通过 2审核通过等待回执 10报名截止未报名 11报名截止已报名
                    if ([_signUpstate isEqualToString:@"1"]) {
                        [self.signUpBtn setTitle:@"我要报名" forState:UIControlStateNormal];
                    }
                    if ([_signUpstate isEqualToString:@"2"]) {
                        [self.signUpBtn setTitle:@"等待回执" forState:UIControlStateNormal];
                    }
                    if ([_signUpstate isEqualToString:@"3"]) {
                        [self.signUpBtn setTitle:@"报名未通过" forState:UIControlStateNormal];
                    }
                    if ([_signUpstate isEqualToString:@"4"]) {
                        [self.signUpBtn setTitle:@"报名审核中" forState:UIControlStateNormal];
                    }
                    if ([_signUpstate isEqualToString:@"5"] || [_signUpstate isEqualToString:@"11"]) {
                        [self.signUpBtn setTitle:@"签到码/修改报名信息" forState:UIControlStateNormal];
                    }
                    [self.signUpBtn setNeedsDisplay];
                    
                    if ([_signUpstate isEqualToString:@"10"]) {
                        _bmEnd = YES;
                    }
                    else {
                        _bmEnd = NO;
                    }
                    
                    if ([[[data objectForKey:@"content"] objectForKey:@"list"] isKindOfClass:[NSArray class]] && [[data objectForKey:@"content"] count] != 0) {
                        NSArray *arr = [[data objectForKey:@"content"] objectForKey:@"list"];
                        for (int i = 0; i < [[_configDictionary objectForKey:@"block_list"] count]; i++) {
                            for (int j = 0; j < arr.count; j++) {
                                if ([[[[_configDictionary objectForKey:@"block_list"] objectAtIndex:i] objectForKey:@"block_id"]isEqualToString:[[arr objectAtIndex:j] objectForKey:@"block_id"]]) {
                                    if (![[[arr objectAtIndex:j] objectForKey:@"state"] isEqualToString:@"0"]) {
                                        _blockID = [[arr objectAtIndex:j] objectForKey:@"block_id"];
                                    }
                                }
                            }
                        }
                    }
                    
                    if ([skipManagerTool shareInstence].btnClickType == SignBtnClick || [skipManagerTool shareInstence].btnClickType == OtherSignBtnClick) {
                        //[self notificationMethed];
                    }
                }else {
                    /*
                    if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                        [Dialog toastCenter:[data objectForKey:@"error"]];
                    }
                    else {
                        NSString *error = [data objectForKey:@"msg"];
                        if (error != nil) {
                            [Dialog toastCenter:error];
                        }
                    }*/
                }
            }
            else {
                /*
                if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                    [Dialog toastCenter:[data objectForKey:@"error"]];
                }
                else {
                    NSString *error = [data objectForKey:@"msg"];
                    if (error != nil) {
                        [Dialog toastCenter:error];
                    }
                }*/
            }
        }];
    }
}

#pragma mark - 报名配置接口

- (void)getMeetConfigData
{
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"partake_%@",_meetID]] length] != 0) {
        _version = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"partake_%@",_meetID]];
    }
    else {
        _version = @"0";
    }
    NSDictionary *dic;
    dic = @{@"meeting_id": _meetID,@"partake_version": _version};
    [MyDataService postMeetingconfig:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"]isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"]isEqualToString:@"203013"]) {
                [skipManagerTool shareInstence].skipType = IndexViewToDetailsFailure;
            }
        }
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"]floatValue] == 200) {
                [skipManagerTool shareInstence].skipType = IndexViewToDetails;
                [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"firstConfig"];
                _version = [[data objectForKey:@"content"] objectForKey:[NSString stringWithFormat:@"version"]];
                [[NSUserDefaults standardUserDefaults] setObject:_version forKey:[NSString stringWithFormat:@"partake_%@",_meetID]];
                [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                if ([[[data objectForKey:@"content"] objectForKey:@"state"] isEqualToString:@"1"]) {
                    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@config",_meetID]];
                    [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"%@config",_meetID]];
                    
                    _configDictionary = [NSDictionary dictionaryWithDictionary:[data objectForKey:@"content"]];
                    
                    NSArray *arr = [NSArray arrayWithArray:[[data objectForKey:@"content"] objectForKey:@"block_list"]];
                    NSMutableArray *mutArr = [NSMutableArray array];
                    for (NSDictionary *dic in arr) {
                        if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                            [mutArr addObject:dic];
                        }
                    }
                    [[data objectForKey:@"content"] setObject:mutArr forKey:@"block_list"];
                    
                    _configDic = [data objectForKey:@"content"];
                    [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isCache"];//当配置文件发生改变时  以后的缓存全都废弃 1发生了改变 0没有发生改变  （没有他  当配置文件发生改变时  后面的页面会宕掉）
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                }
                else {
                    //读文件
                    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isCache"];
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                    
                    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@config",_meetID]];
                    
                    _configDictionary = [NSDictionary dictionaryWithDictionary:[[dataStr JSONValue] objectForKey:@"content"]];
                    
                    NSMutableDictionary *configDic = [NSMutableDictionary dictionaryWithDictionary:[[dataStr JSONValue] objectForKey:@"content"]];
                    
                    NSArray *arr = [NSArray arrayWithArray:[configDic objectForKey:@"block_list"]];
                    NSMutableArray *mutArr = [NSMutableArray array];
                    for (NSDictionary *dic in arr) {
                        if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                            [mutArr addObject:dic];
                        }
                    }
                    [configDic setObject:mutArr forKey:@"block_list"];
                    
                    _configDic = configDic;
                    [skipManagerTool shareInstence].skipType = IndexViewToDetails;
                    
                }
                NSArray *arr = [NSArray arrayWithArray:[[data objectForKey:@"content"] objectForKey:@"block_list"]];
                [_ticketArr removeAllObjects];
                for (NSDictionary *dic in arr) {
                    SDTicketModel *model = [[SDTicketModel alloc]init];
                    model.name = [dic objectForKey:@"name"];
                    model.price = [dic objectForKey:@"price"];
                    model.int_partake_end_time = [dic objectForKey:@"partake_end_time"];
                    double time = [[dic objectForKey:@"partake_end_time"] longLongValue];
                    model.block_id = [dic objectForKey:@"block_id"];
                    NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
                    NSTimeInterval a=[dat timeIntervalSince1970];
                    if ((int)a>time){
                        model.meetEnd = YES;
                    }
                    else {
                        model.meetEnd = NO;
                    }
                    
                    model.partake_end_time = [self formatter:@"yyyy.MM.dd HH:mm" ToTime:[dic objectForKey:@"partake_end_time"]];
                    model.note = [dic objectForKey:@"note"];
                    model.visible = [dic objectForKey:@"visible"];
                    if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                        [_ticketArr addObject:model];
                    }
                }
                [self getMeetStatus];
            }
        }
    }];
}

#pragma mark - 会议插件
- (void)likeBtnClicked:(UIButton *)btn
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    [UIView animateWithDuration:0.5 animations:^{
        btn.alpha = 0.0;
        btn.alpha = 1.0;
        btn.transform = CGAffineTransformMakeScale(1.5f, 1.5f);
    }completion:^(BOOL finished){
         btn.transform = CGAffineTransformMakeScale(1.0f, 1.0f);
         NSString *uid = [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"];
         NSString *status ;
         if (_isLike == YES) {
             status = @"0";
         }
         else {
             status = @"1";
         }
        
         NSDictionary *dic = @{@"meeting_id":_meetID,@"user_id":uid,@"like_state":status};
         [MyDataService postMeetingLikeAdd:dic callback:^(id data) {
             NSLog(@"%@",data);
             if ([[data objectForKey:@"code"]isEqualToString:@"200"]) {
                 btn.selected = !btn.selected;
                 _isLike = !_isLike;
                 NSString *icoUrl;
                 if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"ico_file"] length] == 0) {
                     icoUrl = @"";
                 }
                 else {
                     icoUrl = [[NSUserDefaults standardUserDefaults]objectForKey:@"ico_file"];
                 }
                 NSString *myUser_id = [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"];
                 NSString *name = [[NSUserDefaults standardUserDefaults] objectForKey:@"name"];
                 //NSDictionary *dic = @{@"name":name,@"ico_file":icoUrl};
                 if ([status isEqualToString:@"0"]) {
                     for (NSDictionary *dict  in _likeArr) {
                         NSString *user_id = [dict objectForKey:@"user_id"];
                         if ([user_id isEqualToString:myUser_id]) {
                             [_likeArr removeObject:dict];
                             break;
                         }
                     }
                 }
                 else {
                     NSDictionary *dic = @{@"name":name,@"ico_file":icoUrl,@"user_id":myUser_id};
                     [_likeArr insertObject:dic atIndex:0];
                 }
                 //[newSignUpInfoView reloadData];
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [newSignUpInfoView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationNone];
                 });
             }
         }];
     }];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [[OpenLoginTool sharedManager]loginOff];
        LoginViewController *loginVc = [[LoginViewController alloc]init];
         UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:^{
        }];
    }
}

- (BOOL)authority:(NSString *)authority
{
    int type = [authority integerValue];
    switch (type) {
        case 7:
        {
            return YES;
        }
            break;
        case 6:
        {
            if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]!=0) {
                return YES;
            }
        }
        case 4:
        {
            if ([_signUpstate isEqualToString:@"5"] || [_signUpstate isEqualToString:@"2"] || [_signUpstate isEqualToString:@"11"]) {
                return YES;
            }
            else {
                return NO;
            }
        }
            break;
        default:
            return NO;
            break;
    }
    return NO;
}

- (void)authorityAlertView:(int)status
{
    switch (status) {
        case 1:
        {
            
        }
            break;
        case 3:
        {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"改插件登录后可以查看" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [av show];
        }
            break;
        case 7:
        {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"改插件报名后才可以查看" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [av show];
        }
            break;
        default:
            break;
    }
}

#pragma mark - 插件点击
- (void)pluginSelected:(UIOptionButton *)btn
{
    //if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] != 0) {
    gridInfo *info = (gridInfo *)[_gridArr objectAtIndex:btn.tag];
    BOOL isCreater = [_timeAndAddIpa.ipaUser_id isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]];
    if (info.authority || isCreater) {
        if ([info.pluginType isEqualToString:@"vote"]) {
            VoteListViewController *listVC = [[VoteListViewController alloc]init];
            listVC.meetingTitle = self.meetTitle;
            listVC.meet_id = _meetID;
            listVC.plugin_id = info.pluginID;
            [self.navigationController pushViewController:listVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"stroke"]) {
            MyScheduleViewController *ScheduleVC = [[MyScheduleViewController alloc]init];
            ScheduleVC.meetID = _meetID;
            ScheduleVC.navTitle = info.title;
            ScheduleVC.pluginID = info.pluginID;
            ScheduleVC.pluginType = info.pluginType;
            [self.navigationController pushViewController:ScheduleVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"map"]) {//地图
            MapViewController *mapVC = [[MapViewController alloc]init];
            mapVC.meetID = _meetID;
            mapVC.navTitle = info.title;
            mapVC.pluginID = info.pluginID;
            mapVC.pluginType = info.pluginType;
            [self.navigationController pushViewController:mapVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"schedule"]) {//日程
            ScheduleViewController *schVC = [[ScheduleViewController alloc]init];
            schVC.navTitle = info.title;
            schVC.meetID = _meetID;
            schVC.pluginType = info.pluginType;
            schVC.pluginID = info.pluginID;
            [self.navigationController pushViewController:schVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"section"]) {//列表
            New_signUpInfoListVC *listWebVC = [[New_signUpInfoListVC alloc]init];
            listWebVC.meetint_id = _meetID;
            listWebVC.plugin_id = info.pluginID;
            listWebVC.titleName = info.title;
            listWebVC.plugin_type = info.pluginType;
            [self.navigationController pushViewController:listWebVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"article"]) {//图文
            articleViewController *articleVC = [[articleViewController alloc]init];
            articleVC.titleStr = info.title;
            articleVC.meetID = _meetID;
            articleVC.pluginID = info.pluginID;
            articleVC.pluginType = @"article";
            [self.navigationController pushViewController:articleVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"articleURL"]) {//图文URL
            articleViewController *articleVC = [[articleViewController alloc]init];
            articleVC.titleStr = info.title;
            articleVC.meetID = _meetID;
            articleVC.pluginID = info.pluginID;
            articleVC.pluginType = @"articleURL";
            [self.navigationController pushViewController:articleVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"download"]) {//资料下载
            DataDownLoadViewController *dataVC = [[DataDownLoadViewController alloc]init];
            dataVC.navTitle = info.title;
            dataVC.meeting_id = _meetID;
            dataVC.plugin_id = info.pluginID;
            [self.navigationController pushViewController:dataVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"guests"]) {//嘉宾
            GuestViewController *gvc = [[GuestViewController alloc]init];
            gvc.navTitle = info.title;
            gvc.meetID = _meetID;
            gvc.pluginID = info.pluginID;
            [self.navigationController pushViewController:gvc animated:YES];
        }
        if ([info.pluginType isEqualToString:@"signIn"]) {//签到
            CheckInViewController *CheckVC = [[CheckInViewController alloc]init];
            CheckVC.navTitle = info.title;
            CheckVC.meetID = _meetID;
            [self.navigationController pushViewController:CheckVC animated:YES];
        }
        if ([info.pluginType isEqualToString:@"assess"]) {//问卷调查
            ManagerAssessViewController *managerAssessVC = [[ManagerAssessViewController alloc]init];
            managerAssessVC.meeting_id = _meetID;
            managerAssessVC.isFromSignUpInfo = YES;
            [self.navigationController pushViewController:managerAssessVC animated:YES];
        }
    }
}

- (void)reload
{
    [self getMeetConfigData];
}

- (void)getNetData
{
    _isLoad = YES;
    [self getMeetConfigData];
    [self getMeetInfoData];
}

#pragma mark UITableViewDataSource and UITableViewDelegate Methods

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 2 || section == 3) {
        return 0.01f;
    }
    else{
        return 10;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            if (_likeArr.count==0) {
                return 0;
            }
            else {
                return 1;
            }
            break;
        case 2:
            if (_showPluginStatus) {
                if (_bmListArr.count==10) {
                    return _bmListArr.count+1;
                }
                else {
                    return _bmListArr.count;
                }
            }
            else {
                return 1;
            }
            break;
        case 3:
            return 0;
            break;
        default:
            break;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"indexPath-----%@",indexPath.description);
    static NSString *CellIdentifier2 = @"supportCell";
    if (indexPath.section == 0) {
        return self.webCell;
    }
    if (indexPath.section == 1) {
        EnjoyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier2];
        if (cell == nil) {
            cell = [[EnjoyTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier2];
        }
        cell.enjoyUsers = _likeArr;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    if (indexPath.section == 2) {
        if (_showPluginStatus) {
            if (indexPath.row < _bmListArr.count) {
                UserInfoTableViewCell *cell;
                if ([_personal_data_sw isEqualToString:@"0"]) {
                    cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil andIsShowCompany:NO];
                }
                else if ([_personal_data_sw isEqualToString:@"1"]) {
                    cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil andIsShowCompany:YES];
                }
                else {
                    cell = [[UserInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil andIsShowCompany:NO];
                }
                
                //cell.nameLB.text = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"name"];
                //cell.companyAndPosition.text = [NSString stringWithFormat:@"%@  %@",[[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"company"],[[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"position"]];
                
                NSString *name     = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"name"];
                NSString *position = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"position"];
                NSString *company  = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"company"];
                
                if ([_personal_data_sw isEqualToString:@"1"]) {
                    cell.nameLB.text = [NSString stringWithFormat:@"%@  %@",name,position];
                    if (position.length) {
                        NSMutableAttributedString *string = [[NSMutableAttributedString alloc]initWithString:cell.nameLB.text];
                        UIColor *color = [UIColor lightGrayColor];
                        [string addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(name.length+2, position.length)];
                        [string addAttribute:NSFontAttributeName value:YHUI(13) range:NSMakeRange(name.length+2, position.length)];
                        [cell.nameLB setAttributedText:string];
                    }
                }
                else {
                    cell.nameLB.text = name;
                }
                
                cell.companyAndPosition.text = company;
                
                NSString *time = [[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"partake_time"];
                cell.timeLB.text = [self mdate:time];
                [cell.headImageView sd_setImageWithURL:[NSURL URLWithString:[[_bmListArr objectAtIndex:indexPath.row] objectForKey:@"ico_file"]] placeholderImage:[UIImage imageNamed:@"touxiang262"]];
                if (_bmListArr.count < 10) {
                    if (indexPath.row == _bmListArr.count-1) {
                        cell.isEnd = YES;
                    }
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                return cell;
            }
            if (indexPath.row >= _bmListArr.count) {
                UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                if(_bmListArr.count >= 10){
                    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 48.5)];
                    footView.backgroundColor = [UIColor whiteColor];
                    
                    UIView *line1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
                    BackGround16Color(line1, @"#c8c7cc");
                    [footView  addSubview:line1];
                    
                    UIBottomBtn *button = [UIBottomBtn buttonWithType:UIButtonTypeCustom];
                    button.frame = CGRectMake(0, 0, ScreenWidth, 48);
                    [button setTitleColor:[UIColor colorWithHexString:@"#1b9ecc"] forState:UIControlStateNormal];
                    button.titleLabel.font = YHUI(17);
                    [button addTarget:self action:@selector(moreClicked) forControlEvents:UIControlEventTouchUpInside];
                    [button setTitle:@"查看更多" forState:UIControlStateNormal];
                    [footView addSubview:button];
                    [cell.contentView addSubview:footView];
                    UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(button.frame), ScreenWidth, 0.5)];
                    BackGround16Color(line, @"#c8c7cc");
                    [cell.contentView  addSubview:line];
                }
                cell.contentView.backgroundColor = [UIColor clearColor];
                cell.contentView.clipsToBounds= YES;
                return cell;
            }
        }
        else {
            static NSString *Identifier = @"Identifier";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
            if (!cell) {
                cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
            }
            UILabel *textLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 52)];
            textLabel.backgroundColor = [UIColor clearColor];
            textLabel.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
            textLabel.font = YHUI(17);
            if (showPluginStatusNmb == 4) {
                textLabel.text = @"参会者信息报名用户可见";
            }
            if (showPluginStatusNmb == 6) {
                textLabel.text = @"参会者信息登录用户可见";
            }
            textLabel.textAlignment = NSTextAlignmentCenter;
            [cell.contentView addSubview:textLabel];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.contentView.backgroundColor = [UIColor clearColor];
            //=cell.contentView.clipsToBounds= YES;
            return cell;
        }
    }
    return nil;
}

//by wang zhenxing
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        LoginViewController *loginVc = [[LoginViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
        loginVc.fromSignVC = YES;
        NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
        if (!LoginCompanyArray.count)
        {
            loginVc.isPush = YES;
        }
        loginVc.delegate = self;
        loginVc.companyCode = self.companyCode;
        [self presentViewController:nav animated:YES completion:nil];
        return;
    }
    if (indexPath.section == 2) {
        /*
        if (_showPluginStatus) {
            if ([_bmListArr count]>=indexPath.row) {
                NSString *user_id = [[_bmListArr objectAtIndex:indexPath.row]objectForKey:@"user_id"];
                FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
                friendInfoVC.user_id = user_id;
                [self.navigationController pushViewController:friendInfoVC animated:YES];
            }
        }*/
    }
}

#pragma mark 点击加载更多  event
- (void)moreClicked
{
    MoreUserViewController *more = [[MoreUserViewController alloc]init];
    more.meetID = _meetID;
    more.personal_data_sw = _personal_data_sw;
    [self.navigationController pushViewController:more animated:YES];
}

- (void)makeHUDView
{
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
}

/**
 *  url decode   302
 *
 *  @param input url
 *
 *  @return 标准url
 */

- (NSString *)decodeFromPercentEscapeString: (NSString *) input
{
    NSMutableString *outputStr = [NSMutableString stringWithString:input];
    [outputStr replaceOccurrencesOfString:@"+"
                               withString:@" "
                                  options:NSLiteralSearch
                                    range:NSMakeRange(0, [outputStr length])];
    
    return [outputStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

- (NSString *)getUrlWithEncodeUrl:(NSString*)encodeUrl
{
    NSString *s = @"url=([^&]+)";
    
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:encodeUrl options:0 range:NSMakeRange(0, [encodeUrl length])];
    
    for (int i = 0; i<arrayOfAllMatches.count; i++) {
        NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
        
        NSString* substringForMatch = [encodeUrl substringWithRange:match.range];
        return substringForMatch;
    }
    return nil;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSURL *url = [request URL];
    NSString *urlString = [NSString stringWithFormat:@"%@",url];
    if ([webView isEqual:self.meetPosterWebView]) {
        //测试环境  随便跳
        if ([Base_URL isEqualToString:@"http://a2.huiyiabc.net/"]){
            if (urlString.length>52) {
                
                if([self.isPoster isEqualToString:@"1"]){
                    urlString = [self getUrlWithEncodeUrl:urlString];
                    urlString = [urlString substringWithRange:NSMakeRange(4, urlString.length -4)];
                    urlString = [self decodeFromPercentEscapeString:urlString];
                    
                }
                
                if ([urlString rangeOfString:yqxBackUrl].location !=NSNotFound) {
                    [UIView animateWithDuration:0.5 animations:^{
                        self.meetPosterWebView.frame = CGRectMake(0, -ScreenHeight, ScreenWidth, ScreenHeight);
                    }];
                    return NO;
                }
                else {
                    return YES;
                }
            }
        }
        
        //[urlString isEqualToString:[NSString stringWithFormat:@"http://%@/meet/meetinginfo?meeting_id=%@",COMPANY_ADDR,_meetID]]||[urlString rangeOfString:@"/meet/meetinginfo?meeting_id"].location != NSNotFound
        if ([urlString rangeOfString:@"eqxiu.com"].location != NSNotFound && [self getUrlWithEncodeUrl:urlString]) {
            urlString = [self getUrlWithEncodeUrl:urlString];
            urlString = [urlString substringWithRange:NSMakeRange(4, urlString.length -4)];
            urlString = [self decodeFromPercentEscapeString:urlString];
        }
        else if ([urlString isEqualToString:[NSString stringWithFormat:@"http://%@%@%@",COMPANY_ADDR,yqxBackUrl,_meetID]]||[urlString rangeOfString:yqxBackUrl].location != NSNotFound) {
            [UIView animateWithDuration:0.5 animations:^{
                self.meetPosterWebView.frame = CGRectMake(0, -ScreenHeight, ScreenWidth, ScreenHeight);
            }];
            [self performSelector:@selector(webViewStop) withObject:nil afterDelay:0.5f];
            return NO;
        }
        else {
            return YES;
        }
    }
    else {
        if (navigationType == UIWebViewNavigationTypeLinkClicked) {
            //@"/huiyi/static/dist/eventDetail.html?meeting_id="
            if ([urlString rangeOfString:yqxBackUrl].location != NSNotFound) {
                New_SignUpInfoViewController *signUpVC = [[New_SignUpInfoViewController alloc]init];
                signUpVC.meetID = [urlString substringFromIndex:[urlString rangeOfString:yqxBackUrl].location+yqxBackUrl.length];
                [self.navigationController pushViewController:signUpVC animated:YES];
                return NO;
            }
            else {
                [[UIApplication sharedApplication] openURL:url];
                return NO;
            }
            [[UIApplication sharedApplication] openURL:url];
            return NO;
        }
    }
    return YES;
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [[Dialog Instance]hiddenHSHUD];
    if (![NetworkSingleten shared].isNetwork) {
        [self.view addSubview:self.networkView];
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    //[[Dialog Instance] hideProgress];
    [[Dialog Instance] hiddenHSHUD];
    
    if ([webView isEqual:self.meetPosterWebView])
    {
        if (@available(iOS 11.0, *))
        {
            self.meetPosterWebView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    else
    {
        NSString * js = @"document.body.innerHTML";
        NSString * pageSource = [webView stringByEvaluatingJavaScriptFromString:js];
        NSLog(@"pagesource:%@fdafdaf", pageSource);
        
        //if (viewdidload)
        {
            _contentInfoViewHeight = 0;
            
            [webView stringByEvaluatingJavaScriptFromString: @"document.documentElement.style.webkitUserSelect='none';"];
            //非常重要
            CGRect frame = webView.frame;
            frame.size.height = 1;
            frame.origin.y = -100;
            webView.frame = frame;
            CGSize fittingSize = [webView sizeThatFits:CGSizeZero];
            [webView sizeToFit];
            
            _contentInfoViewHeight = fittingSize.height;
            
            self.mainWebView.frame = CGRectMake(0, 0, ScreenWidth, _contentInfoViewHeight);
            if (@available(iOS 11.0, *))
            {
                self.mainWebView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
            }
            else
            {
                self.automaticallyAdjustsScrollViewInsets = NO;
            }
            
            self.webCell.backgroundColor = [UIColor blackColor];
            [self.webCell.contentView addSubview:self.mainWebView];
            
            [newSignUpInfoView reloadData];
            
            contentlabel = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.mainWebView.frame) , ScreenWidth, 0.5)];
            BackGround16Color(contentlabel, @"#c8c7cc");
            [self.webCell addSubview:contentlabel];
        }
    }
}

- (void)webViewStop
{
    [self.meetPosterWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"about:blank"]]];
}

- (void)getDBMeetInfo
{
    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@config",_meetID]];
    if ([dataStr length] == 0) {
        
    }
    else {
        _configDictionary = [NSDictionary dictionaryWithDictionary:[[dataStr JSONValue] objectForKey:@"content"]];
        
        NSMutableDictionary *configDic = [NSMutableDictionary dictionaryWithDictionary:[[dataStr JSONValue] objectForKey:@"content"]];
        
        NSArray *arr = [NSArray arrayWithArray:[configDic objectForKey:@"block_list"]];
        NSMutableArray *mutArr = [NSMutableArray array];
        for (NSDictionary *dic in arr) {
            if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                [mutArr addObject:dic];
            }
        }
        [configDic setObject:mutArr forKey:@"block_list"];
        
        _configDic = configDic;
        
        _configEnd = YES;
    }
    
    NSString *keyStr = [NSString stringWithFormat:@"%@_%@_meetInfoState",_session,[_configDictionary objectForKey:@"block_id"]];
    NSDictionary *data = [[[DBManager sharedInstance]getPublicDBData:keyStr] JSONValue];
    if ([[data JSONString] length] == 0) {
        //[self showHUD];
    }
    if ([[[data objectForKey:@"content"] objectForKey:@"list"] isKindOfClass:[NSArray class]] && [[data objectForKey:@"content"] count] != 0) {
        NSArray *arr = [[data objectForKey:@"content"] objectForKey:@"list"];
        for (int i = 0; i<[[_configDictionary objectForKey:@"block_list"] count]; i++) {
            for (int j = 0; j<arr.count; j++) {
                if ([[[[_configDictionary objectForKey:@"block_list"] objectAtIndex:i] objectForKey:@"block_id"]isEqualToString:[[arr objectAtIndex:j] objectForKey:@"block_id"]]) {
                    if (![[[arr objectAtIndex:j] objectForKey:@"state"] isEqualToString:@"0"]) {
                        _blockID = [[arr objectAtIndex:j] objectForKey:@"block_id"];
                    }
                }
            }
        }
    }
    /*
    NSString *keyStr2 = [NSString stringWithFormat:@"%@_meetInfo",_meetID];
    NSDictionary * data2 = [[[DBManager sharedInstance]getPublicDBData:keyStr2] JSONValue];
    if ([[data2 objectForKey:@"code"] isKindOfClass:[NSString class]]) {
        NSLog(@"%@",data2);
        if ([[data2 objectForKey:@"code"]floatValue] ==200) {
            //[self setModalData:data2];
        }
    }*/
    [self getNetData];
}

- (NSString *)rePlaceUrl:(NSString*)content
{
    NSError *error;
    content = [content stringByReplacingOccurrencesOfString:@"<br>" withString:@""];
    NSString *s = @"<(\\w+)\\s*src=\\\"(\\w+.*?)\\\"\\s*/>";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSMutableArray *arr = [[NSMutableArray alloc]initWithCapacity:0];
    
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    for (int i = 0; i<arrayOfAllMatches.count; i++) {
        NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
        NSString* substringForMatch = [content substringWithRange:match.range];
        [arr addObject:substringForMatch];
        
    }
    for (NSString *replaceStr in arr) {
        content = [content stringByReplacingOccurrencesOfString:replaceStr withString:@""];
    }
    return content;
}

- (void)setModalData:(id)data
{
    [_bmListArr removeAllObjects];
    
    yqxBackUrl = [[data objectForKey:@"content"]objectForKey:@"yqx_back_url"];
    
    //判断是否有海报
    [self isHaveImage:[[data objectForKey:@"content"] objectForKey:@"banner_info"]];
    
    for (UIView *view in self.view.subviews){
        [view removeFromSuperview];
    }
    [self createWebCell];//创建Webcell 先获取web的高度
    [self createContentUI];
    
    [self navCustomView];//自定义导航
    self.navBGView.alpha = 0;
    
    [self createRightNavItme];//创建导航右边的按钮
    [_bmListArr addObjectsFromArray: data[@"content"][@"bmlist"][@"list"]];
    NSString *userSignUpNum = [[[data objectForKey:@"content"] objectForKey:@"banner_info"] objectForKey:@"userCount"];
    self.company_code = [[[data objectForKey:@"content"] objectForKey:@"company_info"] objectForKey:@"company_code"];
    if ([userSignUpNum isEqualToString:@"0"] || userSignUpNum.length == 0) {
        self.bmCountBtn.hidden = YES;
    }
    else {
        self.bmCountBtn.hidden = NO;
        [_bmCountBtn setImage:[UIImage imageNamed:@"new_info_count"] forState:UIControlStateNormal];
        [_bmCountBtn setTitle:userSignUpNum forState:UIControlStateNormal];
    }
    if (_haveImage) {
        [self.photoMutableArray removeAllObjects];
        NSArray *imageArray = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"pic_list"];
        if ([imageArray count] > 0) {
            for (NSDictionary *imageDic in imageArray) {
                NSString *imageUrl = [imageDic objectForKey:@"img_file"];
                imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
                [self.photoMutableArray addObject:imageUrl];
            }
        }
        else if([[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"img_url"] length] > 0) {
            NSString *imageUrl = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"img_url"];
            imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
            [self.photoMutableArray addObject:imageUrl];
        }
        else {
            
        }
        [self addTopImages];
        
        headView.frame = CGRectMake(0, 0, ScreenWidth, ImageHeight);
        headView.backgroundColor = [UIColor clearColor];
    }
    else {
        headView.frame = CGRectMake(0, 0, ScreenWidth, 0);
        headView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    if ([[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"collection"] isEqualToString:@"1"]) {
        self.collectBtn.selected = YES;
    }
    else {
        self.collectBtn.selected = NO;
    }
    meetBeginTime = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"begin_time"];
    meetEndTime = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"end_time"];
    //start wang zhenxing
    NSString *begin_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"begin_time"];
    if (begin_time.length == 0) {
        _timeAndAddIpa.ipaBegin_time = @"";
    }
    else {
        _timeAndAddIpa.ipaBegin_time = [self formatter:@"yyyy.MM.dd HH:mm" ToTime:begin_time];
        NSInteger days = [DateFormat DaysSinceNow:begin_time];
        if (days <= 0) {
            _timeAndAddIpa.ipaSuprPlus_time = @"";
        }
        else {
            _timeAndAddIpa.ipaSuprPlus_time = [NSString stringWithFormat:@"还有%ld天开始",(long)days];
        }
    }
    NSString *end_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"end_time"];
    if (end_time.length == 0||[end_time isEqualToString:@"0"]) {
        _timeAndAddIpa.ipaEnd_time = @"";
    }
    else {
        _timeAndAddIpa.ipaEnd_time = [self formatter:@"yyyy.MM.dd HH:mm" ToTime:end_time];
    }
    NSString *status = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"status"];
    _timeAndAddIpa.ipaCompanyList = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"company_list"];
    _timeAndAddIpa.ipaIco_file = [[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"ico_file"];
    _timeAndAddIpa.ipaName = [[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"name"];
    _timeAndAddIpa.ipaRcUserId = [[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"ryuserid"];
    _timeAndAddIpa.ipaUser_id = [[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"creator"] objectForKey:@"user_id"];
    _timeAndAddIpa.ipaOrganizerList = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"organizer_list"];
    _timeAndAddIpa.ipaPrevColumns = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"prev_columns"];
    _timeAndAddIpa.ipaAfterColumns = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"after_columns"];
    _timeAndAddIpa.ipaLocation = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"location"];
    _timeAndAddIpa.ipaShuttle_sw = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"shuttle_sw"];
    _timeAndAddIpa.ipaStay_sw = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"stay_sw"];
    _timeAndAddIpa.ipaPhone_sw = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"phone_sw"];
    _timeAndAddIpa.ipaPhone = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"phone"];
    _timeAndAddIpa.ipaGroup_id = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"group_id"];
    _timeAndAddIpa.ipaIs_in = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"is_in"];
    _timeAndAddIpa.ipaCount_user = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"count_user"];
    _timeAndAddIpa.ipaTitle = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
    _timeAndAddIpa.ipaActivity = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"activity"];
    _timeAndAddIpa.ipaExpenses = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"expenses"];
    if ([_meet_type isEqualToString:@"1"]) {//如果是私人会议
        [self.timeAndAddressView getSiRenViewHeight:_timeAndAddIpa callback:^(CGFloat height) {
            NSLog(@"%f",height);
            CGRect frame = self.timeAndAddressView.frame;
            frame.size.height = height;
            self.timeAndAddressView.frame = frame;
        }];
    }
    else {
        [self.timeAndAddressView getViewHeight:_timeAndAddIpa callback:^(CGFloat height) {
            NSLog(@"%f",height);
            CGRect frame = self.timeAndAddressView.frame;
            frame.size.height = height;
            self.timeAndAddressView.frame = frame;
        }];
    }
    shareTitle =  [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
    shareMessage =  [self rePlaceUrl:[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"summary_font_share"] ];
    shareMessage = [shareMessage stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (shareMessage.length >=38) {
        shareMessage = [shareMessage substringToIndex:38];
    }
    message = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"summary"] ;
    _personal_data_sw = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"personal_data_sw"] ;
    if (!_haveImage) {//图片列表为空
        [self.mainWebView loadHTMLString:[StringToHtml stringToHtml:message] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] resourcePath]]];
        NSArray *arr = [[data objectForKey:@"content"]objectForKey:@"plugin_list"];
        [_gridArr removeAllObjects];
        for (int i = 0; i<arr.count; i++) {
            gridInfo *info = [[gridInfo alloc]init];
            info.urlStr = [[arr objectAtIndex:i] objectForKey:@"ico_url"];
            info.title = [[arr objectAtIndex:i] objectForKey:@"name"];
            info.pluginID = [[arr objectAtIndex:i] objectForKey:@"plugin_id"];
            info.pluginType = [[arr objectAtIndex:i] objectForKey:@"plugin_type"];
            info.authority = [self authority:[[arr objectAtIndex:i] objectForKey:@"authority"]];
            
            /*
            BOOL isCreater = [_timeAndAddIpa.ipaUser_id isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]];
            if ([info.pluginType isEqualToString:@"member"]) {
                if (info.authority || isCreater) {
                    _showPluginStatus = YES;
                }
                else {
                    _showPluginStatus = NO;
                    [_bmListArr removeAllObjects];
                    showPluginStatusNmb  = [arr[i][@"authority"] integerValue];
                } continue;
            }
            if(!isCreater) {
                if (info.authority == YES) {
                    [_gridArr addObject:info];
                }
            }
            else {
                [_gridArr addObject:info];
            }*/
            
            [_gridArr addObject:info];
        }
        //加标题
        NSString *title = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
        CGSize titleSize = [title stringSizeWithFont:[UIFont systemFontOfSize:20] constrainedToSize:CGSizeMake(ScreenWidth-30, 100)];
        if (title.length == 0) {
            _blacktransImageView.frame = CGRectMake(0, 0, ScreenHeight, 59);
        }
        else {
            if (titleSize.height > 30) {
                _blacktransImageView.frame = CGRectMake(0, 0, ScreenHeight, 59+47.7199974f-21);
            }
            else {
                _blacktransImageView.frame = CGRectMake(0, 0, ScreenHeight, 59);
            }
        }
        _blacktransImageView.titles = title;
        self.timeAndAddressView.frame = CGRectMake(0, CGRectGetMaxY(_blacktransImageView.frame)+10, ScreenWidth, self.timeAndAddressView.frame.size.height);
        //重新设置页码的坐标
        _imagePageControl.frame = CGRectMake((ScreenWidth-100)/2.0f, CGRectGetMinY(_blacktransImageView.frame)-20, 100, 20);
        
        NSString *update_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"update_time"];//create_time(创建时间)
        _blacktransImageView.viewTime.text = [DateFormat dateString:update_time];//更新时间
        _blacktransImageView.viewReadCount.text = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"read_count"];//阅读数量
        [self getHuiyiStateWithStartTime:begin_time andEndTime:end_time andStatus:status];
        
        headView.frame = CGRectMake(0, 0, ScreenWidth, headView.size.height+self.timeAndAddressView.frame.size.height+20+_blacktransImageView.frame.size.height+10);
        self.optionView.frame = CGRectMake(0,CGRectGetMaxY(self.timeAndAddressView.frame)+10, ScreenWidth, 189);
        [self creatPluginUI:_gridArr];
        [headView setNeedsLayout];

    }
    else {//图片列表不为空
        [self.mainWebView loadHTMLString:[StringToHtml stringToHtml:message] baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] resourcePath]]];
        CGSize size;
        size =  CGSizeMake(ScreenWidth, ImageHeight);
        NSArray *arr = [[data objectForKey:@"content"]objectForKey:@"plugin_list"];
        [_gridArr removeAllObjects];
        for (int i = 0; i<arr.count; i++) {
            gridInfo *info = [[gridInfo alloc]init];
            info.urlStr = [[arr objectAtIndex:i] objectForKey:@"ico_url"];
            info.title = [[arr objectAtIndex:i] objectForKey:@"name"];
            info.pluginID = [[arr objectAtIndex:i] objectForKey:@"plugin_id"];
            info.pluginType = [[arr objectAtIndex:i] objectForKey:@"plugin_type"];
            info.authority = [self authority:[[arr objectAtIndex:i] objectForKey:@"authority"]];
            info.authoritystatus = [[arr objectAtIndex:i] objectForKey:@"authority"];
            
            /*
            BOOL isCreater = [_timeAndAddIpa.ipaUser_id isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]];
            if ([info.pluginType isEqualToString:@"member"]) {
                if (info.authority||isCreater) {
                    _showPluginStatus = YES;
                }
                else {
                    [_bmListArr removeAllObjects];
                    showPluginStatusNmb  = [arr[i][@"authority"] integerValue];
                } continue;
            }
            if(!isCreater) {
                if (info.authority == YES) {
                    [_gridArr addObject:info];
                }
            }
            else {
                [_gridArr addObject:info];
            }*/
            
            [_gridArr addObject:info];
        }
        //加标题
        NSString *title = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"title"];
        CGSize titleSize = [title stringSizeWithFont:[UIFont systemFontOfSize:20] constrainedToSize:CGSizeMake(ScreenWidth-30, 1000)];
        if (title.length == 0) {
            _blacktransImageView.frame = CGRectMake(0, ImageHeight-59, ScreenHeight, 59);
        }
        else {
            if (titleSize.height > 30) {
                _blacktransImageView.frame = CGRectMake(0, ImageHeight-59-47.7199974f+21, ScreenHeight, 59+47.7199974f-21);
            }
            else {
                _blacktransImageView.frame = CGRectMake(0, ImageHeight-59, ScreenHeight, 59);
            }
        }
        _blacktransImageView.titles = title;
        //重新设置页码的坐标
        _imagePageControl.frame = CGRectMake((ScreenWidth-100)/2.0f, CGRectGetMinY(_blacktransImageView.frame)-20, 100, 20);
        NSString *update_time = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"update_time"];//create_time(创建时间)
        _blacktransImageView.viewTime.text = [DateFormat dateString:update_time];//更新时间
        _blacktransImageView.viewReadCount.text = [[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"read_count"];//阅读数量
        [self getHuiyiStateWithStartTime:begin_time andEndTime:end_time andStatus:status];
        
        headView.frame = CGRectMake(0, 0, ScreenWidth, headView.size.height+self.timeAndAddressView.frame.size.height+20);
        self.optionView.frame = CGRectMake(0,CGRectGetMaxY(self.timeAndAddressView.frame)+10, ScreenWidth, 189);
        [self creatPluginUI:_gridArr];
    }
    if ([[[[data objectForKey:@"content"]objectForKey:@"banner_info"] objectForKey:@"is_like"] isEqualToString:@"1"]) {
        _isLike = YES;
    }
    else {
        _isLike = NO;
    }
    _likeArr = [NSMutableArray arrayWithArray:[[[data objectForKey:@"content"]objectForKey:@"like"] objectForKey:@"list"]];
    _bmCount = [[[data objectForKey:@"content"]objectForKey:@"bmlist"] objectForKey:@"cnt"];

    //[newSignUpInfoView reloadData];
    //NSString *signUpstate = [[data objectForKey:@"content"]objectForKey:@"signup_state"];//最外层 M层的状态 1尚未报名 5完成报名 4报名完成等待审核 3审核未通过 2审核通过等待回执 10报名结束
    if (self.meetPoster_url.length != 0) {
        [self.view addSubview:self.meetPosterWebView];
        //[[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
        [[Dialog Instance] showHSHUDWithController:self];
        [self.meetPosterWebView loadRequest:[[NSURLRequest alloc] initWithURL:[NSURL URLWithString:self.meetPoster_url]]];
    }
    [newSignUpInfoView setTableHeaderView:headView];
    [self operateUI:YES];
}

#pragma mark 计算状态会议进行的状态
- (void)getHuiyiStateWithStartTime:(NSString *)begin_time andEndTime:(NSString *)end_time andStatus:(NSString *)status
{
    NSTimeInterval begin_time_inter = [begin_time longLongValue];
    NSTimeInterval end_time_inter = [end_time longLongValue];
    NSTimeInterval timeInter = [[NSDate date] timeIntervalSince1970];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //设置格式 年yyyy 月 MM 日dd 小时hh(HH) 分钟 mm 秒 ss MMM单月 eee周几 eeee星期几 a上午下午
    //与字符串保持一致
    [formatter setDateFormat:@"HH-mm"];
    //设置时区
    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Shanghai"];
    [formatter setTimeZone:timeZone];
    //参数字符串转化成时间格式
    //NSDate * date = [NSDate dateWithTimeIntervalSince1970:begin_time_inter];
    //NSString *dataTimes = [formatter stringFromDate:date];
    //NSArray *array = [dataTimes componentsSeparatedByString:@"-"];
    //NSTimeInterval differ = 24*3600 - [[array objectAtIndex:0] integerValue]*3600+[[array objectAtIndex:1] integerValue]*60;
    
    if ([status isEqualToString:@"0"]) {
        [_blacktransImageView.viewState setTitle:@"未发布" forState:UIControlStateNormal];
    }
    else {
        if (end_time.length > 0) {
            if (timeInter > end_time_inter) {
                [_blacktransImageView.viewState setTitle:@"已结束" forState:UIControlStateNormal];
            }
            else if (timeInter < end_time_inter && timeInter > begin_time_inter) {
                [_blacktransImageView.viewState setTitle:@"进行中" forState:UIControlStateNormal];
            }
            else if (timeInter < begin_time_inter) {
                [_blacktransImageView.viewState setTitle:@"未开始" forState:UIControlStateNormal];
            }
        }
        else {
            if (timeInter > begin_time_inter) {
                [_blacktransImageView.viewState setTitle:@"进行中" forState:UIControlStateNormal];
            }
            else {
                [_blacktransImageView.viewState setTitle:@"未开始" forState:UIControlStateNormal];
            }
        }
    }
}

- (void)getMeetInfoData
{
    //[[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    [[Dialog Instance] showHSHUDWithController:self];
    NSDictionary *dic = @{@"meeting_id": _meetID};
    [MyDataService postMeetingInfo:dic callback:^(id data) {
        _infoEnd = YES;
        //[[Dialog Instance] hideProgress];
        [[Dialog Instance] hiddenHSHUD];
        if (![NetworkSingleten shared].isNetwork) {
            [self.view addSubview:self.networkView];
        }
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"]floatValue] == 200) {
                NSLog(@"%@",data);
                //                [self createContentUI];
                NSString *keyStr = [NSString stringWithFormat:@"%@_meetInfo",_meetID];
                [[DBManager sharedInstance] deleteToPublicOneData:keyStr];
                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:keyStr];
                [self setModalData:data];
                
            }
            else {
                if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                    [Dialog toastCenter:[data objectForKey:@"error"]];
                }
                else {
                    NSString *error = [data objectForKey:@"msg"];
                    if (error != nil) {
                        [Dialog toastCenter:error];
                    }
                }
            }
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
            }
        }
    }];
}

/**
 *  判断是否有海报
 signUpVC.meet_type = index.meetType;
 signUpVC.meetTitle = index.meetName;
 signUpVC.photoArray = index.meetPic_list;
 signUpVC.haveImage = index.haveImage;
 */
- (void)isHaveImage:(NSDictionary *)dic
{
    if ([[dic objectForKey:@"img_url"] length] > 0 || [[dic objectForKey:@"pic_list"] count] > 0) {//判断有没有海报图片
        self.haveImage = YES;
    }
    else {
        self.haveImage = NO;
    }
    
    self.meet_type = [dic objectForKey:@"type"];
    self.meetTitle = [dic objectForKey:@"name"];
    
    NSArray *imageArray = [dic objectForKey:@"pic_list"];
    if ([imageArray count] > 0) {
        NSMutableArray *imageUrls = [[NSMutableArray alloc]init];
        for (NSDictionary *imageDic in imageArray) {
            NSString *imageUrl = [imageDic objectForKey:@"img_file"];
            imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
            [imageUrls addObject:imageUrl];
        }
        self.photoArray = imageUrls;
    }
    else if ([[dic objectForKey:@"img_url"] length] > 0) {
        NSString *imageUrl = [dic objectForKey:@"img_url"];
        imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
        self.photoArray = [NSMutableArray arrayWithObjects:imageUrl, nil];
    }
}

- (void)isCloseMeeting
{
    NSDictionary *dic = @{@"meeting_id": _meetID,@"block_id": [_configDic objectForKey:@"block_id"]};
    [MyDataService postPartakeState:dic callback:^(id data) {
        NSLog(@"%@",data);//0未填,1不完整,2完整,3可选的未填，4可选的不完整
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                
            }
        }
    }];
}

- (void)goToSignUpStatusView:(BOOL)isHost
{
    for (NSDictionary *nextViewDic12 in [_configDictionary objectForKey:@"block_list"]) {
        if ([[nextViewDic12 objectForKey:@"block_id"]isEqualToString:_blockID]) {
            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"10"]) {
                //显示报名状态跟踪
                NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
                [ticket setObject:[nextViewDic12 objectForKey:@"name"] forKey:@"name"];
                [ticket setObject:[nextViewDic12 objectForKey:@"price"] forKey:@"price"];
                
                [ticket setObject:[self formatter:@"yyyy.MM.dd HH:mm" ToTime:[nextViewDic12 objectForKey:@"partake_end_time"]] forKey:@"partake_end_time"];
                [ticket setObject:[nextViewDic12 objectForKey:@"note"] forKey:@"note"];
                [self writePlistToDucment:@"ticketinfo" With:ticket];
                SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                //stateVC.delegate = self;
                stateVC.isCheck = NO;
                stateVC.isHost = isHost;
                stateVC.name = [[NSUserDefaults standardUserDefaults] objectForKey:@"name"];
                stateVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                stateVC.meetID = _meetID;
                stateVC.user_id = [[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"];
                stateVC.configDic = _configDictionary;
                stateVC.type = [nextViewDic12 objectForKey:@"type"];
                stateVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                [self.navigationController pushViewController:stateVC animated:YES];
            }
        }
    }
}

- (void)notificationMethed
{
    if ([skipManagerTool shareInstence].btnClickType == SignBtnClick) {//点击报名 通知
        [skipManagerTool shareInstence].btnClickType = OtherBtnClick;//记录置空
        [self signUpBtnClicked:self.signUpBtn];//执行点击报名功能
    }
    if ([skipManagerTool shareInstence].btnClickType == OtherSignBtnClick) {//点击代人报名 通知
        [skipManagerTool shareInstence].btnClickType = OtherBtnClick;//记录置空
        [self signUpBtnClicked:self.replceSignUpBtn];//执行代人报名
    }
}

- (void)popToLoginView
{
    [[NSUserDefaults standardUserDefaults]setObject:_company_code forKey:@"company_code"];
    LoginViewController *loginVc = [[LoginViewController alloc]init];
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVc];
    loginVc.fromSignVC = YES;
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        loginVc.isPush = YES;
    }
    loginVc.delegate = self;
    loginVc.companyCode = self.companyCode;
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)signUpBtnClicked:(UIButton *)btn {
    if ([skipManagerTool shareInstence].skipType == IndexViewToDetailsFailure) {
        if ([btn isEqual:self.signUpBtn]) {
            [skipManagerTool shareInstence].btnClickType = SignBtnClick;
            if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
                [self popToLoginView];
                return;
            }
        }
        if ([btn isEqual:self.replceSignUpBtn]) {
            [skipManagerTool shareInstence].btnClickType = OtherSignBtnClick;
            if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
                [self popToLoginView];
                return;
            }
        }
        /*
        UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入该会议的企业号并重新登录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"重新登录", nil];
        alertview.tag = 3000;
        [alertview show];*/
        NSString *companyMessage = [NSString stringWithFormat:@"您扫描了『%@』公司的活动二维码，如确认要参加此活动，请重新登录并在企业号中输入：%@", self.companyName, self.companyCode];
        self.hintAlertView = [[HintAlertView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        self.hintAlertView.delegate = self;
        [self.hintAlertView reloadViewWithTitle:@"提示" message:companyMessage range:NSMakeRange(companyMessage.length-self.companyCode.length, self.companyCode.length) cancelButtonTitle:@"取消" otherButtonTitle:@"重新登录"  messageAlignment:NSTextAlignmentLeft];
        [self.hintAlertView show];
        return;
    }
    if ([self compareCompanyCode]) {
        return;
    }
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        [self popToLoginView];
        return;
    }

    BOOL meetIsEnd;
    //NSTimeInterval begin_time_inter = [meetBeginTime longLongValue];
    NSTimeInterval end_time_inter = [meetEndTime longLongValue];
    NSTimeInterval timeInter = [[NSDate date] timeIntervalSince1970];
    if (meetEndTime.length > 0) {
        if (timeInter > end_time_inter) {
            meetIsEnd = YES;
        }
        else {
            meetIsEnd = NO;
        }
    }
    else {
        meetIsEnd = NO;
    }
    
    if ([btn isEqual:self.signUpBtn]) {
        _replceSignUpBtnClicked = NO;
        if (![_signUpstate isEqualToString:@"1"] && ![_signUpstate isEqualToString:@"10"]) {
            [self goToSignUpStatusView:YES];
        }
        else {
            for (SDTicketModel *model in _ticketArr) {
                double time = [model.int_partake_end_time longLongValue];
                NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
                NSTimeInterval a = [dat timeIntervalSince1970];
                if ((int)a > time){
                    model.meetEnd = YES;
                }
                else {
                    model.meetEnd = NO;
                }
            }
            if (meetIsEnd) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"报名已结束" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alert show];
                return;
            }
            
            if (!_sdTableView.isShow) {
                _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                _sdTableView.dataSourceArr = _ticketArr;
                _sdTableView.meeting_title = shareTitle;
                if (self.photoMutableArray.count == 0) {
                    _sdTableView.posterImageUrl = nil;
                }
                else {
                    _sdTableView.posterImageUrl = [self.photoMutableArray objectAtIndex:0];
                }
                if (ticketIndexPath) {
                    _sdTableView.indexPath = ticketIndexPath;
                }
                [_sdTableView showInFatherView:self.view];
            }
            
            /*
            if ([_timeAndAddIpa.ipaUser_id isEqualToString:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"您是会议创建者，不用报名" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alert show];
                return;
            }
            else{*/
                /*
                if (_ticketArr.count == 1) {
                    
                    NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
                    SDTicketModel * info = [_ticketArr firstObject];
                    
                    if (info.meetEnd == YES) {
                        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议报名截止" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                        [alert show];
                        return;
                    }
                    
                    [ticket setObject:info.name forKey:@"name"];
                    [ticket setObject:info.price forKey:@"price"];
                    [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
                    [ticket setObject:info.note forKey:@"note"];
                    [ticket setObject:info.block_id forKey:@"block_id"];
                    [ticket setObject:info.visible forKey:@"visible"];
                    [self writePlistToDucment:@"ticketinfo" With:ticket];
                    [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
                    [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
                    if (_configEnd == YES) {
                        SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
                        tool.signUpstate = _signUpstate;
                        tool.controller = self;
                        tool.meeting_id = _meetID;
                        tool.blockID = _blockID;
                        tool.configDic = _configDic;
                        [tool manageConfig];
                    }
                }
                else {
                    if (!_sdTableView.isShow) {
                        _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                        _sdTableView.dataSourceArr = _ticketArr;
                        _sdTableView.meeting_title = shareTitle;
                        if (self.photoMutableArray.count == 0) {
                            _sdTableView.posterImageUrl = nil;
                        }else{
                            _sdTableView.posterImageUrl = [self.photoMutableArray objectAtIndex:0];
                        }
                        if (ticketIndexPath) {
                            _sdTableView.indexPath = ticketIndexPath;
                        }
                        [_sdTableView showInView:self.view];
                    }
                }*/
            /*}*/
        }
    }
    
    if ([btn isEqual:self.replceSignUpBtn]) {
        _replceSignUpBtnClicked = YES;
        for (SDTicketModel *model in _ticketArr) {
            double time = [model.int_partake_end_time longLongValue];
            NSDate* dat = [NSDate dateWithTimeIntervalSinceNow:0];
            NSTimeInterval a = [dat timeIntervalSince1970];
            if ((int)a > time) {
                model.meetEnd = YES;
            }
            else {
                model.meetEnd = NO;
            }
        }
        
        if (meetIsEnd) {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"报名已结束" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alert show];
            return;
        }
        
        if (!_sdTableView.isShow) {
            _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
            _sdTableView.dataSourceArr = _ticketArr;
            _sdTableView.meeting_title = shareTitle;
            if (self.photoMutableArray.count == 0) {
                _sdTableView.posterImageUrl = nil;
            }else{
                _sdTableView.posterImageUrl = [self.photoMutableArray objectAtIndex:0];
            }
            if (ticketIndexPath) {
                _sdTableView.indexPath = ticketIndexPath;
            }
            [_sdTableView showInFatherView:self.view];
        }
        
        /*
        if (_ticketArr.count == 1) {
         
            NSMutableDictionary *ticket = [[NSMutableDictionary alloc]initWithCapacity:0];
            SDTicketModel * info = [_ticketArr firstObject];
            
            if (info.meetEnd == YES) {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议报名截止" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                [alert show];
                return;
            }
            
            [ticket setObject:info.name forKey:@"name"];
            [ticket setObject:info.price forKey:@"price"];
            [ticket setObject:info.partake_end_time forKey:@"partake_end_time"];
            [ticket setObject:info.note forKey:@"note"];
            [ticket setObject:info.block_id forKey:@"block_id"];
            [ticket setObject:info.visible forKey:@"visible"];
            [self writePlistToDucment:@"ticketinfo" With:ticket];
            [[DBManager sharedInstance] deleteToPublicOneData:@"ticketinfo"];
            [[DBManager sharedInstance]insertDataToPublicDB:[ticket JSONString] valueKey:@"ticketinfo"];
            if (_configEnd == YES) {
                SignUpConfigTool *tool = [[SignUpConfigTool alloc]init];
                tool.signUpstate = _signUpstate;
                tool.controller = self;
                tool.meeting_id = _meetID;
                tool.blockID = _blockID;
                tool.configDic = _configDic;
                [tool manageSubConfig];
            }
        }
        else {
            if (!_sdTableView.isShow) {
                _sdTableView = [[SDTableView alloc]initWithTitle:@"" delegate:self];
                _sdTableView.dataSourceArr = _ticketArr;
                _sdTableView.meeting_title = shareTitle;
                if (self.photoMutableArray.count == 0) {
                    _sdTableView.posterImageUrl = nil;
                }else{
                    _sdTableView.posterImageUrl = [self.photoMutableArray objectAtIndex:0];
                }
                if (ticketIndexPath) {
                    _sdTableView.indexPath = ticketIndexPath;
                }
                [_sdTableView showInView:self.view];
            }
        }*/
    }
}

- (void)selectAtIndex:(NSIndexPath *)indexPath {
    ticketIndexPath = indexPath;
}

- (void)didReceiveMemoryWarning {
    NSLog(@"New_SignUpInfoViewController ReceiveMemoryWarning");
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
