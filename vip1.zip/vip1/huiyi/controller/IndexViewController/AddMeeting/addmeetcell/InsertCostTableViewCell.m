//
//  InsertCostTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "InsertCostTableViewCell.h"

@implementation InsertCostTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    
    
    UILabel *LineLB = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth-20-40, 0.5)];
    BackGround16Color(LineLB, @"#c8c7cc");
    [self.contentView addSubview:LineLB];
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(33, 16, ScreenWidth-20-66, 20)];
    _titleLB.font = YHUI(16);
    _titleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.text = @"价格___________元(人民币)";
    _titleLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_titleLB];
    
    
    _contentTF = [[UITextField alloc]initWithFrame:CGRectMake(60, 16, 100, 20)];
    _contentTF.backgroundColor = [UIColor clearColor];
    _contentTF.keyboardType = UIKeyboardTypeNumberPad;
    _contentTF.font = YHUI(16);
    _contentTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    _contentTF.textAlignment = NSTextAlignmentCenter;
    [_contentTF addTarget:self action:@selector(textFiledChange) forControlEvents:UIControlEventEditingChanged];
    
    
    _subTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_contentTF.frame), 16, 120, 20)];
    _subTitleLB.font = YHUI(16);
    _subTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    _subTitleLB.backgroundColor = [UIColor clearColor];
    _subTitleLB.text = @"元（人民币）";
    _subTitleLB.textAlignment = NSTextAlignmentLeft;
//    [self.contentView addSubview:_subTitleLB];

    

    [self.contentView addSubview:_contentTF];
    

    SDToolBarOfHideView *toolBar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
    toolBar.SDdelegate = self;
    _contentTF.inputAccessoryView = toolBar;
    

    
    
    
}
- (void)hideKeyboard
{
    [_contentTF resignFirstResponder];
}
- (void)textFiledChange
{
    if ([_contentTF.text integerValue]>999999&&_contentTF.text.length==7) {
        _contentTF.text = [_contentTF.text substringToIndex:6];
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"票的价格不得大于999999" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }
    if (_contentTF.text.length>9) {
        _contentTF.text = [_contentTF.text substringToIndex:9];
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"票的价格不得大于999999" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }
    
}
- (void)setFrame:(CGRect)frame
{
    frame.origin.x+=10 ;
    frame.size.width-=20;
    [super setFrame:frame];
}
- (void)awakeFromNib {
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
