//
//  TFTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "TFTableViewCell.h"

@implementation TFTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [self.contentView  addSubview:headLineLB];
        
        endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 40.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        self.contentTF = [[RegistTextField alloc]initWithFrame:CGRectMake(17, CGRectGetMaxY(headLineLB.frame) + 8, 300, 22)];
        BackGroundColor(self.contentTF, clearColor);
        self.contentTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
        [self.contentView addSubview:self.contentTF];


    }
    return self;
}
- (void)setIsHead:(BOOL)isHead
{
    if (isHead) {
        headLineLB.hidden = NO;
    }else{
        headLineLB.hidden = YES;
    }
}

- (void)setIsEnd:(BOOL)isEnd
{
    if (isEnd) {
        endLineLB.frame = CGRectMake(0, 40.5, ScreenWidth, 0.5);
    }else{
        endLineLB.frame = CGRectMake(14.5, 40.5, ScreenWidth, 0.5);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
