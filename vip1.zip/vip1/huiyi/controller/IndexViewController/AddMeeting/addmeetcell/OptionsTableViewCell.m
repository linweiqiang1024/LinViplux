//
//  OptionsTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "OptionsTableViewCell.h"

@implementation OptionsTableViewCell
@synthesize optionsArr = _optionsArr;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    CGFloat selfHeight = 0;
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [self.contentView  addSubview:headLineLB];
        
        endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 40.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        UILabel *nameLB = [[UILabel alloc]initWithFrame:CGRectMake(18.5, 0.5, 250, 31)];
        nameLB.text = @"用户报名填写项";
        nameLB.font = YHUI(16);
        nameLB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        
        nameLB.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:nameLB];
        
        for (int i = 0; i < 6; i++) {
            UIButton *itemBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
            if (i<2) {
                itemBtn.selected = YES;
            }
//            itemBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
            
            [itemBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            [itemBtn setTitleColor:[UIColor colorWithHexString:@"#080808"] forState:UIControlStateNormal];
            [itemBtn setTitle:[_optionsArr objectAtIndex:i] forState:UIControlStateNormal];
            itemBtn.frame = CGRectMake( 25+(25+73)*(i%3), CGRectGetMaxY(nameLB.frame)+35*(i/3), 73, 25);
            itemBtn.selected = self.isSelected;
            
            [itemBtn setBackgroundImage:[UIImage imageNamed:@"seleced_btn"] forState:UIControlStateSelected];
            [itemBtn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
            itemBtn.titleLabel.font = YHUI(16);
            itemBtn.backgroundColor = [UIColor clearColor];
            [itemBtn addTarget:self action:@selector(itemBtntnClicked:) forControlEvents:UIControlEventTouchUpInside];
            itemBtn.tag = 130+i;
            [self.contentView addSubview:itemBtn];
            selfHeight = CGRectGetMaxY(itemBtn.frame);
        }
        selfHeight += 16;
        UILabel *tailDiscribeLB = [[UILabel alloc]initWithFrame:CGRectMake(15, selfHeight, ScreenWidth, 51)];
        tailDiscribeLB.text = @"选项不够用或需要更多报名类型？请发布完毕后，电脑上访问专业版管理后台配置报名选项";
        tailDiscribeLB.font = YHUI(14);
        tailDiscribeLB.numberOfLines = 0;
        tailDiscribeLB.lineBreakMode = NSLineBreakByCharWrapping;
        [self.contentView addSubview:tailDiscribeLB];
        
    }
    return self;
}

- (void)itemBtntnClicked:(UIButton *)btn
{
    
    [self.delegate optionBtnClicked:btn];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
