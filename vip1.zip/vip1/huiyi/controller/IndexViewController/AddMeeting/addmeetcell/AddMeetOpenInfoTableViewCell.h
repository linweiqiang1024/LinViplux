//
//  AddMeetOpenInfoTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddMeetOpenInfoTableViewCell : UITableViewCell
{
    UILabel *_titleLB;
    UIImageView *_selecedImageView;
    BOOL _isSelected;
}
@property (nonatomic)BOOL isSelected;
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UIImageView *selecedImageView;
@end
