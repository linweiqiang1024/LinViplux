//
//  SignUpEndTimeTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpEndTimeTableViewCell : UITableViewCell
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UILabel *contentLB;
@property (nonatomic,strong)UIImageView *goBtn;
@end
