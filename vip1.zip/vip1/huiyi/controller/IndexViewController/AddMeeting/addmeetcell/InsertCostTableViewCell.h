//
//  InsertCostTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDToolBarOfHideView.h"
@interface InsertCostTableViewCell : UITableViewCell<UITextFieldDelegate,HideKeyboardDelegate>
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UILabel *subTitleLB;
@property (nonatomic,strong)UITextField *contentTF;
@end
