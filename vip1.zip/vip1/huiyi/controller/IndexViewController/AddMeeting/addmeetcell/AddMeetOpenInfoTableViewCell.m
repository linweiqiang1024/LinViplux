//
//  AddMeetOpenInfoTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "AddMeetOpenInfoTableViewCell.h"

@implementation AddMeetOpenInfoTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [self.contentView  addSubview:headLineLB];
        
        UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 40.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        self.titleLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0.5, ScreenWidth-26-15, 40)];
        self.titleLB.backgroundColor = [UIColor clearColor];
        self.titleLB.font = YHUI_BOLD(16);
        self.titleLB.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLB];
        
        self.selecedImageView = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.titleLB.frame), 12, 21, 21.5)];
        self.selecedImageView.image = [UIImage imageNamed:@"select"];
        self.selecedImageView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.selecedImageView];
    }
    return self;
}
- (void)setIsSelected:(BOOL)isSelected
{
    if (isSelected == NO) {
        self.selecedImageView.image = [UIImage imageNamed:@"select"];
    }
    if (isSelected == YES) {
        self.selecedImageView.image = [UIImage imageNamed:@"selected-cur"];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
