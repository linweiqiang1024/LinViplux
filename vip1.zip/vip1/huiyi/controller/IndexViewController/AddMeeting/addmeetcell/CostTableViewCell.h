//
//  CostTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SevenSwitch.h"

@protocol ShowCostDelegate <NSObject>

- (void)showCostView:(SevenSwitch*)btn;

@end
@protocol checkDelegate <NSObject>

- (void)checkSignUpInfo:(SevenSwitch*)btn;

@end
@interface CostTableViewCell : UITableViewCell
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)SevenSwitch*switchBtn;
@property (nonatomic,weak)id <ShowCostDelegate>delegate;
@property (nonatomic,weak)id <checkDelegate>CheckDelegate;
@end
