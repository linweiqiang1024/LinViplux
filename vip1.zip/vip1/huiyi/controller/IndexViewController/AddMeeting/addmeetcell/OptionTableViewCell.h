//
//  OptionTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITicketOptionButton.h"
#import "UICleanOptionButton.h"
#import "STAlertView.h"

@protocol OptionDelegate <NSObject>
-(void)sureOption:(UIButton *)btn;
-(void)selectOption:(UIButton *)btn;
-(void)cleanOption:(UIButton *)btn;
@end

@interface OptionTableViewCell : UITableViewCell
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UITicketOptionButton *selectBtn;
@property (nonatomic,strong)UIButton *swichBtn;
@property (nonatomic,strong)UICleanOptionButton *cleanBtn;
@property (nonatomic)NSInteger index;
@property (nonatomic,strong)NSString *cellTitle;
@property (nonatomic,weak)id<OptionDelegate>delegate;
@end
