//
//  SignUpEndTimeTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SignUpEndTimeTableViewCell.h"

@implementation SignUpEndTimeTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    
    UILabel *LineLB = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth-40-20, 0.5)];
    BackGround16Color(LineLB, @"#c8c7cc");
    [self.contentView addSubview:LineLB];
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(33, 16, 118, 20)];
    _titleLB.font = YHUI(16);
    _titleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.text = @"报名截止时间";
    _titleLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_titleLB];
    
    
    _contentLB = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth-10-35-10-189, 16, 189, 20)];
    _contentLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    _contentLB.font = YHUI(16);
    _contentLB.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:_contentLB];

    
    _goBtn = [[UIImageView alloc]init];
    _goBtn.center = CGPointMake(ScreenWidth-20-20-10, _titleLB.center.y-8);
    _goBtn.image = [UIImage imageNamed:@"mine_right_go"];
    _goBtn.size = CGSizeMake(10, 17);
    [self.contentView addSubview:_goBtn];
    

}
- (void)setFrame:(CGRect)frame
{
    frame.origin.x += 10;
    frame.size.width -= 20;
    [super setFrame:frame];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
