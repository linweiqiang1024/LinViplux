//
//  TicketTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/20.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "TicketTableViewCell.h"

@implementation TicketTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        UIImage *buttonImageselected = [UIImage imageNamed:@"ticket_bg"];
//        buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImageselected.size.width/2) topCapHeight:floorf(buttonImageselected.size.height/2)];

        CGFloat top = 10; // 顶端盖高度
        CGFloat bottom = 10 ; // 底端盖高度
        CGFloat left = 25; // 左端盖宽度
        CGFloat right = 25; // 右端盖宽度
        UIEdgeInsets insets = UIEdgeInsetsMake(top, left, bottom, right);
        // 指定为拉伸模式，伸缩后重新赋值
        buttonImageselected = [buttonImageselected resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];

        bgImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth-20, 140)];
        bgImageView.image = buttonImageselected;
        bgImageView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:bgImageView];
        self.backgroundColor = [UIColor clearColor];
        [self createUI];
    }
    return self;
}
- (void)cleanTicketInfo:(UIButton *)btn
{
    [_delegate meetTicketCleaned:btn];
}
- (void)eidtTicketInfo:(UIButton *)btn
{
    [_delegate meetTicketEidt:btn];
}
- (void)createUI
{
    _hideImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 45, 45)];
    _hideImageView.image = [UIImage imageNamed:@"ticketHide"];
    [_hideImageView setHidden:YES];
    [self.contentView addSubview:_hideImageView];
    
    _cleanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _cleanBtn.frame = CGRectMake(0, 4, 50, 50);
    _cleanBtn.imageEdgeInsets = UIEdgeInsetsMake(12.5, 12.5, 12.5, 12.5);
    [_cleanBtn setImage:[UIImage imageNamed:@"add_clear_btn@3x"] forState:UIControlStateNormal];
    [_cleanBtn addTarget:self action:@selector(cleanTicketInfo:) forControlEvents:UIControlEventTouchUpInside];
    [_cleanBtn setHidden:YES];
    [self.contentView addSubview:_cleanBtn];
    
    _eidtBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _eidtBtn.frame = CGRectMake(ScreenWidth-20-37-16, 4, 50, 50);
    _eidtBtn.imageEdgeInsets = UIEdgeInsetsMake(12.5, 12.5, 12.5, 12.5);
    [_eidtBtn setImage:[UIImage imageNamed:@"add_edit_btn@3x"] forState:UIControlStateNormal];
    [_eidtBtn addTarget:self action:@selector(eidtTicketInfo:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:_eidtBtn];
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(48, 17, ScreenWidth-20-48*2, 21)];
    _titleLB.font = YHUI(19);
    _titleLB.textColor = [UIColor colorWithHexString:@"#65a5bc"];
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:_titleLB];
    
    _costLB = [[UILabel alloc]initWithFrame:CGRectMake(48, CGRectGetMaxY(_titleLB.frame) + 13, ScreenWidth-20-48*2, 19)];
    _costLB.font = YHUI(19);
    _costLB.textColor = [UIColor colorWithHexString:@"#c9a766"];
    _costLB.backgroundColor = [UIColor clearColor];
    _costLB.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:_costLB];
    
    UIImageView *lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(_costLB.frame)+11, ScreenWidth-60, 1)];
    lineImageView.image = [UIImage imageNamed:@"ticket_mid_line"];
    [self.contentView addSubview:lineImageView];
    
    UILabel *endTimeTitle = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_costLB.frame)+20, 97, 15)];
    endTimeTitle.backgroundColor = [UIColor clearColor];
    endTimeTitle.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    endTimeTitle.font = YHUI(15);
    endTimeTitle.text = @"报名截止时间:";
    [self.contentView addSubview:endTimeTitle];
    
    _endTimeLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(endTimeTitle.frame), CGRectGetMaxY(_costLB.frame)+20, ScreenWidth-32-CGRectGetMaxX(endTimeTitle.frame), 16)];
    _endTimeLB.font = YHUI(16);
    _endTimeLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    _endTimeLB.backgroundColor = [UIColor clearColor];
    _endTimeLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_endTimeLB];
    
    _introLB = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_endTimeLB.frame)+10, ScreenWidth-44, 15)];
    _introLB.font = YHUI(15);
    _introLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    _introLB.backgroundColor = [UIColor clearColor];
    _introLB.lineBreakMode = NSLineBreakByWordWrapping;
    _introLB.numberOfLines = 0;
    _introLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_introLB];
}

/*
- (void)setIntroLB:(UILabel *)introLB
{
    [_introLB removeFromSuperview];
    _introLB = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_endTimeLB.frame)+10, ScreenWidth-44, 15)];
    _introLB.font = YHUI(15);
    _introLB.textColor = [UIColor colorWithHexString:@"#999b9f"];
    _introLB.backgroundColor = [UIColor clearColor];
    _introLB.lineBreakMode = NSLineBreakByWordWrapping;
    _introLB.numberOfLines = 0;
    _introLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_introLB];
}*/

- (void)setIntroHeight:(NSString *)content
{
    if(content.length == 0){
        _introLB.size = CGSizeMake(ScreenWidth-44, 0);
        bgImageView.size = CGSizeMake(bgImageView.size.width, CGRectGetMaxY(_introLB.frame)+10);
    }else{
        CGSize size = [content sizeWithFont:YHUI(15) constrainedToSize:CGSizeMake(ScreenWidth-44, 500) lineBreakMode:NSLineBreakByWordWrapping];
        _introLB.size = CGSizeMake(ScreenWidth-44, size.height);
        _introLB.lineBreakMode = NSLineBreakByWordWrapping;
        _introLB.numberOfLines = 0;
        bgImageView.size = CGSizeMake(bgImageView.size.width, CGRectGetMaxY(_introLB.frame)+10);
    }
}

- (void)setFrame:(CGRect)frame
{
    frame.origin.x+=10;
    frame.size.width-=20;
    [super setFrame:frame];
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
