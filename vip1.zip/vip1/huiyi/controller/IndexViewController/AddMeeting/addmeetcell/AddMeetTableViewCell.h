//
//  AddMeetTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum _UIType{
    TextField = 1, //输入框
    Btn1 = 2,//勾选
    Btn2 = 3,//更多
    TimeView = 4,   //弹出时间选择器
    TextView = 5,
    TitleLB,    //字段名字
}UIType;

@interface AddMoreMeetInfoModel : NSObject//tableview  section的信息
{
    NSString *_postKey;
    NSString *_title;
    NSString *_time;//如果是选择时间  存储时间戳字符串
    NSString *_summary;
    BOOL _isSelected;
    BOOL _isSection;
    BOOL _isChange;
    
}

@property (nonatomic,strong) NSString *summary;
@property (nonatomic,strong) NSString *postKey;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *placeHolder;
@property (nonatomic,strong) NSString *time;
@property (nonatomic) BOOL isSelected;
@property (nonatomic) BOOL isSection;
@property (nonatomic) BOOL isChange;
@property (nonatomic) UIType uiType;

@end

@interface AddMeetInfoModel : NSObject//选择字段的所有信息和掉接口时的所有key
{
    NSString *_postKey;
    NSString *_title;
    NSString *_content;
    NSString *_imageName;
    BOOL _isSelected;
}

@property (nonatomic,strong) NSString *postKey;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSString *imageName;
@property (nonatomic) BOOL isSelected;

@end

@interface AddMeetTableViewCell : UITableViewCell
{
    UIImageView *_headImageView;
    UILabel *_titleLB;
    UILabel *_subTitleLB;
    UIImageView *_selecedImageView;
    BOOL _isSelected;
    
}
@property (nonatomic,strong)UIImageView *headImageView;
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UILabel *subTitleLB;
@property (nonatomic,strong)UIImageView *selecedImageView;
@property (nonatomic)BOOL isSelected;
@end
