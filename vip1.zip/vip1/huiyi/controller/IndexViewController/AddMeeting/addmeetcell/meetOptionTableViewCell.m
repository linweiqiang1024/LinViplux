//
//  meetOptionTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "meetOptionTableViewCell.h"

@implementation meetOptionTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    
    UILabel *LineLB = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth-40-20, 0.5)];
    BackGround16Color(LineLB, @"#c8c7cc");
    [self.contentView addSubview:LineLB];
    
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(33, 16, 140, 20)];
    _titleLB.font = YHUI(16);
    _titleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.text = @"参会者报名字段";
    _titleLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_titleLB];
    

    
    _describeLB = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth-40-10-7-80, 16, 80, 20)];
    _describeLB.font = YHUI(17);
    _describeLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];

    _describeLB.backgroundColor = [UIColor clearColor];
    
    _describeLB.textAlignment = NSTextAlignmentRight;
    [self.contentView addSubview:_describeLB];
    UIImageView *_goBtn = [[UIImageView alloc]init];
    
    _goBtn.center = CGPointMake(ScreenWidth-20-20-10, _describeLB.center.y-8);
    _goBtn.image = [UIImage imageNamed:@"mine_right_go"];
    _goBtn.size = CGSizeMake(10, 17);
    [self.contentView addSubview:_goBtn];
    
    
}
- (void)setFrame:(CGRect)frame
{
    frame.origin.x += 10;
    frame.size.width -= 20;
    [super setFrame:frame];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
