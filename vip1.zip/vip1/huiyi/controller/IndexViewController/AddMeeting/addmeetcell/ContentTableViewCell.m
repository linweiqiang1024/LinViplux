//
//  ContentTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-28.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "ContentTableViewCell.h"

@implementation ContentTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    CGFloat selfHeight = 0;
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];

        _detailsTextView = [[UITextView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(headLineLB.frame), ScreenWidth-20, 130.5)];
        _detailsTextView.font = YHUI(16);
//        _detailsTextView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        _detailsTextView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_detailsTextView];
        headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_detailsTextView.frame), ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [self.contentView  addSubview:headLineLB];
        
        _placeholder = [[UILabel alloc]initWithFrame:CGRectMake(18, 7, 280, 22)];
        _placeholder.textColor = [UIColor colorWithHexString:@"d3d3d3"];
        _placeholder.text = @"活动详情，详细说明时间、地点、事件";
        _placeholder.font = YHUI(16);
        //    placeholder.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        _placeholder.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_placeholder];

        _imageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLineLB.frame), ScreenWidth , 0)];
        [_imageScrollView setShowsHorizontalScrollIndicator:NO];
        [_imageScrollView setShowsVerticalScrollIndicator:NO];
        _imageScrollView.backgroundColor = [UIColor clearColor];
        for (int i = 0; i < 5; i++) {
            UIImageView * imageviews = [[UIImageView alloc]initWithFrame:CGRectMake(i*(10+60), 0, 60, 60)];
            imageviews.backgroundColor = [UIColor clearColor];
            imageviews.tag = 140+i ;
            imageviews.userInteractionEnabled = YES;
            UIGestureRecognizer  *oneFingeTwoTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getBigImages:)];
            // 点击次数
            
            [imageviews addGestureRecognizer:oneFingeTwoTaps];
            [_imageScrollView addSubview:imageviews];
        }
        _imageScrollView.contentSize = CGSizeMake(ScreenWidth+60, 60);
        [self.contentView addSubview:_imageScrollView];
        
        UILabel *headLine6LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_imageScrollView.frame), ScreenWidth, 0.5)];
//        headLine6LB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        
        BackGround16Color(headLine6LB, @"#c8c7cc");
        [self.contentView addSubview:headLine6LB];
        
        backView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_imageScrollView.frame), ScreenWidth, 31.5)];
//        backView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        backView.tag = 131;
        backView.userInteractionEnabled = YES;
        backView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
        
        [self.contentView addSubview:backView];
        
        endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(backView.frame), ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        
        UIButton *selecedImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        selecedImageBtn.frame = CGRectMake(3, CGRectGetHeight(backView.frame)-27, 58, 23);
        [selecedImageBtn setImage:[UIImage imageNamed:@"photo"] forState:UIControlStateNormal];
        selecedImageBtn.backgroundColor = [UIColor clearColor];
        [selecedImageBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        selecedImageBtn.tag = 122;
//        selecedImageBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        
        
        [backView addSubview:selecedImageBtn];
        
        
        
    }
    return self;
}
- (void)btnClicked:(UIButton *)btn
{
    [_delegate getImages];
}
- (void)getBigImages:(UIGestureRecognizer*)gesture
{
    [_delegate showPhotos];
}
- (void)textViewDidChange:(UITextView *)textView
{
    
    if (textView.text.length == 0) {
        _placeholder.hidden = NO;
    }else{
        _placeholder.hidden = YES;
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
