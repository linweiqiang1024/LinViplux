//
//  CostTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "CostTableViewCell.h"

@implementation CostTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    
    UILabel *LineLB = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth-20-40, 0.5)];
    BackGround16Color(LineLB, @"#c8c7cc");
    [self.contentView addSubview:LineLB];
    
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:@"报名费用"];
    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,4)];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,4)];
    //    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(6,7)];
    //    [tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(33, 18, ScreenWidth-20-66, 16)];
    _titleLB.font = YHUI(16);
    _titleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    _titleLB.backgroundColor = [UIColor clearColor];
//    _titleLB.attributedText = tittle_str;
    _titleLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_titleLB];
    
    _switchBtn = [[ SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth - 20 -20 - 46, 12, 46, 28)];
    _switchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
    [_switchBtn addTarget:self action:@selector(switchBtnClick:) forControlEvents:UIControlEventValueChanged];
    [self.contentView addSubview:_switchBtn];
    


    
    
}
- (void)switchBtnClick:(SevenSwitch*)btn
{
    
    [_delegate showCostView:btn];
}

- (void)setFrame:(CGRect)frame
{
    frame.origin.x+=10 ;
    frame.size.width-=20;
    [super setFrame:frame];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
