//
//  AddMeetTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "AddMeetTableViewCell.h"

@implementation AddMoreMeetInfoModel

- (id)init{
    if (self = [super init]) {
        _title = @"";
        _isSelected = NO;
        _isChange = NO;
        _postKey = @"";
        _time = @"";
        _summary = @"";
    }
    return self;
}


@end
@implementation AddMeetInfoModel

- (id)init{
    if (self = [super init]) {
        _postKey = @"";
        _title = @"";
        _content = @"";
        _imageName = @"";
        _isSelected = NO;
        
    }
    return self;
}

@end
@implementation AddMeetTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.contentView.backgroundColor = [UIColor whiteColor];
        
//        UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 1, ScreenWidth, 0.5)];
//        BackGround16Color(headLineLB, @"#c8c7cc");
//        [self.contentView  addSubview:headLineLB];
        
        UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 71.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        self.titleLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, ScreenWidth-26-15, 26)];
        self.titleLB.backgroundColor = [UIColor clearColor];
        self.titleLB.font = YHUI_BOLD(16);
        self.titleLB.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLB];

        self.headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(16.5, CGRectGetMaxY(self.titleLB.frame)+6, 30, 30)];
        self.headImageView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.headImageView];
        
        
        self.subTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+7.5, CGRectGetMaxY(self.titleLB.frame)+4, ScreenWidth-90, 32)];
        self.subTitleLB.backgroundColor = [UIColor clearColor];
        self.subTitleLB.font = YHUI(13);
        self.subTitleLB.numberOfLines = 2;
        self.subTitleLB.lineBreakMode = NSLineBreakByWordWrapping;
        self.subTitleLB.textColor = [UIColor colorWithHexString:@"#535353"];
        [self.contentView addSubview:self.subTitleLB];
        
        self.selecedImageView = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.titleLB.frame), 25.5, 20, 20)];
        self.selecedImageView.contentMode = UIViewContentModeScaleAspectFit;
        self.selecedImageView.image = [UIImage imageNamed:@"select"];
        self.selecedImageView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.selecedImageView];
        
    }
    return self;
}
- (void)setIsSelected:(BOOL)isSelected
{
    if (isSelected == NO) {
        self.selecedImageView.image = [UIImage imageNamed:@"select"];
    }
    if (isSelected == YES) {
        self.selecedImageView.image = [UIImage imageNamed:@"selected-cur"];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
