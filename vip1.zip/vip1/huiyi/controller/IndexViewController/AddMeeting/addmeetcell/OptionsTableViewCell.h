//
//  OptionsTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol optionBtnClicked <NSObject>

- (void)optionBtnClicked:(UIButton *)btn;

@end

@interface OptionsInfoModel : NSObject
{
    BOOL _isSelected;
}
@property (nonatomic) BOOL isSelected;
@end
@interface OptionsTableViewCell : UITableViewCell
{
    NSArray *_optionsArr;
    UILabel *headLineLB;
    UILabel *endLineLB;
    BOOL _isSelected;
}
@property (nonatomic,strong) NSArray *optionsArr;
@property (nonatomic) id<optionBtnClicked> delegate;
@property (nonatomic) BOOL isSelected;
@end
