//
//  ContentTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-28.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol contentInfoDelegate <NSObject>

- (NSArray *)getImages;
- (void)showPhotos;


@end
@interface ContentTableViewCell : UITableViewCell<UITextViewDelegate>
{
    UIView *backView;
    UILabel *headLineLB;
    UILabel *endLineLB;
    UILabel *_placeholder;
    UIScrollView *_imageScrollView;
    UITextView *_detailsTextView;
    id<contentInfoDelegate>_delegate;
}
@property (nonatomic,strong)UIScrollView *imageScrollView;
@property (nonatomic,strong)UITextView *detailsTextView;
@property (nonatomic,strong)UILabel *placeholder;
@property (nonatomic)id<contentInfoDelegate>delegate;

@end
