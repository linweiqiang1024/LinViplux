//
//  DescripTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DescripTableViewCell : UITableViewCell
{
    void (^summaryBlock)( NSString *str);

}
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UILabel *contentLB;
@property (nonatomic,strong)UIImageView *goBtn;
@property (nonatomic,strong)UILabel *line;
@property (nonatomic,strong)NSString *content;
-(void)initContentLBWithComplentSummary:(void(^)( NSString *str))summary;
- (void)setContentLBWith:(NSString *)content;
@end
