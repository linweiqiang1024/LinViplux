//
//  CheckInfoTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SevenSwitch.h"


@protocol checkDelegate <NSObject>

- (void)checkSignUpInfo:(SevenSwitch*)btn;

@end
@interface CheckInfoTableViewCell : UITableViewCell
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)SevenSwitch*switchBtn;
@property (nonatomic,weak)id <checkDelegate>delegate;
@end
