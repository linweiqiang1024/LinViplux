//
//  SetTicketTypeTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SetTicketTypeTableViewCell.h"

@implementation SetTicketTypeTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}

- (void)createUI
{
    UILabel *LineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth-20, 2)];
    BackGround16Color(LineLB, @"#87d1eb");
    [self.contentView addSubview:LineLB];
    
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:@"票种类型名称(必填)"];
    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,6)];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,6)];
    //[tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(6,7)];
    //[tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(33, 14, ScreenWidth-20-66, 16)];
    _titleLB.font = YHUI(14);
    _titleLB.textColor = [UIColor colorWithHexString:@"#9b9b9b"];
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.attributedText = tittle_str;
    _titleLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_titleLB];
    
    _contentTF = [[UITextField alloc]initWithFrame:CGRectMake(33, CGRectGetMaxY(_titleLB.frame) + 5, ScreenWidth-20-66, 54)];
    _contentTF.placeholder = @"输入新票种类型名称";
    _contentTF.font = YHUI(16);
    _contentTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    _contentTF.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.contentView addSubview:_contentTF];
    
    SDToolBarOfHideView *toolBar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
    toolBar.SDdelegate = self;
    _contentTF.inputAccessoryView = toolBar;
}

- (void)hideKeyboard
{
    [_contentTF resignFirstResponder];
}

- (void)setFrame:(CGRect)frame
{
    frame.origin.x+=10 ;
    frame.size.width-=20;
    cellHeight = frame.size.height;
    [super setFrame:frame];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
