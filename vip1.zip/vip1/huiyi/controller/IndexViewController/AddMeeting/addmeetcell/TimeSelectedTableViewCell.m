//
//  TimeSelectedTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-11-5.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "TimeSelectedTableViewCell.h"

@implementation TimeSelectedTableViewCell
@synthesize timeLB = _timeLB,isEnd = _isEnd,isHead = _isHead,placeHolder = _placeHolder;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [self.contentView  addSubview:headLineLB];
        
        endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 40.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        self.timeLB = [[UILabel alloc]initWithFrame:CGRectMake(17, 0.5, 229, 40)];
        self.timeLB.backgroundColor = [UIColor clearColor];
        self.timeLB.font = YHUI(16);
        self.timeLB.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.timeLB];

        UIImageView *go = [[UIImageView alloc]initWithFrame:CGRectMake(self.contentView.size.width - 28, 12.5, 18, 18)];
        go.image = [UIImage imageNamed:@"less"];
        [self.contentView addSubview:go];
        
    }
    return self;
}
- (void)setIsHead:(BOOL)isHead
{
    if (isHead) {
        headLineLB.hidden = NO;
    }else{
        headLineLB.hidden = YES;
    }
}

- (void)setIsEnd:(BOOL)isEnd
{
    if (isEnd) {
        endLineLB.frame = CGRectMake(0, 40.5, ScreenWidth, 0.5);
    }else{
        endLineLB.frame = CGRectMake(14.5, 40.5, ScreenWidth, 0.5);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
