//
//  OptionTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "OptionTableViewCell.h"
#import "MeetTicketOptionModel.h"

@implementation OptionTableViewCell
@synthesize selectBtn = _selectBtn,swichBtn = _swichBtn,cleanBtn = _cleanBtn,titleLB = _titleLB,delegate = _delegate,cellTitle = _cellTitle;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor clearColor];
        UIImage *buttonImageselected = [UIImage imageNamed:@"option_bg"];
        buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImageselected.size.width/2) topCapHeight:floorf(buttonImageselected.size.height/2)];
        /*
        CGFloat top = 25; // 顶端盖高度
        CGFloat bottom = 25 ; // 底端盖高度
        CGFloat left = 10; // 左端盖宽度
        CGFloat right = 10; // 右端盖宽度
        UIEdgeInsets insets = UIEdgeInsetsMake(top, left, bottom, right);
        // 指定为拉伸模式，伸缩后重新赋值
        buttonImageselected = [buttonImageselected resizableImageWithCapInsets:insets resizingMode:UIImageResizingModeStretch];
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor colorWithPatternImage:buttonImageselected];*/
        [self createUI];
    }
    return self;
}

- (void)createUI
{
    UIImage *buttonImageselected = [UIImage imageNamed:@"option_bg"];
    buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImageselected.size.width/2) topCapHeight:floorf(buttonImageselected.size.height/2)];
    
    UIImage *buttonImageEnselected = [UIImage imageNamed:@"option_enselect_bg"];
    buttonImageEnselected = [buttonImageEnselected stretchableImageWithLeftCapWidth:floorf(buttonImageEnselected.size.width/2) topCapHeight:floorf(buttonImageEnselected.size.height/2)];
    
    _selectBtn = [UITicketOptionButton buttonWithType:UIButtonTypeCustom];
    _selectBtn.frame = CGRectMake(14, 23, ScreenWidth-28, 55);
    _selectBtn.titleLabel.font = YHUI(16);
    _selectBtn.adjustsImageWhenHighlighted = YES;
    _selectBtn.userInteractionEnabled = YES;
    _selectBtn.titleEdgeInsets = UIEdgeInsetsMake(_selectBtn.titleEdgeInsets.top, -(ScreenWidth-28)/2, _selectBtn.titleEdgeInsets.bottom, _selectBtn.titleEdgeInsets.right);
    [_selectBtn setBackgroundImage:buttonImageEnselected forState:UIControlStateNormal];
    [_selectBtn setBackgroundImage:buttonImageselected forState:UIControlStateSelected];
    [_selectBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [_selectBtn setTitleColor:[UIColor colorWithHexString:@"#373737"] forState:UIControlStateNormal];
    [_selectBtn addTarget:self action:@selector(btnclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:_selectBtn];
    
    _swichBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _swichBtn.frame = CGRectMake(ScreenWidth-28-95, 12.5, 72, 30);
    _swichBtn.adjustsImageWhenHighlighted = NO;
    _swichBtn.backgroundColor = [UIColor clearColor];
    _swichBtn.hidden = !_selectBtn.selected ;
    [_swichBtn addTarget:self action:@selector(btnsclick:) forControlEvents:UIControlEventTouchUpInside];
    [_selectBtn addSubview:_swichBtn];
    
    _cleanBtn = [UICleanOptionButton buttonWithType:UIButtonTypeCustom];
    _cleanBtn.frame = CGRectMake(ScreenWidth-28-10, 00, 50, 50);
    _cleanBtn.adjustsImageWhenHighlighted = YES;
    _cleanBtn.backgroundColor = [UIColor clearColor];
    [_cleanBtn setImage:[UIImage imageNamed:@"ticket_clean_btn_bg"] forState:UIControlStateNormal];
    [_cleanBtn addTarget:self action:@selector(cleanBtnclick:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:_cleanBtn];
}

- (void)setCellTitle:(NSString *)cellTitle
{
    [_selectBtn setTitle:cellTitle forState:UIControlStateNormal];
    [_selectBtn setTitle:cellTitle forState:UIControlStateSelected];
}

- (void)setIndex:(NSInteger)index
{
    if (index < 2) {
        [_swichBtn setBackgroundImage:[UIImage imageNamed:@"en_btn_bg"] forState:UIControlStateNormal];
        [_swichBtn setBackgroundImage:[UIImage imageNamed:@"en_btn_bg"] forState:UIControlStateSelected];

    }
    else {
        [_swichBtn setImage:[UIImage imageNamed:@"on_btn_bg"] forState:UIControlStateSelected];
        [_swichBtn setImage:[UIImage imageNamed:@"off_btn_bg"] forState:UIControlStateNormal];
    }
}

- (void)btnclick:(UIButton *)btn
{
    [_delegate selectOption:btn];
}

- (void)btnsclick:(UIButton *)btn
{
    if (_selectBtn.selected == YES) {
        [_delegate sureOption:btn];
    }
}

- (void)cleanBtnclick:(UIButton *)btn
{
    [_delegate cleanOption:btn];
}

/*
- (void)setFrame:(CGRect)frame
{
    frame.origin.y -=23;
    frame.size.height-=23;
    frame.origin.x+=14 ;
    frame.size.width-=28;
    [super setFrame:frame];
}*/

- (void)awakeFromNib {
    [super awakeFromNib];
    
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
