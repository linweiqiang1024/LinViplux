//
//  DescripTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "DescripTableViewCell.h"

@implementation DescripTableViewCell
@synthesize contentLB = _contentLB;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    _line = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth-20 - 40, 0.5)];
    BackGround16Color(_line, @"#c8c7cc");
    [self.contentView  addSubview:_line];
    
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:@"票种类型说明"];
    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,6)];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,6)];
    //    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(6,7)];
    //    [tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(33, 14, ScreenWidth-20-66, 16)];
    _titleLB.font = YHUI(14);
    _titleLB.textColor = [UIColor colorWithHexString:@"#9b9b9b"];
    
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.attributedText = tittle_str;
    _titleLB.textAlignment = NSTextAlignmentLeft;
    [self.contentView addSubview:_titleLB];
    
    
    
    _goBtn = [[UIImageView alloc]init];
    _goBtn.center = CGPointMake(ScreenWidth-20-30, CGRectGetMaxY(_titleLB.frame)+(CGRectGetMinX(_contentLB.frame)-CGRectGetMaxY(_titleLB.frame))/2);
    _goBtn.image = [UIImage imageNamed:@"mine_right_go"];
    _goBtn.size = CGSizeMake(10, 17);
    [self.contentView addSubview:_goBtn];
    
    
    
}
- (void)setContentLB:(UILabel *)contentLB
{
    [_contentLB removeFromSuperview];
    _contentLB = [[UILabel alloc]initWithFrame:CGRectMake(33, CGRectGetMaxY(_titleLB.frame) + 27, ScreenWidth-20-66, 16)];
    _contentLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    _contentLB.font = YHUI(16);
    _contentLB.numberOfLines = 0;
    _contentLB.lineBreakMode = NSLineBreakByWordWrapping;
    [self.contentView addSubview:_contentLB];

}
- (void)setContentLBWith:(NSString *)content
{
     CGSize size = [content sizeWithFont:YHUI(16) constrainedToSize:CGSizeMake(ScreenWidth-20-66, 500) lineBreakMode:NSLineBreakByWordWrapping];
    _contentLB.size = CGSizeMake(_contentLB.size.width, size.height);
    _goBtn.center = CGPointMake(_goBtn.center.x, _contentLB.center.y-28);

}
-(void)initContentLBWithComplentSummary:(void(^)( NSString *str))summary{
    summaryBlock = [summary copy];
    }

- (void)setFrame:(CGRect)frame
{
    frame.origin.x+=10 ;
    frame.size.width-=20;
    [super setFrame:frame];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
