//
//  EndTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/1/21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "EndTableViewCell.h"

@implementation EndTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    

    UILabel *LineLB = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, ScreenWidth-40-20, 0.5)];
    BackGround16Color(LineLB, @"#c8c7cc");
    [self.contentView addSubview:LineLB];
    
    UIImage *buttonImageselected = [UIImage imageNamed:@"new_07"];
    buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImageselected.size.width/2) topCapHeight:floorf(buttonImageselected.size.height/2)];
    
    _btn = [UIButton buttonWithType:UIButtonTypeCustom];
    _btn.frame = CGRectMake((ScreenWidth-20-180)/2, 12, 180, 36);
    [_btn setTitle:@"完成" forState:UIControlStateNormal];
    [_btn setTitleColor:[UIColor colorWithHexString:@"#1b9ecc"] forState:UIControlStateNormal];
    _btn.titleLabel.font = YHUI(16);
    [_btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [_btn setBackgroundImage:buttonImageselected forState:UIControlStateNormal];
    [self.contentView addSubview:_btn];
    
    UIImageView *endImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 65, ScreenWidth-20, 8)];
    endImageView.image = [UIImage imageNamed:@"bottom_bg"];
    [self.contentView addSubview:endImageView];
    
    
}
- (void)btnClick:(UIButton *)btn
{
    [_delegate completeBtnClicked:btn];

}
- (void)setFrame:(CGRect)frame
{
    frame.origin.x += 10;
    frame.size.width -= 20;
    [super setFrame:frame];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
