//
//  TicketTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/1/20.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol addOtherMeetingDelegate <NSObject>

- (void)meetTicketEidt:(UIButton *)btn;
- (void)meetTicketCleaned:(UIButton *)btn;

@end

@interface TicketTableViewCell : UITableViewCell
{
    UIImageView *bgImageView;
}
@property (nonatomic,strong)UILabel *titleLB;//票名
@property (nonatomic,strong)UILabel *costLB;//票价
@property (nonatomic,strong)UILabel *endTimeLB;//结束时间;
@property (nonatomic,strong)UILabel *introLB;//简介
@property (nonatomic,strong)UIButton *eidtBtn;
@property (nonatomic,strong)UIButton *cleanBtn;
@property (nonatomic,strong)UIImageView *hideImageView;
@property (nonatomic,weak)id<addOtherMeetingDelegate>delegate;
- (void)setIntroHeight:(NSString *)content;
@end
