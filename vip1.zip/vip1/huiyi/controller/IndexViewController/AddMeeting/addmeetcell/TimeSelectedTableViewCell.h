//
//  TimeSelectedTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-11-5.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeSelectedTableViewCell : UITableViewCell
{
    BOOL _isHead;
    BOOL _isEnd;
    NSString *_placeHolder;
    UILabel *_timeLB;
    UILabel *headLineLB;
    UILabel *endLineLB;
}
@property (nonatomic,strong) UILabel *timeLB;
@property (nonatomic,strong) NSString *placeHolder;
@property (nonatomic) BOOL isHead;
@property (nonatomic) BOOL isEnd;
@end
