//
//  TFTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RegistTextField.h"
@interface TFTableViewCell : UITableViewCell
{
    RegistTextField * _contentTF;
    BOOL _isHead;
    BOOL _isEnd;
    UILabel *headLineLB;
    UILabel *endLineLB;
}
@property (nonatomic,strong) RegistTextField *contentTF;
@property (nonatomic) BOOL isHead;
@property (nonatomic) BOOL isEnd;

@end
