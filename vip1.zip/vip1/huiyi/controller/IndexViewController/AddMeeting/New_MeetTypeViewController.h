//
//  New_MeetTypeViewController.h
//  huiyi
//
//  Created by 林伟强 on 16/7/28.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "FatherViewController.h"

@interface New_MeetTypeViewController : FatherViewController

@property (nonatomic)BOOL isMyPublish;

@end
