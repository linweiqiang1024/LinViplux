//
//  UIContentView_05.h
//  huiyi
//
//  Created by songhongshuai on 15/1/9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UICostTypeButton.h"
@interface UIContentView_05 : UIView
@property(nonatomic,strong) UILabel * nameLB;
@property(nonatomic,strong) UICostTypeButton * costBtn;
@end
