//
//  New_MeetTypeTableViewCell.h
//  huiyi
//
//  Created by 林伟强 on 16/7/29.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^SendViewBlock)(NSInteger sender, NSString *text);
typedef void (^SendTextFieldBlock)(id sender);
typedef void (^SendButtonBlock)(id sender);
typedef void (^SendPanBlock)(UIPanGestureRecognizer *pan, CGFloat y);

@interface New_MeetTypeTableViewCell : UITableViewCell

@property (nonatomic, strong) UIButton    *deleteButton;
@property (nonatomic, strong) UIView      *myView;

@property (nonatomic, strong) UIImageView *myImageView;
@property (nonatomic, strong) UITextField *myTextField;
@property (nonatomic, strong) UIImageView *bottomLineView;
@property (nonatomic, strong) UILabel     *addTagLabel;
@property (nonatomic, strong) UIButton    *myButton;
@property (nonatomic, copy) SendViewBlock      sendBlock;
@property (nonatomic, copy) SendTextFieldBlock sendTextFieldBlock;
@property (nonatomic, copy) SendButtonBlock    sendButtonBlock;
@property (nonatomic, copy) SendPanBlock       sendPanBlock;

@property (nonatomic, assign) NSInteger    count;

- (void)reloadCellWith:(NSInteger)index;

@end
