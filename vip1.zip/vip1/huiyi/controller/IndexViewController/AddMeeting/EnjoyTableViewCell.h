//
//  EnjoyTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EnjoyTableViewCell : UITableViewCell
{
    UIScrollView *scrollView;
    NSArray *_enjoyUsers;
}
@property (nonatomic,strong)NSArray *enjoyUsers;
@end
