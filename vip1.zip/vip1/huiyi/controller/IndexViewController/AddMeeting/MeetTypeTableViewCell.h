//
//  MeetTypeTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeetTypeInfo : NSObject<UITextFieldDelegate>

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *subtitle;
@property (nonatomic, strong) UIImage *headImage;

@end
@interface MeetTypeTableViewCell : UITableViewCell

{
    UIImageView *_headImageView;
    UILabel *_titleLB;
    UILabel *_subTitleLB;
    UIImageView *_goImageView;
}

@property (nonatomic) BOOL isHead;
@property (nonatomic, strong) UIImageView *headImageView;
@property (nonatomic, strong) UILabel *titleLB;
@property (nonatomic, strong) UILabel *subTitleLB;
@property (nonatomic, strong) UIImageView *goImageView;

@end
