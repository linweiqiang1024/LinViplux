//
//  MeetTypeTableHeaderView.h
//  huiyi
//
//  Created by 林伟强 on 16/7/29.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MeetTypeTableHeaderViewDelegate <NSObject>

- (void)endEdit;

@end

@interface MeetTypeTableHeaderView : UIView

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray   *dataSource;
@property (nonatomic, strong) NSString         *title;
@property (nonatomic, strong) UIImageView      *bottomLineView;
@property (nonatomic, assign) BOOL              isType;

@property (nonatomic, weak)   id <MeetTypeTableHeaderViewDelegate> delegate;

@end
