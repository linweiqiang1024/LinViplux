//
//  PartyViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//


#import "AddMeetInfoContentTypeModel.h"
#import "AddMeetTableViewCell.h"
#import "PartyViewController.h"
#import "AddMeetSectionBtn.h"
#import "TFTableViewCell.h"
#import "MHShortCut.h"
#import "GTMBase64.h"
#import "MWCommon.h"
#import "DBManager.h"
#import "SevenSwitch.h"
#import "HPGrowingTextView.h"
#import "LoginViewController.h"
#import "MinePutOutViewController.h"
#import "SignUpFieldsModel.h"
#import "MWPhotoBrowser.h"
#import "SDTimeActiontSheet.h"
#import "ContentTableViewCell.h"
#import "TimeSelectedTableViewCell.h"
#import "AddMeetOpenInfoTableViewCell.h"


@interface PartyViewController ()<UITableViewDataSource,UITableViewDelegate,SDTimeActionSheetDelegate,UITextViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate,UITextFieldDelegate,UIAlertViewDelegate,MWPhotoBrowserDelegate,HPGrowingTextViewDelegate>
{
    NSMutableDictionary *_fieldArr;// 记录所有选择类型的状态  用于上传接口
    NSMutableDictionary *_postDic;
    NSMutableArray *_signUpFiledsArr;//报名字段（按钮的所有信息）
    NSMutableArray *_pluginInfoArr;//插件字段 （所有信息 见model）
    NSMutableArray *_meetBackInfoArr;//返回信息插件 和插件信息用的同一个model类
    NSMutableArray *_moreInfoDataArr;//记录tableview的所有section的信息
    NSMutableArray *_contentInfoDataArr;//记录基础字段的所有信息（会议主题 开会时间 。。。。。图文）
    NSMutableDictionary *_summaryDic;
    UITableView *_partyTableView;
    NSIndexPath *contentIndex;
    NSIndexPath *detailIndex;
    NSIndexPath *_indexpath;//当前编辑的位置
    SDTimeActiontSheet * _dateActionSheet;
    UITextView *_detailsTextView;//图文
    UILabel *_placeholder;
    UIScrollView *_imageScrollView;
    CGFloat imageHeight;
    NSMutableDictionary *imageDic;
    NSMutableDictionary *dbDic;
    NSInteger imageIndex;//要删除的图片 序号
    int _indexRow;//section = 0  记录row 选择的时间
    int _section;//
    BOOL IMAGES;
    BOOL _textviewEdit;
    BOOL _isSection;//报名字段选择状态记录器
    BOOL _isCell;

    BOOL _keyboardShow;//系统键盘 YES显示  NO收回
    BOOL _contentBeginEdit;//系统键盘 YES显示  NO收回
    BOOL _fristCome;
    BOOL _haveContent;
    int optionsHeight;//报名字段行高  根据字段多少控制高度
    NSArray *optionsArr;//报名字段
    NSMutableArray *imageArr;//图片
    NSMutableArray *imageUrlArr;//图片url
    NSString *_imageStr;//base64 图片
    
    CGSize _keySize;//键盘大小
    CGPoint textviewPoint;
    CGFloat contentDefHeight;
    UIToolbar *toolBar;
    UISegmentedControl *_segmentedControl;

}
@property (nonatomic,strong)SDTimeActiontSheet *dateActionSheet;
@property (nonatomic,strong)NSMutableArray *pluginInfoArr;
@property (nonatomic,strong)NSMutableArray *meetBackInfoArr;
@property (nonatomic,strong)NSMutableArray *moreInfoDataArr;
@property (nonatomic,strong)NSMutableArray *contentInfoDataArr;

@end

@implementation PartyViewController

- (void)createNavRightBtn
{
//    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
//    rightbtn.frame = CGRectMake(240, _navheight+4, 80, 40);
//    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
//    [rightbtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    
//    rightbtn.titleLabel.font = YHUI(16);
////    [rightbtn setTitle:@"创建" forState:UIControlStateNormal];
//    [self.view addSubview:rightbtn];
    
}
- (void)ReturnBtn
{
    [self creatPostData];
    [_postDic setObject:[imageDic JSONString] forKey:@"pic"];
    [_postDic setObject:[_summaryDic objectForKey:@"summary"] forKey:@"summary"];
    [_postDic setObject:[_fieldArr JSONString] forKey:@"fieldArr"];
    [_postDic setObject:[NSString stringWithFormat:@"%d",(_type+1)] forKey:@"type"];
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type+1)]];
    [[DBManager sharedInstance] insertDataToPublicDB:[_postDic JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type+1)]];
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (alertView.tag == 2501||alertView.tag == 2502) {
        
    }
    if (alertView.tag == 10000) {
        if (buttonIndex == 0) {
            NSLog(@"取消");
            
        }
        if (buttonIndex == 1) {
            LoginViewController *loginVC = [[LoginViewController alloc]init];
            UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVC];
            loginVC.fromSignVC = YES;
            NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
            if (!LoginCompanyArray.count)
            {
                loginVC.isPush = YES;
            }
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
    }

}
- (void)rightBtnClicked
{
   
    [self creatPostData];
    if ([[_postDic objectForKey:@"title"] length]==0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议主题不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }else if ([[_postDic objectForKey:@"title"] length]<5){
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议主题多于5个汉字" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    
    }
    else if ([[_postDic objectForKey:@"begin_time"] length]==0){
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议开始时间不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];

    }else if ([[_postDic objectForKey:@"location"] length]==0){
        if(_type == 0)
        {
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动地址不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }else{
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议地址不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
    }
    else{
        
        [_postDic setObject:[imageDic JSONString] forKey:@"pic"];
        if ([[_summaryDic objectForKey:@"summary"] length]<10) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请输入更多详情内容" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            av.tag = 2001;
            [av show];
            return;
        }
      
        
        [_postDic setObject:[_summaryDic objectForKey:@"summary"] forKey:@"summary"];
        [_postDic setObject:[_fieldArr JSONString] forKey:@"fieldArr"];
        [_postDic setObject:[NSString stringWithFormat:@"%d",(_type+1)] forKey:@"type"];
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]!=0) {
            [_postDic setObject:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]forKey:@"user_id"];
            [[Dialog Instance] showProgress:self];
            [MyDataService postAddMeeting:_postDic callback:^(id data) {
                NSLog(@"%@",data);
                [[Dialog Instance]hideProgress];
                if([[data objectForKey:@"code"]isEqualToString:@"200"]||[[data objectForKey:@"code"] objectForKey:@"201"])
                {
                    [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type+1)]];
                    MinePutOutViewController *outView = [[MinePutOutViewController alloc]init];
                    outView.FROMADDVC = YES;
                    outView.meetID = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                    outView.status = @"0";
                    [[NSNotificationCenter defaultCenter]postNotificationName:@"refreashGetGruopData" object:nil];
                    [self.navigationController pushViewController:outView animated:YES];
                    
                }
            }];
        }else{
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"是否登录会议邦?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            alertView.tag = 10000;
            [alertView show];
        }
    }
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardShow:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    [MobClick beginLogPageView:@"PartyViewController"];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if( self.dateActionSheet.isShow == YES){
        _section = MAXFLOAT;
        _isCell = NO;
        _isSection = YES;
        [self.dateActionSheet tappedCancel];
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [MobClick endLogPageView:@"PersonalInfoController"];
}
#pragma mark - keyboard  notification
- (void)keyboardHide:(NSNotification*)notification {
    _detailsTextView.contentInset=UIEdgeInsetsZero;
    _keyboardShow = NO;
    if (_contentBeginEdit == YES) {
        toolBar.frame = CGRectMake(0,ScreenHeight,320,44);
    }
    [UIView animateWithDuration:0.01 animations:^{
        
        _partyTableView.frame = CGRectMake(0, _partyTableView.frame.origin.y, ScreenWidth, _partyTableView.bounds.size.height+_keySize.height);
    }];
}
- (void)creatToolBar
{
//    if (!toolBar) {
        toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0,ScreenHeight,320,44)];
        toolBar.barStyle = UIBarStyleDefault;
    toolBar.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
        UIBarButtonItem *hiddenButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"确定" style:UIBarButtonItemStyleBordered target:self action:@selector(ShowPrevious)];
        
        UIBarButtonItem *spaceButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem: UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        toolBar.items = [NSArray arrayWithObjects:spaceButtonItem,hiddenButtonItem,nil];
        [self.view addSubview:toolBar];
//    }else{
//        toolBar.frame = CGRectMake(0,ScreenHeight-hight-44,320,44);
//    }
    
    
}
- (void)ShowPrevious
{
    [self.view endEditing:YES];
}
- (void)keyboardShow:(NSNotification*)notification {
    NSValue *keyboardRectAsObject=[[notification userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect;
    [keyboardRectAsObject getValue:&keyboardRect];
    
    NSDictionary *userInfo = [notification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize size = [aValue CGRectValue].size;
    
    if (size.height != _keySize.height) {
        _partyTableView.frame = CGRectMake(0, _partyTableView.frame.origin.y, ScreenWidth, _partyTableView.bounds.size.height+_keySize.height);
    }
    _keySize = size;
    _partyTableView.frame = CGRectMake(0, _partyTableView.frame.origin.y, ScreenWidth, ScreenHeight -64-_keySize.height);
    //获取当前cell在tableview中的位置

    [_partyTableView scrollToRowAtIndexPath:_indexpath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    if(_contentBeginEdit == YES)
        [UIView animateWithDuration:0.01 animations:^{
        toolBar.frame = CGRectMake(0,ScreenHeight-size.height-44,320,44);
        
    }];
    //_detailsTextView.contentInset=UIEdgeInsetsMake(0, 0,keyboardRect.size.height, 0);
    _keyboardShow = YES;
    if( self.dateActionSheet.isShow == YES){
        _section = MAXFLOAT;
        _isCell = NO;
        _isSection = YES;
        [self.dateActionSheet tappedCancel];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatRightNav];
    _fristCome = YES;
    contentDefHeight = 130.5;
    dbDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    imageArr = [[NSMutableArray alloc]initWithCapacity:0];
    imageUrlArr = [[NSMutableArray alloc] initWithCapacity:0];
    _summaryDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [_summaryDic setObject:@"" forKey:@"summary"];
    imageDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [self createNavRightBtn];
    
    int maxImageCount = [[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"type_%d_imageCount",_type+1] ] intValue];
    if (maxImageCount>0) {
        [imageDic addEntriesFromDictionary:[[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]] JSONValue]];
        for (int imageId = 0; imageId < maxImageCount; imageId++) {
            NSString *key = [NSString stringWithFormat:@"pic_%d_%d.png",_type+1,imageId +1];
            UIImage *image = [self getImageFormDocument:key];
            [imageArr addObject:image];
            
        }
    }
    
    _isSection = NO;//报名字段选择状态记录器
    _isCell = NO;
    _postDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    // Do any additional setup after loading the view.
    self.titlelabel.text = _nav_title;
    _fieldArr = [[NSMutableDictionary alloc]initWithCapacity:0];
    dbDic = [[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"meeting_type_%d",_type+1]] JSONValue];
    UIView * tabelheadview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 49.5+11.5)];
    tabelheadview.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    
    UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 49, ScreenWidth, 0.5)];
    BackGround16Color(headLineLB, @"#c8c7cc");
    [tabelheadview  addSubview:headLineLB];
    
//    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 60.5, ScreenWidth, 0.5)];
//    BackGround16Color(endLineLB, @"#c8c7cc");
//    [tabelheadview  addSubview:endLineLB];
    
//    UILabel *mid = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLineLB.frame), ScreenWidth, 2)];
//    BackGround16Color(mid, @"#efeff4");
//    [tabelheadview  addSubview:mid];
    UIView * PromptView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 49)];
    BackGround16Color(PromptView, @"#eefbfe")
    [tabelheadview addSubview:PromptView];
    
    UILabel *headLB = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, ScreenWidth-20, 49)];
    headLB.backgroundColor = [UIColor colorWithHexString:@"#eefbfe"];
    headLB.text = @"提示：发布违法，反动互动信息或冒用他人、组织名义发起互动将依据记录提交公安机关处理。";
    headLB.font = YHUI(14);
    headLB.lineBreakMode = NSLineBreakByWordWrapping;
    headLB.numberOfLines = 0;
    [PromptView addSubview:headLB];

    _partyTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT) style:UITableViewStyleGrouped ];
    _partyTableView.backgroundColor = [UIColor clearColor];
    _partyTableView.dataSource = self;
    _partyTableView.delegate = self;
    _partyTableView . sectionFooterHeight = 11.5;
    _partyTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_partyTableView];
    _partyTableView.tableHeaderView = tabelheadview;
    [self initData];
    [self creatToolBar];

}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if( self.dateActionSheet.isShow == YES){
        _section = MAXFLOAT;
        _isCell = NO;
        _isSection = YES;
        [self.dateActionSheet tappedCancel];
    }
}
- (void)creatPostData//组织上传的数据
{
    switch (_type) {
        case 0:
        {
            NSArray *keys = @[@"nickname",@"phone",@"email"];
            for (SignUpFieldsModel *info in _signUpFiledsArr) {
                int index = [_signUpFiledsArr indexOfObject:info];
                [_fieldArr setObject:@"1" forKey:[keys objectAtIndex:index]];
            }
        }
            break;
        case 1:
        case 2:
        case 3:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"remarks"];
            for (SignUpFieldsModel *info in _signUpFiledsArr) {
                int index = [_signUpFiledsArr indexOfObject:info];
                if (info.selected) {
                    [_fieldArr setObject:@"1" forKey:[keys objectAtIndex:index]];
                    
                }else{
                    [_fieldArr setObject:@"0" forKey:[keys objectAtIndex:index]];
                }
            }
        }
            
            break;
        case 4:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"remarks"];
            for (SignUpFieldsModel *info in _signUpFiledsArr) {
            
                int index = [_signUpFiledsArr indexOfObject:info];
                if (info.selected) {
                    [_fieldArr setObject:@"1" forKey:[keys objectAtIndex:index]];
                    
                }else{
                    [_fieldArr setObject:@"0" forKey:[keys objectAtIndex:index]];
                }
            }

            
        }
            break;
        case 5:
        case 6:{
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"major",@"remarks"];
            for (SignUpFieldsModel *info in _signUpFiledsArr) {
                int index = [_signUpFiledsArr indexOfObject:info];
                if (info.selected) {
                    [_fieldArr setObject:@"1" forKey:[keys objectAtIndex:index]];
                    
                }else{
                    [_fieldArr setObject:@"0" forKey:[keys objectAtIndex:index]];
                }
            }
            
        }
            break;
        default:
            break;
    }

    for (AddMeetInfoContentTypeModel *info in self.contentInfoDataArr) {
        if (info.iType == TimeInput) {
            if(info.time.length!=0){
                [_postDic setObject:info.time forKey:info.postKey];
            }
        }else{
            if (info.content.length!=0) {
                [_postDic setObject:info.content forKey:info.postKey];
            }
        }
        
    }
    for (AddMoreMeetInfoModel *moreInfo in self.moreInfoDataArr) {
        if ([moreInfo.postKey isEqualToString:@"location"]) {
            [_postDic setObject:moreInfo.title forKey:moreInfo.postKey];
           
        }
        if([moreInfo.postKey isEqualToString:@"partake_end_time"]){
            [_postDic setObject:moreInfo.time forKey:moreInfo.postKey];
            
        }
        if ([moreInfo.postKey isEqualToString:@"openstatus"]) {
            if (moreInfo.isSelected) {
                [_postDic setObject:@"0" forKey:moreInfo.postKey];
            }else{
                [_postDic setObject:@"1" forKey:moreInfo.postKey];
            }
        }
        if ([moreInfo.postKey isEqualToString:@"personal_data_sw"]) {
            if (moreInfo.isSelected) {
                [_postDic setObject:@"1" forKey:moreInfo.postKey];
            }else{
                [_postDic setObject:@"0" forKey:moreInfo.postKey];
            }
        }


        
    }

//    accommodationInfo.postKey = @"houseinfo";
//    trafficInfo.postKey = @"goback";
//    plug1Info.postKey = @"meetingAgenda";
//    plug2Info.postKey = @"trafficGuide";
//    plug3Info.postKey = @"participants";
//    plug4Info.postKey = @"meetingInfo";
//    plug5Info.postKey = @"meetingService";
//    plug6Info.postKey = @"feedback";
//    plug7Info.postKey = @"projectDocking";
    for (AddMeetInfoModel *info in self.meetBackInfoArr) {
        if (info.isSelected) {
            [_fieldArr setObject:@"1" forKey:info.postKey];
            
        }else{
            [_fieldArr setObject:@"0" forKey:info.postKey];
        }
    }
    for (AddMeetInfoModel *info in self.pluginInfoArr) {
        if (info.isSelected) {
            [_fieldArr setObject:@"1" forKey:info.postKey];
            
        }else{
            [_fieldArr setObject:@"0" forKey:info.postKey];
        }
    }
}

#pragma mark -
#pragma mark UITableViewDataSource and UITableViewDelegate Methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _moreInfoDataArr.count+1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == 0) {
        return self.contentInfoDataArr.count;//基本信息
    }
    else
    {
        AddMoreMeetInfoModel *info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:section-1];
        if (info.isSelected == YES) {
            switch (_type) {
//                case 2:
//                case 4:
//                    if (section == 4) {
//                        return self.meetBackInfoArr.count;//回执
//                    }
//                    if (section == 5) {
//                        return self.pluginInfoArr.count;//插件类型
//                    }
//                    break;
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                    if (section == 5) {
                        return self.meetBackInfoArr.count;//回执
                    }
                    if (section == 6) {
                        return self.pluginInfoArr.count;//插件类型
                    }
                default:
                    break;
            }
            
            
        }
    }
    return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (_type) {
        case 0:{
            if (indexPath.section == 0) {
                return 41;
            }else{
                return 72;
            }
        }
            break;
        
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:{
            if (indexPath.section == 0) {
                return 41;
            }else{
                return 72;
            }
            break;
        }
        default:
            break;
    }
//    if (indexPath.section == 0) {
//        return 41;
//    }
    return 72;
}
- (void)showActiom:(AddMeetSectionBtn *)btn
{
    
    if (NO == self.dateActionSheet.isShow) {
        self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
        self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    _isSection = YES;
    _isCell = NO;
    _section = btn.tag - 300 -1;
    [self.dateActionSheet showInView:self.view];
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
#pragma mark
#pragma mark --SDTimeActionSheetDelegate
- (void)cancelBtnClicked
{
    
}
- (void)returnData:(NSDate*)date Time:(NSTimeInterval)time
{
    if (_isSection == YES) {
        for (AddMeetInfoContentTypeModel *infos  in  self.contentInfoDataArr) {
            if ([infos.postKey isEqualToString:@"begin_time"]) {
                if ([infos.time doubleValue]>time) {
                    UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"报名截止时间必须晚于开始时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    av.tag = 2550;
                    [av show];
                    return;
                }
            }
            if ([infos.postKey isEqualToString:@"end_time"]) {
                if ([infos.time doubleValue]<time&&infos.time.length != 0) {
                    UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"报名截止时间必须早于结束时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                    av.tag = 2551;
                    [av show];
                    return;
                }
            }

        }

        AddMoreMeetInfoModel *info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:_section];
        info.title = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
        info.time = [NSString stringWithFormat:@"%0.f",time];
        info.isSelected = YES;
        [self.moreInfoDataArr replaceObjectAtIndex:_section withObject:info];
        [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"%@_type%d",info.postKey,_type+1]];
        [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%f",time] valueKey:[NSString stringWithFormat:@"%@_type%d",info.postKey,_type+1]];
    }
    
    if (_isCell == YES) {
        AddMeetInfoContentTypeModel *infos = [self.contentInfoDataArr objectAtIndex:_indexRow];
        if ([infos.postKey isEqualToString:@"begin_time"]) {
            if ([self currentTime]>time) {
                UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"开始时间必须大于当前时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                av.tag = 2501;
                [av show];
                return;
            }else{
                infos.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
                infos.time = [NSString stringWithFormat:@"%0.f",time];
                infos.iChange = @"1";
                [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"%@_type%d",infos.postKey,_type+1]];
                [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%f",time] valueKey:[NSString stringWithFormat:@"%@_type%d",infos.postKey,_type+1]];

            }
            
        }
        if ([infos.postKey isEqualToString:@"end_time"]) {
            for (AddMeetInfoContentTypeModel *model in self.contentInfoDataArr) {
                if ([model.postKey isEqualToString:@"begin_time"]) {
                    NSLog(@"%lld\n%f",[model.time longLongValue],time);
                    if ([model.time longLongValue]>time) {//开始时间大于结束时间
                        
                        UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"结束时间必须大于开始时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
                        av.tag = 2502;
                        [av show];
                        return;
                    }else{
                        infos.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
                        infos.time = [NSString stringWithFormat:@"%0.f",time];
                        
                        infos.iChange = @"1";
                        [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"%@_type%d",infos.postKey,_type+1]];
                        [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%f",time] valueKey:[NSString stringWithFormat:@"%@_type%d",infos.postKey,_type+1]];
                    }
                }
            }
        }

        [self.contentInfoDataArr replaceObjectAtIndex:_indexRow withObject:infos];
    }
    [_partyTableView reloadData];

}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [tableView endEditing:YES];
    if (indexPath.section == 0) {
        AddMeetInfoContentTypeModel *infos = [self.contentInfoDataArr objectAtIndex:indexPath.row];
        if (infos.iType == TimeInput){
            if (YES == self.dateActionSheet.isShow)
            {
                
            }
            if (NO == self.dateActionSheet.isShow) {
                _isCell = YES;
                _isSection = NO;
                self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 MeetingType:(_type+1) PostKey:infos.postKey delegate:self];
                self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
            }
            _indexRow = indexPath.row;
            [self.dateActionSheet showInView:self.view];
            return;
        }
    }
    
    AddMeetInfoModel *info ;
    switch (_type) {
        case 0:
            break;
        case 2:
        case 4:
        {
            if (indexPath.section == 5) {
                info = [self.meetBackInfoArr objectAtIndex:indexPath.row];
            }
            if (indexPath.section == 6 ) {
                info = [self.pluginInfoArr objectAtIndex:indexPath.row];
            }
            info.isSelected = !info.isSelected;
            if (indexPath.section == 5) {
                [self.meetBackInfoArr replaceObjectAtIndex:indexPath.row withObject:info];
            }
            if (indexPath.section == 6 ) {
                [self.pluginInfoArr replaceObjectAtIndex:indexPath.row withObject:info];
            }
            [tableView reloadData];
        }
            break;
        case 1:
        case 3:
        case 5:
        case 6:{
        
            if (indexPath.section == 5) {
                info = [self.meetBackInfoArr objectAtIndex:indexPath.row];
            }
            if (indexPath.section == 6 ) {
                info = [self.pluginInfoArr objectAtIndex:indexPath.row];
            }
            info.isSelected = !info.isSelected;
            if (indexPath.section == 5) {
                [self.meetBackInfoArr replaceObjectAtIndex:indexPath.row withObject:info];
            }
            if (indexPath.section == 6 ) {
                [self.pluginInfoArr replaceObjectAtIndex:indexPath.row withObject:info];
            }
            [tableView reloadData];
        }
            break;
        default:
            break;
    }
}


- (void)textViewDidChange:(UITextView *)textView
{
    
    if (textView.text.length == 0) {
        _haveContent = NO;
        _placeholder.hidden = NO;
    }else{
        _placeholder.hidden = YES;
        _haveContent = YES;
    }
    [_summaryDic setObject:textView.text forKey:@"summary"];
    for (AddMoreMeetInfoModel *info in self.moreInfoDataArr) {
        if ([info.postKey isEqualToString:@"summary"]) {
            [_summaryDic setObject:textView.text forKey:info.postKey];
            info.summary = textView.text;

        }
    }
//        [_partyTableView reloadData];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AddMeetInfoModel *info ;
    switch (_type) {
//        case 2:
//        case 4:
//            if (indexPath.section == 4) {//刷新插件和回执的数据源
//                info = [self.meetBackInfoArr objectAtIndex:indexPath.row];
//            }
//            if (indexPath.section == 5 ) {
//               info = [self.pluginInfoArr objectAtIndex:indexPath.row];
//            }
//            break;
        case 1:
        case 2:
        case 4:
        case 3:
        case 5:
        case 6:
            if (indexPath.section == 5) {//刷新插件和回执的数据源
                NSLog(@"%d",indexPath.row);
                info = [self.meetBackInfoArr objectAtIndex:indexPath.row];
            }
            if (indexPath.section == 6 ) {
                info = [self.pluginInfoArr objectAtIndex:indexPath.row];
            }
        default:
            break;
    }
    if (indexPath.section == 0) {
        AddMeetInfoContentTypeModel *infos = [self.contentInfoDataArr objectAtIndex:indexPath.row];
        if (infos.iType == TextInputView) {
             static NSString *CellIdentifier = @"ContentTableViewCell";
            ContentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[ContentTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            contentIndex = indexPath;
            cell.detailsTextView.delegate = self;
            if ([[dbDic objectForKey:info.postKey] length]!=0) {
                cell.detailsTextView.text = [dbDic objectForKey:info.postKey];
            }
            
        
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;

        }else if (infos.iType == TimeInput)
        {
            static NSString *CellIdentifier = @"TimeSelectedTableViewCell";
            TimeSelectedTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[TimeSelectedTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            if ([infos.iChange isEqualToString:@"1"]) {
                cell.timeLB.textColor = [UIColor blackColor];
                cell.timeLB.text = infos.content;

            }else{
                cell.timeLB.textColor = [UIColor colorWithHexString:@"#d3d3d3"];
                cell.timeLB.text = infos.placeholder;
            }
           
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if (indexPath.row == 0) {
                cell.isHead = YES;
            }else{
                cell.isHead = NO;
            }
            if (indexPath.row == self.contentInfoDataArr.count-1) {
                cell.isEnd = YES;
            }else
            {
                cell.isEnd = NO;
            }

            return cell;
            
        }
        else{
            static NSString *CellIdentifier = @"TFMeetCell";
//            TFTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
//            if (cell == nil) {
            TFTableViewCell *cell = [[TFTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
                
            
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if (indexPath.row == 0) {
                cell.isHead = YES;
            }else{
                cell.isHead = NO;
            }
            if (indexPath.row == self.contentInfoDataArr.count-1) {
                cell.isEnd = YES;
            }else
            {
                cell.isEnd = NO;
            }
            cell.contentTF.delegate = self;
            cell.contentTF.placeholder = infos.placeholder;
            cell.contentTF.tag = indexPath.row + 500;
            cell.contentTF.text = infos.content;
            if ([infos.postKey isEqualToString:@"money"]) {
                cell.contentTF.keyboardType = UIKeyboardTypeNumberPad;
            }
            if ([infos.postKey isEqualToString:@"phone"]) {
                cell.contentTF.keyboardType = UIKeyboardTypeNumberPad;
            }
            [cell.contentTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
            return cell;
        }
        
    }else{
        static NSString *CellIdentifier = @"AddMeetTableViewCell";
        AddMeetTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[AddMeetTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        if (info.isSelected == YES) {
    
            cell.isSelected = YES;
        }else{
            cell.isSelected = NO;
        }
        cell.titleLB.text = info.title;
        cell.subTitleLB.text = info.content;
        cell.headImageView.image = [UIImage imageNamed:info.imageName];
        return cell;
    }
       return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    NSLog(@"%d",section);
    if (section >0) {
        AddMoreMeetInfoModel *info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:section-1];
        if (info.uiType == TitleLB) {
            return  30+45+optionsHeight;
        }
        if (info.uiType == TextView) {
            if (imageArr.count == 0) {
                imageHeight = 0;
            }else{
                imageHeight = 60;
            }
            if(_contentBeginEdit)
                return contentDefHeight+imageHeight;
            else
                return contentDefHeight+44+imageHeight;
        }
    }
    
    
    if (section == 0) {
        return 0;
    }
   
    return 41;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    //    self.view.frame = CGRectMake(0, 0, 320, 568);
    textField.returnKeyType = UIReturnKeyDone;
    
    UIView *contentView = [textField superview];
    NSArray *sub = [contentView subviews];


        for (UIView *v  in sub) {
        if ([v isKindOfClass:[UITextField class]]) {
            UITextField *vs =  (UITextField *)v;
            
            [self changeContentOffSet:vs];
        }
    }
}

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    NSLog(@"1111");
    _contentBeginEdit = YES;
    //[self respondsToSelector:@selector(keyboardShow:)];
    [[NSNotificationCenter defaultCenter] postNotificationName:UIKeyboardDidShowNotification object:nil];

    textView.superview.frame = CGRectMake(textView.superview.origin.x, textView.superview.origin.y, textView.superview.size.width, textView.superview.size.height-44);
    [textView.superview setNeedsDisplay];
    [_partyTableView scrollToNearestSelectedRowAtScrollPosition:UITableViewScrollPositionTop animated:YES];
    UIView *contentView = [textView superview];
    NSArray *sub = [contentView subviews];
    
    for (UIView *v  in sub) {
        if ([v isKindOfClass:[UITextView class]]) {
            UITextView *vs =  (UITextView *)v;
            //[self changeDetailOffSet:vs];
        }
    }

}
- (void)textViewDidEndEditing:(UITextView *)textView
{
    NSLog(@"22222");
    _contentBeginEdit = NO;
    
}
//-(void)changeDetailOffSet:(UITextView *)info{
//    NSLog(@"%@",info.superview);
//    textviewPoint = [info.superview convertPoint:CGPointZero fromView:_partyTableView];
//    
//    //_indexpath = [_partyTableView indexPathForRowAtPoint:infoPosition];
//}
-(void)changeContentOffSet:(UITextField *)info{
    CGPoint infoPosition = [info convertPoint:CGPointZero fromView:_partyTableView];
    _indexpath = [_partyTableView indexPathForRowAtPoint:infoPosition];
        
}
- (void)textChange:(RegistTextField *)textField
{
    if(textField.tag <600&&textField.tag >=500){
        AddMeetInfoContentTypeModel *info = [self.contentInfoDataArr objectAtIndex:textField.tag-500];
       
        info.content = textField.text;
        info.iChange = @"1";
        [self.contentInfoDataArr replaceObjectAtIndex:textField.tag-500 withObject:info];
    }
    if(textField.tag <1100&&textField.tag >=1000){
        
        AddMoreMeetInfoModel *moreInfo = [self.moreInfoDataArr objectAtIndex:textField.tag-1000-1];
        moreInfo.title = textField.text;
        moreInfo.isChange = YES;
//        [_postDic setObject:textField.text forKey:@"location"];
        [self.moreInfoDataArr replaceObjectAtIndex:textField.tag-1000-1 withObject:moreInfo];
    }
}

- (void)creatRightNav
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    rightbtn.frame = CGRectMake(260, _navheight+12, 50, 22);
    [rightbtn setImage:[UIImage imageNamed:@"cj_btn"] forState:UIControlStateNormal];
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [rightbtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    
    
    [self.view addSubview:rightbtn];
}
- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    AddMoreMeetInfoModel *info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:section-1];

    

    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 41)];
    headView.backgroundColor = [UIColor whiteColor];
    UILabel *headViewMidLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headViewMidLB, @"#c8c7cc");
    [headView addSubview:headViewMidLB];

    switch (_type) {
        case 0:
        {
            if (info.uiType == TextView) {
                headView.backgroundColor = [UIColor whiteColor];
                headView.frame = CGRectMake(0, 0.5, ScreenWidth, contentDefHeight+32.5+imageHeight);
                UIView *backView ;
                UILabel *headLineLB;
                UILabel *headLine6LB;
                UILabel *endLineLB;
                UIButton *selecedImageBtn;
                //if (!_detailsTextView) {
                    _detailsTextView = [[UITextView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth-20, contentDefHeight)];
                    _detailsTextView.font = YHUI(16);
                    //        _detailsTextView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                if (_contentBeginEdit) {
                    [_detailsTextView becomeFirstResponder];
                }
                    _detailsTextView.delegate = self;
                    _detailsTextView.text = [_summaryDic objectForKey:@"summary"];
                    _detailsTextView.backgroundColor = [UIColor clearColor];
                    [headView addSubview:_detailsTextView];
                    
                    headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_detailsTextView.frame), ScreenWidth, 0.5)];
                    BackGround16Color(headLineLB, @"#c8c7cc");
                    [headView addSubview:headLineLB];
                    
                    _placeholder = [[UILabel alloc]initWithFrame:CGRectMake(8, 7, 280, 22)];
                    _placeholder.textColor = [UIColor colorWithHexString:@"d3d3d3"];
                if ([[_summaryDic objectForKey:@"summary"] length]==0) {
                    _placeholder.hidden = NO;
                }else{
                    _placeholder.hidden = YES;
                }
                    _placeholder.text = @"活动详情事件，至少10个字";
                    _placeholder.font = YHUI(16);
//                if (_haveContent) {
//                    _placeholder.hidden = YES;
//                }else{
//                    _placeholder.hidden = NO;
//                }
                    //    placeholder.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    _placeholder.backgroundColor = [UIColor clearColor];
                    [_detailsTextView addSubview:_placeholder];
                if (imageArr.count == 0) {
                    imageHeight = 0;
                }else{
                    imageHeight = 60;
                }
                    _imageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLineLB.frame), ScreenWidth , 0+imageHeight)];
                    [_imageScrollView setShowsHorizontalScrollIndicator:NO];
                    [_imageScrollView setShowsVerticalScrollIndicator:NO];
                    _imageScrollView.backgroundColor = [UIColor clearColor];
                    for (UIView *view in _imageScrollView.subviews) {
                        [view removeFromSuperview];
                    }
                    for (int i = 0; i < imageArr.count; i++) {
                        
                        
                        UIImageView * imageviews = [[UIImageView alloc]initWithFrame:CGRectMake(i*(10+60), 0, 60, 60)];
                        imageviews.image = [imageArr objectAtIndex:i];
                        imageviews.backgroundColor = [UIColor clearColor];
                        imageviews.tag = 140+i ;
                        imageviews.userInteractionEnabled = YES;
                        UIGestureRecognizer  *oneFingeTwoTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getBigImages:)];
                        [imageviews addGestureRecognizer:oneFingeTwoTaps];
                        [_imageScrollView addSubview:imageviews];
                    }
                    _imageScrollView.contentSize = CGSizeMake(70*imageArr.count, 60);
                    [headView addSubview:_imageScrollView];
                    
                    headLine6LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_imageScrollView.frame), ScreenWidth, 0.5)];
                    //        headLine6LB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    
                    BackGround16Color(headLine6LB, @"#c8c7cc");
                    [headView addSubview:headLine6LB];
                    
                    backView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_imageScrollView.frame), ScreenWidth, 44)];
                    //        backView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    backView.tag = 131;
                    backView.userInteractionEnabled = YES;
                    backView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
                    
                    [headView addSubview:backView];
                    
                    endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(backView.frame), ScreenWidth, 0.5)];
                    BackGround16Color(endLineLB, @"#c8c7cc");
                    [headView  addSubview:endLineLB];
                    
                    
                    selecedImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                    selecedImageBtn.frame = CGRectMake(3, CGRectGetHeight(backView.frame)-32, 58, 23);
                    [selecedImageBtn setImage:[UIImage imageNamed:@"addPhoto"] forState:UIControlStateNormal];
                    selecedImageBtn.backgroundColor = [UIColor clearColor];
                    [selecedImageBtn addTarget:self action:@selector(photoBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
                    selecedImageBtn.tag = 122;
                    //        selecedImageBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    
                    
                    [backView addSubview:selecedImageBtn];
                UILabel * photoLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(selecedImageBtn.frame)+5, CGRectGetHeight(backView.frame)-38, 0.5, 32)];
                BackGround16Color(photoLB, @"c8c7cc");
                [backView addSubview:photoLB];

                return headView;
            }
            if (info.uiType == TextField) {
                UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 39.5)];
                label.backgroundColor = [UIColor whiteColor];
                [headView addSubview:label];
                
                UIImageView *addrImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 8, 20, 25)];
                addrImageView.image = [UIImage imageNamed:@"map_04"];
                [headView addSubview:addrImageView];
                
                RegistTextField *addressTF = [[RegistTextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(addrImageView.frame)+12, 8, 262, 24)];
                addressTF.tag = section+1000;
                addressTF.delegate = self;
                addressTF.text = info.title;
                addressTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
                [addressTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
//                addressTF.text = info.title;
                addressTF.backgroundColor = [UIColor whiteColor];
                addressTF.placeholder = info.placeHolder;
                [headView addSubview:addressTF];
                
                UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(label.frame), ScreenWidth, 0.5)];
                BackGround16Color(endLineLB, @"#c8c7cc");
                [headView  addSubview:endLineLB];

                return headView;
            }
            if (info.uiType == 2||info.uiType == 3) {
                AddMeetSectionBtn *SectionBtn = [AddMeetSectionBtn buttonWithType:UIButtonTypeCustom];
                SectionBtn.frame = CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 41);
                SectionBtn.backgroundColor = [UIColor whiteColor];
                SectionBtn.titleLabel.font = YHUI(16);
                SectionBtn.tag = 300+section;
                [SectionBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                SectionBtn.selected = info.isSelected;
                [SectionBtn setTitle:info.title forState:UIControlStateNormal] ;
                if (section == _moreInfoDataArr.count) {
                    [SectionBtn setImage:[UIImage imageNamed:@"select"] forState:UIControlStateNormal];
                    [SectionBtn setImage:[UIImage imageNamed:@"selected-cur"] forState:UIControlStateSelected];

                }
                if (section != _moreInfoDataArr.count) {
                    [SectionBtn setImage:[UIImage imageNamed:@"less"] forState:UIControlStateNormal];
                    [SectionBtn setImage:[UIImage imageNamed:@"more"] forState:UIControlStateSelected];

                }
                
                [SectionBtn addTarget:self action:@selector(showMoreInfo:) forControlEvents:UIControlEventTouchUpInside];
                [headView addSubview:SectionBtn];
                UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(SectionBtn.frame), ScreenWidth, 0.5)];
                BackGround16Color(endLineLB, @"#c8c7cc");
                [headView  addSubview:endLineLB];
            }

            return headView;
        }
            break;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            
        {
            if (section > 0) {
                if (info.uiType == TextView) {
                    headView.backgroundColor = [UIColor whiteColor];
                    headView.frame = CGRectMake(0, 0.5, ScreenWidth, 163+imageHeight);
                    _detailsTextView = [[UITextView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth-20, 130.5)];
                    _detailsTextView.font = YHUI(16);
                   
                    _detailsTextView.text = [_summaryDic objectForKey:@"summary"];
                    //        _detailsTextView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    _detailsTextView.delegate = self;
                    _detailsTextView.backgroundColor = [UIColor clearColor];
                    [headView addSubview:_detailsTextView];
                    UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_detailsTextView.frame), ScreenWidth, 0.5)];
                    BackGround16Color(headLineLB, @"#c8c7cc");
                    [headView addSubview:headLineLB];
                    
                    _placeholder = [[UILabel alloc]initWithFrame:CGRectMake(8, 7, 280, 22)];
                    _placeholder.textColor = [UIColor colorWithHexString:@"d3d3d3"];
                    _placeholder.text = @"活动详情事件，至少10个字";
                    _placeholder.font = YHUI(16);
                    if ([[_summaryDic objectForKey:@"summary"] length]!=0) {
                        _placeholder.hidden = YES;
                    }else{
                        _placeholder.hidden = NO;
                    }
                    //    placeholder.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    _placeholder.backgroundColor = [UIColor clearColor];
                    [_detailsTextView addSubview:_placeholder];
                    
                
                    if (imageArr.count == 0) {
                        imageHeight = 0;
                    }else{
                        imageHeight = 60;
                    }
                    _imageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLineLB.frame), ScreenWidth , 0+imageHeight)];
                    [_imageScrollView setShowsHorizontalScrollIndicator:NO];
                    [_imageScrollView setShowsVerticalScrollIndicator:NO];
                    _imageScrollView.backgroundColor = [UIColor clearColor];
                    for (UIView *view in _imageScrollView.subviews) {
                        [view removeFromSuperview];
                    }
                    for (int i = 0; i < imageArr.count; i++) {
                        UIImageView * imageviews = [[UIImageView alloc]initWithFrame:CGRectMake(i*(10+60), 0, 60, 60)];
                        imageviews.image = [imageArr objectAtIndex:i];
                        imageviews.backgroundColor = [UIColor clearColor];
                        imageviews.tag = 140+i ;
                        imageviews.userInteractionEnabled = YES;
                        UIGestureRecognizer  *oneFingeTwoTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getBigImages:)];
                        [imageviews addGestureRecognizer:oneFingeTwoTaps];                        [_imageScrollView addSubview:imageviews];
                    }
                    _imageScrollView.contentSize = CGSizeMake(70*imageArr.count, 60);
                    [headView addSubview:_imageScrollView];
                    
                    UILabel *headLine6LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_imageScrollView.frame), ScreenWidth, 0.5)];
                    //        headLine6LB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    
                    BackGround16Color(headLine6LB, @"#c8c7cc");
                    [headView addSubview:headLine6LB];
                    
                    UIView *backView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_imageScrollView.frame), ScreenWidth, 44)];
                    //        backView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    backView.tag = 131;
                    backView.userInteractionEnabled = YES;
                    backView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
                    
                    [headView addSubview:backView];
                    
                    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(backView.frame), ScreenWidth, 0.5)];
                    BackGround16Color(endLineLB, @"#c8c7cc");
                    [headView  addSubview:endLineLB];
                    
                    
                    UIButton *selecedImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
                    selecedImageBtn.frame = CGRectMake(3, CGRectGetHeight(backView.frame)-32, 58, 23);
                    [selecedImageBtn setImage:[UIImage imageNamed:@"addPhoto"] forState:UIControlStateNormal];
                    selecedImageBtn.backgroundColor = [UIColor clearColor];
                    [selecedImageBtn addTarget:self action:@selector(photoBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
                    selecedImageBtn.tag = 122;
                    //        selecedImageBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    
                    
                    [backView addSubview:selecedImageBtn];
                    
                    UILabel * photoLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(selecedImageBtn.frame)+5, CGRectGetHeight(backView.frame)-38, 0.5, 32)];
                    BackGround16Color(photoLB, @"c8c7cc");
                    [backView addSubview:photoLB];
                    return headView;
                }

                if (info.uiType == TextField) {
                    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 40)];
                    label.backgroundColor = [UIColor whiteColor];
                    [headView addSubview:label];
                    
                    
                    UIImageView *addrImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 8, 20, 25)];
                    addrImageView.image = [UIImage imageNamed:@"map_04"];
                    [headView addSubview:addrImageView];
                    
                    RegistTextField *addressTF = [[RegistTextField alloc]initWithFrame:CGRectMake(CGRectGetMaxX(addrImageView.frame)+12, 8, 262, 24)];
                    addressTF.backgroundColor = [UIColor whiteColor];
                    addressTF.tag = section+1000;
                    addressTF.delegate = self;
                    addressTF.font = YHUI(16);
                    addressTF.text = info.title;
                    addressTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
//                    addressTF.text = info.title;
                    addressTF.placeholder = info.placeHolder;
                    [addressTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
                    [headView addSubview:addressTF];
                    
                    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(label.frame), ScreenWidth, 0.5)];
                    BackGround16Color(endLineLB, @"#c8c7cc");
                    [headView  addSubview:endLineLB];

                }
                if (info.uiType == TimeView) {
                    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 40)];
                    label.backgroundColor = [UIColor whiteColor];
                    [headView addSubview:label];
                    
                    AddMeetSectionBtn *SectionBtn = [AddMeetSectionBtn buttonWithType:UIButtonTypeCustom];
                    SectionBtn.frame = CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 41);
                    SectionBtn.backgroundColor = [UIColor whiteColor];
                    SectionBtn.titleLabel.font = YHUI(16);
                    SectionBtn.tag = 300+section;
                   
                    if (info.isSelected == YES) {
                        [SectionBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                    }else{
                        [SectionBtn setTitleColor:[UIColor colorWithHexString:@"#d3d3d3"] forState:UIControlStateNormal];
                    }

                    SectionBtn.selected = info.isSelected;
                    [SectionBtn setTitle:info.title forState:UIControlStateNormal] ;
                    [headView addSubview:SectionBtn];
                    
                    [SectionBtn setImage:[UIImage imageNamed:@"less"] forState:UIControlStateNormal];
//                    [SectionBtn setImage:[UIImage imageNamed:@"more"] forState:UIControlStateSelected];
                    [SectionBtn addTarget:self action:@selector(showActiom:) forControlEvents:UIControlEventTouchUpInside];
                    
                    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(SectionBtn.frame), ScreenWidth, 0.5)];
                    BackGround16Color(endLineLB, @"#c8c7cc");
                    [headView  addSubview:endLineLB];

                }
                if (info.uiType == TitleLB) {
                    headView.frame = CGRectMake(0, 0, ScreenWidth, 30+optionsHeight+45);
                    UILabel *titleLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 30+optionsHeight+45-0.5)];
                    titleLB.backgroundColor = [UIColor whiteColor];
                    [headView addSubview:titleLB];
                    UILabel *nameLB = [[UILabel alloc]initWithFrame:CGRectMake(18.5, 0.5, 250, 31)];
                    //nameLB.text = @"用户报名填写项";
                    nameLB.font = YHUI(16);
                    nameLB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                    nameLB.text = info.title;
                    nameLB.backgroundColor = [UIColor clearColor];
                    [headView addSubview:nameLB];

                    for (int i = 0; i < _signUpFiledsArr.count; i++) {
                        SignUpFieldsModel *fieldsInfo =  [_signUpFiledsArr objectAtIndex:i];
                        fieldsInfo.btnTag = 130+i;
                        UIButton *itemBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
                        
                        itemBtn.selected =  fieldsInfo.selected;
                        itemBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
                        
                        [itemBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
                        [itemBtn setTitleColor:[UIColor colorWithHexString:@"#080808"] forState:UIControlStateNormal];
                        [itemBtn setTitle:fieldsInfo.title forState:UIControlStateNormal];
                        itemBtn.frame = CGRectMake( 25+(25+73)*(i%3), CGRectGetMaxY(nameLB.frame)+35*(i/3), 73, 25);
                        //itemBtn.selected = self.isSelected;
                        [itemBtn setBackgroundImage:[UIImage imageNamed:@"seleced_btn"] forState:UIControlStateSelected];
                        [itemBtn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
                        itemBtn.titleLabel.font = YHUI(16);
                        itemBtn.backgroundColor = [UIColor clearColor];
                        [itemBtn addTarget:self action:@selector(itemBtntnClicked:) forControlEvents:UIControlEventTouchUpInside];
                        itemBtn.tag = 130+i;
                        [headView addSubview:itemBtn];
                        
                    }
                    UILabel *tailDiscribeLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 30+optionsHeight+7, ScreenWidth, 35)];
                    tailDiscribeLB.text = @"选项不够用或需要更多报名类型？请发布完毕后，电脑上访问专业版管理后台配置报名选项";
                    tailDiscribeLB.font = YHUI(14);
                    tailDiscribeLB.numberOfLines = 0;
                    BackGroundColor(tailDiscribeLB, clearColor);
                    tailDiscribeLB.lineBreakMode = NSLineBreakByCharWrapping;
                    [headView addSubview: tailDiscribeLB];
                    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headView.frame)-0.5, ScreenWidth, 0.5)];
                    BackGround16Color(endLineLB, @"#c8c7cc");
                    [headView  addSubview:endLineLB];


                }
                if (info.uiType == 2||info.uiType == 3) {
           
                    if (section == _moreInfoDataArr.count) {
                        
                    }
                    if (section == _moreInfoDataArr.count||section == _moreInfoDataArr.count-1) {
                        
                        UILabel *endTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12,  14, ScreenWidth-80, 14)];
                        endTitleLB.backgroundColor = [UIColor clearColor];
                        endTitleLB.font = YHUI(16);
                        if (section == _moreInfoDataArr.count-1) {
                            endTitleLB.text = @"是否非公开（不显示在广场页）";
                        }else{
                            endTitleLB.text = @"是否显示报名人员信息";
                        }
                        
                        endTitleLB.textColor = [UIColor blackColor];
                        [headView addSubview:endTitleLB];
                        
                        SevenSwitch* switchBtn = [[ SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth - 35 - 18, 10, 35, 22)];
                        switchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
                        
                        //    switchBtn.offImage = [UIImage imageNamed:@"off"];
                        //    switchBtn.onImage = [UIImage imageNamed:@"on"];
                        if ([[_postDic objectForKey:@"openstatus"] isEqualToString:@"0"]) {
                            switchBtn.on = YES;
                        }else{
                            switchBtn.on = NO;
                        }
                        if ([[_postDic objectForKey:@"personal_data_sw"] isEqualToString:@"1"]) {
                            switchBtn.on = YES;
                        }else{
                            switchBtn.on = NO;
                        }
                        if (section ==_moreInfoDataArr.count) {
                            switchBtn.tag = 600+ _moreInfoDataArr.count;
                        }
                        if (section == _moreInfoDataArr.count-1) {
                            switchBtn.tag = 600+ _moreInfoDataArr.count-1;
                        }
                        [switchBtn addTarget:self action:@selector(switchBtnClick:) forControlEvents:UIControlEventValueChanged];
                        [headView addSubview:switchBtn];
                        
                        UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headView.frame)-0.5, ScreenWidth, 0.5)];
                        BackGround16Color(endLineLB, @"#c8c7cc");
                        [headView  addSubview:endLineLB];

                        
                    }else{
                        AddMeetSectionBtn *SectionBtn = [AddMeetSectionBtn buttonWithType:UIButtonTypeCustom];
                        SectionBtn.frame = CGRectMake(0, CGRectGetMaxY(headViewMidLB.frame), ScreenWidth, 41);
                        SectionBtn.backgroundColor = [UIColor whiteColor];
                        SectionBtn.titleLabel.font = YHUI(16);
                        SectionBtn.tag = 300+section;
                        [SectionBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                        SectionBtn.selected = info.isSelected;
                        [SectionBtn setTitle:info.title forState:UIControlStateNormal] ;
                        [SectionBtn setImage:[UIImage imageNamed:@"less"] forState:UIControlStateNormal];
                        [SectionBtn setImage:[UIImage imageNamed:@"more"] forState:UIControlStateSelected];
                        [SectionBtn addTarget:self action:@selector(showMoreInfo:) forControlEvents:UIControlEventTouchUpInside];
                        [headView addSubview:SectionBtn];
                        UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(SectionBtn.frame), ScreenWidth, 0.5)];
                        BackGround16Color(endLineLB, @"#c8c7cc");
                        [headView  addSubview:endLineLB];

                    }
                    
                }
                

                
                return headView;
            }else{
                UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, 0)];
                return view;
            }

        }
            break;
        default:
            break;
    }
    
   
    return nil;
}
- (void)switchBtnClick:(SevenSwitch *)btn
{
    if (btn.tag == 607) {
        AddMoreMeetInfoModel *info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:btn.tag-600-1];
        _isSection = YES;
        info.isSelected = !info.isSelected;
        [self.moreInfoDataArr replaceObjectAtIndex:btn.tag-600-1 withObject:info];
    }
    if (btn.tag == 608) {
        AddMoreMeetInfoModel *info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:btn.tag-600-1];
        _isSection = YES;
        info.isSelected = !info.isSelected;
        [self.moreInfoDataArr replaceObjectAtIndex:btn.tag-600-1 withObject:info];
    }
}
- (void)deleteImage:(NSInteger)index
{
    NSString *urlKey = [NSString stringWithFormat:@"url%d",imageIndex];
    [imageDic removeObjectForKey:urlKey];
    [imageArr removeObjectAtIndex:imageIndex];
    if (imageArr.count == 0) {
        imageHeight = 0;
    }
   
    
    
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type+1]];
    [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",imageArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type+1]];
    
    [self deleteFile:[NSString stringWithFormat:@"pic_%d_%d.png",_type+1,index]];

    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]];
    [[DBManager sharedInstance] insertDataToPublicDB:[imageDic JSONString]  valueKey:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]];
    
    
    [_partyTableView reloadData];
}
- (void)getBigImages:(UIGestureRecognizer*)gesture
{
    imageIndex =  (gesture.self.view.tag-140) ;
    if (gesture.self.view.tag-140<imageArr.count) {
        NSMutableArray *photos = [[NSMutableArray alloc] init];
        NSMutableArray *thumbs = [[NSMutableArray alloc] init];
        
        BOOL displayActionButton = NO;
        BOOL displaySelectionButtons = NO;
        BOOL displayNavArrows = NO;
        BOOL enableGrid = NO;
        BOOL startOnGrid = NO;
        MWPhoto *photo = [MWPhoto photoWithImage:[imageArr objectAtIndex:gesture.self.view.tag-140]];
//        MWPhoto *photo = [MWPhoto photoWithURL:[NSURL URLWithString:[[imageArr objectAtIndex:gesture.self.view.tag-140] objectForKey:@"url"]]];
        photo.caption = nil;
        [photos addObject:photo];

        self.photos = photos;
        self.thumbs = thumbs;
        
        // Create browser
        MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
        browser.rightNavButtonIsHiden = NO;
        browser.displayActionButton = displayActionButton;
        browser.displayNavArrows = displayNavArrows;
        browser.displaySelectionButtons = displaySelectionButtons;
        browser.alwaysShowControls = displaySelectionButtons;
        browser.navTitle = nil;
        browser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
        browser.wantsFullScreenLayout = YES;
#endif
        browser.enableGrid = enableGrid;
        browser.startOnGrid = startOnGrid;
        browser.enableSwipeToDismiss = YES;
        [browser setCurrentPhotoIndex:0];
        // Show
        if (_segmentedControl.selectedSegmentIndex == 0) {
            // Push
            [self.navigationController pushViewController:browser animated:YES];
        } else {
            // Modal
            UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:browser];
            nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [self presentViewController:nc animated:YES completion:nil];
        }
        
        // Release
        
        // Deselect
        
        
        // Test reloading of data after delay
        double delayInSeconds = 3;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        });
    }
    
}

- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser {
    return self.photos.count;
}

- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index {
    if (index < self.photos.count)
        return [self.photos objectAtIndex:index];
    return nil;
}

- (void)photoBtnClicked:(UIButton*)btn
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:@"照相"
                                  otherButtonTitles:@"相册",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];


}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (0 == buttonIndex) {
        //照相
        UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
        pickerController.delegate = self;
        pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        pickerController.allowsEditing = YES;
        [self presentViewController:pickerController animated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }];
    }
    else if (1 == buttonIndex) {
        //相册
        UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
        pickerController.delegate = self;
        pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        pickerController.allowsEditing = YES;
        [self presentViewController:pickerController animated:YES completion:nil];
    }
}
- (UIImage *)getImageFormDocument:(NSString*)imageName{
    
    
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *document = [paths objectAtIndex:0];
    NSString *imageDir = [NSString stringWithFormat:@"%@/Caches", document];
    BOOL isDir = NO;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    UIImage *cacheImage;
    NSString *filePath;
    BOOL existed = [fileManager fileExistsAtPath:imageDir isDirectory:&isDir];
    if ( !(isDir == YES && existed == YES) )
    {
        [fileManager createDirectoryAtPath:imageDir withIntermediateDirectories:YES attributes:nil error:nil];
       
        
        }

//    NSArray  *paths  =  NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
//    NSString *docDir = [paths objectAtIndex:0];
//    NSString *filePath = [docDir stringByAppendingPathComponent:imageName];
//    UIImage *cacheImage = [[UIImage alloc]initWithContentsOfFile:filePath];
    filePath = [document stringByAppendingPathComponent:[NSString stringWithFormat:imageName,nil]];  // 保存文件的名称
    cacheImage = [[UIImage alloc]initWithContentsOfFile:filePath];
    return cacheImage;

}
- (void)saveImageToDocument:(UIImage *)image imageName:(NSString *)imagename
{
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *document = [paths objectAtIndex:0];
    NSString *imageDir = [NSString stringWithFormat:@"%@/Caches", document];
    BOOL isDir = NO;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL existed = [fileManager fileExistsAtPath:imageDir isDirectory:&isDir];
    if ( !(isDir == YES && existed == YES))
    {
        [fileManager createDirectoryAtPath:imageDir withIntermediateDirectories:YES attributes:nil error:nil];
       
    }
    NSString *filePath = [document stringByAppendingPathComponent:[NSString stringWithFormat:imagename,nil]];  // 保存文件的名称
    
    
    NSLog(@"%@",filePath);
   // [UIImagePNGRepresentation(image)writeToFile: filePath atomically:YES];
    [UIImageJPEGRepresentation(image, 1)writeToFile:filePath atomically:YES];

   
}
-(void)deleteFile:(NSString *)imageName {
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
    NSString *document = [paths objectAtIndex:0];
    NSString *imageDir = [NSString stringWithFormat:@"%@/Caches", document];
    BOOL isDir = NO;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL existed = [fileManager fileExistsAtPath:imageDir isDirectory:&isDir];
    if ( !(isDir == YES && existed == YES))
    {
        [fileManager createDirectoryAtPath:imageDir withIntermediateDirectories:YES attributes:nil error:nil];
        
    }

    
    //文件名
    NSString *uniquePath=[imageDir stringByAppendingPathComponent:imageName];
    BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:uniquePath];
    if (!blHave) {
        NSLog(@"no  have");
        return ;
    }else {
        NSLog(@" have");
        BOOL blDele= [fileManager removeItemAtPath:uniquePath error:nil];
        if (blDele) {
            NSLog(@"dele success");
        }else {
            NSLog(@"dele fail");
        }
        
    }
}
#pragma mark - uiimageviewdelegate
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    if (imageArr.count == 0) {
        imageHeight = 0;
        
    }
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    
}
- (void)imagePickerController:(UIImagePickerController *)ipicker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [ipicker dismissViewControllerAnimated:NO completion:nil];
    
    UIImage *selectedImage =nil;
    selectedImage=[info objectForKey:UIImagePickerControllerEditedImage];
    if (nil == selectedImage) {
        selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    [imageArr addObject:selectedImage];
    if ( selectedImage == nil)
        return;
    // mySelfInfo *myself = (mySelfInfo*)[self.dataMutAry objectAtIndex:0];
    //_newHeadImage = selectedImage;
    NSData * data;
    data = UIImageJPEGRepresentation(selectedImage, 0.0001);
    
//    if (data == nil) {
//        data = UIImagePNGRepresentation(selectedImage);
//    }
    imageHeight = 60;
    _imageStr = [GTMBase64 stringByEncodingData:data];
    NSDictionary *dic = @{@"iospic":_imageStr,@"iospic_type":@"jpg"};
    //NSDictionary *dic = @{@"ico_file":_imageStr};
    [MyDataService postUploadPicture:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
            NSLog(@"%@",[[data objectForKey:@"content"] class]);
            
            NSString *urlKey = [NSString stringWithFormat:@"url%lu",(unsigned long)imageDic.count];
            
            
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type+1]];
            [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%lu",(unsigned long)imageArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type+1]];
            
            [self saveImageToDocument:selectedImage imageName:[NSString stringWithFormat:@"pic_%d_%lu.png",_type+1,(unsigned long)imageArr.count ]];
            [imageDic setObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] forKey:urlKey];
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]];
            [[DBManager sharedInstance] insertDataToPublicDB:[imageDic JSONString]  valueKey:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]];
//            NSDictionary *dic = @{@"url":[[data objectForKey:@"content"] objectForKey:@"icon_file"]};
//            [imageArr addObject:dic];
        }
    }];
    
    [_partyTableView reloadData];
    return ;
}

- (void)itemBtntnClicked:(UIButton*)btn
{
    SignUpFieldsModel *fieldsInfo =  [_signUpFiledsArr objectAtIndex:btn.tag-130];
    if (btn.tag > 132) {
        if (btn.selected == YES) {
            btn.selected = NO;
            fieldsInfo.selected = NO;
            
        }else{
            btn.selected = YES;
            fieldsInfo.selected = YES;
        }
        
    }
    [_signUpFiledsArr replaceObjectAtIndex:(btn.tag-130) withObject:fieldsInfo];

    
}
- (void)showMoreInfo:(UIButton *)btn
{
    if ([btn.titleLabel.text isEqualToString:@"选择会议功能插件"]) {
        if (_fristCome) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:[NSString stringWithFormat:@"功能插件选取后，请您在电脑上访问%@对选择的功能插件进行配置。",COMPANY_ADDR] delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [av show];
            _fristCome = NO;
        }
    }
   
    NSLog(@"%ld",btn.tag-300-1);
    AddMoreMeetInfoModel *info = [[AddMoreMeetInfoModel alloc]init];
    switch (_type) {
            
        case 0:
            info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:btn.tag-300-1];
            info.isSelected = !info.isSelected;
            [self.moreInfoDataArr replaceObjectAtIndex:btn.tag-300-1 withObject:info];

            break;
        case 2:
        case 4:
            info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:btn.tag-300-1];
            _isSection = YES;
            info.isSelected = !info.isSelected;
            [self.moreInfoDataArr replaceObjectAtIndex:btn.tag-300-1 withObject:info];
            break;
        case 1:
        case 3:
        case 5:
        case 6:
            info = (AddMoreMeetInfoModel *)[self.moreInfoDataArr objectAtIndex:btn.tag-300-1];
            _isSection = YES;
            info.isSelected = !info.isSelected;
            [self.moreInfoDataArr replaceObjectAtIndex:btn.tag-300-1 withObject:info];
        default:
            break;
    }

    
    
    
    [_partyTableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark - 初始化数据源
- (void)initData
{
    _signUpFiledsArr = [[NSMutableArray alloc]initWithCapacity:0];
    self.contentInfoDataArr = [[NSMutableArray alloc]initWithCapacity:0];//报名填写字段
    self.pluginInfoArr = [[NSMutableArray alloc]initWithCapacity:0];//插件
    self.meetBackInfoArr = [[NSMutableArray alloc]initWithCapacity:0];//回执
    self.moreInfoDataArr = [[NSMutableArray alloc]initWithCapacity:0];//headviewinfo
    NSDictionary *dbfieldArr = [[dbDic objectForKey:@"fieldArr"] JSONValue];
    if ([[dbDic objectForKey:@"summary"] length]!=0) {
        [_summaryDic setObject:[dbDic objectForKey:@"summary"] forKey:@"summary"];
    }
    
    switch (_type) {
        case 0:{
            NSArray *postkeys = @[@"nickname",@"phone",@"email"];
            for (int i = 0; i<3; i++) {
                SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                info.postKey = [postkeys objectAtIndex:i];
            
                if ([[dbfieldArr objectForKey:[postkeys objectAtIndex:i]] isEqualToString:@"1"]) {
                    info.selected = YES;
                }else{
                    info.selected = NO;
                }
                
                [_signUpFiledsArr addObject:info];

            }
        }
            break;
        case 1:
        case 2:
        case 3:{
            
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"备注"];
             NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"remarks"];
            for (NSString *title in _optionsArr) {
                SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                
                int index = [_optionsArr indexOfObject:title];
                if ([[dbfieldArr objectForKey:[keys objectAtIndex:index]] isEqualToString:@"1"]) {
                    info.selected = YES;
                }else{
                    info.selected = NO;
                }

                
                
                if ([_optionsArr indexOfObject:title]<3) {
                    info.selected = YES;
                    
                }
//                else{
//                    info.selected = NO;
//                }
                info.title = title;
                info.btnTag = MAXFLOAT;
                [_signUpFiledsArr addObject:info];
            }
            if (_optionsArr.count%3==0) {
                optionsHeight = 35*(_optionsArr.count/3);
            }else
            {
                optionsHeight = 35*(_optionsArr.count/3+1);
            }
        }
            
            break;
        case 4:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"remarks"];
            for (NSString *title in _optionsArr) {
                SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                
                if ([[dbfieldArr objectForKey:[keys objectAtIndex:[_optionsArr indexOfObject:title]]] isEqualToString:@"1"]) {
                    info.selected = YES;
                }else{
                    info.selected = NO;
                }
                if ([_optionsArr indexOfObject:title]<3) {
                    info.selected = YES;
                    
                }else{
                    info.selected = NO;
                }
                info.title = title;
                info.btnTag = MAXFLOAT;
                [_signUpFiledsArr addObject:info];
            }
            
            if (_optionsArr.count%3==0) {
                optionsHeight = 35*(_optionsArr.count/3);
            }else
            {
                optionsHeight = 35*(_optionsArr.count/3+1);
            }


        }
            break;
        case 5:
        case 6:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"专业领域",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"major",@"remarks"];
            
            for (NSString *title in _optionsArr) {
                SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                
                if ([[dbfieldArr objectForKey:[keys objectAtIndex:[_optionsArr indexOfObject:title]]] isEqualToString:@"1"]) {
                    info.selected = YES;
                }else{
                    info.selected = NO;
                }

                if ([_optionsArr indexOfObject:title]<3) {
                    info.selected = YES;
                    
                }else{
                    info.selected = NO;
                }
                info.title = title;
                
                info.btnTag = MAXFLOAT;
                [_signUpFiledsArr addObject:info];
            }
            
            if (_optionsArr.count%3==0) {
                optionsHeight = 35*(_optionsArr.count/3);
            }else
            {
                optionsHeight = 35*(_optionsArr.count/3+1);
            }

            
        }
            break;
        default:
            break;
    }
    switch (_type) {
        case 0://私人聚会
        {
            AddMeetInfoContentTypeModel * contentInfo0 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo0.placeholder = @"输入聚会主题";
            contentInfo0.postKey = @"title";
            contentInfo0.iType = TextInput;
            if ([[dbDic objectForKey:contentInfo0.postKey] length]!=0) {
                contentInfo0.content = [dbDic objectForKey:contentInfo0.postKey] ;
                contentInfo0.iChange = @"1";
            }else{
                contentInfo0.content = @"";
                contentInfo0.iChange = @"0";
            }
            
            
            [self.contentInfoDataArr addObject:contentInfo0];
            
            AddMeetInfoContentTypeModel * contentInfo1 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo1.placeholder = @"活动开始时间";
            contentInfo1.iChange = @"0";
            
            contentInfo1.postKey = @"begin_time";
            contentInfo1.iType = TimeInput;
            if ([[dbDic objectForKey:contentInfo1.postKey] length]!=0) {
                contentInfo1.time = [dbDic objectForKey:contentInfo1.postKey] ;
                contentInfo1.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:contentInfo1.time];
                contentInfo1.iChange = @"1";
            }else{
                contentInfo1.time = @"";
                contentInfo1.iChange = @"0";
                contentInfo1.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo1];
        }
            break;
        case 1://内部会议
        {
            AddMeetInfoContentTypeModel * contentInfo0 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo0.placeholder = @"输入会议主题";
            contentInfo0.iType = TextInput;
            contentInfo0.postKey = @"title";
            
            contentInfo0.content = [dbDic objectForKey:contentInfo0.postKey];
            if (contentInfo0.content.length == 0) {
                contentInfo0.iChange = @"0";
            }else{
                contentInfo0.iChange = @"1";
            }
            [self.contentInfoDataArr addObject:contentInfo0];
            
            AddMeetInfoContentTypeModel * contentInfo1 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo1.placeholder = @"会议开始时间";
            contentInfo1.postKey = @"begin_time";
            contentInfo1.iType = TimeInput;
            if ([[dbDic objectForKey:contentInfo1.postKey] length]!=0) {
                contentInfo1.time = [dbDic objectForKey:contentInfo1.postKey] ;
                contentInfo1.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:contentInfo1.time];
                contentInfo1.iChange = @"1";
            }else{
                contentInfo1.time = @"";
                contentInfo1.iChange = @"0";
                contentInfo1.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo1];
            
            AddMeetInfoContentTypeModel * contentInfo2 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo2.placeholder = @"会议结束时间 (选填)";
            contentInfo2.postKey = @"end_time";
            contentInfo2.iType = TimeInput;
            if ([[dbDic objectForKey:contentInfo2.postKey] length]!=0) {
                contentInfo2.time = [dbDic objectForKey:contentInfo2.postKey] ;
                contentInfo2.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:contentInfo1.time];
                contentInfo2.iChange = @"1";
            }else{
                contentInfo2.time = @"";
                contentInfo2.iChange = @"0";
                contentInfo2.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo2];
            
            AddMeetInfoContentTypeModel * contentInfo3 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo3.placeholder = @"主办单位名称（选填）";
            contentInfo3.postKey = @"company";
            contentInfo3.content = [dbDic objectForKey:contentInfo3.postKey];
            if (contentInfo3.content.length == 0) {
                contentInfo3.iChange = @"0";
            }else{
                contentInfo3.iChange = @"1";
            }

            contentInfo3.iType = TextInput;
            [self.contentInfoDataArr addObject:contentInfo3];
            
            AddMeetInfoContentTypeModel * contentInfo7 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo7.placeholder = @"承办单位名称（选填）";
            contentInfo7.iType = TextInput;
            contentInfo7.postKey = @"organizer";
            contentInfo7.content = [dbDic objectForKey:contentInfo7.postKey];
            if (contentInfo7.content.length == 0) {
                contentInfo7.iChange = @"0";
            }else{
                contentInfo7.iChange = @"1";
            }

            [self.contentInfoDataArr addObject:contentInfo7];
            
            
            AddMeetInfoContentTypeModel * contentInfo4 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo4.placeholder = @"您的联系电话（选填）";
            contentInfo4.postKey = @"phone";
            contentInfo4.iType = TextInput;

            contentInfo4.content = [dbDic objectForKey:contentInfo4.postKey];
            if (contentInfo4.content.length == 0) {
                contentInfo4.iChange = @"0";
            }else{
                contentInfo4.iChange = @"1";
            }

            [self.contentInfoDataArr addObject:contentInfo4];
            
            AddMeetInfoContentTypeModel * contentInfo5 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo5.placeholder = @"您的姓名（选填）";
            contentInfo5.postKey = @"name";
            contentInfo5.iType = TextInput;
            contentInfo5.content = [dbDic objectForKey:contentInfo5.postKey];
            if (contentInfo5.content.length == 0) {
                contentInfo5.iChange = @"0";
            }else{
                contentInfo5.iChange = @"1";
            }

            [self.contentInfoDataArr addObject:contentInfo5];
        }
            break;
        case 2://沙龙活动
        {
            AddMeetInfoContentTypeModel * contentInfo0 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo0.placeholder = @"输入会议主题";
            contentInfo0.iType = TextInput;
            contentInfo0.postKey = @"title";
            contentInfo0.content = [dbDic objectForKey:contentInfo0.postKey];
            if (contentInfo0.content.length == 0) {
                contentInfo0.iChange = @"0";
            }else{
                contentInfo0.iChange = @"1";
            }
            [self.contentInfoDataArr addObject:contentInfo0];
            
            AddMeetInfoContentTypeModel * contentInfo6 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo6.placeholder = @"收费金额，如果免费则不填";
            contentInfo6.iType = TextInput;
            contentInfo6.postKey = @"money";
            contentInfo6.content = [dbDic objectForKey:contentInfo6.postKey];
            if (contentInfo6.content.length == 0) {
                contentInfo6.iChange = @"0";
            }else{
                contentInfo6.iChange = @"1";
            }

            [self.contentInfoDataArr addObject:contentInfo6];

            AddMeetInfoContentTypeModel * contentInfo1 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo1.placeholder = @"会议开始时间";
            contentInfo1.iType = TimeInput;
            contentInfo1.postKey = @"begin_time";
            if ([[dbDic objectForKey:contentInfo1.postKey] length]!=0) {
                contentInfo1.time = [dbDic objectForKey:contentInfo1.postKey] ;
                contentInfo1.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:contentInfo1.time];
                contentInfo1.iChange = @"1";
            }else{
                contentInfo1.time = @"";
                contentInfo1.iChange = @"0";
                contentInfo1.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo1];
            
            AddMeetInfoContentTypeModel * contentInfo2 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo2.placeholder = @"会议结束时间（选填）";
            contentInfo2.postKey = @"end_time";
            contentInfo2.iType = TimeInput;
            if ([[dbDic objectForKey:contentInfo1.postKey] length]!=0) {
                contentInfo2.time = [dbDic objectForKey:contentInfo1.postKey] ;
                contentInfo2.content = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:contentInfo1.time];
                contentInfo2.iChange = @"1";
            }else{
                contentInfo2.time = @"";
                contentInfo2.iChange = @"0";
                contentInfo2.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo2];
            
            AddMeetInfoContentTypeModel * contentInfo3 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo3.placeholder = @"主办单位名称（选填）";
            contentInfo3.iType = TextInput;
            contentInfo3.iChange = @"0";
            contentInfo3.postKey = @"company";
            if ([[dbDic objectForKey:contentInfo3.postKey] length]!=0) {
                contentInfo3.content = [dbDic objectForKey:contentInfo3.postKey];
                contentInfo3.iChange = @"1";
            }else{
                contentInfo3.iChange = @"0";
                contentInfo3.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo3];
            
            AddMeetInfoContentTypeModel * contentInfo7 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo7.placeholder = @"承办单位名称（选填）";
            contentInfo7.iType = TextInput;
            contentInfo7.postKey = @"organizer";
            
            if ([[dbDic objectForKey:contentInfo7.postKey] length]!=0) {
                contentInfo7.content = [dbDic objectForKey:contentInfo7.postKey];
                contentInfo7.iChange = @"1";
            }else{
                contentInfo7.iChange = @"0";
                contentInfo7.content = @"";
            }

            [self.contentInfoDataArr addObject:contentInfo7];
            
            AddMeetInfoContentTypeModel * contentInfo4 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo4.placeholder = @"您的联系电话（选填）";
            contentInfo4.postKey = @"phone";
            contentInfo4.iType = TextInput;
            if ([[dbDic objectForKey:contentInfo4.postKey] length]!=0) {
                contentInfo4.content = [dbDic objectForKey:contentInfo4.postKey];
                contentInfo4.iChange = @"1";
            }else{
                contentInfo4.iChange = @"0";
                contentInfo4.content = @"";
            }
            [self.contentInfoDataArr addObject:contentInfo4];
            
            AddMeetInfoContentTypeModel * contentInfo5 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo5.placeholder = @"您的姓名（选填）";
            contentInfo5.postKey = @"name";
            contentInfo5.iType = TextInput;
            if ([[dbDic objectForKey:contentInfo5.postKey] length]!=0) {
                contentInfo5.content = [dbDic objectForKey:contentInfo5.postKey];
                contentInfo5.iChange = @"1";
            }else{
                contentInfo5.iChange = @"0";
                contentInfo5.content = @"";
            }
            [self.contentInfoDataArr addObject:contentInfo5];
        }
             break;
        case 3://学术研讨，项目路演，招才引智，展览会
        case 4:
        case 5:
        case 6:
        {
            [self.contentInfoDataArr removeAllObjects];
            AddMeetInfoContentTypeModel * contentInfo0 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo0.placeholder = @"输入会议主题";
            contentInfo0.iType = TextInput;
            contentInfo0.content = @"";
            contentInfo0.iChange = @"0";
            contentInfo0.postKey = @"title";
            [self.contentInfoDataArr addObject:contentInfo0];
            
            AddMeetInfoContentTypeModel * contentInfo6 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo6.placeholder = @"收费金额，如果免费则不填";
            contentInfo6.iType = TextInput;
            contentInfo6.postKey = @"money";
            contentInfo6.iChange = @"0";
            contentInfo6.content = @"";
            [self.contentInfoDataArr addObject:contentInfo6];

            AddMeetInfoContentTypeModel * contentInfo1 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo1.placeholder = @"会议开始时间";
            contentInfo1.postKey = @"begin_time";
            contentInfo1.iType = TimeInput;
            contentInfo1.content = @"";
            contentInfo1.iChange = @"0";
            [self.contentInfoDataArr addObject:contentInfo1];
            
            AddMeetInfoContentTypeModel * contentInfo2 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo2.placeholder = @"会议结束时间（选填）";
            contentInfo2.postKey = @"end_time";
            contentInfo2.iType = TimeInput;
            contentInfo2.content = @"";
            contentInfo2.iChange = @"0";
            [self.contentInfoDataArr addObject:contentInfo2];
            
            AddMeetInfoContentTypeModel * contentInfo3 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo3.placeholder = @"主办单位名称（选填）";
            contentInfo3.iType = TextInput;
            contentInfo3.postKey = @"company";
            contentInfo3.content = @"";
            contentInfo3.iChange = @"0";
            [self.contentInfoDataArr addObject:contentInfo3];
            
            AddMeetInfoContentTypeModel * contentInfo7 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo7.placeholder = @"承办单位名称（选填）";
            contentInfo7.iType = TextInput;
            contentInfo7.iChange = @"0";
            contentInfo7.postKey = @"organizer";
            contentInfo7.content = @"";
            [self.contentInfoDataArr addObject:contentInfo7];
            
            AddMeetInfoContentTypeModel * contentInfo4 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo4.placeholder = @"您的联系电话（选填）";
            contentInfo4.postKey = @"phone";
            contentInfo4.iType = TextInput;
            contentInfo4.content = @"";
            contentInfo4.iChange = @"0";
            [self.contentInfoDataArr addObject:contentInfo4];
            
            AddMeetInfoContentTypeModel * contentInfo5 = [[AddMeetInfoContentTypeModel alloc]init];
            contentInfo5.placeholder = @"您的姓名（选填）";
            contentInfo5.postKey = @"name";
            contentInfo5.iChange = @"0";
            contentInfo5.iType = TextInput;
            contentInfo5.content = @"";
            [self.contentInfoDataArr addObject:contentInfo5];
        }
             break;

        default:
            break;
    }
    [self createArr];
    
    
}
- (void)createArr//会议的具体信息
{

    
    switch (_type) {
        case 0:
        {   [self.moreInfoDataArr removeAllObjects];
            
            AddMoreMeetInfoModel *moreInfo0 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo0.placeHolder = @"会议详情，详细说明时间，地点，时间";
            moreInfo0.isSelected = NO;
            moreInfo0.isSection = YES;
            moreInfo0.uiType = TextView;
            moreInfo0.postKey = @"summary";
            
            [self.moreInfoDataArr addObject:moreInfo0];
            
            AddMoreMeetInfoModel *moreInfo = [[AddMoreMeetInfoModel alloc]init];
            moreInfo.placeHolder = @"输入活动地址";
            moreInfo.isSelected = NO;
            moreInfo.isSection = YES;
            moreInfo.uiType = TextField;
            moreInfo.postKey = @"location";
            if([[dbDic objectForKey:moreInfo.postKey] length]==0) {
                moreInfo.title = @"";
                moreInfo.isSelected = NO;
            }else{
                moreInfo.title = [dbDic objectForKey:moreInfo.postKey];
                moreInfo.isSelected = YES;
            }

            [self.moreInfoDataArr addObject:moreInfo];

            AddMoreMeetInfoModel *moreInfo3 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo3.title = @"设置私人活动（不显示在首页）";
            moreInfo3.postKey = @"openstatus";
            if([[dbDic objectForKey:moreInfo3.postKey] isEqualToString:@"0"]) {
                moreInfo3.isSelected = YES;
            }else{
                moreInfo3.isSelected = NO;
            }
            
            moreInfo3.uiType = 2;
            [self.moreInfoDataArr addObject:moreInfo3];
            
        }
            break;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        {
           
            AddMoreMeetInfoModel *moreInfo5 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo5.placeHolder = @"会议详情，详细说明时间，地点，时间";
            moreInfo5.isSelected = NO;
            moreInfo5.isSection = YES;
            moreInfo5.uiType = TextView;
            [self.moreInfoDataArr addObject:moreInfo5];

            AddMoreMeetInfoModel *moreInfo = [[AddMoreMeetInfoModel alloc]init];
            moreInfo.placeHolder = @"输入活动地址";
           
            moreInfo.isSection = YES;
            moreInfo.postKey = @"location";
            moreInfo.uiType = TextField;
            if([[dbDic objectForKey:moreInfo.postKey] length]==0) {
                moreInfo.title = @"";
                moreInfo.isSelected = NO;
            }else{
                moreInfo.title = [dbDic objectForKey:moreInfo.postKey];
                moreInfo.isSelected = YES;
            }

            [self.moreInfoDataArr addObject:moreInfo];

            
            AddMoreMeetInfoModel *moreInfo0 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo0.title = @"参会者报名字段";
            moreInfo0.isSelected = NO;
            moreInfo0.uiType = TitleLB;
            [self.moreInfoDataArr addObject:moreInfo0];
            
            AddMoreMeetInfoModel *moreInfo1 = [[AddMoreMeetInfoModel alloc]init];
            
            moreInfo1.postKey = @"partake_end_time";
            
            moreInfo1.uiType = TimeView;
            if ([[dbDic objectForKey:@"partake_end_time"] length]==0) {
                moreInfo1.title = @"报名截止时间";
                moreInfo1.isSelected = NO;
            }else{
                moreInfo1.title = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[dbDic objectForKey:@"partake_end_time"]];
                moreInfo1.isSelected = YES;
                moreInfo1.time = [dbDic objectForKey:@"partake_end_time"];
            }
            [self.moreInfoDataArr addObject:moreInfo1];

            AddMoreMeetInfoModel *moreInfo2 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo2.title = @"报名成功后需填写回执信息";
            moreInfo2.isSelected = NO;
            moreInfo2.uiType = 3;
            [self.moreInfoDataArr addObject:moreInfo2];
            
            AddMoreMeetInfoModel *moreInfo3 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo3.title = @"选择会议功能插件";
            moreInfo3.isSelected = NO;
            moreInfo3.uiType = 2;
            [self.moreInfoDataArr addObject:moreInfo3];
            
            AddMoreMeetInfoModel *moreInfo4 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo4.title = @"是否非公开（不显示在广场页）";

            moreInfo4.uiType = 2;
            moreInfo4.postKey = @"openstatus";
            if([[dbDic objectForKey:moreInfo4.postKey] isEqualToString:@"0"]) {
                moreInfo4.isSelected = YES;
            }else{
                moreInfo4.isSelected = NO;
            }
            [self.moreInfoDataArr addObject:moreInfo4];
            
            AddMoreMeetInfoModel *moreInfo10 = [[AddMoreMeetInfoModel alloc]init];
            moreInfo10.title = @"是否显示报名人员信息";
            
            moreInfo10.uiType = 2;
            moreInfo10.postKey = @"personal_data_sw";
            if([[dbDic objectForKey:moreInfo10.postKey] isEqualToString:@"1"]) {
                moreInfo5.isSelected = YES;
            }else{
                moreInfo5.isSelected = NO;
            }
            [self.moreInfoDataArr addObject:moreInfo10];

#pragma mark----------------------------------------------------------
            
            AddMeetInfoModel *accommodationInfo = [[AddMeetInfoModel alloc]init];
            accommodationInfo.title = @"住宿信息";
            accommodationInfo.content = @"用户可以提交住宿信息，主办方为其提供住宿相关事宜。";
            accommodationInfo.postKey = @"houseinfo";
            accommodationInfo.imageName = @"adress";
            NSDictionary *dbfieldArr = [[dbDic objectForKey:@"fieldArr"] JSONValue];
            if([[dbfieldArr objectForKey:accommodationInfo.postKey] isEqualToString:@"1"]) {
                accommodationInfo.isSelected = YES;
            }else{
                accommodationInfo.isSelected = NO;
            }
            [self.meetBackInfoArr addObject:accommodationInfo];
            AddMeetInfoModel *trafficInfo = [[AddMeetInfoModel alloc]init];
            trafficInfo.title = @"交通信息";
            trafficInfo.postKey = @"goback";
            trafficInfo.content = @"用户可以提交往返信息，主办方为其提供接送服务。";
            trafficInfo.imageName = @"traffic";
            if([[dbfieldArr objectForKey:trafficInfo.postKey] isEqualToString:@"1"]) {
                trafficInfo.isSelected = YES;
            }else{
                trafficInfo.isSelected = NO;
            }
            [self.meetBackInfoArr addObject:trafficInfo];
            
            AddMeetInfoModel *plug1Info = [[AddMeetInfoModel alloc]init];
            plug1Info.title = @"会议议程";
            plug1Info.postKey = @"meetingAgenda";
            plug1Info.content = @"您可以配置会议或活动的议程安排，包括议程的简介、每个议程的演讲嘉宾。";
            plug1Info.imageName = @"plug_info_01";
            if([[dbfieldArr objectForKey:plug1Info.postKey] isEqualToString:@"1"]) {
                plug1Info.isSelected = YES;
            }else{
                plug1Info.isSelected = NO;
            }
            [self.pluginInfoArr addObject:plug1Info];
            
            AddMeetInfoModel *plug2Info = [[AddMeetInfoModel alloc]init];
            plug2Info.title = @"交通指南";
            plug2Info.postKey = @"trafficGuide";
            plug2Info.content = @"您可以在地图上标记酒店或会场的位置，也可以发布一些列现场的布局图。";
            plug2Info.imageName = @"plug_info_02";
            if([[dbfieldArr objectForKey:plug2Info.postKey] isEqualToString:@"1"]) {
                plug2Info.isSelected = YES;
            }else{
                plug2Info.isSelected = NO;
            }
            [self.pluginInfoArr addObject:plug2Info];
            
            AddMeetInfoModel *plug3Info = [[AddMeetInfoModel alloc]init];
            plug3Info.title = @"参会人员";
            plug3Info.postKey = @"participants";
            plug3Info.content = @"将参会的重量级嘉宾介绍给大家吧。";
            plug3Info.imageName = @"plug_info_03";
            if([[dbfieldArr objectForKey:plug3Info.postKey] isEqualToString:@"1"]) {
                plug3Info.isSelected = YES;
            }else{
                plug3Info.isSelected = NO;
            }
            [self.pluginInfoArr addObject:plug3Info];
            
            AddMeetInfoModel *plug4Info = [[AddMeetInfoModel alloc]init];
            plug4Info.title = @"会议资料";
            plug4Info.postKey = @"meetingInfo";
            plug4Info.content = @"让参会者提前了解会议和活动的相关文档。";
            plug4Info.imageName = @"plug_info_04";
            if([[dbfieldArr objectForKey:plug4Info.postKey] isEqualToString:@"1"]) {
                plug4Info.isSelected = YES;
            }else{
                plug4Info.isSelected = NO;
            }
            [self.pluginInfoArr addObject:plug4Info];
            
            AddMeetInfoModel *plug5Info = [[AddMeetInfoModel alloc]init];
            plug5Info.title = @"会议服务";
            plug5Info.postKey = @"meetingService";
            plug5Info.content = @"您可以发布多条会议或活动的最新公告。";
            plug5Info.imageName = @"plug_info_05";
            if([[dbfieldArr objectForKey:plug5Info.postKey] isEqualToString:@"1"]) {
                plug5Info.isSelected = YES;
            }else{
                plug5Info.isSelected = NO;
            }
            [self.pluginInfoArr addObject:plug5Info];
        }
            break;
        default:
            break;
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
