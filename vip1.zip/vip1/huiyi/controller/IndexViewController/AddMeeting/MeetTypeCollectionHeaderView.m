//
//  MeetTypeCollectionHeaderView.m
//  huiyi
//
//  Created by 林伟强 on 16/7/28.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "MeetTypeCollectionHeaderView.h"

@implementation MeetTypeCollectionHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self = [self sharedInit];
    }
    return self;
}

- (id)initWithCoder: (NSCoder *)aDecoder {
    self = [super initWithCoder: aDecoder];
    if (self) {
        self = [self sharedInit];
    }
    return self;
}

- (id)sharedInit {
    self.backgroundColor = [UIColor whiteColor];
    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, ScreenWidth-40, 40)];
    [self.titleLabel setFont:[UIFont systemFontOfSize:14.0]];
    [self.titleLabel setTextColor:[UIColor colorWithHexString:@"#686868"]];
    [self.titleLabel setTextAlignment:NSTextAlignmentLeft];
    [self.titleLabel setBackgroundColor:[UIColor clearColor]];
    [self addSubview:self.titleLabel];
    return self;
}

@end
