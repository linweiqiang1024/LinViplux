//
//  PluginView.h
//  huiyi
//
//  Created by songhongshuai on 16/1/21.
//  Copyright © 2016年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PluginView : UIView
@property (nonatomic,strong)NSArray *pluginItems;
@end
