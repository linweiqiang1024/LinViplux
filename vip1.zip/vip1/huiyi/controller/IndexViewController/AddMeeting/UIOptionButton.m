//
//  UIOptionButton.m
//  huiyi
//
//  Created by qstx1 on 14-10-31.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "UIOptionButton.h"

@implementation UIOptionButton


- (void)drawRect:(CGRect)rect {
    
    [self.imageView.layer setCornerRadius:CGRectGetHeight([self.imageView bounds])/2];
    self.imageView.layer.masksToBounds = YES;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    

}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        [self.imageView.layer setCornerRadius:CGRectGetHeight([self.imageView bounds])/2];
        self.imageView.layer.masksToBounds = YES;
        self.titleLabel.font = YHUI(12);
        self.titleLabel.frame = CGRectMake(0, 60, self.frame.size.width, 20);
        // Initialization code
    }
    return self;
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect{
    
    
    return CGRectMake(0, 60, self.frame.size.width, 20);
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
       return CGRectMake(18, 14, 45, 45);
}

@end
