//
//  MyNewViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-29.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MyNewViewController.h"
#import "MyBGTableViewCell.h"
#import "ItmeViewController.h"
#import "New_SignUpInfoViewController.h"
#import "EditContentViewController.h"
#import "EidtMeetNameViewController.h"
@interface MyNewViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSArray *_titleArr;
}
@end

@implementation MyNewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _titleArr = @[@"发布时间",@"会议名称",@"会议详情",@"地图上标注位置，可不标",@"报名截止时间"];
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 10)];
    view.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    UITableView *myMeetView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT) style:UITableViewStyleGrouped];
    myMeetView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    myMeetView.separatorStyle = UITableViewCellSeparatorStyleNone;
    myMeetView.dataSource = self;
    myMeetView.delegate = self;

    myMeetView.sectionFooterHeight = 0;
    myMeetView.sectionHeaderHeight = 10;
    [self.view addSubview:myMeetView];
    myMeetView.tableHeaderView = view;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
