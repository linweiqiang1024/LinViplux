//
//  ActSheetCell.h
//  huiyi
//
//  Created by 王振兴 on 15-2-9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActSheetCell : UITableViewCell
@property (nonatomic,strong)UILabel *titleLB;//票名
@property (nonatomic,strong)UILabel *costLB;//票价
@property (nonatomic,strong)UILabel *endTimeLB;//结束时间;
@property (nonatomic,strong)UILabel *introLB;//简介
@property (nonatomic,strong)UIImageView *topRightImage;//右上角的图片
- (void)setIntroHeight:(NSString *)content;
@end
