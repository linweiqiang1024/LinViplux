//
//  MeetTypeViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MeetTypeViewController.h"
#import "MeetTypeTableViewCell.h"
#import "AddMeetViewController.h"
#import "PartyViewController.h"
#import "SiRenViewController.h"
#import "New_indexViewController.h"
#import "TwoMeetStepViewController.h"
#import "CreateOtherMeetPartOneVC.h"//创建除私人会议的界面（新界面）

#import "NewCreateOtherMeetPartOneVC.h"

@interface MeetTypeViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_meetTypeInfoArr;
}
@end

@implementation MeetTypeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.titlelabel.text = @"选择会议类型/活动类型";
    
    [self initData];
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    
    UITableView *meetTypeTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    meetTypeTableView.scrollEnabled = YES;
    meetTypeTableView.backgroundColor = [UIColor clearColor];
    meetTypeTableView.dataSource = self;
    meetTypeTableView.delegate = self;
    meetTypeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:meetTypeTableView];
    
    // Do any additional setup after loading the view.
}

- (void)initData
{
    _meetTypeInfoArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    /*
    MeetTypeInfo *info1 = [[MeetTypeInfo alloc]init];
    info1.title = @"朋友聚会";
    info1.subtitle = @"召集小伙伴们,聚餐,K歌,桌游,一起玩耍啦！";
    info1.headImage = [UIImage imageNamed:@"meet_type_01"];
    [_meetTypeInfoArr addObject:info1];
    
    MeetTypeInfo *info2 = [[MeetTypeInfo alloc]init];
    info2.title = @"内部会议";
    info2.subtitle = @"组织年会、工作会、内部交流会,轻松举办！";
    info2.headImage = [UIImage imageNamed:@"meet_type_02"];
    [_meetTypeInfoArr addObject:info2];
    
    MeetTypeInfo *info3 = [[MeetTypeInfo alloc]init];
    info3.title = @"沙龙、论坛、联谊活动";
    info3.subtitle = @"搭建沟通交流平台,让您结识更多小伙伴哦！";
    info3.headImage = [UIImage imageNamed:@"meet_type_03"];
    [_meetTypeInfoArr addObject:info3];
    
    MeetTypeInfo *info4 = [[MeetTypeInfo alloc]init];
    info4.title = @"研讨会、培训活动";
    info4.subtitle = @"轻松组织专业研讨会、各类培训活动！";
    info4.headImage = [UIImage imageNamed:@"meet_type_04"];
    [_meetTypeInfoArr addObject:info4];
    
    MeetTypeInfo *info5 = [[MeetTypeInfo alloc]init];
    info5.title = @"项目路演、招商引才活动";
    info5.subtitle = @"搭建永不落幕的项目路演、招商引才活动！";
    info5.headImage = [UIImage imageNamed:@"meet_type_05"];
    [_meetTypeInfoArr addObject:info5];
    
    MeetTypeInfo *info6 = [[MeetTypeInfo alloc]init];
    info6.title = @"旅游、体育活动";
    info6.subtitle = @"旅游、体育赛事活动组织,同样轻松便捷！";
    info6.headImage = [UIImage imageNamed:@"meet_type_06"];
    [_meetTypeInfoArr addObject:info6];
    
    MeetTypeInfo *info7 = [[MeetTypeInfo alloc]init];
    info7.title = @"展览、交易、洽谈会";
    info7.subtitle = @"高效组织各种展览交流会、交易会、贸易洽谈会！";
    info7.headImage = [UIImage imageNamed:@"meet_type_07"];
    [_meetTypeInfoArr addObject:info7];*/
    
    MeetTypeInfo *info2 = [[MeetTypeInfo alloc]init];
    info2.title = @"创建会议/活动";
    info2.headImage = [UIImage imageNamed:@"meet_type_02"];
    [_meetTypeInfoArr addObject:info2];
    
    MeetTypeInfo *info1 = [[MeetTypeInfo alloc]init];
    info1.title = @"创建朋友聚会";
    info1.headImage = [UIImage imageNamed:@"meet_type_01"];
    [_meetTypeInfoArr addObject:info1];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _meetTypeInfoArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 65;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MeetTypeInfo * info = [_meetTypeInfoArr objectAtIndex:indexPath.row];
    
    static NSString * CellIdentifier = @"meetTypeCell";
    
    MeetTypeTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        cell = [[MeetTypeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.row == 0)
    {
        cell.isHead = YES;
    }
    else
    {
        cell.isHead = NO;
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleLB.text = info.title;
    //cell.subTitleLB.text = info.subtitle;
    cell.headImageView.image = info.headImage;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MeetTypeInfo * info = [_meetTypeInfoArr objectAtIndex:indexPath.row];
    
    /*
    if (indexPath.row == 0)
    {
        //New_indexViewController *partyVC = [[New_indexViewController alloc]init];
        //[self.navigationController pushViewController:partyVC animated:YES];
        
        CreateOtherMeetPartOneVC *partOneVC = [[CreateOtherMeetPartOneVC alloc]init];
        partOneVC.type = indexPath.row+1;
        partOneVC.titleName = info.title;
        [self.navigationController pushViewController:partOneVC animated:YES];
    }
    else
    {
        SiRenViewController *partyVC = [[SiRenViewController alloc]init];
        partyVC.type = indexPath.row;
        partyVC.titleName = info.title;
        [self.navigationController pushViewController:partyVC animated:YES];
    }*/
    
    NewCreateOtherMeetPartOneVC *partOneVC = [[NewCreateOtherMeetPartOneVC alloc]init];
    partOneVC.titleName = info.title;
    partOneVC.type = indexPath.row;
    [self.navigationController pushViewController:partOneVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
