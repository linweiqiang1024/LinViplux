//
//  TimeAndAddress.m
//  huiyi
//
//  Created by 王振兴 on 15-1-21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "TimeAndAddress.h"
#import "UIImageView+WebCache.h"
#import "NSString+Size.h"
#import "UITypeButton.h"
#import "UICostTypeButton.h"

#import <objc/runtime.h>

@implementation TimeAndAddress
{
    //1
    UILabel *_activeTime;
    UIImageView *_activeStartIcon;
    UIImageView *_activeEndIcon;
    UIImageView *_activeMidIcon;
    UILabel *_startLB;
    UIView *_endLBBGView;//对结束时间特殊处理
    UILabel *_endLB;
    UILabel *_addressLB;
    UIView *_line1;
    
    //2
    UILabel *_creatorLB;
    UIButton *_creatorPhone;
    UIButton *_creatorUser_id;
    UILabel *_companyLB;//
    UILabel *_organerLB;
    UIView *_companyLBBG;//
    UIView *_organerLBBG;//
    UILabel *_serviceLB;
    UIView *_line2;
    UIView *_line3;
    UIView *_line4;
    
    UILabel *_serviceStay;//住宿图片
    UILabel *_serviceShutle;//接送图片
    
    //3  两大块View
    UIView *_topView;
    UIView *_bottomView;
    UIView *_sirenBottomView;
    
    
    //4  私人部分的特殊UI
    UILabel *_sirenActiveType;//活动类型
    UILabel *_sirenActiveCost;//费用
    UIView *_line5;
    UIView *_line6;
    UIView *_line7;
    
    NSString *_phone;
    NSString *_user_id;
    NSString *_user_name;
    NSString *_group_id;
    NSString *_group_name;
    
    NSString *_meet_type;
    
    //5  群组方面的UI
    UILabel *_goupTitle;
    UIView *_line8;
    
}
#define FontSize 16
#define StartAndEndSize 17
- (void)createTopViewUIWithMeet_type:(NSString *)meet_type{
    
    _topView = [[UIView alloc]init];
    _topView.backgroundColor = [UIColor whiteColor];
    if ([meet_type isEqualToString:@"1"]) {
        _topView.frame = CGRectMake(-0.5, 0, ScreenWidth+1, 326);
    }
    else{
        _topView.frame = CGRectMake(-0.5, 0, ScreenWidth+1, 206);
    }
    
    _topView.layer.borderColor = [[UIColor colorWithHexString:@"#c8c7cc"]CGColor];
    _topView.layer.borderWidth = 0.5;
    [self addSubview:_topView];
    
    _activeTime = [[UILabel alloc]init];
    _activeTime.frame = CGRectMake(18, 12, 100, 18);
    _activeTime.backgroundColor = [UIColor clearColor];
    _activeTime.font = YHUI_BOLD(FontSize);
    _activeTime.text = @"活动时间";
    _activeTime.textColor = [UIColor blackColor];
    [_topView addSubview:_activeTime];
    
    self.viewSurPlusDays = [[UILabel alloc]init];
    self.viewSurPlusDays.frame = CGRectMake(CGRectGetMaxX(_activeTime.frame), 12, ScreenWidth-17-118, 18);
    self.viewSurPlusDays.textAlignment = NSTextAlignmentRight;
    self.viewSurPlusDays.text = @"";
    self.viewSurPlusDays.backgroundColor = [UIColor clearColor];
    self.viewSurPlusDays.font = [UIFont systemFontOfSize:FontSize];
    self.viewSurPlusDays.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    [_topView addSubview:self.viewSurPlusDays];
    
    _activeStartIcon = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"meetInfo_start"]];
    _activeStartIcon.frame = CGRectMake(20, CGRectGetMaxY(_activeTime.frame)+22, 11, 11);
    _activeStartIcon.backgroundColor = [UIColor clearColor];
    [_topView addSubview:_activeStartIcon];
    
    _startLB = [[UILabel alloc]init];
    _startLB.frame = CGRectMake(CGRectGetMaxX(_activeStartIcon.frame)+8, CGRectGetMaxY(_activeTime.frame)+19.5, 34, 18);
    _startLB.backgroundColor = [UIColor clearColor];
    _startLB.text = @"开始";
    _startLB.textColor = [UIColor blackColor];
    _startLB.font = [UIFont systemFontOfSize:FontSize];
    [_topView addSubview:_startLB];
    
    self.viewStartTime = [[UILabel alloc]init];
    self.viewStartTime.frame = CGRectMake(CGRectGetMaxX(_startLB.frame)+8, CGRectGetMaxY(_activeTime.frame)+21.5, 125, 14);
    self.viewStartTime.backgroundColor = [UIColor clearColor];
    self.viewStartTime.text = @"";
    self.viewStartTime.textColor = [UIColor blackColor];
    self.viewStartTime.font = [UIFont systemFontOfSize:14];
    [_topView addSubview:self.viewStartTime];
    
    _activeMidIcon = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"meetInfo_dian"]];
    _activeMidIcon.frame = CGRectMake(23.5, CGRectGetMaxY(_activeStartIcon.frame)+2, 4, 37);
    _activeMidIcon.backgroundColor = [UIColor clearColor];
    [_topView addSubview:_activeMidIcon];
    
    _activeEndIcon = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"meetInfo_end"]];
    _activeEndIcon.frame = CGRectMake(20, CGRectGetMaxY(_startLB.frame)+37, 11, 11);
    _activeEndIcon.backgroundColor = [UIColor clearColor];
    [_topView addSubview:_activeEndIcon];
    
    _endLBBGView = [[UIView alloc]init];
    _endLBBGView.backgroundColor = [UIColor clearColor];
    _endLBBGView.frame = CGRectMake(CGRectGetMaxX(_activeStartIcon.frame)+8, CGRectGetMaxY(_startLB.frame), ScreenWidth -80, 50);
    [_topView addSubview:_endLBBGView];
    
    _endLB = [[UILabel alloc]init];
    _endLB.frame = CGRectMake(CGRectGetMaxX(_activeEndIcon.frame)+8, CGRectGetMaxY(_startLB.frame)+33, 34, 18);
    _endLB.backgroundColor = [UIColor clearColor];
    _endLB.text = @"结束";
    _endLB.textColor = [UIColor blackColor];
    _endLB.font = [UIFont systemFontOfSize:FontSize];
    [_topView addSubview:_endLB];
    
    self.viewEndTime = [[UILabel alloc]init];
    self.viewEndTime.frame = CGRectMake(CGRectGetMaxX(_startLB.frame)+8, CGRectGetMaxY(_startLB.frame)+35, 125, 14);
    self.viewEndTime.backgroundColor = [UIColor clearColor];
    self.viewEndTime.text = @"";
    self.viewEndTime.textColor = [UIColor blackColor];
    self.viewEndTime.font = [UIFont systemFontOfSize:14];
    [_topView addSubview:self.viewEndTime];

    //地址上边的线
    _line1 = [[UIView alloc]init];
    _line1.frame = CGRectMake(18, CGRectGetMaxY(_endLBBGView.frame)+9, ScreenWidth-18, 0.5);
    _line1.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_topView addSubview:_line1];
    
    _addressLB = [[UILabel alloc]init];
    _addressLB.frame = CGRectMake(18, CGRectGetMaxY(_line1.frame)+12.5, 100, 18);
    _addressLB.backgroundColor = [UIColor clearColor];
    _addressLB.text = @"地点";
    _addressLB.textColor = [UIColor blackColor];
    _addressLB.font = YHUI_BOLD(FontSize);;
    [_topView addSubview:_addressLB];
    
    self.viewAddress = [[UILabel alloc]init];
    self.viewAddress.frame = CGRectMake(18, CGRectGetMaxY(_addressLB.frame)+15, ScreenWidth-36, 18);
    self.viewAddress.numberOfLines = 0;
    self.viewAddress.backgroundColor = [UIColor clearColor];
    self.viewAddress.text = @"";
    self.viewAddress.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    self.viewAddress.font = [UIFont systemFontOfSize:FontSize];
    [_topView addSubview:self.viewAddress];
    
    if ([meet_type isEqualToString:@"1"]) {
        [self createSIRenPartUI];
    }
}
//私人会议部分的特殊UI
- (void)createSIRenPartUI{
    
    _sirenBottomView = [[UIView alloc]init];
    _sirenBottomView.backgroundColor = [UIColor whiteColor];
    _sirenBottomView.frame = CGRectMake(0, CGRectGetMaxY(self.viewAddress.frame), ScreenWidth, 145 + 42);
    [_topView addSubview:_sirenBottomView];
    
    //地址下边的线
    _line5 = [[UIView alloc]init];
    _line5.frame = CGRectMake(18, 9, ScreenWidth-18, 0.5);
    _line5.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_sirenBottomView addSubview:_line5];
    
    _sirenActiveType = [[UILabel alloc]init];
    _sirenActiveType.frame = CGRectMake(18, CGRectGetMaxY(_line5.frame)+12.5, 72, 18);
    _sirenActiveType.backgroundColor = [UIColor clearColor];
    _sirenActiveType.text = @"活动类型";
    _sirenActiveType.textColor = [UIColor blackColor];
    _sirenActiveType.font = YHUI_BOLD(FontSize);;
    [_sirenBottomView addSubview:_sirenActiveType];
    
    self.viewSirenActiveType = [[UILabel alloc]init];
    self.viewSirenActiveType.frame = CGRectMake(CGRectGetMaxX(_sirenActiveType.frame), CGRectGetMaxY(_line5.frame)+12.5, ScreenWidth-_sirenActiveType.frame.size.width-10, 18);
    self.viewSirenActiveType.backgroundColor = [UIColor clearColor];
    self.viewSirenActiveType.text = @"";
    self.viewSirenActiveType.textColor = [UIColor blackColor];
    self.viewSirenActiveType.font = [UIFont systemFontOfSize:FontSize];
    [_sirenBottomView addSubview:self.viewSirenActiveType];

    _line6 = [[UIView alloc]init];
    _line6.frame = CGRectMake(18, CGRectGetMaxY(self.viewSirenActiveType.frame)+9, ScreenWidth-18, 0.5);
    _line6.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_sirenBottomView addSubview:_line6];
    
    _creatorLB = [[UILabel alloc]init];
    _creatorLB.frame = CGRectMake(18, CGRectGetMaxY(_line6.frame)+12.5, 55, 18);
    _creatorLB.backgroundColor = [UIColor clearColor];
    _creatorLB.font = YHUI_BOLD(FontSize);;
    _creatorLB.text = @"发起者";
    _creatorLB.textColor = [UIColor blackColor];
    [_sirenBottomView addSubview:_creatorLB];
    //用户头像
    self.viewUserPhoto = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"touxiang262"]];
    self.viewUserPhoto.frame = CGRectMake(CGRectGetMaxX(_creatorLB.frame)+8, CGRectGetMaxY(_line6.frame)+4.5, 34, 34);
    self.viewUserPhoto.layer.cornerRadius = 17;
    self.viewUserPhoto.layer.masksToBounds = YES;
    self.viewUserPhoto.backgroundColor = [UIColor clearColor];
    [_sirenBottomView addSubview:self.viewUserPhoto];
    //用户名儿
    self.viewUserName = [[UILabel alloc]init];
    self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, CGRectGetMaxY(_line6.frame)+12.5, ScreenWidth-230, 18);
    self.viewUserName.backgroundColor = [UIColor clearColor];
    self.viewUserName.font = [UIFont systemFontOfSize:FontSize];
    self.viewUserName.text = @"";
    self.viewUserName.textColor = [UIColor blackColor];
    [_sirenBottomView addSubview:self.viewUserName];
    //电话
    _creatorPhone = [UIButton buttonWithType:UIButtonTypeCustom];
    _creatorPhone.frame = CGRectMake(ScreenWidth-110, CGRectGetMaxY(_line6.frame)+4.5, 34, 34);
    [_creatorPhone addTarget:self action:@selector(phone) forControlEvents:UIControlEventTouchUpInside];
    [_creatorPhone setImage:[UIImage imageNamed:@"meetInfo_phone"] forState:UIControlStateNormal];
    _creatorPhone.backgroundColor = [UIColor clearColor];
    [_sirenBottomView addSubview:_creatorPhone];
    //聊天
    _creatorUser_id = [UIButton buttonWithType:UIButtonTypeCustom];
    _creatorUser_id.frame = CGRectMake(CGRectGetMaxX(_creatorPhone.frame)+5, CGRectGetMaxY(_line6.frame)+7.5, 61, 27);
    [_creatorUser_id setBackgroundImage:[UIImage imageNamed:@"private_chat_btn"] forState:UIControlStateNormal];
    [_creatorUser_id setTitle:@"聊天" forState:UIControlStateNormal];
    [_creatorUser_id setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_creatorUser_id addTarget:self action:@selector(chat) forControlEvents:UIControlEventTouchUpInside];
    _creatorUser_id.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    _creatorUser_id.backgroundColor = [UIColor clearColor];
    [_sirenBottomView addSubview:_creatorUser_id];
    
    _line7 = [[UIView alloc]init];
    _line7.frame = CGRectMake(18, CGRectGetMaxY(_creatorLB.frame)+12.5, ScreenWidth-18, 0.5);
    _line7.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_sirenBottomView addSubview:_line7];
    
    _goupTitle = [[UILabel alloc]init];
    _goupTitle.frame = CGRectMake(18, CGRectGetMaxY(_line7.frame)+12.5, 55, 18);
    _goupTitle.backgroundColor = [UIColor clearColor];
    _goupTitle.font = YHUI_BOLD(FontSize);;
    _goupTitle.text = @"活动群";
    _goupTitle.textColor = [UIColor blackColor];
    [_sirenBottomView addSubview:_goupTitle];
    
    //群头像
    self.viewGroupIcon = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pic_1234"]];
    self.viewGroupIcon.frame = CGRectMake(CGRectGetMaxX(_goupTitle.frame)+8, CGRectGetMaxY(_line7.frame)+4.5, 34, 34);
    self.viewGroupIcon.layer.cornerRadius = 17;
    self.viewGroupIcon.layer.masksToBounds = YES;
    self.viewGroupIcon.backgroundColor = [UIColor redColor];
    [_sirenBottomView addSubview:self.viewGroupIcon];
    //群名儿
    self.viewGroupCount = [[UILabel alloc]init];
    self.viewGroupCount.frame = CGRectMake(CGRectGetMaxX(self.viewGroupIcon.frame)+8, CGRectGetMaxY(_line7.frame)+12.5, 220+ScreenWidth, 18);
    self.viewGroupCount.backgroundColor = [UIColor clearColor];
    self.viewGroupCount.font = [UIFont systemFontOfSize:FontSize];
    self.viewGroupCount.text = @"群成员";
    self.viewGroupCount.textColor = [UIColor blackColor];
    [_sirenBottomView addSubview:self.viewGroupCount];
    //群聊天
    self.viewGroupChatButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.viewGroupChatButton.frame = CGRectMake(ScreenWidth - 71, CGRectGetMaxY(_line7.frame)+7.5, 61, 27);
    [self.viewGroupChatButton setBackgroundImage:[UIImage imageNamed:@"private_group_btn"] forState:UIControlStateNormal];
    [self.viewGroupChatButton setTitle:@"群聊" forState:UIControlStateNormal];
    [self.viewGroupChatButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.viewGroupChatButton addTarget:self action:@selector(group) forControlEvents:UIControlEventTouchUpInside];
    self.viewGroupChatButton.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    self.viewGroupChatButton.backgroundColor = [UIColor clearColor];
    [_sirenBottomView addSubview:self.viewGroupChatButton];
    
    _line8 = [[UIView alloc]init];
    _line8.frame = CGRectMake(18, CGRectGetMaxY(_goupTitle.frame)+12.5, ScreenWidth-18, 0.5);
    _line8.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_sirenBottomView addSubview:_line8];
    
    
    _sirenActiveCost = [[UILabel alloc]init];
    _sirenActiveCost.frame = CGRectMake(18, CGRectGetMaxY(_line8.frame)+12.5, 36, 18);
    _sirenActiveCost.backgroundColor = [UIColor clearColor];
    _sirenActiveCost.text = @"费用";
    _sirenActiveCost.textColor = [UIColor blackColor];
    _sirenActiveCost.font = YHUI_BOLD(FontSize);;
    [_sirenBottomView addSubview:_sirenActiveCost];
    
    self.viewSirenActiveCost = [[UILabel alloc]init];
    self.viewSirenActiveCost.frame = CGRectMake(18, CGRectGetMaxY(_line8.frame)+12.5, 36, 18);
    self.viewSirenActiveCost.backgroundColor = [UIColor clearColor];
    self.viewSirenActiveCost.text = @"";
    self.viewSirenActiveCost.textColor = [UIColor blackColor];
    self.viewSirenActiveCost.font = [UIFont systemFontOfSize:FontSize];
    [_sirenBottomView addSubview:self.viewSirenActiveCost];
    
}
- (void)group{
    [_delegate sendGroup:_group_id andUserName:_group_name];
}
- (void)chat{
    [_delegate sendChat:_user_id andUserName:_user_name];
}
- (void)phone{
    [_delegate sendPhone:_phone];
}

- (void)createBottomViewUI
{
    _bottomView = [[UIView alloc]init];
    _bottomView.backgroundColor = [UIColor whiteColor];
    _bottomView.frame = CGRectMake(-0.5, CGRectGetMaxY(_topView.frame)+10, ScreenWidth+1, 310);
    _bottomView.layer.borderColor = [[UIColor colorWithHexString:@"#c8c7cc"]CGColor];
    _bottomView.layer.borderWidth = 0.5;
    [self addSubview:_bottomView];
    
    _creatorLB = [[UILabel alloc]init];
    _creatorLB.frame = CGRectMake(18, 21, 55, 18);
    _creatorLB.backgroundColor = [UIColor clearColor];
    _creatorLB.font = YHUI_BOLD(FontSize);;
    _creatorLB.text = @"发起者";
    _creatorLB.textColor = [UIColor blackColor];
    [_bottomView addSubview:_creatorLB];
    
    //用户头像
    self.viewUserPhoto = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"touxiang262"]];
    self.viewUserPhoto.frame = CGRectMake(CGRectGetMaxX(_creatorLB.frame)+8, 12.5, 34, 34);
    self.viewUserPhoto.layer.cornerRadius = 17;
    self.viewUserPhoto.layer.masksToBounds = YES;
    self.viewUserPhoto.backgroundColor = [UIColor redColor];
    [_bottomView addSubview:self.viewUserPhoto];
    
    //用户名儿
    self.viewUserName = [[UILabel alloc]init];
    self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, 21, ScreenWidth-230, 18);
    self.viewUserName.backgroundColor = [UIColor clearColor];
    self.viewUserName.font = [UIFont systemFontOfSize:FontSize];
    self.viewUserName.text = @"";
    self.viewUserName.textColor = [UIColor blackColor];
    [_bottomView addSubview:self.viewUserName];
    //电话
    _creatorPhone = [UIButton buttonWithType:UIButtonTypeCustom];
    _creatorPhone.frame = CGRectMake(ScreenWidth-106, 12.5, 34, 34);
    [_creatorPhone setImage:[UIImage imageNamed:@"meetInfo_phone"] forState:UIControlStateNormal];
    [_creatorPhone addTarget:self action:@selector(phone) forControlEvents:UIControlEventTouchUpInside];
    _creatorPhone.backgroundColor = [UIColor clearColor];
    [_bottomView addSubview:_creatorPhone];
    //聊天
    _creatorUser_id = [UIButton buttonWithType:UIButtonTypeCustom];
    _creatorUser_id.frame = CGRectMake(CGRectGetMaxX(_creatorPhone.frame)+5, 15.5, 61, 27);
    [_creatorUser_id setBackgroundImage:[UIImage imageNamed:@"private_chat_btn"] forState:UIControlStateNormal];
    [_creatorUser_id setTitle:@"聊天" forState:UIControlStateNormal];
    [_creatorUser_id setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_creatorUser_id addTarget:self action:@selector(chat) forControlEvents:UIControlEventTouchUpInside];
    _creatorUser_id.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    _creatorUser_id.backgroundColor = [UIColor clearColor];
    [_bottomView addSubview:_creatorUser_id];
    
    _line2 = [[UIView alloc]init];
    _line2.frame = CGRectMake(18, CGRectGetMaxY(_creatorLB.frame)+17, ScreenWidth-18, 0.5);
    _line2.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_bottomView addSubview:_line2];
    
    _goupTitle = [[UILabel alloc]init];
    _goupTitle.frame = CGRectMake(18, CGRectGetMaxY(_line2.frame)+12.5, 55, 18);
    _goupTitle.backgroundColor = [UIColor clearColor];
    _goupTitle.font = YHUI_BOLD(FontSize);;
    _goupTitle.text = @"活动群";
    _goupTitle.textColor = [UIColor blackColor];
    [_bottomView addSubview:_goupTitle];
    
    //群头像
    self.viewGroupIcon = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"pic_1234"]];
    self.viewGroupIcon.frame = CGRectMake(CGRectGetMaxX(_goupTitle.frame)+8, CGRectGetMaxY(_line2.frame)+4.5, 34, 34);
    self.viewGroupIcon.layer.cornerRadius = 17;
    self.viewGroupIcon.layer.masksToBounds = YES;
    self.viewGroupIcon.backgroundColor = [UIColor clearColor];
    [_bottomView addSubview:self.viewGroupIcon];
    //群名儿
    self.viewGroupCount = [[UILabel alloc]init];
    self.viewGroupCount.frame = CGRectMake(CGRectGetMaxX(self.viewGroupIcon.frame)+8, CGRectGetMaxY(_line2.frame)+12.5, ScreenWidth-210, 18);
    self.viewGroupCount.backgroundColor = [UIColor clearColor];
    self.viewGroupCount.font = [UIFont systemFontOfSize:FontSize];
    self.viewGroupCount.text = @"群成员";
    self.viewGroupCount.textColor = [UIColor blackColor];
    [_bottomView addSubview:self.viewGroupCount];
    //群聊天
    self.viewGroupChatButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.viewGroupChatButton.frame = CGRectMake(ScreenWidth - 67, CGRectGetMaxY(_line2.frame)+7.5, 61, 27);
    [self.viewGroupChatButton setBackgroundImage:[UIImage imageNamed:@"private_group_btn"] forState:UIControlStateNormal];
    [self.viewGroupChatButton setTitle:@"群聊" forState:UIControlStateNormal];
    [self.viewGroupChatButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.viewGroupChatButton addTarget:self action:@selector(group) forControlEvents:UIControlEventTouchUpInside];
    self.viewGroupChatButton.titleLabel.font = [UIFont systemFontOfSize:FontSize];
    self.viewGroupChatButton.backgroundColor = [UIColor clearColor];
    [_bottomView addSubview:self.viewGroupChatButton];
    
    _line8 = [[UIView alloc]init];
    _line8.frame = CGRectMake(18, CGRectGetMaxY(_goupTitle.frame)+12.5, ScreenWidth-18, 0.5);
    _line8.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_bottomView addSubview:_line8];
    
    _companyLBBG = [[UIView alloc]init];
    _companyLBBG.backgroundColor = [UIColor clearColor];
    _companyLBBG.frame = CGRectMake(0, CGRectGetMaxY(_line8.frame), ScreenWidth, 82.5);
    [_bottomView addSubview:_companyLBBG];
    
    _organerLBBG = [[UIView alloc]init];
    _organerLBBG.backgroundColor = [UIColor clearColor];
    _organerLBBG.frame = CGRectMake(0, CGRectGetMaxY(_companyLBBG.frame), ScreenWidth, 82.5);
    [_bottomView addSubview:_organerLBBG];
    
    //主办方
    _companyLB = [[UILabel alloc]init];
    _companyLB.frame = CGRectMake(18, CGRectGetMaxY(_line8.frame)+12, 100, 18);
    _companyLB.backgroundColor = [UIColor clearColor];
    _companyLB.font = YHUI_BOLD(FontSize);
    _companyLB.text = @"主办方";
    _companyLB.textColor = [UIColor blackColor];
    [_bottomView addSubview:_companyLB];
    
    self.viewCompany = [[UILabel alloc]init];
    self.viewCompany.frame = CGRectMake(18, CGRectGetMaxY(_companyLB.frame)+17, ScreenWidth-36, 18);
    self.viewCompany.numberOfLines = 0;
    self.viewCompany.backgroundColor = [UIColor clearColor];
    self.viewCompany.font = [UIFont systemFontOfSize:FontSize];
    self.viewCompany.text = @"dafdasfdafda";
    self.viewCompany.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    [_bottomView addSubview:self.viewCompany];
    
    _line3 = [[UIView alloc]init];
    _line3.frame = CGRectMake(18, CGRectGetMaxY(_companyLBBG.frame), ScreenWidth-18, 0.5);
    _line3.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_bottomView addSubview:_line3];
    
    //承办方
    _organerLB = [[UILabel alloc]init];
    _organerLB.frame = CGRectMake(18, CGRectGetMaxY(_line3.frame)+12, 100, 18);
    _organerLB.backgroundColor = [UIColor clearColor];
    _organerLB.font = YHUI_BOLD(FontSize);
    _organerLB.text = @"承办方";
    _organerLB.textColor = [UIColor blackColor];
    [_bottomView addSubview:_organerLB];
    
    self.viewOrganer = [[UILabel alloc]init];
    self.viewOrganer.frame = CGRectMake(18, CGRectGetMaxY(_organerLB.frame)+17, ScreenWidth-36, 18);
    self.viewOrganer.backgroundColor = [UIColor clearColor];
    self.viewOrganer.font = [UIFont systemFontOfSize:FontSize];
    self.viewOrganer.text = @"";
    self.viewOrganer.numberOfLines = 0;
    self.viewOrganer.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    [_bottomView addSubview:self.viewOrganer];
    
    _line4 = [[UIView alloc]init];
    _line4.frame = CGRectMake(18, CGRectGetMaxY(_organerLBBG.frame), ScreenWidth-18, 0.5);
    _line4.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [_bottomView addSubview:_line4];
    
    //提供服务
    _serviceLB = [[UILabel alloc]init];
    _serviceLB.frame = CGRectMake(18, CGRectGetMaxY(_line4.frame)+12, 100, 18);
    _serviceLB.backgroundColor = [UIColor clearColor];
    _serviceLB.font = YHUI_BOLD(FontSize);;
    _serviceLB.text = @"提供服务";
    _serviceLB.textColor = [UIColor blackColor];
    [_bottomView addSubview:_serviceLB];
    
    _serviceStay = [[UILabel alloc]init];
    _serviceStay.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
    _serviceStay.text = @"提供免费住宿";
    _serviceStay.font = [UIFont systemFontOfSize:FontSize];
    _serviceStay.backgroundColor = [UIColor clearColor];
    _serviceStay.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    [_bottomView addSubview:_serviceStay];
    
    _serviceShutle = [[UILabel alloc]init];
    _serviceShutle.frame = CGRectMake(CGRectGetMaxX(_serviceStay.frame)+23, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
    _serviceShutle.text = @"提供免费接送";
    _serviceShutle.font = [UIFont systemFontOfSize:FontSize];
    _serviceShutle.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    [_bottomView addSubview:_serviceShutle];
}

- (id)initWithType:(NSString *)Meet_type
{
    self = [super init];
    if (self) {
        _meet_type = Meet_type;
        [self createTopViewUIWithMeet_type:Meet_type];
        if ([Meet_type isEqualToString:@"1"]) {
            
        }
        else{
             [self createBottomViewUI];
        }
        
       
    }
    return self;
}

//根据数据源来加载
- (void)getViewHeight:(TimeAndAddressIpa *)ipa callback:(TimeAndAddressHeight)_block
{
    for (UIView * view in self.subviews)
    {
        [view removeFromSuperview];
    }
    
    [self createTopViewUIWithMeet_type:_meet_type];
    
    if ([_meet_type isEqualToString:@"1"])
    {
        
    }
    else
    {
        [self createBottomViewUI];
    }
    
    CGFloat _height = 526;
    
    //1 topView部分
    self.viewStartTime.text = ipa.ipaBegin_time;
    self.viewEndTime.text = ipa.ipaEnd_time;
    self.viewSurPlusDays.text = ipa.ipaSuprPlus_time;
    self.viewAddress.text = ipa.ipaLocation;
    
    _phone = ipa.ipaPhone;
    _user_id = ipa.ipaRcUserId;
    _user_name = ipa.ipaName;
    _group_name = ipa.ipaTitle;
    _group_id = ipa.ipaGroup_id;
    
    if (ipa.ipaPhone.length > 0)
    {
        _creatorPhone.hidden = NO;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, 21, ScreenWidth-230, 18);
    }
    else
    {
        _creatorPhone.hidden = YES;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, 21, ScreenWidth-200, 18);
    }
    
    if ([ipa.ipaPhone_sw isEqualToString:@"0"])
    {
        _creatorPhone.hidden = YES;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, 21, ScreenWidth-200, 18);
    }
    else
    {
        _creatorPhone.hidden = NO;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, 21, ScreenWidth-230, 18);
    }
    
    if (ipa.ipaEnd_time.length == 0 || [ipa.ipaEnd_time isEqualToString:@"0"])
    {
        //如果结束时间为空
        [_endLB removeFromSuperview];
        [self.viewEndTime removeFromSuperview];
        [_activeMidIcon removeFromSuperview];
        [_activeEndIcon removeFromSuperview];
        _activeStartIcon.hidden = YES;
        _startLB.frame = CGRectMake(CGRectGetMinX(_activeStartIcon.frame)-3, CGRectGetMaxY(_activeTime.frame)+19.5, 34, 18);
        self.viewStartTime.frame = CGRectMake(CGRectGetMaxX(_startLB.frame)+8, CGRectGetMaxY(_activeTime.frame)+21.5, 125, 14);
        CGRect frame =_endLBBGView.frame;
        frame.size.height = 0;
        _endLBBGView.frame = frame;
        
        CGRect frame1 = _topView.frame;
        frame1.size.height -= 50;
        _topView.frame = frame1;
        
        _line1.frame = CGRectMake(18, CGRectGetMaxY(_endLBBGView.frame)+9, ScreenWidth-18, 0.5);
        _addressLB.frame = CGRectMake(18, CGRectGetMaxY(_line1.frame)+12.5, 100, 18);
        self.viewAddress.frame = CGRectMake(18, CGRectGetMaxY(_addressLB.frame)+15, ScreenWidth-36, 18);
        _bottomView.frame = CGRectMake(-0.5, CGRectGetMaxY(_topView.frame)+10, ScreenWidth+1, 310);
        _height -= 50;
    }
    
    if (ipa.ipaLocation.length == 0)
    {
        //如果地址为空
        //地址为必传字段，所有该情况不存在
    }
    else
    {
        CGSize size = [ipa.ipaLocation stringSizeWithFont:[UIFont systemFontOfSize:FontSize] constrainedToSize:CGSizeMake(ScreenWidth-36, 200)];
        if (size.height > 18)
        {
            CGRect frame1 = _topView.frame;
            frame1.size.height += size.height-18;
            _topView.frame = frame1;
            self.viewAddress.frame = CGRectMake(18, CGRectGetMaxY(_addressLB.frame)+15, ScreenWidth-36, size.height);
            _bottomView.frame = CGRectMake(-0.5, CGRectGetMaxY(_topView.frame)+10, ScreenWidth+1, 310);
            _height += size.height-18;
        }
    }
    
    //2 bottomView部分
    if ([ipa.ipaIs_in isEqualToString:@"1"])
    {
        self.viewGroupChatButton.hidden = NO;
    }
    else
    {
        self.viewGroupChatButton.hidden = YES;
    }
    
    if ([ipa.ipaCount_user isEqualToString:@"0"] || ipa.ipaCount_user.length == 0 || ipa.ipaCount_user == nil)
    {
        self.viewGroupCount.text = @"群成员";
    }
    else
    {
        self.viewGroupCount.text = [NSString stringWithFormat:@"群成员(%@)",ipa.ipaCount_user];
    }
    
    CGRect frame1 = _bottomView.frame;
    frame1.size.height +=42;
    _bottomView.frame = frame1;
    [self.viewUserPhoto sd_setImageWithURL:[NSURL URLWithString:ipa.ipaIco_file] placeholderImage:[UIImage imageNamed:@"touxiang262"]];
    self.viewUserName.text = ipa.ipaName;
    
    __block NSString * companyStr = [ipa.ipaCompanyList componentsJoinedByString:@"\n"];
    __block NSString * organizerStr = [ipa.ipaOrganizerList componentsJoinedByString:@"\n"];
    
    if (!ipa.ipaPrevColumns.count && companyStr.length == 0 && organizerStr.length == 0 && !ipa.ipaAfterColumns.count && [ipa.ipaShuttle_sw isEqualToString:@"0"] && [ipa.ipaStay_sw isEqualToString:@"0"]) {
        [_line8 removeFromSuperview];
    }
    
    CGFloat ipaPrevTop = CGRectGetMaxY(_line8.frame);
    
    if (ipa.ipaPrevColumns.count)
    {
        for (int i = 0; i < ipa.ipaPrevColumns.count; i++)
        {
            CGFloat ipaPrevHeight = 82.5;
            NSMutableArray * ipaPrevArr = [NSMutableArray arrayWithArray:[[ipa.ipaPrevColumns objectAtIndex:i] objectForKey:@"value"]];
            NSString * ipaPrevStr = [ipaPrevArr componentsJoinedByString:@"\n"];
            CGSize ipaPrevSize = [ipaPrevStr stringSizeWithFont:[UIFont systemFontOfSize:FontSize] constrainedToSize:CGSizeMake(ScreenWidth-36, 20000)];
            if (ipaPrevSize.height > 18)
            {
                ipaPrevHeight += ipaPrevSize.height-18;
            }
            
            UIView * prevView = [[UIView alloc]initWithFrame:CGRectMake(0, ipaPrevTop, ScreenWidth, ipaPrevHeight)];
            prevView.backgroundColor = [UIColor clearColor];
            [_bottomView addSubview:prevView];
            
            UILabel * prevLB = [[UILabel alloc]init];
            prevLB.frame = CGRectMake(18, 12, 100, 18);
            prevLB.backgroundColor = [UIColor clearColor];
            prevLB.font = YHUI_BOLD(FontSize);
            prevLB.text = [[ipa.ipaPrevColumns objectAtIndex:i] objectForKey:@"name"];
            prevLB.textColor = [UIColor blackColor];
            [prevView addSubview:prevLB];
            
            UILabel * prevValue = [[UILabel alloc]init];
            prevValue.frame = CGRectMake(18, CGRectGetMaxY(prevLB.frame)+17, ScreenWidth-36, ipaPrevHeight-82.5+18);
            prevValue.numberOfLines = 0;
            prevValue.backgroundColor = [UIColor clearColor];
            prevValue.font = [UIFont systemFontOfSize:FontSize];
            prevValue.text = ipaPrevStr;
            prevValue.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
            [prevView addSubview:prevValue];
            
            UIView * prevLine = [[UIView alloc]init];
            prevLine.frame = CGRectMake(18, ipaPrevHeight, ScreenWidth-18, 0.5);
            prevLine.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
            [prevView addSubview:prevLine];
            
            if (i == ipa.ipaPrevColumns.count-1 && companyStr.length == 0 && organizerStr.length == 0 && !ipa.ipaAfterColumns.count && [ipa.ipaShuttle_sw isEqualToString:@"0"] && [ipa.ipaStay_sw isEqualToString:@"0"]) {
                [prevLine removeFromSuperview];
            }
            
            ipaPrevTop += ipaPrevHeight;
        }
        
        _height += ipaPrevTop-CGRectGetMaxY(_line8.frame);
        
        CGRect frame3 = _bottomView.frame;
        frame3.size.height += ipaPrevTop-CGRectGetMaxY(_line8.frame);
        _bottomView.frame = frame3;
    }
    
    
    self.viewCompany.text = companyStr;
    if (companyStr.length == 0)
    {
        //如果主办方为空
        [_line3 removeFromSuperview];
        [_companyLB removeFromSuperview];
        [self.viewCompany removeFromSuperview];
        
        CGRect frame = _companyLBBG.frame;
        frame.size.height = 0;
        _companyLBBG.frame = frame;
        
        CGRect frame1 = _bottomView.frame;
        frame1.size.height -=82.5;
        _bottomView.frame = frame1;
        _height -= 82.5;
        
        _companyLBBG.frame = CGRectMake(0, ipaPrevTop, ScreenWidth, 0);
        _organerLBBG.frame = CGRectMake(0, ipaPrevTop, ScreenWidth, 82.5);
        _line3.frame = CGRectMake(18, ipaPrevTop, ScreenWidth-18, 0.5);
        _organerLB.frame = CGRectMake(18, CGRectGetMaxY(_line3.frame)+12, 100, 18);
        self.viewOrganer.frame = CGRectMake(18, CGRectGetMaxY(_organerLB.frame)+17, ScreenWidth-36, 18);
        _line4.frame = CGRectMake(18, CGRectGetMaxY(_organerLBBG.frame), ScreenWidth-18, 0.5);
        _serviceLB.frame = CGRectMake(18, CGRectGetMaxY(_line4.frame)+12, 100, 18);
        _serviceStay.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
        _serviceShutle.frame = CGRectMake(CGRectGetMaxX(_serviceStay.frame)+23, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
    }
    else
    {
        CGSize size = [companyStr stringSizeWithFont:[UIFont systemFontOfSize:FontSize] constrainedToSize:CGSizeMake(ScreenWidth-36, 20000)];
        if (size.height > 18)
        {
            CGRect frame1 = _bottomView.frame;
            frame1.size.height += size.height-18;
            _bottomView.frame = frame1;
            
            _companyLBBG.frame = CGRectMake(0, ipaPrevTop, ScreenWidth, 82.5-18+size.height);
            _organerLBBG.frame = CGRectMake(0, CGRectGetMaxY(_companyLBBG.frame), ScreenWidth, 82.5);
            _companyLB.frame = CGRectMake(18, ipaPrevTop+12, 100, 18);
            self.viewCompany.frame = CGRectMake(18, CGRectGetMaxY(_companyLB.frame)+17, ScreenWidth-36, size.height);
            _line3.frame = CGRectMake(18, CGRectGetMaxY(_companyLBBG.frame), ScreenWidth-18, 0.5);
            _organerLB.frame = CGRectMake(18, CGRectGetMaxY(_line3.frame)+12, 100, 18);
            self.viewOrganer.frame = CGRectMake(18, CGRectGetMaxY(_organerLB.frame)+17, ScreenWidth-36, 18);
            _line4.frame = CGRectMake(18, CGRectGetMaxY(_organerLBBG.frame), ScreenWidth-18, 0.5);
            _serviceLB.frame = CGRectMake(18, CGRectGetMaxY(_line4.frame)+12, 100, 18);
            _serviceStay.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
            _serviceShutle.frame = CGRectMake(CGRectGetMaxX(_serviceStay.frame)+23, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
            _height += size.height-18;
        }
    }
    
    
    self.viewOrganer.text = organizerStr;
    if (organizerStr.length == 0)
    {
        //如果承办方为空
        [_line4 removeFromSuperview];
        [_organerLB removeFromSuperview];
        [self.viewOrganer removeFromSuperview];
        
        CGRect frame = _organerLBBG.frame;
        frame.size.height = 0;
        _organerLBBG.frame = frame;
        
        CGRect frame1 = _bottomView.frame;
        frame1.size.height -=82.5;
        _bottomView.frame = frame1;
        _height -= 82.5;
        
        _line4.frame = CGRectMake(18, CGRectGetMaxY(_organerLBBG.frame), ScreenWidth-18, 0.5);
        _serviceLB.frame = CGRectMake(18, CGRectGetMaxY(_line4.frame)+12, 100, 18);
        _serviceStay.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
        _serviceShutle.frame = CGRectMake(CGRectGetMaxX(_serviceStay.frame)+23, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
        
        if (!ipa.ipaAfterColumns.count && [ipa.ipaShuttle_sw isEqualToString:@"0"] && [ipa.ipaStay_sw isEqualToString:@"0"]) {
            [_line3 removeFromSuperview];
        }
    }
    else
    {
        CGSize size = [organizerStr stringSizeWithFont:[UIFont systemFontOfSize:FontSize] constrainedToSize:CGSizeMake(ScreenWidth-36, 20000)];
        if (size.height > 18)
        {
            CGRect frame1 = _bottomView.frame;
            frame1.size.height += size.height-18;
            _bottomView.frame = frame1;
            
            _organerLBBG.frame = CGRectMake(0, CGRectGetMaxY(_companyLBBG.frame), ScreenWidth, 82.5+size.height-18);
            self.viewOrganer.frame = CGRectMake(18, CGRectGetMaxY(_organerLB.frame)+17, ScreenWidth-36, size.height);
            _line4.frame = CGRectMake(18, CGRectGetMaxY(_organerLBBG.frame), ScreenWidth-18, 0.5);
            _serviceLB.frame = CGRectMake(18, CGRectGetMaxY(_line4.frame)+12, 100, 18);
            _serviceStay.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
            _serviceShutle.frame = CGRectMake(CGRectGetMaxX(_serviceStay.frame)+23, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
            _height += size.height-18;
        }
    }
    
    if (ipa.ipaAfterColumns.count)
    {
        CGFloat ipaAfterTop = CGRectGetMaxY(_line4.frame);
        for (int i = 0; i < ipa.ipaAfterColumns.count; i++)
        {
            CGFloat ipaAfterHeight = 82.5;
            NSMutableArray * ipaAfterArr = [NSMutableArray arrayWithArray:[[ipa.ipaAfterColumns objectAtIndex:i] objectForKey:@"value"]];
            NSString * ipaAfterStr = [ipaAfterArr componentsJoinedByString:@"\n"];
            CGSize ipaAfterSize = [ipaAfterStr stringSizeWithFont:[UIFont systemFontOfSize:FontSize] constrainedToSize:CGSizeMake(ScreenWidth-36, 20000)];
            if (ipaAfterSize.height > 18)
            {
                ipaAfterHeight += ipaAfterSize.height-18;
            }
            
            UIView * afterView = [[UIView alloc]initWithFrame:CGRectMake(0, ipaAfterTop, ScreenWidth, ipaAfterHeight)];
            afterView.backgroundColor = [UIColor clearColor];
            [_bottomView addSubview:afterView];
            
            UILabel * afterLB = [[UILabel alloc]init];
            afterLB.frame = CGRectMake(18, 12, 100, 18);
            afterLB.backgroundColor = [UIColor clearColor];
            afterLB.font = YHUI_BOLD(FontSize);
            afterLB.text = [[ipa.ipaAfterColumns objectAtIndex:i] objectForKey:@"name"];
            afterLB.textColor = [UIColor blackColor];
            [afterView addSubview:afterLB];
            
            UILabel * afterValue = [[UILabel alloc]init];
            afterValue.frame = CGRectMake(18, CGRectGetMaxY(afterLB.frame)+17, ScreenWidth-36, ipaAfterHeight-82.5+18);
            afterValue.numberOfLines = 0;
            afterValue.backgroundColor = [UIColor clearColor];
            afterValue.font = [UIFont systemFontOfSize:FontSize];
            afterValue.text = ipaAfterStr;
            afterValue.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
            [afterView addSubview:afterValue];
            
            UIView * afterLine = [[UIView alloc]init];
            afterLine.frame = CGRectMake(18, ipaAfterHeight, ScreenWidth-18, 0.5);
            afterLine.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
            [afterView addSubview:afterLine];
            
            if (i == ipa.ipaAfterColumns.count-1 && [ipa.ipaShuttle_sw isEqualToString:@"0"] && [ipa.ipaStay_sw isEqualToString:@"0"])
            {
                [afterLine removeFromSuperview];
            }
            
            ipaAfterTop += ipaAfterHeight;
        }
        
        _serviceLB.frame = CGRectMake(18, ipaAfterTop+12, 100, 18);
        _serviceStay.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
        _serviceShutle.frame = CGRectMake(CGRectGetMaxX(_serviceStay.frame)+23, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
        _height += ipaAfterTop-CGRectGetMaxY(_line4.frame);
        
        CGRect frame2 = _bottomView.frame;
        frame2.size.height += ipaAfterTop-CGRectGetMaxY(_line4.frame);
        _bottomView.frame = frame2;
    }
    
    //接送情况
    if ([ipa.ipaShuttle_sw isEqualToString:@"0"] && [ipa.ipaStay_sw isEqualToString:@"0"])
    {
        if (!ipa.ipaAfterColumns.count)
        {
            [_line4 removeFromSuperview];
        }
        
        //不提供接送且不提供住宿
        [_serviceLB removeFromSuperview];
        [_serviceShutle removeFromSuperview];
        [_serviceStay removeFromSuperview];
        
        CGRect frame = _bottomView.frame;
        frame.size.height -= 85.5;
        _bottomView.frame = frame;
        _height -=85.5;
    }
    else if ([ipa.ipaShuttle_sw isEqualToString:@"1"] && [ipa.ipaStay_sw isEqualToString:@"0"])
    {
        //只提供接送
        [_serviceStay removeFromSuperview];
        _serviceShutle.frame = CGRectMake(18, CGRectGetMaxY(_serviceLB.frame)+14, 103, 32);
    }
    else if ([ipa.ipaShuttle_sw isEqualToString:@"0"] && [ipa.ipaStay_sw isEqualToString:@"1"])
    {
        //只提供住宿
        [_serviceShutle removeFromSuperview];
    }
    else
    {
        //即提供接送又提供住宿
    }
    _block(_height + 42);
}

//特殊处理私人会议
- (UIView *)createActivity:(NSString *)activity{//加载会议类型
    UIView *view = [[UIView alloc]init];
    view.frame = CGRectMake(100, CGRectGetMaxY(_line5.frame), ScreenWidth-100, 40);
    view.backgroundColor = [UIColor clearColor];
    NSArray *meettype = [activity componentsSeparatedByString:@","];
    int i=0;
    for (NSString *type in meettype) {
        UITypeButton *meetTypeBtn = [UITypeButton buttonWithType:UIButtonTypeCustom];
        meetTypeBtn.frame = CGRectMake(i*70, 7, 70, 26);
        meetTypeBtn.backgroundColor = [UIColor clearColor];
        [meetTypeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        meetTypeBtn.titleLabel.font = [UIFont systemFontOfSize:FontSize];
        if ([type isEqualToString:@"1"]) {
            [meetTypeBtn setTitle:@"聚餐" forState:UIControlStateNormal];
            [meetTypeBtn setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateNormal];
        }
        else if([type isEqualToString:@"2"])
        {
            [meetTypeBtn setTitle:@"娱乐" forState:UIControlStateNormal];
            [meetTypeBtn setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateNormal];
        }
        else{
            [meetTypeBtn setTitle:@"运动" forState:UIControlStateNormal];
            [meetTypeBtn setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateNormal];
        }
        [view addSubview:meetTypeBtn];
         i++;
    }
    [_sirenBottomView addSubview:view];
    return nil;
}
- (void)createMonney:(NSString *)expense{
    UICostTypeButton *costTypeBtn = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
    if ([expense isEqualToString:@"1"]) {
        costTypeBtn.frame = CGRectMake(CGRectGetMaxX(_sirenActiveCost.frame)+45,CGRectGetMaxY(_line8.frame)+9.5, 56, 24);
        [costTypeBtn setTitle:@"我请客" forState:UIControlStateNormal];
    }
    else if([expense isEqualToString:@"2"]){
        costTypeBtn.frame = CGRectMake(CGRectGetMaxX(_sirenActiveCost.frame)+45,CGRectGetMaxY(_line8.frame)+9.5, 64, 24);
        [costTypeBtn setTitle:@"AA" forState:UIControlStateNormal];
    }
    else if([expense isEqualToString:@"3"])
    {
        costTypeBtn.frame = CGRectMake(CGRectGetMaxX(_sirenActiveCost.frame)+45,CGRectGetMaxY(_line8.frame)+9.5, 86, 24);
        [costTypeBtn setTitle:@"有活动费用" forState:UIControlStateNormal];
    }
    else{
        costTypeBtn.frame = CGRectMake(CGRectGetMaxX(_sirenActiveCost.frame)+45,CGRectGetMaxY(_line8.frame)+9.5, 64, 24);
        [costTypeBtn setTitle:@"待定" forState:UIControlStateNormal];
    }
    costTypeBtn.backgroundColor = [UIColor clearColor];
    costTypeBtn.titleLabel.font = YHUI(16);
    costTypeBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
    [costTypeBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_sirenBottomView addSubview:costTypeBtn];
}
- (void)getSiRenViewHeight:(TimeAndAddressIpa *)ipa callback:(TimeAndAddressHeight)_block{
    
    for(UIView *view in self.subviews){
        [view removeFromSuperview];
    }
    
    [self createTopViewUIWithMeet_type:_meet_type];
    
    CGRect frame1 = _topView.frame;
    frame1.size.height +=  43;
    _topView.frame = frame1;
    if ([_meet_type isEqualToString:@"1"]) {
        
    }
    else{
        [self createBottomViewUI];
    }
    
    CGFloat _height = 327;
    //1 topView部分
    
    self.viewStartTime.text = ipa.ipaBegin_time;
    self.viewEndTime.text = ipa.ipaEnd_time;
    self.viewSurPlusDays.text = ipa.ipaSuprPlus_time;
    self.viewAddress.text = ipa.ipaLocation;
    [self.viewUserPhoto sd_setImageWithURL:[NSURL URLWithString:ipa.ipaIco_file] placeholderImage:[UIImage imageNamed:@"touxiang262"]];
    self.viewUserName.text = ipa.ipaName;
    _phone = ipa.ipaPhone;
    _user_id = ipa.ipaUser_id;
    _user_name = ipa.ipaName;
    _group_id = ipa.ipaGroup_id;
    _group_name = ipa.ipaTitle;
    
    if ([ipa.ipaIs_in isEqualToString:@"1"]) {
        self.viewGroupChatButton.hidden = NO;
    }
    else{
        self.viewGroupChatButton.hidden = YES;
    }
    if ([ipa.ipaCount_user isEqualToString:@"0"]||ipa.ipaCount_user.length == 0 || ipa.ipaCount_user == nil) {
        self.viewGroupCount.text = @"群成员";
    }
    else{
        self.viewGroupCount.text = [NSString stringWithFormat:@"群成员(%@)",ipa.ipaCount_user];
    }
    if (ipa.ipaPhone.length>0) {
        _creatorPhone.hidden = NO;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, CGRectGetMaxY(_line6.frame)+12.5, ScreenWidth-230, 18);
    }
    else{
        _creatorPhone.hidden = YES;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, CGRectGetMaxY(_line6.frame)+12.5, ScreenWidth-200, 18);
    }
    if ([ipa.ipaPhone_sw isEqualToString:@"0"]) {
        _creatorPhone.hidden = YES;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, CGRectGetMaxY(_line6.frame)+12.5, ScreenWidth-200, 18);
    }
    else{
        _creatorPhone.hidden = NO;
        self.viewUserName.frame = CGRectMake(CGRectGetMaxX(self.viewUserPhoto.frame)+8, CGRectGetMaxY(_line6.frame)+12.5, ScreenWidth-230, 18);
    }
    if (ipa.ipaEnd_time.length == 0||[ipa.ipaEnd_time isEqualToString:@"0"]) {//如果结束时间为空
        [_endLB removeFromSuperview];
        [self.viewEndTime removeFromSuperview];
        [_activeMidIcon removeFromSuperview];
        [_activeEndIcon removeFromSuperview];
        
        _activeStartIcon.hidden = YES;
        _startLB.frame = CGRectMake(CGRectGetMinX(_activeStartIcon.frame)-3, CGRectGetMaxY(_activeTime.frame)+19.5, 34, 18);
        self.viewStartTime.frame = CGRectMake(CGRectGetMaxX(_startLB.frame)+8, CGRectGetMaxY(_activeTime.frame)+21.5, 125, 14);
        CGRect frame =_endLBBGView.frame;
        frame.size.height = 0;
        _endLBBGView.frame = frame;
        CGRect frame1 = _topView.frame;
        frame1.size.height -= 50;
        _topView.frame = frame1;
        
        _line1.frame = CGRectMake(18, CGRectGetMaxY(_endLBBGView.frame)+9, ScreenWidth-18, 0.5);
        _addressLB.frame = CGRectMake(18, CGRectGetMaxY(_line1.frame)+12.5, 100, 18);
        self.viewAddress.frame = CGRectMake(18, CGRectGetMaxY(_addressLB.frame)+15, ScreenWidth-36, 18);
        _sirenBottomView.frame = CGRectMake(0, CGRectGetMaxY(self.viewAddress.frame), ScreenWidth, 145 + 42);
        _height -= 50;
    }
    if (ipa.ipaLocation.length == 0) {//如果地址为空
        //地址为必传字段，所有该情况不存在
    }
    else{
        CGSize size = [ipa.ipaLocation stringSizeWithFont:[UIFont systemFontOfSize:FontSize] constrainedToSize:CGSizeMake(ScreenWidth-36, 200)];
        if (size.height>18) {
            CGRect frame1 = _topView.frame;
            frame1.size.height += size.height-18;
            _topView.frame = frame1;
            self.viewAddress.frame = CGRectMake(18, CGRectGetMaxY(_addressLB.frame)+15, ScreenWidth-36, size.height);
            _sirenBottomView.frame = CGRectMake(0, CGRectGetMaxY(self.viewAddress.frame), ScreenWidth, 145+42);
            _height += size.height-18;
        }
    }
    [self createActivity:ipa.ipaActivity];
    [self createMonney:ipa.ipaExpenses];
    _block(_height + 42);
}
@end
