//
//  MoreButtonView.m
//  huiyi
//
//  Created by 王振兴 on 15-1-23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "MoreButtonView.h"

@implementation MoreButtonView
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        _button.frame = CGRectMake(0, 0, ScreenWidth, 48);
        [_button setTitle:@"查看更多" forState:UIControlStateNormal];
        [_button setTitleColor:[UIColor colorWithHexString:@"#1b9ecc"] forState:UIControlStateNormal];
        [_button setImage:[UIImage imageNamed:@"meetInfo_spread"] forState:UIControlStateNormal];
        [_button setImage:[UIImage imageNamed:@"meetInfo_packup"] forState:UIControlStateSelected];
        
        _button.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, _button.imageEdgeInsets.right-140);
        _button.titleEdgeInsets = UIEdgeInsetsMake(0, _button.titleEdgeInsets.left-50, 0, 0);
        
        [self addSubview:_button];
        
        UIView *line = [[UIView alloc]init];
        line.frame = CGRectMake(0, 47.5, ScreenWidth, 0.5);
        line.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
        [self addSubview:line];
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
