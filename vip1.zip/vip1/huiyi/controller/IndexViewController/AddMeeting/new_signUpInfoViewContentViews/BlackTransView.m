//
//  BlackTransView.m
//  huiyi
//
//  Created by 王振兴 on 15-1-21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "BlackTransView.h"
#import "NSString+Size.h"
@implementation BlackTransView
{
    UILabel *readLabel;//文字显示 “阅读”
    UILabel *publishLabel;
    //会议管理界面
    UILabel *shareLabel;//文字显示 “分享”
    UILabel *applyLabel;//文字显示 “报名”
    BOOL _isShowSwitch;//是否显示的是开关按钮
    UIView *_topLine;//上边的线
}
@synthesize isShowBlackTrans = _isShowBlackTrans;
- (void)createUIWithIsShowBlackTrans:(BOOL)isShowBlackTrans {
    UIColor *color;
    if (isShowBlackTrans) {
        color = [UIColor whiteColor];
    }
    else{
        color = [UIColor blackColor];
    }
    _viewTitle = [[UILabel alloc]init];
    _viewTitle.frame = CGRectMake(19, 7.5f, ScreenWidth-30, 21);
    _viewTitle.textColor = color;
    _viewTitle.numberOfLines = 2;
    _viewTitle.font = [UIFont systemFontOfSize:20];
    _viewTitle.lineBreakMode = NSLineBreakByTruncatingTail;
    _viewTitle.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewTitle];
    
    publishLabel = [[UILabel alloc]init];
    publishLabel.frame = CGRectMake(19, CGRectGetMaxY(_viewTitle.frame)+10, 35, 11);
    publishLabel.textColor = color;
    publishLabel.text = @"发布于";
    publishLabel.font = [UIFont systemFontOfSize:11];
    [self addSubview:publishLabel];
    
    _viewTime = [[UILabel alloc]init];
    _viewTime.frame = CGRectMake(CGRectGetMaxX(publishLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 60, 11);
    _viewTime.textColor = color;
    _viewTime.font = [UIFont systemFontOfSize:10];
    _viewTime.lineBreakMode = NSLineBreakByWordWrapping;
    _viewTime.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewTime];
    
    readLabel = [[UILabel alloc]init];
    readLabel.frame = CGRectMake(CGRectGetMaxX(_viewTime.frame)+10, CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
    readLabel.textColor = color;
    readLabel.text = @"阅读";
    readLabel.font = [UIFont systemFontOfSize:11];
    [self addSubview:readLabel];
    
    _viewReadCount = [[UILabel alloc]init];
    _viewReadCount.frame = CGRectMake(CGRectGetMaxX(readLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 66, 11);
    _viewReadCount.textColor = color;
    _viewReadCount.font = [UIFont systemFontOfSize:10];
    _viewReadCount.lineBreakMode = NSLineBreakByWordWrapping;
    _viewReadCount.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewReadCount];
    
    _viewState = [UIButton buttonWithType:UIButtonTypeCustom];
    _viewState.frame = CGRectMake(ScreenWidth-10-55, 35, 55, 18);
    _viewState.titleLabel.font = [UIFont boldSystemFontOfSize:12];
    [_viewState setBackgroundImage:[UIImage imageNamed:@"meetInfo_state"] forState:UIControlStateNormal];
    //[_viewState setBackgroundImage:[UIImage imageNamed:@"signUp_apply_reject"] forState:UIControlStateNormal];
    //[_viewState setTitle:@"进行中" forState:UIControlStateNormal];
    [_viewState setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self addSubview:_viewState];
    
    _bottomLine = [[UIView alloc]init];
    _bottomLine.frame = CGRectMake(0, 59-0.5, ScreenWidth, 0.5);
    [self addSubview:_bottomLine];
    
    _topLine = [[UIView alloc]init];
    _topLine.frame = CGRectMake(0, 0, ScreenWidth, 0.5);
    [self addSubview:_topLine];
    
    if (isShowBlackTrans) {
        _topLine.backgroundColor = [UIColor clearColor];
        _bottomLine.backgroundColor = [UIColor clearColor];
    }
    else{
        _topLine.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
        _bottomLine.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    }
}

- (void)createManagerUI {
    _viewTitle = [[UILabel alloc]init];
    _viewTitle.frame = CGRectMake(10, 7.5f, ScreenWidth-122, 21);
    _viewTitle.textColor = [UIColor whiteColor];
    _viewTitle.numberOfLines = 2;
    _viewTitle.font = [UIFont systemFontOfSize:20];
    _viewTitle.lineBreakMode = NSLineBreakByTruncatingTail;
    _viewTitle.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewTitle];
    
    readLabel = [[UILabel alloc]init];
    readLabel.frame = CGRectMake(10, CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
    readLabel.textColor = [UIColor whiteColor];
    readLabel.text = @"阅读";
    readLabel.font = [UIFont systemFontOfSize:11];
    [self addSubview:readLabel];
    
    _viewReadCount = [[UILabel alloc]init];
    _viewReadCount.frame = CGRectMake(CGRectGetMaxX(readLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 40, 11);
    _viewReadCount.textColor = [UIColor whiteColor];
    _viewReadCount.font = [UIFont systemFontOfSize:10];
    _viewReadCount.lineBreakMode = NSLineBreakByWordWrapping;
    _viewReadCount.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewReadCount];
    
    shareLabel = [[UILabel alloc]init];
    shareLabel.frame = CGRectMake(CGRectGetMaxX(_viewReadCount.frame), CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
    shareLabel.textColor = [UIColor whiteColor];
    shareLabel.text = @"分享";
    shareLabel.font = [UIFont systemFontOfSize:11];
    [self addSubview:shareLabel];
    
    _viewShareLabel = [[UILabel alloc]init];
    _viewShareLabel.frame = CGRectMake(CGRectGetMaxX(shareLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 40, 11);
    _viewShareLabel.textColor = [UIColor whiteColor];
    _viewShareLabel.font = [UIFont systemFontOfSize:10];
    _viewShareLabel.lineBreakMode = NSLineBreakByWordWrapping;
    _viewShareLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewShareLabel];
    
    applyLabel = [[UILabel alloc]init];
    applyLabel.frame = CGRectMake(CGRectGetMaxX(_viewShareLabel.frame), CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
    applyLabel.textColor = [UIColor whiteColor];
    applyLabel.text = @"报名";
    applyLabel.font = [UIFont systemFontOfSize:11];
    [self addSubview:applyLabel];
    
    _viewApplyLabel = [[UILabel alloc]init];
    _viewApplyLabel.frame = CGRectMake(CGRectGetMaxX(applyLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 40, 11);
    _viewApplyLabel.textColor = [UIColor whiteColor];
    _viewApplyLabel.font = [UIFont systemFontOfSize:10];
    _viewApplyLabel.lineBreakMode = NSLineBreakByWordWrapping;
    _viewApplyLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:_viewApplyLabel];
    
    _viewState = [UIButton buttonWithType:UIButtonTypeCustom];
    _viewState.adjustsImageWhenHighlighted = NO;
    _viewState.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    _viewState.frame = CGRectMake(ScreenWidth-10-83, 11.5, 83, 36);
    [_viewState setBackgroundImage:[UIImage imageNamed:@"manager_switch_off"] forState:UIControlStateNormal];
    [_viewState setBackgroundImage:[UIImage imageNamed:@"manager_switch_on"] forState:UIControlStateSelected];
    [_viewState setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self addSubview:_viewState];
}

- (void)setTitles:(NSString *)titles {
    if (titles.length == 0) {
        return;
    }
    
    CGSize size = [titles stringSizeWithFont:_viewTitle.font constrainedToSize:CGSizeMake(_viewTitle.frame.size.width, 100)];
    _viewTitle.text = titles;
    
    if (_isShowSwitch) {
        if (size.height>48.0f) {
            _viewTitle.frame = CGRectMake(10, 7.5f, ScreenWidth-112, 48.0f);
        }
        else {
            _viewTitle.frame = CGRectMake(10, 7.5f, ScreenWidth-112, size.height);
        }
        _viewState.frame = CGRectMake(ScreenWidth-10-83, (self.height-36)/2, 83, 36);
        readLabel.frame = CGRectMake(10, CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
        _viewReadCount.frame = CGRectMake(CGRectGetMaxX(readLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 40, 11);
        shareLabel.frame = CGRectMake(CGRectGetMaxX(_viewReadCount.frame), CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
        _viewShareLabel.frame = CGRectMake(CGRectGetMaxX(shareLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 40, 11);
        applyLabel.frame = CGRectMake(CGRectGetMaxX(_viewShareLabel.frame), CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
        _viewApplyLabel.frame = CGRectMake(CGRectGetMaxX(applyLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 40, 11);
    }
    else {
        if (size.height>48.0f) {
            _viewTitle.frame = CGRectMake(19, 7.5f, ScreenWidth-30, 48.0f);
        }
        else {
            _viewTitle.frame = CGRectMake(19, 7.5f, ScreenWidth-30, size.height);
        }
        _viewState.frame = CGRectMake(ScreenWidth-10-55, CGRectGetMaxY(_viewTitle.frame)+(self.height-CGRectGetMaxY(_viewTitle.frame)-18)/2, 55, 18);
        publishLabel.frame = CGRectMake(19, CGRectGetMaxY(_viewTitle.frame)+10, 35, 11);
        _viewTime.frame = CGRectMake(CGRectGetMaxX(publishLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 60, 11);
        readLabel.frame = CGRectMake(CGRectGetMaxX(_viewTime.frame)+10, CGRectGetMaxY(_viewTitle.frame)+10, 25, 11);
        _viewReadCount.frame = CGRectMake(CGRectGetMaxX(readLabel.frame)+5, CGRectGetMaxY(_viewTitle.frame)+10, 66, 11);
        _bottomLine.frame = CGRectMake(0, self.bounds.size.height-0.5, ScreenWidth, 0.5);
    }
}

- (id)initWithTitle:(NSString *)title andTime:(NSString *)time andReadCount:(NSString *)readCount andState:(NSString *)state andIsShowBlackTrans:(BOOL)isShowBlackTrans andIsShowSwitch:(BOOL)isShow {
    self = [super init];
    if (self) {
        _isShowSwitch = isShow;
        self.userInteractionEnabled = YES;
        if (isShow) {
            [self createManagerUI];
        }
        else{
            [self createUIWithIsShowBlackTrans:isShowBlackTrans];
        }
    }
    return self;
}

@end
