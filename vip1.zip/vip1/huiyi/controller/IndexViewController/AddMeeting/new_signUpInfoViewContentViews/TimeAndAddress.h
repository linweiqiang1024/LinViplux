//
//  TimeAndAddress.h
//  huiyi
//
//  Created by 王振兴 on 15-1-21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TimeAndAddressIpa.h"
typedef void (^TimeAndAddressHeight)(CGFloat height);
@protocol timeAndAddressDelegate <NSObject>

- (void)sendPhone:(NSString *)phone;
- (void)sendChat:(NSString *)user_id andUserName:(NSString *)name;
- (void)sendGroup:(NSString *)group_id andUserName:(NSString *)GroupName;

@end
@interface TimeAndAddress : UIView
{
    TimeAndAddressIpa *_viewIpa;
    __weak id <timeAndAddressDelegate> _delegate;
}
//1
@property (nonatomic,strong)UILabel *viewStartTime;
@property (nonatomic,strong)UILabel *viewEndTime;
@property (nonatomic,strong)UILabel *viewSurPlusDays;//剩余天数
@property (nonatomic,strong)UILabel *viewAddress;//地点

//2
@property (nonatomic,strong)UIImageView *viewUserPhoto;//发起者头像
@property (nonatomic,strong)UILabel *viewUserName;//发起者名称
@property (nonatomic,strong)UILabel *viewCompany;//主办方名称
@property (nonatomic,strong)UILabel *viewOrganer;//承办方名称
//3
@property (nonatomic,strong)TimeAndAddressIpa *viewIpa;//数据模型

//4私人部分
@property (nonatomic,strong)UILabel *viewSirenActiveType;//活动类型
@property (nonatomic,strong)UILabel *viewSirenActiveCost;//活动费用

//5群组部分
@property (nonatomic,strong)UILabel *viewGroupCount;//群组数量
@property (nonatomic,strong)UIButton *viewGroupChatButton;//群聊按钮
@property (nonatomic,strong)UIImageView *viewGroupIcon;//群头像

@property (nonatomic,weak)id <timeAndAddressDelegate> delegate;
- (void)getViewHeight:(TimeAndAddressIpa *)ipa callback:(TimeAndAddressHeight)_block;
- (id)initWithType:(NSString *)Meet_type;
//特殊处理私人会议
- (void)getSiRenViewHeight:(TimeAndAddressIpa *)ipa callback:(TimeAndAddressHeight)_block;
@end
