//
//  TimeAndAddressIpa.h
//  huiyi
//
//  Created by 王振兴 on 15-1-21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeAndAddressIpa : NSObject
@property (nonatomic,strong)NSString *ipaBegin_time;//会议的开始时间
@property (nonatomic,strong)NSString *ipaEnd_time;//会议的结束时间
@property (nonatomic,strong)NSString *ipaSuprPlus_time;//剩余多少天开始
@property (nonatomic,strong)NSString *ipaLocation;//地点
@property (nonatomic,strong)NSString *ipaName;//创建者名称
@property (nonatomic,strong)NSString *ipaRcUserId;//创建者融云的userid
@property (nonatomic,strong)NSString *ipaIco_file;//创建者头像
@property (nonatomic,strong)NSString *ipaUser_id;//创建者id
//@property (nonatomic,strong)NSString *ipaCompany;//主办方
@property (nonatomic,strong)NSArray *ipaCompanyList;//主办方
@property (nonatomic,strong)NSArray *ipaOrganizerList;//协办方（承办方）
//@property (nonatomic,strong)NSString *ipaOrganizer;//协办方（承办方）
@property (nonatomic,strong)NSArray *ipaPrevColumns;
@property (nonatomic,strong)NSArray *ipaAfterColumns;
@property (nonatomic,strong)NSString *ipaStay_sw;//是否提供免费住宿（0不提供1提供）
@property (nonatomic,strong)NSString *ipaShuttle_sw;//是否提供免费接送
@property (nonatomic,strong)NSString *ipaPhone_sw;//是否有电话号码
@property (nonatomic,strong)NSString *ipaPhone;//电话号码

@property (nonatomic,strong)NSString *ipaGroup_id;//群ID
@property (nonatomic,strong)NSString *ipaIs_in;//是否在群里边
@property (nonatomic,strong)NSString *ipaCount_user;//群组人数
@property (nonatomic,strong)NSString *ipaTitle;//会议的名称


//私人部分的 活动类型和费用
@property (nonatomic,strong)NSString *ipaActivity;//会议类型
@property (nonatomic,strong)NSString *ipaExpenses;//费用
@end
