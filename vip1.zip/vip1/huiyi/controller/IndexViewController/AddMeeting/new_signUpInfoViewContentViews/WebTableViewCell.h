//
//  WebTableViewCell.h
//  huiyi
//
//  Created by 王振兴 on 15-1-23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebTableViewCell : UITableViewCell
{
    UIWebView *_webView;
}
@property (nonatomic,strong)UIWebView *webView;
@end
