//
//  BlackTransView.h
//  huiyi
//
//  Created by 王振兴 on 15-1-21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SevenSwitch.h"
@interface BlackTransView : UIImageView
{
    UILabel *_viewTitle;
    UILabel *_viewTime;
    UILabel *_viewReadCount;
    UIButton *_viewState;
    UIView *_bottomLine;//底部的线
    BOOL _isShowBlackTrans;//是否显示半透明
    //会议管理界面
    UILabel *_viewShareLabel;
    UILabel *_viewApplyLabel;
    SevenSwitch *_viewSwitch;
}
- (id)initWithTitle:(NSString *)title andTime:(NSString *)time andReadCount:(NSString *)readCount andState:(NSString *)state  andIsShowBlackTrans:(BOOL)isShowBlackTrans andIsShowSwitch:(BOOL)isShow;
@property (nonatomic,strong)UIButton *viewState;
@property (nonatomic,strong)UILabel *viewTitle;
@property (nonatomic,strong)UILabel *viewTime;
@property (nonatomic,strong)UILabel *viewReadCount;
@property (nonatomic,strong)NSString *titles;
@property (nonatomic,strong)UIView *bottomLine;
@property (nonatomic)BOOL isShowBlackTrans;
@property (nonatomic,strong)UILabel *viewShareLabel;
@property (nonatomic,strong)UILabel *viewApplyLabel;
@property (nonatomic,strong)SevenSwitch *viewSwitch;
@end
