//
//  TimeAndAddressIpa.m
//  huiyi
//
//  Created by 王振兴 on 15-1-21.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "TimeAndAddressIpa.h"

@implementation TimeAndAddressIpa
@synthesize ipaBegin_time,ipaEnd_time,ipaIco_file,ipaLocation,ipaName,ipaShuttle_sw,ipaStay_sw,ipaSuprPlus_time,ipaUser_id,ipaPhone,ipaPhone_sw,ipaActivity = _ipaActivity,ipaExpenses = _ipaExpenses,ipaCount_user= _ipaCount_user,ipaGroup_id = _ipaGroup_id,ipaIs_in = _ipaIs_in,ipaTitle = _ipaTitle;


- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}

@end
