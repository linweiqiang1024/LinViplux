//
//  WebTableViewCell.m
//  huiyi
//
//  Created by 王振兴 on 15-1-23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "WebTableViewCell.h"

@implementation WebTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
