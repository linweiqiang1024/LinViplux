//
//  MoreButtonView.h
//  huiyi
//
//  Created by 王振兴 on 15-1-23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreButtonView : UIView
{
    UIButton *_button;
}
@property (nonatomic,strong)UIButton *button;
@end
