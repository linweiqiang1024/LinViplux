//
//  SignUpFieldsModel.h
//  huiyi
//
//  Created by qstx1 on 14-11-5.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUpFieldsModel : NSObject
{
    int _btnTag;
    BOOL _selected;
    NSString *_title;
    NSString *_postKey;
}
@property (nonatomic) int btnTag;
@property (nonatomic) BOOL selected;
@property (nonatomic,strong)  NSString *title;
@property (nonatomic,strong)  NSString *postKey;

@end
