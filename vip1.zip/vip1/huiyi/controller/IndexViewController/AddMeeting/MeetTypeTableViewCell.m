//
//  MeetTypeTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MeetTypeTableViewCell.h"

@implementation MeetTypeInfo

- (id)init
{
    if (self = [super init]) {
        _title = @"";
        _subtitle = @"";
        _headImage = nil;
    }
    
    return self;
}

@end

@interface MeetTypeTableViewCell()
{
    UIView *headLineLB ;
}
@end

@implementation MeetTypeTableViewCell
@synthesize headImageView = _headImageView;
@synthesize titleLB = _titleLB;
@synthesize subTitleLB = _subTitleLB;
@synthesize goImageView = _goImageView;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    if (self) {
        
        self.contentView.backgroundColor = [UIColor whiteColor];
        
        headLineLB = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(headLineLB, @"#c8c7cc");
        [self.contentView  addSubview:headLineLB];
        
        UIView *endLineLB = [[UIView alloc]initWithFrame:CGRectMake(0, 64.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        self.headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 10, 45, 45)];
        self.headImageView.backgroundColor = [UIColor clearColor];
        self.headImageView.contentMode = UIViewContentModeScaleAspectFit;
        self.headImageView.clipsToBounds = YES;
        [self.contentView addSubview:self.headImageView];
        
        self.titleLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+15, 10, ScreenWidth-20-75, 45)];
        self.titleLB.backgroundColor = [UIColor clearColor];
        self.titleLB.font = YHUI(18);
        self.titleLB.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLB];
        
        /*
        self.subTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+(iphone6Plus?25:20), CGRectGetMaxY(self.titleLB.frame)+8, ScreenWidth-26, 12)];
        self.subTitleLB.backgroundColor = [UIColor clearColor];
        self.subTitleLB.font = YHUI_BOLD(11);
        self.subTitleLB.textColor = [UIColor colorWithHexString:@"#a1a1a1"];
        [self.contentView addSubview:self.subTitleLB];*/
        
        self.goImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-20, (65-17)/2, 10, 17)];
        self.goImageView.image = [UIImage imageNamed:@"go_bg"];//[UIImage imageNamed:@"meet_type_next"];
        self.goImageView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.goImageView];
    }
    
    return self;
}

- (void)setIsHead:(BOOL)isHead
{
    if (isHead) {
        headLineLB.hidden = NO;
    }
    else {
        headLineLB.hidden = YES;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
