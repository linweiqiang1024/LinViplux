//
//  MineBaseMeetInfoModel.h
//  huiyi
//
//  Created by qstx1 on 14-11-6.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MineBaseMeetInfoModel : NSObject
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *content;
@property(nonatomic,strong)NSArray *meetTypeArr;
@property(nonatomic,strong)NSString *costType;
@property(nonatomic,strong)NSArray *pic;//详情图片
@property(nonatomic)BOOL isSelected;
@property(nonatomic) BOOL isShare;//是否显示报名人员信息 状态  by wang zhenxing
@end
