//
//  MineBaseMeetInfoModel.m
//  huiyi
//
//  Created by qstx1 on 14-11-6.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MineBaseMeetInfoModel.h"

@implementation MineBaseMeetInfoModel

@end
