//
//  UIContentView_01.h
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIContentView_01 : UIView{
    BOOL didSetupConstraints;
}
@property (nonatomic,strong)UILabel *nameLB;
@property (nonatomic,strong)UILabel *contentLB;
@property (nonatomic,strong)UILabel *line;
@end
