//
//  SiRenSignUpViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface SiRenSignUpViewController : FatherViewController
{
    NSString *_meetID;
    NSString *_meetTitle;
    NSString *_blockID;
}
@property (nonatomic,strong)NSString *meetID;
@property (nonatomic,strong)NSString *meetTitle;
@property (nonatomic,strong)NSString *blockID;
@property (nonatomic)BOOL isBack;

@end
