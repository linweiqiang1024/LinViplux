//
//  EnjoyTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "EnjoyTableViewCell.h"
#import "MYWebImage.h"
#import <QuartzCore/QuartzCore.h>
@implementation EnjoyTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        BackGroundColor(self.contentView, whiteColor);
        scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 66)];
        scrollView.backgroundColor = [UIColor whiteColor];
        scrollView.showsHorizontalScrollIndicator = NO;
        scrollView.showsVerticalScrollIndicator = NO;
        [self.contentView addSubview:scrollView];
        
        UIView *endLineLB = [[UIView alloc]initWithFrame:CGRectMake(0, 65.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView addSubview:endLineLB];
    }
    
    return self;
}
#define userPhotoWidth 40
- (void)setEnjoyUsers:(NSArray *)enjoyUsers
{
    if (enjoyUsers.count != 0) {
        for(UIView *view in scrollView .subviews){
            [view removeFromSuperview];
        }
        for (int i = 0; i < enjoyUsers.count; i++) {
            UIImageView *userPhotoImageView = [[UIImageView alloc]initWithFrame:CGRectMake(12+(12+userPhotoWidth)*i, 4, userPhotoWidth, userPhotoWidth)];
            userPhotoImageView.backgroundColor = [UIColor clearColor];
           
//            userPhotoImageView.image = PNGIMAGE(@"mine_userheader@2x");
            [userPhotoImageView.layer setCornerRadius:CGRectGetHeight([userPhotoImageView bounds])/2];
            userPhotoImageView.layer.masksToBounds = YES;
             [MYWebImage OneImageView:userPhotoImageView SetImageWithURL:[[enjoyUsers objectAtIndex:i] objectForKey:@"ico_file"] PlaceHolderImageName:@"touxiang262" CacheOrNot:YES];
            [scrollView addSubview:userPhotoImageView];
            
            UILabel *userNameLB = [[UILabel alloc]initWithFrame:CGRectMake(12+(12+userPhotoWidth)*i, 4+userPhotoWidth, userPhotoWidth, 18)];
            userNameLB.backgroundColor = [UIColor clearColor];
            userNameLB.font = YHUI(12);
            userNameLB.text = [[enjoyUsers objectAtIndex:i] objectForKey:@"name"];
            userNameLB.textAlignment = NSTextAlignmentCenter;
            [scrollView addSubview:userNameLB];
        }
        scrollView.contentSize = CGSizeMake(12+(12+userPhotoWidth)*enjoyUsers.count, CGRectGetHeight(scrollView.frame));
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
