//
//  AddMeetSectionBtn.h
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddMeetSectionBtn : UIButton

@end
