//
//  UIContentVIew.m
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIContentVIew.h"
#import "PureLayout.h"
@implementation UIContentVIew
- (id)initWithFrame:(CGRect)frame
{

    self = [super initWithFrame:frame];
    if (self) {
    
        UILabel *topLine = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(topLine, @"#c8c7cc");
        [self  addSubview:topLine];
        
        UILabel *endLine = [[UILabel alloc]initWithFrame:CGRectMake(0, frame.size.height-0.5, ScreenWidth, 0.5)];
        BackGround16Color(endLine, @"#c8c7cc");
        [self  addSubview:endLine];
          }
    return self;
}

@end
