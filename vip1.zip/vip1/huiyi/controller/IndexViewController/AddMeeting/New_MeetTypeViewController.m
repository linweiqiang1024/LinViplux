//
//  New_MeetTypeViewController.m
//  huiyi
//
//  Created by 林伟强 on 16/7/28.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "New_MeetTypeViewController.h"
#import "New_MeetTypeTableViewCell.h"
#import "MeetTypeTableHeaderView.h"
#import "SiRenViewController.h"
#import "CreateOtherMeetPartOneVC.h"//创建除私人会议的界面（新界面）
#import "PostImageTool.h"

static NSString * const kCellIdentifier           = @"MTCellIdentifier";
static NSString * const kHeaderViewCellIdentifier = @"MTHeaderViewCellIdentifier";
static NSString * const kFooterViewCellIdentifier = @"MTFooterViewCellIdentifier";

@interface New_MeetTypeViewController ()<UITableViewDelegate,UITableViewDataSource, UIAlertViewDelegate, MeetTypeTableHeaderViewDelegate>

@property (nonatomic, strong) UITableView      *tableView;
@property (nonatomic, strong) UIView           *tableHeadView;
@property (nonatomic, strong) NSMutableArray   *dataSource;
@property (nonatomic, strong) NSMutableArray   *dataType;
@property (nonatomic, strong) NSMutableArray   *dataMeetType;
@property (nonatomic, strong) NSMutableArray   *dataTag;
@property (nonatomic, strong) NSMutableArray   *customTags;
@property (nonatomic, strong) NSString         *urlString;
@property (nonatomic, assign) CGSize           keyBoardSize;

@property (nonatomic, strong) MeetTypeTableHeaderView *typeHeaderView;
@property (nonatomic, strong) MeetTypeTableHeaderView *tagHeaderView;

@property (nonatomic, strong) UIButton         *nextButton;
@property (nonatomic, strong) UILabel          *nextLabel;

@property (nonatomic, assign) CGFloat           tableViewBeginY;

@end

@implementation New_MeetTypeViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification *)notification {
    
    NSDictionary* info = [notification userInfo];
    self.keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    self.tableView.frame = CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT-self.keyBoardSize.height);
}

- (void)keyboardWillHide:(NSNotification *)notification {
    
    NSDictionary* info = [notification userInfo];
    self.keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    self.tableView.frame = CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titlelabel.text = @"发布活动";
    self.urlString = [Base_URL stringByAppendingString:@"platform/v2meeting/getMeetingLabel"];
    
    self.dataSource = [NSMutableArray array];
    NSMutableArray * array1 = [@[@"项目路演、招商引才活动",@"研讨会、培训活动",@"展览、交易、洽谈会",@"沙龙、论坛、联谊活动",@"内部会议",@"旅游、体育活动",@"朋友聚会"]mutableCopy];
    [self.dataSource addObject:array1];
    NSMutableArray * array2 = [@[@"互联网＋",@"金融&投资",@"体育",@"休闲&户外",@"展览",@"创新&创业",@"人工智能",@"健康&医疗",@"大数据",@"公益&环保",@"娱乐&时尚",@"营销"]mutableCopy];
    [self.dataSource addObject:array2];
    
    self.dataType   = [NSMutableArray array];
    self.dataTag    = [NSMutableArray array];
    self.customTags = [NSMutableArray array];
    
    self.dataType   = [@[@"项目路演·招商引才活动",@"研讨会·培训活动",@"展览·交易·洽谈会",@"沙龙·论坛·联谊活动",@"内部会议",@"旅游·体育活动",@"朋友聚会"]mutableCopy];
    self.customTags = [@[@"",@""]mutableCopy];
    [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
    //[[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"newMeetEdit"];
    [[NSUserDefaults standardUserDefaults] setObject:@"add" forKey:@"customTag"];
    
    self.dataMeetType = [NSMutableArray array];
    self.dataMeetType = [@[@"5",@"4",@"7",@"3",@"2",@"6",@"1"]mutableCopy];
    
    [self addTableView];
    [self getMeetingLabel];
    [self getMeetingLabelData];
}

- (void)getMeetingLabel
{
    [MyDataService postPlatfromV2meetingLabel:@{@"label_version":@"new"} callback:^(id data) {
        if ([data[@"code"]isEqualToString:@"200"]) {
            [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"%@getMeetingLabel",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]];
            [[DBManager sharedInstance]insertDataToPublicDB:[data JSONString]valueKey:[NSString stringWithFormat:@"%@getMeetingLabel",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]];
        }
    }];
    /*
    [PostImageTool MeetingLabelRequestGET:self.urlString WithParameters:nil whenSuccess:^(id responsObject) {
        if ([responsObject[@"code"]isEqualToString:@"200"]) {
            [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"%@getMeetingLabel",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]];
            [[DBManager sharedInstance]insertDataToPublicDB:[responsObject JSONString]valueKey:[NSString stringWithFormat:@"%@getMeetingLabel",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]];
        }
    } orFail:^(id responsObject) {
        
    }];*/
}

- (void)getMeetingLabelData
{
    NSString *jsonStr = [[DBManager sharedInstance]getPublicDBData:[NSString stringWithFormat:@"%@getMeetingLabel",[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]]];
    NSDictionary *data = [jsonStr JSONValue];
    NSString *code = [data objectForKey: @"code"];
    if ([code  isEqualToString: @"200"]) {
        self.dataTag = data[@"content"];
        [self.tableView reloadData];
        
        NSMutableArray *tagDataSource = [NSMutableArray array];
        [tagDataSource addObject:self.dataTag];
        self.tagHeaderView.dataSource = tagDataSource;
        [self.tagHeaderView.collectionView reloadData];
    }
    
    [MyDataService postPlatfromV2meetingLabel:@{@"label_version":@"new"} callback:^(id data) {
        if ([data[@"code"]isEqualToString:@"200"]) {
            self.dataTag = data[@"content"];
            [self.tableView reloadData];
            
            NSMutableArray *tagDataSource = [NSMutableArray array];
            [tagDataSource addObject:self.dataTag];
            self.tagHeaderView.dataSource = tagDataSource;
            [self.tagHeaderView.collectionView reloadData];
        }
    }];
    /*
    [PostImageTool MeetingLabelRequestGET:self.urlString WithParameters:nil whenSuccess:^(id responsObject) {
        if ([responsObject[@"code"]isEqualToString:@"200"]) {
            self.dataTag = responsObject[@"content"];
            [self.tableView reloadData];
            
            NSMutableArray *tagDataSource = [NSMutableArray array];
            [tagDataSource addObject:self.dataTag];
            self.tagHeaderView.dataSource = tagDataSource;
            [self.tagHeaderView.collectionView reloadData];
        }
    } orFail:^(id responsObject) {
        
    }];*/
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.tableView.editing = NO;
}

- (void)addTableView {
    self.tableHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 330)];
    [self.tableHeadView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:self.tableHeadView];
    
    self.typeHeaderView = [[MeetTypeTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 160)];
    self.typeHeaderView.backgroundColor = [UIColor whiteColor];
    NSMutableArray *typeDataSource = [NSMutableArray array];
    [typeDataSource addObject:self.dataType];
    self.typeHeaderView.dataSource = typeDataSource;
    self.typeHeaderView.title = @"活动类型";
    self.typeHeaderView.bottomLineView.hidden = YES;
    self.typeHeaderView.isType = YES;
    self.typeHeaderView.delegate = self;
    [self.tableHeadView addSubview:self.typeHeaderView];
    
    self.tagHeaderView = [[MeetTypeTableHeaderView alloc] initWithFrame:CGRectMake(0, 170, ScreenWidth, 160)];
    self.tagHeaderView.backgroundColor = [UIColor whiteColor];
    
    NSMutableArray *tagDataSource = [NSMutableArray array];
    [tagDataSource addObject:self.dataTag];
    self.tagHeaderView.dataSource = tagDataSource;
    self.tagHeaderView.title = @"请给活动添加个标签";
    self.tagHeaderView.bottomLineView.hidden = NO;
    self.tagHeaderView.isType = NO;
    self.tagHeaderView.delegate = self;
    [self.tableHeadView addSubview:self.tagHeaderView];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT) style:UITableViewStyleGrouped];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.tableHeaderView = self.tableHeadView;
    [self.tableView registerClass:[New_MeetTypeTableViewCell class] forCellReuseIdentifier:kCellIdentifier];
//    [self.tableView registerClass:[MeetTypeTableHeaderView class] forHeaderFooterViewReuseIdentifier:kHeaderViewCellIdentifier];
    [self.tableView registerClass:[UITableViewHeaderFooterView class] forHeaderFooterViewReuseIdentifier:kFooterViewCellIdentifier];
    [self.view addSubview:self.tableView];
}

#pragma mark - tableView dataSource / delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.customTags.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    New_MeetTypeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCellIdentifier forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.count = self.customTags.count;
    [cell reloadCellWith:indexPath.row];
    
    if (indexPath.row == 0 && self.customTags.count > 1) {
        cell.myButton.hidden = YES;
        cell.myImageView.hidden = YES;
    }
    else {
        cell.myButton.hidden = NO;
        cell.myImageView.hidden = NO;
    }
    
    if (indexPath.row == self.customTags.count-1) {
        NSString *customTag = [[NSUserDefaults standardUserDefaults] objectForKey:@"customTag"];
        if ([customTag isEqualToString:@"add"]) {
            cell.myImageView.image = [UIImage imageNamed:@"addTag"];
            cell.bottomLineView.hidden = YES;
            cell.myTextField.hidden = YES;
            cell.addTagLabel.hidden = NO;
        }
        else if ([customTag isEqualToString:@"delete"]) {
            cell.myImageView.image = [UIImage imageNamed:@"deleteTag"];
            cell.bottomLineView.hidden = YES;
            cell.myTextField.hidden = NO;
            cell.addTagLabel.hidden = YES;
        }
    }
    else {
        cell.myImageView.image = [UIImage imageNamed:@"deleteTag"];
        cell.bottomLineView.hidden = NO;
        cell.myTextField.hidden = NO;
        cell.addTagLabel.hidden = YES;
    }
    
    [cell.myButton setTag:indexPath.row+100];
    [cell.myTextField setTag:indexPath.row+200];
    [cell.contentView setTag:indexPath.row+300];
    [cell.deleteButton setTag:indexPath.row+400];
    [cell.myTextField setText:self.customTags[indexPath.row]];
    
    //@"请输入自定义标签（不可超过5个汉字）"
    [cell.myTextField setPlaceholder:[NSString stringWithFormat:@"请输入自定义标签%d",(int)indexPath.row+1]];
    
    __weak typeof(self) weakSelf = self;
    cell.sendButtonBlock =  ^(id sender) {
        [weakSelf endEdit];
        [weakSelf buttonAction:(UIButton *)sender];
    };
    
    cell.sendTextFieldBlock = ^(id sender) {
        /*
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"newMeetEdit"];
        NSMutableArray *meetTagArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"meetTag"];
        NSMutableArray *newMeetTagArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"newMeetTag"];
        NSMutableArray *newMeetArr = [NSMutableArray array];
        for (int i = 0; i < newMeetTagArr.count; i++) {
            if (![newMeetTagArr[i] isEqualToString:@""]) {
                [newMeetArr addObject:newMeetTagArr[i]];
            }
        }
        if ((meetTagArr.count + newMeetArr.count) >= 4) {
            if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0) {
                [sender resignFirstResponder];
            }
            else{
                
            }
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"最多只可以添加四个会议标签" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            alertView.delegate = self;
            [alertView show];
        }*/
    };
    
    cell.sendBlock = ^(NSInteger sender, NSString *text) {
        //[[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"newMeetEdit"];
        [weakSelf.customTags replaceObjectAtIndex:sender-200 withObject:text];
        [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
    };
    
    
    cell.sendPanBlock =  ^(UIPanGestureRecognizer *pan, CGFloat y) {
        // 判定手势的状态
        if (pan.state == UIGestureRecognizerStateBegan)
        {
            self.tableViewBeginY = self.tableView.contentOffset.y;
        }
        else if (pan.state == UIGestureRecognizerStateChanged)
        {
            self.tableView.contentOffset = CGPointMake(self.tableView.contentOffset.x, self.tableViewBeginY-y);
        }
        else if (pan.state == UIGestureRecognizerStateEnded)
        {
            CGFloat h = self.customTags.count*40+450-self.tableView.height;
            if (h > 0) {
                if (self.tableView.contentOffset.y < 0) {
                    [UIView animateWithDuration:0.25 animations:^{
                        self.tableView.contentOffset = CGPointMake(self.tableView.contentOffset.x, 0);
                    }];
                }
                else if (self.tableView.contentOffset.y > h) {
                    [UIView animateWithDuration:0.25 animations:^{
                        self.tableView.contentOffset = CGPointMake(self.tableView.contentOffset.x, h);
                    }];
                }
            }
            else {
                [UIView animateWithDuration:0.25 animations:^{
                    self.tableView.contentOffset = CGPointMake(self.tableView.contentOffset.x, 0);
                }];
            }
        }
    };
    
    return cell;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [self.view endEditing:YES];
    }
}

/*
// 修改组头的内容
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    MeetTypeTableHeaderView *headerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:kHeaderViewCellIdentifier];
    if (!headerView) {
        headerView = [[MeetTypeTableHeaderView alloc]initWithReuseIdentifier:kHeaderViewCellIdentifier];
    }
    headerView.contentView.backgroundColor = [UIColor whiteColor];
    
    NSMutableArray *dataSource = [NSMutableArray array];
    if (section == 0) {
        [dataSource addObject:self.dataType];
        headerView.dataSource = dataSource;
    }
    else if (section == 1) {
        [dataSource addObject:self.dataTag];
        headerView.dataSource = dataSource;
    }
    
    NSString * str = section == 0 ? @"活动类型":@"请给活动添加个标签";
    headerView.title = str;
    
    if (section == 0) {
        headerView.bottomLineView.hidden = YES;
        headerView.isType = YES;
    }
    else if (section == 1) {
        headerView.bottomLineView.hidden = NO;
        headerView.isType = NO;
    }
    return headerView;
}*/

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UITableViewHeaderFooterView *footerView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:kFooterViewCellIdentifier];
    footerView.contentView.backgroundColor = [UIColor clearColor];
    
    if (!self.nextLabel) {
        self.nextLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 5, ScreenWidth-30, 20)];
        [self.nextLabel setText:@"最多支持4个标签、每个不超过10个字符（5个汉字）"];
        [self.nextLabel setFont:[UIFont systemFontOfSize:12.0]];
        [self.nextLabel setTextColor:[UIColor colorWithHexString:@"#686868"]];
        [self.nextLabel setTextAlignment:NSTextAlignmentLeft];
        [self.nextLabel setBackgroundColor:[UIColor clearColor]];
    }
    [footerView addSubview:self.nextLabel];
    
    if (!self.nextButton) {
        self.nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.nextButton setFrame:CGRectMake(15, 40, [UIScreen mainScreen].bounds.size.width-30, 52)];
        [self.nextButton setBackgroundColor:[UIColor colorWithHexString:@"#17b4eb"]];
        [self.nextButton.layer setCornerRadius:2.0];
        [self.nextButton.layer setMasksToBounds:YES];
        [self.nextButton setTitle:@"下一步" forState:UIControlStateNormal];
        [self.nextButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.nextButton.titleLabel setFont:[UIFont boldSystemFontOfSize:18]];
        [self.nextButton addTarget:self action:@selector(nextAction) forControlEvents:UIControlEventTouchUpInside];
    }
    [footerView addSubview:self.nextButton];
    
    return footerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 120;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
    if (indexPath.row == self.customTags.count-1) {
        return NO;
    }
    return YES;*/
    return NO;
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

// 实现删除的代理方法，这样才能删除
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.customTags removeObjectAtIndex:indexPath.row];
        [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView reloadData];
    }
    else if (editingStyle == UITableViewCellEditingStyleInsert)
    {
        [self.customTags insertObject:@"" atIndex:indexPath.row];
        [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
        [tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
        [self.tableView reloadData];
    }
}

- (void)buttonAction:(UIButton *)sender
{
    UIButton *myButton = (UIButton *)sender;
    if (myButton.tag >= 100 && myButton.tag < 200) {
        if (myButton.tag == self.customTags.count-1+100) {
            /*
             if (self.customTags.count > 1 && [self.customTags[self.customTags.count-2] isEqualToString:@""]) {
             UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入自定义标签" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
             [alertView show];
             }
             else {*/
            if (self.customTags.count > 4) {
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"最多只可以添加四个自定义标签" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alertView show];
            }
            else {
                if (myButton.tag-100 == 3) {
                    [[NSUserDefaults standardUserDefaults] setObject:@"delete" forKey:@"customTag"];
                    [self.customTags insertObject:@"" atIndex:myButton.tag-100];
                    [self.customTags removeLastObject];
                    [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
                    [self.tableView reloadData];
                }
                else {
                    [self.customTags insertObject:@"" atIndex:myButton.tag-100];
                    [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
                    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.customTags.count-1 inSection:0];
                    [self.tableView beginUpdates];
                    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
                    [self.tableView endUpdates];
                    [self.tableView reloadData];
                }
                /*
                if (myButton.tag-100 == 3) {
                    [self.customTags removeLastObject];
                    [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
                    [[NSUserDefaults standardUserDefaults] setObject:@"delete" forKey:@"customTag"];
                    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.customTags.count inSection:0];
                    [self.tableView beginUpdates];
                    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                    [self.tableView endUpdates];
                    [self.tableView reloadData];
                }*/
            }
            /*
             }*/
        }
        else {
            /*
             [self.customTags removeObjectAtIndex:myButton.tag-100];
             
             NSIndexPath *indexPath = [NSIndexPath indexPathForRow:myButton.tag-100 inSection:0];
             [self.tableView beginUpdates];
             [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
             [self.tableView endUpdates];
             [self.tableView reloadData];*/
            /*
            [UIView animateWithDuration:0.3
                             animations:^{
                                 UIView *contentView = (UIView *)[self.view viewWithTag:myButton.tag+200];
                                 contentView.center = CGPointMake(ScreenWidth/2-60, 20);
                             }
                             completion:^(BOOL finished) {
                                 [self.customTags removeObjectAtIndex:myButton.tag-100];
                                 [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
                                 NSIndexPath *indexPath = [NSIndexPath indexPathForRow:myButton.tag-100 inSection:0];
                                 [self.tableView beginUpdates];
                                 [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                                 [self.tableView endUpdates];
                                 [self.tableView reloadData];
                             }];*/
        }
    }
    else if (myButton.tag >= 400 && myButton.tag < 500) {
        if (myButton.tag-400 == 3) {
            [[NSUserDefaults standardUserDefaults] setObject:@"add" forKey:@"customTag"];
            [self.customTags removeObjectAtIndex:myButton.tag-400];
            [self.customTags addObject:@""];
            [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
            [self.tableView reloadData];
        }
        else {
            [self.customTags removeObjectAtIndex:myButton.tag-400];
            [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:myButton.tag-400 inSection:0];
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
            [self.tableView reloadData];
            
            NSString *customTag = [[NSUserDefaults standardUserDefaults] objectForKey:@"customTag"];
            
            if ([customTag isEqualToString:@"delete"]) {
                [[NSUserDefaults standardUserDefaults] setObject:@"add" forKey:@"customTag"];
                [self.customTags addObject:@""];
                [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.customTags.count-1 inSection:0];
                [self.tableView beginUpdates];
                [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
                [self.tableView endUpdates];
                [self.tableView reloadData];
            }
            
        }
        /*
        NSString *customTag = [[NSUserDefaults standardUserDefaults] objectForKey:@"customTag"];
        
        if ([customTag isEqualToString:@"delete"]) {
            [[NSUserDefaults standardUserDefaults] setObject:@"add" forKey:@"customTag"];
            [self.customTags addObject:@""];
            [[NSUserDefaults standardUserDefaults] setObject:self.customTags forKey:@"newMeetTag"];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.customTags.count-1 inSection:0];
            [self.tableView beginUpdates];
            [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationRight];
            [self.tableView endUpdates];
            [self.tableView reloadData];
        }*/
    }
}

- (void)nextAction
{
    [self endEdit];
    
    NSString *meetType = [[NSUserDefaults standardUserDefaults] objectForKey:@"meetType"];
    NSMutableArray *meetTagArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"meetTag"];
    
    NSMutableDictionary *meet_label = [NSMutableDictionary dictionary];
    if (meetTagArr.count) {
        for (int i = 0; i < meetTagArr.count; i++) {
            [meet_label setValue:meetTagArr[i] forKey:[NSString stringWithFormat:@"%d",i]];
        }
    }
    
    NSMutableArray *newLabelArr = [NSMutableArray array];
    for (int i = 0; i < self.customTags.count; i++) {
        if (![self.customTags[i] isEqualToString:@""]) {
            [newLabelArr addObject:self.customTags[i]];
        }
    }
    NSMutableDictionary *new_label = [NSMutableDictionary dictionary];
    if (newLabelArr.count) {
        for (int i = 0; i < newLabelArr.count; i++) {
            [new_label setValue:newLabelArr[i] forKey:[NSString stringWithFormat:@"%d",i]];
        }
    }
    
    int count = meet_label.count + new_label.count;
    if (meet_label.count == 0 && new_label.count == 0) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"请至少选择一个会议标签" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertView show];
    }
    else if (count > 4) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"会议标签最多可以支持4个" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertView show];
    }
    else {
        NSString *title = [self.dataSource[0] objectAtIndex:[meetType intValue]];
        NSString *type = [self.dataMeetType objectAtIndex:[meetType intValue]];
        if ([meetType intValue] == 6) {
            SiRenViewController *partyVC = [[SiRenViewController alloc]init];
            partyVC.type = [type intValue];
            partyVC.titleName = title;
            partyVC.meet_label = meet_label;
            partyVC.meetnew_label = new_label;
            [self.navigationController pushViewController:partyVC animated:YES];
        }
        else {
            CreateOtherMeetPartOneVC *partOneVC = [[CreateOtherMeetPartOneVC alloc]init];
            partOneVC.type = [type intValue];
            partOneVC.titleName = title;
            partOneVC.meet_label = meet_label;
            partOneVC.meetnew_label = new_label;
            [self.navigationController pushViewController:partOneVC animated:YES];
        }
    }
}

- (void)ReturnBtn {
    if (_isMyPublish) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)endEdit
{
    [self.tableView endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
