//
//  UIContentView_04.h
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITypeButton.h"


@interface UIContentView_04 : UIView
@property (nonatomic)BOOL isShow;
@property (nonatomic,strong)UILabel *nameLB;
@property (nonatomic,strong)UITypeButton *meetTypeBtn1;
@property (nonatomic,strong)UITypeButton *meetTypeBtn2;
@property (nonatomic,strong)UITypeButton *meetTypeBtn3;
@end
