//
//  SignUpConfigTool.m
//  huiyi
//
//  Created by songhongshuai on 15/7/30.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SignUpConfigTool.h"
#import "EduExpViewController.h"
#import "SubPersonInfoViewController.h"
#import "UpInfoViewController.h"
#import "BriefViewController.h"
#import "UpViewController.h"
#import "SignUpTypeViewController.h"
#import "PersonalInfoController.h"
#import "SignUpStatusViewController.h"

@interface SignUpConfigTool ()
{
    NSDictionary *_nextViewDic;//下一页配置
}
@end

@implementation SignUpConfigTool
+ (SignUpConfigTool *)shareManager
{
    static SignUpConfigTool * tool = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        tool = [[self alloc]init];
    });
    return tool;
}
- (void)manageSubConfigWithSameTicket:(NSInteger)ticketIndex
{
    NSDictionary *nextViewDic0 = [[_configDic objectForKey:@"block_list"] objectAtIndex:ticketIndex];
    if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"10"]) {
        NSDictionary *nextViewDic1 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
        if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"3"]) {
            if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                NSDictionary *nextViewDic2 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic2 objectForKey:@"type"]isEqualToString:@"2"]) {
                    if ([[nextViewDic2 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                        NSDictionary *nextViewDic3 = [[nextViewDic2 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic3 objectForKey:@"name"];
                            eduVC.meetID = _meeting_id;
                            eduVC.blockID =  [nextViewDic3 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0 ) {
                            if (![[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                perInfoVC.meetID = _meeting_id;
                                perInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [nextViewDic3  objectForKey:@"name"];
                                upInfoVC.meetID = _meeting_id;
                                upInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                upInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                            }
                        }
                        
                        
                    }else{//显示2
                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                        briefVC.meetID = _meeting_id;
                        briefVC.briefDic = nextViewDic2;
                        briefVC.blockID =  [nextViewDic2 objectForKey:@"block_id"];
                        briefVC.configArr = [nextViewDic2 objectForKey:@"block_list"];
                        [self.controller.navigationController pushViewController:briefVC animated:YES];
                    }
                    
                }
            }else{//显示3
                UpViewController *upVC = [[UpViewController alloc]init];
                upVC.meetID = _meeting_id;
                upVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                upVC.configArr = [nextViewDic1 objectForKey:@"block_list"];//3正常跳转 传4
                [self.controller.navigationController pushViewController:upVC animated:YES];
            }
        }
        if ([[nextViewDic1 objectForKey:@"type"]isEqualToString:@"2"]) {
            if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {
                NSDictionary *nextViewDic8 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic8  objectForKey:@"field_list"]count]!=0) {
                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                    eduVC.addName = [nextViewDic8 objectForKey:@"name"];
                    eduVC.meetID = _meeting_id;
                    eduVC.blockID =  [nextViewDic8 objectForKey:@"block_id"];
                    eduVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:eduVC animated:YES];
                }
                if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic8 objectForKey:@"field_list"]count]!=0) {
                    if (![[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                        perInfoVC.meetID = _meeting_id;
                        perInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                        perInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                    }
                    if ([[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                        upInfoVC.upInfoTitle = [nextViewDic8  objectForKey:@"name"];
                        upInfoVC.meetID = _meeting_id;
                        upInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                        upInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                    }
                }
            }else{
                BriefViewController *briefVC = [[BriefViewController alloc]init];
                briefVC.meetID = _meeting_id;
                briefVC.briefDic = nextViewDic0;
                briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                [self.controller.navigationController pushViewController:briefVC animated:YES];
            }
        }
        if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic1 objectForKey:@"field_list"] count]!=0) {
            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
            eduVC.addName = [nextViewDic1 objectForKey:@"name"];
            eduVC.meetID = _meeting_id;
            eduVC.blockID =  [nextViewDic1 objectForKey:@"block_id"];
            eduVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
            [self.controller.navigationController pushViewController:eduVC animated:YES];
        }
        if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic1 objectForKey:@"field_list"]count]!=0) {
            if (![[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                perInfoVC.meetID = _meeting_id;
                perInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                perInfoVC.infoTitle = [nextViewDic1  objectForKey:@"name"];
                perInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
            }
            if ([[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                upInfoVC.upInfoTitle = [nextViewDic1  objectForKey:@"name"];
                upInfoVC.meetID = _meeting_id;
                upInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                upInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
            }
        }
        
    }else{
        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"3"]) {
            if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                NSDictionary * nextViewDic5 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic5 objectForKey:@"type"]isEqualToString:@"2"]) {
                    if ([[nextViewDic5 objectForKey:@"block_list"] count] == 1) {
                        NSDictionary *nextViewDic6 = [[nextViewDic5 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic6 objectForKey:@"field_list"] count]!=0) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic6 objectForKey:@"name"];
                            eduVC.meetID = _meeting_id;
                            eduVC.blockID =  [nextViewDic6 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic6  objectForKey:@"field_list"] count]!=0) {
                            if (![[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                perInfoVC.meetID = _meeting_id;
                                perInfoVC.blockID = [nextViewDic6 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [_nextViewDic  objectForKey:@"name"];
                                upInfoVC.meetID = _meeting_id;
                                upInfoVC.blockID = [_nextViewDic objectForKey:@"block_id"];
                                upInfoVC.configArr = [_nextViewDic objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                            }
                            
                        }
                        
                    }else{
                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                        briefVC.meetID = _meeting_id;
                        briefVC.briefDic = nextViewDic5;
                        briefVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                        briefVC.configArr = [nextViewDic5 objectForKey:@"block_list"];
                        [self.controller.navigationController pushViewController:briefVC animated:YES];
                    }
                    
                }
                if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"1"]) {
                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                    eduVC.addName = [nextViewDic5 objectForKey:@"name"];
                    eduVC.meetID = _meeting_id;
                    eduVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                    eduVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:eduVC animated:YES];
                }
                if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic5 objectForKey:@"field_list"]count]!=0) {
                    if (![[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                        perInfoVC.meetID = _meeting_id;
                        perInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                        perInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                    }
                    if ([[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                        upInfoVC.upInfoTitle = [nextViewDic5  objectForKey:@"name"];
                        upInfoVC.meetID = _meeting_id;
                        upInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                        upInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                    }
                }
                
            }else{
                UpViewController *upVC = [[UpViewController alloc]init];
                upVC.meetID = _meeting_id;
                upVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                upVC.configArr = [nextViewDic0 objectForKey:@"block_list"];//3正常跳转 传4
                [self.controller.navigationController pushViewController:upVC animated:YES];
            }
            
        }
        if ([[nextViewDic0 objectForKey:@"type"]isEqualToString:@"2"]) {
            if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {
                NSDictionary *nextViewDic4 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                    eduVC.addName = [nextViewDic4 objectForKey:@"name"];
                    eduVC.meetID = _meeting_id;
                    eduVC.blockID =  [nextViewDic4 objectForKey:@"block_id"];
                    eduVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:eduVC animated:YES];
                }
                if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                    if (![[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                        perInfoVC.meetID = _meeting_id;
                        perInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                        perInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                    }
                    if ([[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                        upInfoVC.upInfoTitle = [nextViewDic4  objectForKey:@"name"];
                        upInfoVC.meetID = _meeting_id;
                        upInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                        upInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                    }
                }
            }else{
                BriefViewController *briefVC = [[BriefViewController alloc]init];
                briefVC.meetID = _meeting_id;
                briefVC.briefDic = nextViewDic0;
                briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                [self.controller.navigationController pushViewController:briefVC animated:YES];
            }
        }
        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
            eduVC.addName = [nextViewDic0 objectForKey:@"name"];
            eduVC.meetID = _meeting_id;
            eduVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
            eduVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
            [self.controller.navigationController pushViewController:eduVC animated:YES];
        }
        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
            if (![[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                perInfoVC.meetID = _meeting_id;
                perInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                perInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
            }
            if ([[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                upInfoVC.upInfoTitle = [nextViewDic0  objectForKey:@"name"];
                upInfoVC.meetID = _meeting_id;
                upInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                upInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
            }
        }
    }

}
- (void)manageSubConfig
{
    
    
    
    if ([[_configDic objectForKey:@"type"] isEqualToString:@"4"]) {
        if ([[_configDic objectForKey:@"block_list"] count] == 1) {//type 4  一定会有报名状态跟踪
            NSDictionary *nextViewDic0 = [[_configDic objectForKey:@"block_list"] objectAtIndex:0];
            
            if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"10"]) {
                NSDictionary *nextViewDic1 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"3"]) {
                    if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                        NSDictionary *nextViewDic2 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic2 objectForKey:@"type"]isEqualToString:@"2"]) {
                            if ([[nextViewDic2 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                                NSDictionary *nextViewDic3 = [[nextViewDic2 objectForKey:@"block_list"] objectAtIndex:0];
                                if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0) {
                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                    eduVC.addName = [nextViewDic3 objectForKey:@"name"];
                                    eduVC.meetID = _meeting_id;
                                    eduVC.blockID =  [nextViewDic3 objectForKey:@"block_id"];
                                    eduVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                    [_controller.navigationController pushViewController:eduVC animated:YES];
                                }
                                if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0 ) {
                                    if (![[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                        
                                        perInfoVC.meetID = _meeting_id;
                                        perInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                        perInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                    }
                                    if ([[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                        upInfoVC.upInfoTitle = [nextViewDic3  objectForKey:@"name"];
                                        upInfoVC.meetID = _meeting_id;
                                        upInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                        upInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                    }
                                }
                                
                                
                            }else{//显示2
                                BriefViewController *briefVC = [[BriefViewController alloc]init];
                                briefVC.meetID = _meeting_id;
                                briefVC.briefDic = nextViewDic2;
                                briefVC.blockID =  [nextViewDic2 objectForKey:@"block_id"];
                                briefVC.configArr = [nextViewDic2 objectForKey:@"block_list"];
                                [_controller.navigationController pushViewController:briefVC animated:YES];
                            }
                            
                        }
                    }else{//显示3
                        UpViewController *upVC = [[UpViewController alloc]init];
                        upVC.meetID = _meeting_id;
                        upVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                        upVC.configArr = [nextViewDic1 objectForKey:@"block_list"];//3正常跳转 传4
                        [_controller.navigationController pushViewController:upVC animated:YES];
                    }
                }
                if ([[nextViewDic1 objectForKey:@"type"]isEqualToString:@"2"]) {
                    if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {
                        NSDictionary *nextViewDic8 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic8  objectForKey:@"field_list"]count]!=0) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic8 objectForKey:@"name"];
                            eduVC.meetID = _meeting_id;
                            eduVC.blockID =  [nextViewDic8 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                            [_controller.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic8 objectForKey:@"field_list"]count]!=0) {
                            if (![[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                perInfoVC.meetID = _meeting_id;
                                perInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [nextViewDic8  objectForKey:@"name"];
                                upInfoVC.meetID = _meeting_id;
                                upInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                                upInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:upInfoVC animated:YES];
                            }
                        }
                    }else{
                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                        briefVC.meetID = _meeting_id;
                        briefVC.briefDic = nextViewDic0;
                        briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                        briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                        [_controller.navigationController pushViewController:briefVC animated:YES];
                    }
                }
                if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic1 objectForKey:@"field_list"] count]!=0) {
                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                    eduVC.addName = [nextViewDic1 objectForKey:@"name"];
                    eduVC.meetID = _meeting_id;
                    eduVC.blockID =  [nextViewDic1 objectForKey:@"block_id"];
                    eduVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                    [_controller.navigationController pushViewController:eduVC animated:YES];
                }
                if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic1 objectForKey:@"field_list"]count]!=0) {
                    if (![[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                        perInfoVC.meetID = _meeting_id;
                        perInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                        perInfoVC.infoTitle = [nextViewDic1  objectForKey:@"name"];
                        perInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                        [_controller.navigationController pushViewController:perInfoVC animated:YES];
                    }
                    if ([[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                        upInfoVC.upInfoTitle = [nextViewDic1  objectForKey:@"name"];
                        upInfoVC.meetID = _meeting_id;
                        upInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                        upInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                        [_controller.navigationController pushViewController:upInfoVC animated:YES];
                    }
                }
                //                        }else{//显示报名状态跟踪
                //                            SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                //                            stateVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                //                            stateVC.meetID = _meeting_id;
                //                            stateVC.type = [nextViewDic0 objectForKey:@"type"];
                //                            stateVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                //                            [self.controller.navigationController pushViewController:stateVC animated:YES];
                //                        }
            }else{
                if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"3"]) {
                    if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                        NSDictionary * nextViewDic5 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic5 objectForKey:@"type"]isEqualToString:@"2"]) {
                            if ([[nextViewDic5 objectForKey:@"block_list"] count] == 1) {
                                NSDictionary *nextViewDic6 = [[nextViewDic5 objectForKey:@"block_list"] objectAtIndex:0];
                                if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic6 objectForKey:@"field_list"] count]!=0) {
                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                    eduVC.addName = [nextViewDic6 objectForKey:@"name"];
                                    eduVC.meetID = _meeting_id;
                                    eduVC.blockID =  [nextViewDic6 objectForKey:@"block_id"];
                                    eduVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                    [_controller.navigationController pushViewController:eduVC animated:YES];
                                }
                                if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic6  objectForKey:@"field_list"] count]!=0) {
                                    if (![[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                        perInfoVC.meetID = _meeting_id;
                                        perInfoVC.blockID = [nextViewDic6 objectForKey:@"block_id"];
                                        perInfoVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                    }
                                    if ([[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                        upInfoVC.upInfoTitle = [_nextViewDic  objectForKey:@"name"];
                                        upInfoVC.meetID = _meeting_id;
                                        upInfoVC.blockID = [_nextViewDic objectForKey:@"block_id"];
                                        upInfoVC.configArr = [_nextViewDic objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                    }
                                    
                                }
                                
                            }else{
                                BriefViewController *briefVC = [[BriefViewController alloc]init];
                                briefVC.meetID = _meeting_id;
                                briefVC.briefDic = nextViewDic5;
                                briefVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                                briefVC.configArr = [nextViewDic5 objectForKey:@"block_list"];
                                [_controller.navigationController pushViewController:briefVC animated:YES];
                            }
                            
                        }
                        if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"1"]) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic5 objectForKey:@"name"];
                            eduVC.meetID = _meeting_id;
                            eduVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                            [_controller.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic5 objectForKey:@"field_list"]count]!=0) {
                            if (![[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                perInfoVC.meetID = _meeting_id;
                                perInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [nextViewDic5  objectForKey:@"name"];
                                upInfoVC.meetID = _meeting_id;
                                upInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                                upInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:upInfoVC animated:YES];
                            }
                        }
                        
                    }else{
                        UpViewController *upVC = [[UpViewController alloc]init];
                        upVC.meetID = _meeting_id;
                        upVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                        upVC.configArr = [nextViewDic0 objectForKey:@"block_list"];//3正常跳转 传4
                        [_controller.navigationController pushViewController:upVC animated:YES];
                    }
                    
                }
                if ([[nextViewDic0 objectForKey:@"type"]isEqualToString:@"2"]) {
                    if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {
                        NSDictionary *nextViewDic4 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic4 objectForKey:@"name"];
                            eduVC.meetID = _meeting_id;
                            eduVC.blockID =  [nextViewDic4 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                            [_controller.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                            if (![[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                perInfoVC.meetID = _meeting_id;
                                perInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [nextViewDic4  objectForKey:@"name"];
                                upInfoVC.meetID = _meeting_id;
                                upInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                                upInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:upInfoVC animated:YES];
                            }
                        }
                    }else{
                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                        briefVC.meetID = _meeting_id;
                        briefVC.briefDic = nextViewDic0;
                        briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                        briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                        [_controller.navigationController pushViewController:briefVC animated:YES];
                    }
                }
                if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                    eduVC.addName = [nextViewDic0 objectForKey:@"name"];
                    eduVC.meetID = _meeting_id;
                    eduVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                    eduVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                    [_controller.navigationController pushViewController:eduVC animated:YES];
                }
                if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                    if (![[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                        perInfoVC.meetID = _meeting_id;
                        perInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                        perInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                        [_controller.navigationController pushViewController:perInfoVC animated:YES];
                    }
                    if ([[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                        upInfoVC.upInfoTitle = [nextViewDic0  objectForKey:@"name"];
                        upInfoVC.meetID = _meeting_id;
                        upInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                        upInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                        [_controller.navigationController pushViewController:upInfoVC animated:YES];
                    }
                }
            }
        }
        
        else{
            if (_blockID.length != 0 ){
                
                for (NSDictionary *nextViewDic12 in [_configDic objectForKey:@"block_list"]) {
                    if ([[nextViewDic12 objectForKey:@"block_id"] isEqualToString:_blockID]) {
                        if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"10"]) {
                            
                            NSDictionary *nextViewDic13 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic13 objectForKey:@"type"] isEqualToString:@"3"]) {
                                if ([[nextViewDic13 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                    NSDictionary *nextViewDic14 = [[nextViewDic13 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic14 objectForKey:@"type"]isEqualToString:@"2"]) {
                                        if ([[nextViewDic14 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                                            NSDictionary *nextViewDic15 = [[nextViewDic14 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic15 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic15  objectForKey:@"field_list"]count]!=0) {
                                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                eduVC.addName = [nextViewDic15 objectForKey:@"name"];
                                                eduVC.meetID = _meeting_id;
                                                eduVC.blockID =  [nextViewDic15 objectForKey:@"block_id"];
                                                eduVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                [_controller.navigationController pushViewController:eduVC animated:YES];
                                            }
                                            if ([[nextViewDic15 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic15  objectForKey:@"field_list"]count]!=0 ) {
                                                if (![[[[nextViewDic15  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                                    perInfoVC.meetID = _meeting_id;
                                                    perInfoVC.blockID = [nextViewDic15 objectForKey:@"block_id"];
                                                    perInfoVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                    [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                                }
                                                if ([[[[nextViewDic15  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                    upInfoVC.upInfoTitle = [nextViewDic15  objectForKey:@"name"];
                                                    upInfoVC.meetID = _meeting_id;
                                                    upInfoVC.blockID = [nextViewDic15 objectForKey:@"block_id"];
                                                    upInfoVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                    [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                                }
                                            }
                                            
                                            
                                        }else{//显示2
                                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                                            briefVC.meetID = _meeting_id;
                                            briefVC.briefDic = nextViewDic14;
                                            briefVC.blockID =  [nextViewDic14 objectForKey:@"block_id"];
                                            briefVC.configArr = [nextViewDic14 objectForKey:@"block_list"];
                                            [_controller.navigationController pushViewController:briefVC animated:YES];
                                        }
                                        
                                    }
                                }else{//显示3
                                    UpViewController *upVC = [[UpViewController alloc]init];
                                    upVC.meetID = _meeting_id;
                                    upVC.blockID = [nextViewDic13 objectForKey:@"block_id"];
                                    upVC.configArr = [nextViewDic13 objectForKey:@"block_list"];//3正常跳转 传4
                                    [_controller.navigationController pushViewController:upVC animated:YES];
                                }
                            }
                            if ([[nextViewDic12 objectForKey:@"type"]isEqualToString:@"2"]) {
                                if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {
                                    NSDictionary *nextViewDic16 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic16 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic16  objectForKey:@"field_list"]count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic16 objectForKey:@"name"];
                                        eduVC.meetID = _meeting_id;
                                        eduVC.blockID =  [nextViewDic16 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic16 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic16 objectForKey:@"field_list"]count]!=0) {
                                        if (![[[[nextViewDic16  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                            perInfoVC.meetID = _meeting_id;
                                            perInfoVC.blockID = [nextViewDic16 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                            [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic16  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic16  objectForKey:@"name"];
                                            upInfoVC.meetID = _meeting_id;
                                            upInfoVC.blockID = [nextViewDic16 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                            [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                }else{
                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                    briefVC.meetID = _meeting_id;
                                    briefVC.briefDic = nextViewDic12;
                                    briefVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                    briefVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                    [_controller.navigationController pushViewController:briefVC animated:YES];
                                }
                            }
                            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic12 objectForKey:@"field_list"] count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic12 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                    [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic12  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                    [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                        }else{
                            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"3"]) {
                                if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                    NSDictionary * nextViewDic17 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic17 objectForKey:@"type"]isEqualToString:@"2"]) {
                                        if ([[nextViewDic17 objectForKey:@"block_list"] count] == 1) {
                                            NSDictionary *nextViewDic18 = [[nextViewDic17 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic18 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic18 objectForKey:@"field_list"] count]!=0) {
                                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                eduVC.addName = [nextViewDic18 objectForKey:@"name"];
                                                eduVC.meetID = _meeting_id;
                                                eduVC.blockID =  [nextViewDic18 objectForKey:@"block_id"];
                                                eduVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                [_controller.navigationController pushViewController:eduVC animated:YES];
                                            }
                                            if ([[nextViewDic18 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic18  objectForKey:@"field_list"] count]!=0) {
                                                if (![[[[nextViewDic18  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                                    perInfoVC.meetID = _meeting_id;
                                                    perInfoVC.blockID = [nextViewDic18 objectForKey:@"block_id"];
                                                    perInfoVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                    [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                                }
                                                if ([[[[nextViewDic18  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                    upInfoVC.upInfoTitle = [nextViewDic18  objectForKey:@"name"];
                                                    upInfoVC.meetID = _meeting_id;
                                                    upInfoVC.blockID = [nextViewDic18 objectForKey:@"block_id"];
                                                    upInfoVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                    [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                                }
                                                
                                            }
                                            
                                        }else{
                                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                                            briefVC.meetID = _meeting_id;
                                            briefVC.briefDic = nextViewDic17;
                                            briefVC.blockID =  [nextViewDic17 objectForKey:@"block_id"];
                                            briefVC.configArr = [nextViewDic17 objectForKey:@"block_list"];
                                            [_controller.navigationController pushViewController:briefVC animated:YES];
                                        }
                                    }
                                    if ([[nextViewDic17 objectForKey:@"type"] isEqualToString:@"1"]) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic17 objectForKey:@"name"];
                                        eduVC.meetID = _meeting_id;
                                        eduVC.blockID =  [nextViewDic17 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic17 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic17 objectForKey:@"field_list"]count]!=0) {
                                        if (![[[[nextViewDic17  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                            perInfoVC.meetID = _meeting_id;
                                            perInfoVC.blockID = [nextViewDic17 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                            [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic17  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic17  objectForKey:@"name"];
                                            upInfoVC.meetID = _meeting_id;
                                            upInfoVC.blockID = [nextViewDic17 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                            [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                    
                                }else{
                                    UpViewController *upVC = [[UpViewController alloc]init];
                                    upVC.meetID = _meeting_id;
                                    upVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                    upVC.configArr = [nextViewDic12 objectForKey:@"block_list"];//3正常跳转 传4
                                    [_controller.navigationController pushViewController:upVC animated:YES];
                                }
                                
                            }
                            if ([[nextViewDic12 objectForKey:@"type"]isEqualToString:@"2"]) {
                                if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {
                                    NSDictionary *nextViewDic19 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic19 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic19 objectForKey:@"field_list"]count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic19 objectForKey:@"name"];
                                        eduVC.meetID = _meeting_id;
                                        eduVC.blockID =  [nextViewDic19 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic19 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic19 objectForKey:@"field_list"]count]!=0) {
                                        if (![[[[nextViewDic19  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                            perInfoVC.meetID = _meeting_id;
                                            perInfoVC.blockID = [nextViewDic19 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                            [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic19  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic19  objectForKey:@"name"];
                                            upInfoVC.meetID = _meeting_id;
                                            upInfoVC.blockID = [nextViewDic19 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                            [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                }else{
                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                    briefVC.meetID = _meeting_id;
                                    briefVC.briefDic = nextViewDic12;
                                    briefVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                    briefVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                    [_controller.navigationController pushViewController:briefVC animated:YES];
                                }
                            }
                            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic12 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                [_controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                    [_controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic12  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                    [_controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                        }
                        
                    }
                }
            }
            else{
                _blockID = [_configDic objectForKey:@"block_id"];
                SignUpTypeViewController *typeVC = [[SignUpTypeViewController alloc]init];
                typeVC.meetID = _meeting_id;
                typeVC.blockID = [_configDic objectForKey:@"block_id"];
                typeVC.configDic = _configDic;
                [_controller.navigationController pushViewController:typeVC animated:YES];
            }
        }
    }
    if ([[_configDic objectForKey:@"type"] isEqualToString:@"3"]) {
        if ([[_configDic objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
            NSDictionary *nextViewDic9 = [[_configDic objectForKey:@"block_list"] objectAtIndex:0];
            
            if ([[nextViewDic9 objectForKey:@"type"]isEqualToString:@"2"]) {
                if ([[nextViewDic9 objectForKey:@"block_list"] count] == 1) {
                    NSDictionary *nextViewDic10 = [[nextViewDic9 objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic10 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic10 objectForKey:@"field_list"] count]!=0) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic10 objectForKey:@"name"];
                        eduVC.meetID = _meeting_id;
                        eduVC.blockID =  [nextViewDic10 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                        [_controller.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic10 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic10 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic10  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                            perInfoVC.meetID = _meeting_id;
                            perInfoVC.blockID = [nextViewDic10 objectForKey:@"block_id"];
                            perInfoVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                            [_controller.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic10  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic10  objectForKey:@"name"];
                            upInfoVC.meetID = _meeting_id;
                            upInfoVC.blockID = [nextViewDic10 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                            [_controller.navigationController pushViewController:upInfoVC animated:YES];
                        }
                        
                    }
                    
                }else{
                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                    briefVC.meetID = _meeting_id;
                    briefVC.briefDic = nextViewDic9;
                    briefVC.blockID =  [nextViewDic9 objectForKey:@"block_id"];
                    briefVC.configArr = [nextViewDic9 objectForKey:@"block_list"];
                    [_controller.navigationController pushViewController:briefVC animated:YES];
                }
                
            }
            
        }else{
            UpViewController *upVC = [[UpViewController alloc]init];
            upVC.meetID = _meeting_id;
            upVC.blockID = [_configDic objectForKey:@"block_id"];
            upVC.configArr = [_configDic objectForKey:@"block_list"];//3正常跳转 传4
            [_controller.navigationController pushViewController:upVC animated:YES];
        }
    }
    if ([[_configDic objectForKey:@"type"]isEqualToString:@"2"]) {
        if ([[_nextViewDic objectForKey:@"block_list"] count] == 1) {
            NSDictionary * nextViewDic11 = [[_nextViewDic objectForKey:@"block_list"] objectAtIndex:0];
            if ([[nextViewDic11 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic11 objectForKey:@"field_list"] count]!=0) {
                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                eduVC.addName = [nextViewDic11 objectForKey:@"name"];
                eduVC.meetID = _meeting_id;
                eduVC.blockID =  [nextViewDic11 objectForKey:@"block_id"];
                eduVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                [_controller.navigationController pushViewController:eduVC animated:YES];
            }
            if ([[nextViewDic11 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic11 objectForKey:@"field_list"]count]!=0) {
                if (![[[[nextViewDic11  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                    SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
                    perInfoVC.meetID = _meeting_id;
                    perInfoVC.blockID = [nextViewDic11 objectForKey:@"block_id"];
                    perInfoVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                    [_controller.navigationController pushViewController:perInfoVC animated:YES];
                }
                if ([[[[nextViewDic11  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                    upInfoVC.upInfoTitle = [nextViewDic11  objectForKey:@"name"];
                    upInfoVC.meetID = _meeting_id;
                    upInfoVC.blockID = [nextViewDic11 objectForKey:@"block_id"];
                    upInfoVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                    [_controller.navigationController pushViewController:upInfoVC animated:YES];
                }
                
            }
            
            
        }else{
            BriefViewController *briefVC = [[BriefViewController alloc]init];
            briefVC.meetID = _meeting_id;
            briefVC.briefDic = _nextViewDic;
            briefVC.blockID =  [_nextViewDic objectForKey:@"block_id"];
            briefVC.configArr = [_nextViewDic objectForKey:@"block_list"];
            [_controller.navigationController pushViewController:briefVC animated:YES];
        }
    }
    if ([[_configDic objectForKey:@"type"] isEqualToString:@"1"]&&[[_configDic objectForKey:@"field_list"]count]!=0) {//第一层  type1
        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
        eduVC.addName = [_configDic objectForKey:@"name"];
        eduVC.meetID = _meeting_id;
        eduVC.blockID =  [_configDic objectForKey:@"block_id"];
        eduVC.configArr = [_configDic objectForKey:@"field_list"];
        [_controller.navigationController pushViewController:eduVC animated:YES];
    }
    if ([[_configDic objectForKey:@"type"] isEqualToString:@"0"]&&[[_configDic objectForKey:@"field_list"] count]!=0) {
        if (![[[[_configDic  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {//第一层  type1 且跳转到普通页
            SubPersonInfoViewController *perInfoVC = [[SubPersonInfoViewController alloc]init];
            perInfoVC.meetID = _meeting_id;
            perInfoVC.blockID = [_configDic objectForKey:@"block_id"];
            perInfoVC.configArr = [_configDic objectForKey:@"field_list"];
            [_controller.navigationController pushViewController:perInfoVC animated:YES];
        }
        if ([[[[_configDic  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {//第一层  type1 且跳转到上传图片
            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
            upInfoVC.upInfoTitle = [_configDic  objectForKey:@"name"];
            upInfoVC.meetID = _meeting_id;
            upInfoVC.blockID = [_configDic objectForKey:@"block_id"];
            upInfoVC.configArr = [_configDic objectForKey:@"field_list"];
            [_controller.navigationController pushViewController:upInfoVC animated:YES];
        }
    }
    
    
}

- (void)manageConfig{
        if ([[_configDic objectForKey:@"type"] isEqualToString:@"4"]) {
            if ([[_configDic objectForKey:@"block_list"] count] == 1) {//type 4  一定会有报名状态跟踪
                NSDictionary *nextViewDic0 = [[_configDic objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"10"]) {
                    NSDictionary *nextViewDic1 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"3"]) {
                        if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                            NSDictionary *nextViewDic2 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic2 objectForKey:@"type"]isEqualToString:@"2"]) {
                                if ([[nextViewDic2 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                                    NSDictionary *nextViewDic3 = [[nextViewDic2 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic3 objectForKey:@"name"];
                                        eduVC.meetID = _meeting_id;
                                        eduVC.blockID =  [nextViewDic3 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                        [_controller.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0 ) {
                                        if (![[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                            
                                            perInfoVC.meetID = _meeting_id;
                                            perInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic3  objectForKey:@"name"];
                                            upInfoVC.meetID = _meeting_id;
                                            upInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                    
                                    
                                }else{//显示2
                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                    briefVC.meetID = _meeting_id;
                                    briefVC.briefDic = nextViewDic2;
                                    briefVC.blockID =  [nextViewDic2 objectForKey:@"block_id"];
                                    briefVC.configArr = [nextViewDic2 objectForKey:@"block_list"];
                                    [self.controller.navigationController pushViewController:briefVC animated:YES];
                                }
                                
                            }
                        }else{//显示3
                            UpViewController *upVC = [[UpViewController alloc]init];
                            upVC.meetID = _meeting_id;
                            upVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                            upVC.configArr = [nextViewDic1 objectForKey:@"block_list"];//3正常跳转 传4
                            [self.controller.navigationController pushViewController:upVC animated:YES];
                        }
                    }
                    if ([[nextViewDic1 objectForKey:@"type"]isEqualToString:@"2"]) {
                        if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {
                            NSDictionary *nextViewDic8 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic8  objectForKey:@"field_list"]count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic8 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic8 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic8 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic8  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                        }else{
                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                            briefVC.meetID = _meeting_id;
                            briefVC.briefDic = nextViewDic0;
                            briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                            briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                            [self.controller.navigationController pushViewController:briefVC animated:YES];
                        }
                    }
                    if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic1 objectForKey:@"field_list"] count]!=0) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic1 objectForKey:@"name"];
                        eduVC.meetID = _meeting_id;
                        eduVC.blockID =  [nextViewDic1 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic1 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                            perInfoVC.meetID = _meeting_id;
                            perInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                            perInfoVC.infoTitle = [nextViewDic1  objectForKey:@"name"];
                            perInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic1  objectForKey:@"name"];
                            upInfoVC.meetID = _meeting_id;
                            upInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                        }
                    }
                    //                        }else{//显示报名状态跟踪
                    //                            SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                    //                            stateVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                    //                            stateVC.meetID = _meeting_id;
                    //                            stateVC.type = [nextViewDic0 objectForKey:@"type"];
                    //                            stateVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                    //                            [self.controller.navigationController pushViewController:stateVC animated:YES];
                    //                        }
                }else{
                    if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"3"]) {
                        if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                            NSDictionary * nextViewDic5 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic5 objectForKey:@"type"]isEqualToString:@"2"]) {
                                if ([[nextViewDic5 objectForKey:@"block_list"] count] == 1) {
                                    NSDictionary *nextViewDic6 = [[nextViewDic5 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic6 objectForKey:@"field_list"] count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic6 objectForKey:@"name"];
                                        eduVC.meetID = _meeting_id;
                                        eduVC.blockID =  [nextViewDic6 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic6  objectForKey:@"field_list"] count]!=0) {
                                        if (![[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                            perInfoVC.meetID = _meeting_id;
                                            perInfoVC.blockID = [nextViewDic6 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [_nextViewDic  objectForKey:@"name"];
                                            upInfoVC.meetID = _meeting_id;
                                            upInfoVC.blockID = [_nextViewDic objectForKey:@"block_id"];
                                            upInfoVC.configArr = [_nextViewDic objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                        
                                    }
                                    
                                }else{
                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                    briefVC.meetID = _meeting_id;
                                    briefVC.briefDic = nextViewDic5;
                                    briefVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                                    briefVC.configArr = [nextViewDic5 objectForKey:@"block_list"];
                                    [self.controller.navigationController pushViewController:briefVC animated:YES];
                                }
                                
                            }
                            if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"1"]) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic5 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic5 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic5  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                            
                        }else{
                            UpViewController *upVC = [[UpViewController alloc]init];
                            upVC.meetID = _meeting_id;
                            upVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                            upVC.configArr = [nextViewDic0 objectForKey:@"block_list"];//3正常跳转 传4
                            [self.controller.navigationController pushViewController:upVC animated:YES];
                        }
                        
                    }
                    if ([[nextViewDic0 objectForKey:@"type"]isEqualToString:@"2"]) {
                        if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {
                            NSDictionary *nextViewDic4 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic4 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic4 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                                if (![[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic4  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                        }else{
                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                            briefVC.meetID = _meeting_id;
                            briefVC.briefDic = nextViewDic0;
                            briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                            briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                            [self.controller.navigationController pushViewController:briefVC animated:YES];
                        }
                    }
                    if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic0 objectForKey:@"name"];
                        eduVC.meetID = _meeting_id;
                        eduVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                            perInfoVC.meetID = _meeting_id;
                            perInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                            perInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic0  objectForKey:@"name"];
                            upInfoVC.meetID = _meeting_id;
                            upInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                        }
                    }
                }
            }
            
            else{
                if (_blockID.length != 0 ){
                    
                    for (NSDictionary *nextViewDic12 in [_configDic objectForKey:@"block_list"]) {
                        if ([[nextViewDic12 objectForKey:@"block_id"] isEqualToString:_blockID]) {
                            if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"10"]) {
                                if ([_signUpstate isEqualToString:@"1"]) {
                                    NSDictionary *nextViewDic13 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                    if ([[nextViewDic13 objectForKey:@"type"] isEqualToString:@"3"]) {
                                        if ([[nextViewDic13 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                            NSDictionary *nextViewDic14 = [[nextViewDic13 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic14 objectForKey:@"type"]isEqualToString:@"2"]) {
                                                if ([[nextViewDic14 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                                                    NSDictionary *nextViewDic15 = [[nextViewDic14 objectForKey:@"block_list"] objectAtIndex:0];
                                                    if ([[nextViewDic15 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic15  objectForKey:@"field_list"]count]!=0) {
                                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                        eduVC.addName = [nextViewDic15 objectForKey:@"name"];
                                                        eduVC.meetID = _meeting_id;
                                                        eduVC.blockID =  [nextViewDic15 objectForKey:@"block_id"];
                                                        eduVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                                                    }
                                                    if ([[nextViewDic15 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic15  objectForKey:@"field_list"]count]!=0 ) {
                                                        if (![[[[nextViewDic15  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                            perInfoVC.meetID = _meeting_id;
                                                            perInfoVC.blockID = [nextViewDic15 objectForKey:@"block_id"];
                                                            perInfoVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                                        }
                                                        if ([[[[nextViewDic15  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                            upInfoVC.upInfoTitle = [nextViewDic15  objectForKey:@"name"];
                                                            upInfoVC.meetID = _meeting_id;
                                                            upInfoVC.blockID = [nextViewDic15 objectForKey:@"block_id"];
                                                            upInfoVC.configArr = [nextViewDic15 objectForKey:@"field_list"];
                                                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                                        }
                                                    }
                                                    
                                                    
                                                }else{//显示2
                                                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                                                    briefVC.meetID = _meeting_id;
                                                    briefVC.briefDic = nextViewDic14;
                                                    briefVC.blockID =  [nextViewDic14 objectForKey:@"block_id"];
                                                    briefVC.configArr = [nextViewDic14 objectForKey:@"block_list"];
                                                    [self.controller.navigationController pushViewController:briefVC animated:YES];
                                                }
                                                
                                            }
                                        }else{//显示3
                                            UpViewController *upVC = [[UpViewController alloc]init];
                                            upVC.meetID = _meeting_id;
                                            upVC.blockID = [nextViewDic13 objectForKey:@"block_id"];
                                            upVC.configArr = [nextViewDic13 objectForKey:@"block_list"];//3正常跳转 传4
                                            [self.controller.navigationController pushViewController:upVC animated:YES];
                                        }
                                    }
                                    if ([[nextViewDic12 objectForKey:@"type"]isEqualToString:@"2"]) {
                                        if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {
                                            NSDictionary *nextViewDic16 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                            if ([[nextViewDic16 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic16  objectForKey:@"field_list"]count]!=0) {
                                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                eduVC.addName = [nextViewDic16 objectForKey:@"name"];
                                                eduVC.meetID = _meeting_id;
                                                eduVC.blockID =  [nextViewDic16 objectForKey:@"block_id"];
                                                eduVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                                [self.controller.navigationController pushViewController:eduVC animated:YES];
                                            }
                                            if ([[nextViewDic16 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic16 objectForKey:@"field_list"]count]!=0) {
                                                if (![[[[nextViewDic16  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                    perInfoVC.meetID = _meeting_id;
                                                    perInfoVC.blockID = [nextViewDic16 objectForKey:@"block_id"];
                                                    perInfoVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                                }
                                                if ([[[[nextViewDic16  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                    upInfoVC.upInfoTitle = [nextViewDic16  objectForKey:@"name"];
                                                    upInfoVC.meetID = _meeting_id;
                                                    upInfoVC.blockID = [nextViewDic16 objectForKey:@"block_id"];
                                                    upInfoVC.configArr = [nextViewDic16 objectForKey:@"field_list"];
                                                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                                }
                                            }
                                        }else{
                                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                                            briefVC.meetID = _meeting_id;
                                            briefVC.briefDic = nextViewDic12;
                                            briefVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                            briefVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                            [self.controller.navigationController pushViewController:briefVC animated:YES];
                                        }
                                    }
                                    if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic12 objectForKey:@"field_list"] count]!=0) {
                                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                        eduVC.addName = [nextViewDic12 objectForKey:@"name"];
                                        eduVC.meetID = _meeting_id;
                                        eduVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                        eduVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                                    }
                                    if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                        if (![[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                            perInfoVC.meetID = _meeting_id;
                                            perInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                            perInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                        }
                                        if ([[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                            upInfoVC.upInfoTitle = [nextViewDic12  objectForKey:@"name"];
                                            upInfoVC.meetID = _meeting_id;
                                            upInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                            upInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                        }
                                    }
                                }else{//显示报名状态跟踪
                                    SignUpStatusViewController *stateVC = [[SignUpStatusViewController alloc]init];
                                    stateVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                    stateVC.meetID = _meeting_id;
                                    stateVC.type = [nextViewDic12 objectForKey:@"type"];
                                    stateVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                    [self.controller.navigationController pushViewController:stateVC animated:YES];
                                }
                            }else{
                                if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"3"]) {
                                    if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                                        NSDictionary * nextViewDic17 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                        if ([[nextViewDic17 objectForKey:@"type"]isEqualToString:@"2"]) {
                                            if ([[nextViewDic17 objectForKey:@"block_list"] count] == 1) {
                                                NSDictionary *nextViewDic18 = [[nextViewDic17 objectForKey:@"block_list"] objectAtIndex:0];
                                                if ([[nextViewDic18 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic18 objectForKey:@"field_list"] count]!=0) {
                                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                                    eduVC.addName = [nextViewDic18 objectForKey:@"name"];
                                                    eduVC.meetID = _meeting_id;
                                                    eduVC.blockID =  [nextViewDic18 objectForKey:@"block_id"];
                                                    eduVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                    [self.controller.navigationController pushViewController:eduVC animated:YES];
                                                }
                                                if ([[nextViewDic18 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic18  objectForKey:@"field_list"] count]!=0) {
                                                    if (![[[[nextViewDic18  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                        PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                        perInfoVC.meetID = _meeting_id;
                                                        perInfoVC.blockID = [nextViewDic18 objectForKey:@"block_id"];
                                                        perInfoVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                        [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                                    }
                                                    if ([[[[nextViewDic18  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                        upInfoVC.upInfoTitle = [nextViewDic18  objectForKey:@"name"];
                                                        upInfoVC.meetID = _meeting_id;
                                                        upInfoVC.blockID = [nextViewDic18 objectForKey:@"block_id"];
                                                        upInfoVC.configArr = [nextViewDic18 objectForKey:@"field_list"];
                                                        [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                                    }
                                                    
                                                }
                                                
                                            }else{
                                                BriefViewController *briefVC = [[BriefViewController alloc]init];
                                                briefVC.meetID = _meeting_id;
                                                briefVC.briefDic = nextViewDic17;
                                                briefVC.blockID =  [nextViewDic17 objectForKey:@"block_id"];
                                                briefVC.configArr = [nextViewDic17 objectForKey:@"block_list"];
                                                [self.controller.navigationController pushViewController:briefVC animated:YES];
                                            }
                                        }
                                        if ([[nextViewDic17 objectForKey:@"type"] isEqualToString:@"1"]) {
                                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                            eduVC.addName = [nextViewDic17 objectForKey:@"name"];
                                            eduVC.meetID = _meeting_id;
                                            eduVC.blockID =  [nextViewDic17 objectForKey:@"block_id"];
                                            eduVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:eduVC animated:YES];
                                        }
                                        if ([[nextViewDic17 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic17 objectForKey:@"field_list"]count]!=0) {
                                            if (![[[[nextViewDic17  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                perInfoVC.meetID = _meeting_id;
                                                perInfoVC.blockID = [nextViewDic17 objectForKey:@"block_id"];
                                                perInfoVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                            }
                                            if ([[[[nextViewDic17  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                upInfoVC.upInfoTitle = [nextViewDic17  objectForKey:@"name"];
                                                upInfoVC.meetID = _meeting_id;
                                                upInfoVC.blockID = [nextViewDic17 objectForKey:@"block_id"];
                                                upInfoVC.configArr = [nextViewDic17 objectForKey:@"field_list"];
                                                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                            }
                                        }
                                        
                                    }else{
                                        UpViewController *upVC = [[UpViewController alloc]init];
                                        upVC.meetID = _meeting_id;
                                        upVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                        upVC.configArr = [nextViewDic12 objectForKey:@"block_list"];//3正常跳转 传4
                                        [self.controller.navigationController pushViewController:upVC animated:YES];
                                    }
                                    
                                }
                                if ([[nextViewDic12 objectForKey:@"type"]isEqualToString:@"2"]) {
                                    if ([[nextViewDic12 objectForKey:@"block_list"] count] == 1) {
                                        NSDictionary *nextViewDic19 = [[nextViewDic12 objectForKey:@"block_list"] objectAtIndex:0];
                                        if ([[nextViewDic19 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic19 objectForKey:@"field_list"]count]!=0) {
                                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                            eduVC.addName = [nextViewDic19 objectForKey:@"name"];
                                            eduVC.meetID = _meeting_id;
                                            eduVC.blockID =  [nextViewDic19 objectForKey:@"block_id"];
                                            eduVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                            [self.controller.navigationController pushViewController:eduVC animated:YES];
                                        }
                                        if ([[nextViewDic19 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic19 objectForKey:@"field_list"]count]!=0) {
                                            if (![[[[nextViewDic19  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                                perInfoVC.meetID = _meeting_id;
                                                perInfoVC.blockID = [nextViewDic19 objectForKey:@"block_id"];
                                                perInfoVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                            }
                                            if ([[[[nextViewDic19  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                                upInfoVC.upInfoTitle = [nextViewDic19  objectForKey:@"name"];
                                                upInfoVC.meetID = _meeting_id;
                                                upInfoVC.blockID = [nextViewDic19 objectForKey:@"block_id"];
                                                upInfoVC.configArr = [nextViewDic19 objectForKey:@"field_list"];
                                                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                            }
                                        }
                                    }else{
                                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                                        briefVC.meetID = _meeting_id;
                                        briefVC.briefDic = nextViewDic12;
                                        briefVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                        briefVC.configArr = [nextViewDic12 objectForKey:@"block_list"];
                                        [self.controller.navigationController pushViewController:briefVC animated:YES];
                                    }
                                }
                                if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                    eduVC.addName = [nextViewDic12 objectForKey:@"name"];
                                    eduVC.meetID = _meeting_id;
                                    eduVC.blockID =  [nextViewDic12 objectForKey:@"block_id"];
                                    eduVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:eduVC animated:YES];
                                }
                                if ([[nextViewDic12 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic12 objectForKey:@"field_list"]count]!=0) {
                                    if (![[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                        perInfoVC.meetID = _meeting_id;
                                        perInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                        perInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                        [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                    }
                                    if ([[[[nextViewDic12  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                        upInfoVC.upInfoTitle = [nextViewDic12  objectForKey:@"name"];
                                        upInfoVC.meetID = _meeting_id;
                                        upInfoVC.blockID = [nextViewDic12 objectForKey:@"block_id"];
                                        upInfoVC.configArr = [nextViewDic12 objectForKey:@"field_list"];
                                        [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                    }
                                }
                            }
                            
                        }
                    }
                }
                else{
                    _blockID = [_configDic objectForKey:@"block_id"];
                    SignUpTypeViewController *typeVC = [[SignUpTypeViewController alloc]init];
                    typeVC.meetID = _meeting_id;
                    typeVC.blockID = [_configDic objectForKey:@"block_id"];
                    typeVC.configDic = _configDic;
                    [self.controller.navigationController pushViewController:typeVC animated:YES];
                }
            }
        }
        if ([[_configDic objectForKey:@"type"] isEqualToString:@"3"]) {
            if ([[_configDic objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                NSDictionary *nextViewDic9 = [[_configDic objectForKey:@"block_list"] objectAtIndex:0];
                
                if ([[nextViewDic9 objectForKey:@"type"]isEqualToString:@"2"]) {
                    if ([[nextViewDic9 objectForKey:@"block_list"] count] == 1) {
                        NSDictionary *nextViewDic10 = [[nextViewDic9 objectForKey:@"block_list"] objectAtIndex:0];
                        if ([[nextViewDic10 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic10 objectForKey:@"field_list"] count]!=0) {
                            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                            eduVC.addName = [nextViewDic10 objectForKey:@"name"];
                            eduVC.meetID = _meeting_id;
                            eduVC.blockID =  [nextViewDic10 objectForKey:@"block_id"];
                            eduVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:eduVC animated:YES];
                        }
                        if ([[nextViewDic10 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic10 objectForKey:@"field_list"]count]!=0) {
                            if (![[[[nextViewDic10  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                perInfoVC.meetID = _meeting_id;
                                perInfoVC.blockID = [nextViewDic10 objectForKey:@"block_id"];
                                perInfoVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                            }
                            if ([[[[nextViewDic10  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                upInfoVC.upInfoTitle = [nextViewDic10  objectForKey:@"name"];
                                upInfoVC.meetID = _meeting_id;
                                upInfoVC.blockID = [nextViewDic10 objectForKey:@"block_id"];
                                upInfoVC.configArr = [nextViewDic10 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                            }
                            
                        }
                        
                    }else{
                        BriefViewController *briefVC = [[BriefViewController alloc]init];
                        briefVC.meetID = _meeting_id;
                        briefVC.briefDic = nextViewDic9;
                        briefVC.blockID =  [nextViewDic9 objectForKey:@"block_id"];
                        briefVC.configArr = [nextViewDic9 objectForKey:@"block_list"];
                        [self.controller.navigationController pushViewController:briefVC animated:YES];
                    }
                    
                }
                
            }else{
                UpViewController *upVC = [[UpViewController alloc]init];
                upVC.meetID = _meeting_id;
                upVC.blockID = [_configDic objectForKey:@"block_id"];
                upVC.configArr = [_configDic objectForKey:@"block_list"];//3正常跳转 传4
                [self.controller.navigationController pushViewController:upVC animated:YES];
            }
        }
        if ([[_configDic objectForKey:@"type"]isEqualToString:@"2"]) {
            if ([[_nextViewDic objectForKey:@"block_list"] count] == 1) {
                NSDictionary * nextViewDic11 = [[_nextViewDic objectForKey:@"block_list"] objectAtIndex:0];
                if ([[nextViewDic11 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic11 objectForKey:@"field_list"] count]!=0) {
                    EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                    eduVC.addName = [nextViewDic11 objectForKey:@"name"];
                    eduVC.meetID = _meeting_id;
                    eduVC.blockID =  [nextViewDic11 objectForKey:@"block_id"];
                    eduVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:eduVC animated:YES];
                }
                if ([[nextViewDic11 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic11 objectForKey:@"field_list"]count]!=0) {
                    if (![[[[nextViewDic11  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                        perInfoVC.meetID = _meeting_id;
                        perInfoVC.blockID = [nextViewDic11 objectForKey:@"block_id"];
                        perInfoVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                    }
                    if ([[[[nextViewDic11  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                        UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                        upInfoVC.upInfoTitle = [nextViewDic11  objectForKey:@"name"];
                        upInfoVC.meetID = _meeting_id;
                        upInfoVC.blockID = [nextViewDic11 objectForKey:@"block_id"];
                        upInfoVC.configArr = [nextViewDic11 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                    }
                    
                }
                
                
            }else{
                BriefViewController *briefVC = [[BriefViewController alloc]init];
                briefVC.meetID = _meeting_id;
                briefVC.briefDic = _nextViewDic;
                briefVC.blockID =  [_nextViewDic objectForKey:@"block_id"];
                briefVC.configArr = [_nextViewDic objectForKey:@"block_list"];
                [self.controller.navigationController pushViewController:briefVC animated:YES];
            }
        }
        if ([[_configDic objectForKey:@"type"] isEqualToString:@"1"]&&[[_configDic objectForKey:@"field_list"]count]!=0) {//第一层  type1
            EduExpViewController *eduVC = [[EduExpViewController alloc]init];
            eduVC.addName = [_configDic objectForKey:@"name"];
            eduVC.meetID = _meeting_id;
            eduVC.blockID =  [_configDic objectForKey:@"block_id"];
            eduVC.configArr = [_configDic objectForKey:@"field_list"];
            [self.controller.navigationController pushViewController:eduVC animated:YES];
        }
        if ([[_configDic objectForKey:@"type"] isEqualToString:@"0"]&&[[_configDic objectForKey:@"field_list"] count]!=0) {
            if (![[[[_configDic  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {//第一层  type1 且跳转到普通页
                PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                perInfoVC.meetID = _meeting_id;
                perInfoVC.blockID = [_configDic objectForKey:@"block_id"];
                perInfoVC.configArr = [_configDic objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:perInfoVC animated:YES];
            }
            if ([[[[_configDic  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {//第一层  type1 且跳转到上传图片
                UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                upInfoVC.upInfoTitle = [_configDic  objectForKey:@"name"];
                upInfoVC.meetID = _meeting_id;
                upInfoVC.blockID = [_configDic objectForKey:@"block_id"];
                upInfoVC.configArr = [_configDic objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:upInfoVC animated:YES];
            }
        }
    

}
- (void)manageConfigWithSameTicket:(NSInteger)ticketIndex
{
        NSDictionary *nextViewDic0 = [[_configDic objectForKey:@"block_list"] objectAtIndex:ticketIndex];
        if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"10"]) {
            NSDictionary *nextViewDic1 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
            if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"3"]) {
                if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                    NSDictionary *nextViewDic2 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic2 objectForKey:@"type"]isEqualToString:@"2"]) {
                        if ([[nextViewDic2 objectForKey:@"block_list"] count] == 1) { //type 2  长度1  跳过 显示  0或1
                            NSDictionary *nextViewDic3 = [[nextViewDic2 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic3 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic3 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic3 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic3  objectForKey:@"field_list"]count]!=0 ) {
                                if (![[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic3  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [nextViewDic3  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [nextViewDic3 objectForKey:@"block_id"];
                                    upInfoVC.configArr = [nextViewDic3 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                            
                            
                        }else{//显示2
                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                            briefVC.meetID = _meeting_id;
                            briefVC.briefDic = nextViewDic2;
                            briefVC.blockID =  [nextViewDic2 objectForKey:@"block_id"];
                            briefVC.configArr = [nextViewDic2 objectForKey:@"block_list"];
                            [self.controller.navigationController pushViewController:briefVC animated:YES];
                        }
                    }
                }else{//显示3
                    UpViewController *upVC = [[UpViewController alloc]init];
                    upVC.meetID = _meeting_id;
                    upVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                    upVC.configArr = [nextViewDic1 objectForKey:@"block_list"];//3正常跳转 传4
                    [self.controller.navigationController pushViewController:upVC animated:YES];
                }
            }
            if ([[nextViewDic1 objectForKey:@"type"]isEqualToString:@"2"]) {
                if ([[nextViewDic1 objectForKey:@"block_list"] count] == 1) {
                    NSDictionary *nextViewDic8 = [[nextViewDic1 objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic8  objectForKey:@"field_list"]count]!=0) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic8 objectForKey:@"name"];
                        eduVC.meetID = _meeting_id;
                        eduVC.blockID =  [nextViewDic8 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic8 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic8 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                            perInfoVC.meetID = _meeting_id;
                            perInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                            perInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic8  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic8  objectForKey:@"name"];
                            upInfoVC.meetID = _meeting_id;
                            upInfoVC.blockID = [nextViewDic8 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic8 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                        }
                    }
                }else{
                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                    briefVC.meetID = _meeting_id;
                    briefVC.briefDic = nextViewDic0;
                    briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                    briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                    [self.controller.navigationController pushViewController:briefVC animated:YES];
                }
            }
            if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic1 objectForKey:@"field_list"] count]!=0) {
                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                eduVC.addName = [nextViewDic1 objectForKey:@"name"];
                eduVC.meetID = _meeting_id;
                eduVC.blockID =  [nextViewDic1 objectForKey:@"block_id"];
                eduVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:eduVC animated:YES];
            }
            if ([[nextViewDic1 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic1 objectForKey:@"field_list"]count]!=0) {
                if (![[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                    perInfoVC.meetID = _meeting_id;
                    perInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                    perInfoVC.infoTitle = [nextViewDic1  objectForKey:@"name"];
                    perInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                }
                if ([[[[nextViewDic1  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                    upInfoVC.upInfoTitle = [nextViewDic1  objectForKey:@"name"];
                    upInfoVC.meetID = _meeting_id;
                    upInfoVC.blockID = [nextViewDic1 objectForKey:@"block_id"];
                    upInfoVC.configArr = [nextViewDic1 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                }
            }
        }else{
            if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"3"]) {
                if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {//type 3  长度1  跳过 显示  2
                    NSDictionary * nextViewDic5 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic5 objectForKey:@"type"]isEqualToString:@"2"]) {
                        if ([[nextViewDic5 objectForKey:@"block_list"] count] == 1) {
                            NSDictionary *nextViewDic6 = [[nextViewDic5 objectForKey:@"block_list"] objectAtIndex:0];
                            if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic6 objectForKey:@"field_list"] count]!=0) {
                                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                                eduVC.addName = [nextViewDic6 objectForKey:@"name"];
                                eduVC.meetID = _meeting_id;
                                eduVC.blockID =  [nextViewDic6 objectForKey:@"block_id"];
                                eduVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                [self.controller.navigationController pushViewController:eduVC animated:YES];
                            }
                            if ([[nextViewDic6 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic6  objectForKey:@"field_list"] count]!=0) {
                                if (![[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                                    perInfoVC.meetID = _meeting_id;
                                    perInfoVC.blockID = [nextViewDic6 objectForKey:@"block_id"];
                                    perInfoVC.configArr = [nextViewDic6 objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                                }
                                if ([[[[nextViewDic6  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                                    upInfoVC.upInfoTitle = [_nextViewDic  objectForKey:@"name"];
                                    upInfoVC.meetID = _meeting_id;
                                    upInfoVC.blockID = [_nextViewDic objectForKey:@"block_id"];
                                    upInfoVC.configArr = [_nextViewDic objectForKey:@"field_list"];
                                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                                }
                            }
                        }else{
                            BriefViewController *briefVC = [[BriefViewController alloc]init];
                            briefVC.meetID = _meeting_id;
                            briefVC.briefDic = nextViewDic5;
                            briefVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                            briefVC.configArr = [nextViewDic5 objectForKey:@"block_list"];
                            [self.controller.navigationController pushViewController:briefVC animated:YES];
                        }
                    }
                    if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"1"]) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic5 objectForKey:@"name"];
                        eduVC.meetID = _meeting_id;
                        eduVC.blockID =  [nextViewDic5 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic5 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic5 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                            perInfoVC.meetID = _meeting_id;
                            perInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                            perInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic5  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic5  objectForKey:@"name"];
                            upInfoVC.meetID = _meeting_id;
                            upInfoVC.blockID = [nextViewDic5 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic5 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                        }
                    }
                }else{
                    UpViewController *upVC = [[UpViewController alloc]init];
                    upVC.meetID = _meeting_id;
                    upVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                    upVC.configArr = [nextViewDic0 objectForKey:@"block_list"];//3正常跳转 传4
                    [self.controller.navigationController pushViewController:upVC animated:YES];
                }
            }
            if ([[nextViewDic0 objectForKey:@"type"]isEqualToString:@"2"]) {
                if ([[nextViewDic0 objectForKey:@"block_list"] count] == 1) {
                    NSDictionary *nextViewDic4 = [[nextViewDic0 objectForKey:@"block_list"] objectAtIndex:0];
                    if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                        EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                        eduVC.addName = [nextViewDic4 objectForKey:@"name"];
                        eduVC.meetID = _meeting_id;
                        eduVC.blockID =  [nextViewDic4 objectForKey:@"block_id"];
                        eduVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                        [self.controller.navigationController pushViewController:eduVC animated:YES];
                    }
                    if ([[nextViewDic4 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic4 objectForKey:@"field_list"]count]!=0) {
                        if (![[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                            perInfoVC.meetID = _meeting_id;
                            perInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                            perInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                        }
                        if ([[[[nextViewDic4  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                            UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                            upInfoVC.upInfoTitle = [nextViewDic4  objectForKey:@"name"];
                            upInfoVC.meetID = _meeting_id;
                            upInfoVC.blockID = [nextViewDic4 objectForKey:@"block_id"];
                            upInfoVC.configArr = [nextViewDic4 objectForKey:@"field_list"];
                            [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                        }
                    }
                }else{
                    BriefViewController *briefVC = [[BriefViewController alloc]init];
                    briefVC.meetID = _meeting_id;
                    briefVC.briefDic = nextViewDic0;
                    briefVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                    briefVC.configArr = [nextViewDic0 objectForKey:@"block_list"];
                    [self.controller.navigationController pushViewController:briefVC animated:YES];
                }
            }
            if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"1"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                EduExpViewController *eduVC = [[EduExpViewController alloc]init];
                eduVC.addName = [nextViewDic0 objectForKey:@"name"];
                eduVC.meetID = _meeting_id;
                eduVC.blockID =  [nextViewDic0 objectForKey:@"block_id"];
                eduVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                [self.controller.navigationController pushViewController:eduVC animated:YES];
            }
            if ([[nextViewDic0 objectForKey:@"type"] isEqualToString:@"0"]&&[[nextViewDic0 objectForKey:@"field_list"]count]!=0) {
                if (![[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                    PersonalInfoController *perInfoVC = [[PersonalInfoController alloc]init];
                    perInfoVC.meetID = _meeting_id;
                    perInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                    perInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:perInfoVC animated:YES];
                }
                if ([[[[nextViewDic0  objectForKey:@"field_list"] objectAtIndex:0] objectForKey:@"type"] isEqualToString:@"photo"]) {
                    UpInfoViewController *upInfoVC = [[UpInfoViewController alloc]init];
                    upInfoVC.upInfoTitle = [nextViewDic0  objectForKey:@"name"];
                    upInfoVC.meetID = _meeting_id;
                    upInfoVC.blockID = [nextViewDic0 objectForKey:@"block_id"];
                    upInfoVC.configArr = [nextViewDic0 objectForKey:@"field_list"];
                    [self.controller.navigationController pushViewController:upInfoVC animated:YES];
                }
            }
        }
}
@end
