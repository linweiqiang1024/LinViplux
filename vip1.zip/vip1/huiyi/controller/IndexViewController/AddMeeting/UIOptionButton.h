//
//  UIOptionButton.h
//  huiyi
//
//  Created by qstx1 on 14-10-31.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIOptionButton : UIButton

@end
