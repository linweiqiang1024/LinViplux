//
//  UIContentVIew.h
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIContentVIew : UIView
{
    BOOL didSetupConstraints;
}
@property (nonatomic,strong) UILabel *topLine;
@property (nonatomic,strong) UILabel *endLine;
@end
