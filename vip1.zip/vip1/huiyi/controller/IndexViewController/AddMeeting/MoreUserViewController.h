//
//  MoreUserViewController.h
//  huiyi
//
//  Created by songhongshuai on 14/11/18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
#import "MJRefresh.h"
@interface MoreUserViewController : FatherViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSString *_meetID;
    NSString *_personal_data_sw;
}
@property(nonatomic,strong)NSString *meetID;
@property (nonatomic,strong)NSString *personal_data_sw;
@end
