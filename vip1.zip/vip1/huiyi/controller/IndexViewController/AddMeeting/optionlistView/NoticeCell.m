//
//  NoticeCell.m
//  huiyi
//
//  Created by songhongshuai on 15/6/30.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "NoticeCell.h"
#import "UIImageView+WebCache.h"
@interface NoticeCell ()
@property (nonatomic,strong)UIImageView *headImageView;
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UILabel *contentLB;
@property (nonatomic,strong)UILabel *timeLB;
@end

@implementation NoticeCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.headImageView];
        [self.contentView addSubview:self.titleLB];
        [self.contentView addSubview:self.contentLB];
        [self.contentView addSubview:self.timeLB];
    }
    return self;
}
- (UIImageView*)headImageView
{
    if (!_headImageView) {
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(10, 10, 93, 71)];
        _headImageView.backgroundColor = [UIColor blueColor];
        _headImageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _headImageView;
}
- (void)setModel:(New_signUpInfoListModel *)model
{
    NSString *str = @"中青在线北京6月30日中青在线北京6月啊";
    [self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.modelImg] placeholderImage:[UIImage imageNamed:@"notice"]];
    self.titleLB.text = model.modelName;
    self.contentLB.text = [self getContentL:model.modelshot_summary];
    self.timeLB.text = model.modelUpload_time;
}
- (NSString *)getContentL:(NSString *)content
{
    if (iPhone4||iPhone5) {
        if (content.length <=9) {
            self.timeLB.frame = CGRectMake(ScreenWidth-90, 55, 76, 12);
        }else if (content.length > 9&&content.length <14){
            content = [content substringToIndex:7];
            content = [NSString stringWithFormat:@"%@...",content];
            self.timeLB.frame = CGRectMake(ScreenWidth-90, 55, 76, 12);
        }
        if(content.length>=22){
            content = [content substringToIndex:21];
            content = [NSString stringWithFormat:@"%@...",content];
            self.timeLB.frame = CGRectMake(ScreenWidth-85, 63, 76, 12);
        }
    }else if (iPhone6){
        if (content.length <=12) {
            self.timeLB.frame = CGRectMake(ScreenWidth-85, 55, 76, 12);
        }else if (content.length > 12&&content.length <=19){
            content = [content substringToIndex:11];
            content = [NSString stringWithFormat:@"%@...",content];
            self.timeLB.frame = CGRectMake(ScreenWidth-85, 55, 76, 12);
        }
        if(content.length>=29){
            content = [content substringToIndex:29];
            content = [NSString stringWithFormat:@"%@...",content];
            self.timeLB.frame = CGRectMake(ScreenWidth-85, 63, 76, 12);
        }
    }else if (iphone6Plus){
        if (content.length <=14) {
            self.timeLB.frame = CGRectMake(ScreenWidth-85, 57, 76, 12);
        }else if (content.length > 14&&content.length <=22){
            content = [content substringToIndex:14];
            content = [NSString stringWithFormat:@"%@...",content];
            self.timeLB.frame = CGRectMake(ScreenWidth-90, 57, 76, 12);
        }
        if(content.length>=33){
            content = [content substringToIndex:33];
            content = [NSString stringWithFormat:@"%@...",content];
            
        }
    }
    return content;
}
- (UILabel*)titleLB
{
    if (!_titleLB) {
        _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+10 , 12, ScreenWidth-CGRectGetMaxX(self.headImageView.frame)-24, 17)];
        _titleLB.text = @"公告";
        _titleLB.textColor = [UIColor colorWithHexString:@"#141414"];
        _titleLB.font = YHUI(17);
        BackGroundColor(_titleLB, clearColor);
    }
    return _titleLB;
}
- (UILabel *)contentLB
{
    if (!_contentLB) {
        _contentLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+10 , CGRectGetMaxY(self.titleLB.frame)+7, ScreenWidth-CGRectGetMaxX(self.headImageView.frame)-20, 50)];
        _contentLB.text = @"公告详情";
        _contentLB.textColor = [UIColor colorWithHexString:@"#cccccb"];
        _contentLB.font = YHUI(14);
        _contentLB.numberOfLines = 2;
        _contentLB.lineBreakMode = NSLineBreakByCharWrapping;
        BackGroundColor(_contentLB, clearColor);
    }
    return _contentLB;
}
- (UILabel *)timeLB
{
    if (!_timeLB) {
        _timeLB = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth-90, 63, 76, 12)];
        BackGroundColor(_timeLB, clearColor);
        _timeLB.textColor = [UIColor colorWithHexString:@"#8f8e8e"];
        _timeLB.font = YHUI(14);
        _timeLB.text = @"18:60";
        _timeLB.textAlignment = NSTextAlignmentRight;
    }
    return _timeLB;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    UIBezierPath *bezierPath;
    if (_FristLine) {
        bezierPath = [[UIBezierPath alloc]init];
        [bezierPath moveToPoint:CGPointMake(0, 0.5)];
        [bezierPath addLineToPoint:CGPointMake(rect.size.width, 0.5)];
        [[UIColor colorWithHexString:@"#c8c7cc"] setStroke];//
        [bezierPath setLineWidth:0.5];
        [bezierPath stroke];
    }
    
    bezierPath = [[UIBezierPath alloc]init];
    [bezierPath moveToPoint:CGPointMake(0, rect.size.height-0.5)];
    [bezierPath addLineToPoint:CGPointMake(rect.size.width, rect.size.height-0.5)];
    [[UIColor colorWithHexString:@"#c8c7cc"] setStroke];//
    [bezierPath setLineWidth:0.5];
    [bezierPath stroke];
}
@end
