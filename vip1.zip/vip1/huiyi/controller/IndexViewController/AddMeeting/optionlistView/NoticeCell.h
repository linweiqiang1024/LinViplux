//
//  NoticeCell.h
//  huiyi
//
//  Created by songhongshuai on 15/6/30.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "New_signUpInfoListModel.h"
@interface NoticeCell : UITableViewCell
@property (nonatomic)BOOL FristLine;
@property (nonatomic)BOOL EndLine;
@property (nonatomic,strong)New_signUpInfoListModel *model;
@end
