//
//  New_signUpInfoListVC.m
//  huiyi
//
//  Created by 王振兴 on 14-11-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "New_signUpInfoListVC.h"
#import "MapCell.h"
#import "NoticeCell.h"
#import "New_signUpInfoListModel.h"
#import "New_signUpInfoListWebVC.h"
@implementation New_signUpInfoListVC
{
    MBProgressHUD *HUD;
    UITableView *_tableView;
    NSMutableArray *_dataArray;
}
@synthesize meetint_id,plugin_id,titleName,plugin_type;
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"New_signUpInfoListVC"];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"New_signUpInfoListVC"];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
//create  tableView
- (void)createTableView{
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    // Do any additional setup after loading the view.
    SET_NAV_HEIGHT;
    [self customizeAboveToolbar];
    _dataArray = [[NSMutableArray alloc]init];
    [self createTableView];
    [self getDataFromNetWrok];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_dataArray count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 91;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellName = @"cellName";
    New_signUpInfoListModel *model = [_dataArray objectAtIndex:indexPath.row];
    NoticeCell *cell = [tableView dequeueReusableCellWithIdentifier:cellName];
    if (!cell) {
        cell = [[NoticeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName];
    }
    if (indexPath.row == 0) {
        cell.FristLine = YES;
    }else{
        cell.FristLine = NO;
    }
    cell.model = model;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return  cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    New_signUpInfoListModel *model = [_dataArray objectAtIndex:indexPath.row];
    New_signUpInfoListWebVC *webVC = [[New_signUpInfoListWebVC alloc]init];
    webVC.summary = model.modelSummary;
    webVC.titleName = self.titleName;
    [self.navigationController pushViewController:webVC animated:YES];
}
- (void) customizeAboveToolbar
{
    self.titlelabel.text = self.titleName;
}
-(void)gobac:(UIButton *)btn{
    [self.navigationController popViewControllerAnimated: YES];
}
#pragma mark 下载网络数据
- (void)getDataFromNetWrok{
    NSDictionary *params = @{@"meeting_id":meetint_id,@"plugin_id":plugin_id,@"page":@"1"};
    [MyDataService platformPlugincommonArticleGetsectionlist:params callback:^(id data) {
        NSLog(@"%@",data);
        [self hideHUD];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                for(NSDictionary *dic in [[data objectForKey:@"content"] objectForKey:@"list"]){
                    New_signUpInfoListModel *model = [[New_signUpInfoListModel alloc]init];
                    model.modelshot_summary = [dic objectForKey:@"shot_summary"];
                    model.modelImg = [dic objectForKey:@"img"];
                    model.modelItem_id = [dic objectForKey:@"item_id"];
                    model.modelMeeting_id = [dic objectForKey:@"meeting_id"];
                    model.modelName = [dic objectForKey:@"name"];
                    model.modelPlugin_id = [dic objectForKey:@"plugin_id"];
                    model.modelSn = [dic objectForKey:@"sn"];
                    model.modelSummary = [dic objectForKey:@"summary"];
                    model.modelUpload_time = [self formatter:@"MM-dd HH:mm" ToTime:[dic objectForKey:@"upload_time"]];
                    [_dataArray addObject:model];
                }
                [_tableView reloadData];
            }
        }
    } ];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
