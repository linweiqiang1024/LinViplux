//
//  New_signUpInfoListModel.h
//  huiyi
//
//  Created by 王振兴 on 14-11-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface New_signUpInfoListModel : NSObject
{
    NSString *_modelImg;
    NSString *_modelItem_id;
    NSString *_modelMeeting_id;
    NSString *_modelName;
    NSString *_modelPlugin_id;
    NSString *_modelSn;
    NSString *_modelSummary;
    NSString *_modelUpload_time;
}
@property (nonatomic,strong)NSString *modelshot_summary;
@property (nonatomic,strong)NSString *modelImg;
@property (nonatomic,strong)NSString *modelItem_id;
@property (nonatomic,strong)NSString *modelMeeting_id;
@property (nonatomic,strong)NSString *modelName;
@property (nonatomic,strong)NSString *modelPlugin_id;
@property (nonatomic,strong)NSString *modelSn;
@property (nonatomic,strong)NSString *modelSummary;
@property (nonatomic,strong)NSString *modelUpload_time;
@end
