//
//  New_signUpInfoListWebVC.m
//  huiyi
//
//  Created by 王振兴 on 14-11-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "New_signUpInfoListWebVC.h"

@implementation New_signUpInfoListWebVC
{
    MBProgressHUD *HUD;
}
@synthesize scrollView,summary,titleName;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (NSString *)textForView
{
    NSLog(@"%@",[NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"ServiceTerm" ofType:@"txt"] encoding:NSUTF8StringEncoding error:nil]);
    return [NSString stringWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"ServiceTerm" ofType:@"txt"] encoding:NSUTF8StringEncoding error:nil];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    // Do any additional setup after loading the view.
    SET_NAV_HEIGHT;
    [self customizeAboveToolbar];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    CGFloat height = [[UIScreen mainScreen] bounds].size.height;
    UIWebView *_webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0+self.F_NAV_HEIGHT, ScreenWidth, IOS7 ? height - 64:height - 64)];
    _webView.delegate = self;
    _webView.scalesPageToFit = YES;
    _webView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_webView];
    HUD = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    HUD.labelText = @"加载中";
    //HUD.dimBackground = YES;
    HUD.mode = MBProgressHUDModeIndeterminate;
    [HUD show:YES];
    NSString *htmlStrs = [NSString stringWithFormat:@"<!DOCTYPE html><html lang=\"en\"><head><meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" /><meta charset=\"utf-8\" /><meta name=\"description\" content=\"Common UI Features &amp; Elements\" /><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\" /><style>img{max-width:100%%;}</style></head><body>%@</body></html>",summary];
    [_webView loadHTMLString:htmlStrs baseURL:nil];

}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [HUD removeFromSuperview];
}
- (void) customizeAboveToolbar
{
    self.titlelabel.text = self.titleName;
}
-(void)gobac:(UIButton *)btn{
    [self.navigationController popViewControllerAnimated: YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
