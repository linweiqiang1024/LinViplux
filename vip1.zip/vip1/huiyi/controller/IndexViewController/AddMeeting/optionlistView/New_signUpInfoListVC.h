//
//  New_signUpInfoListVC.h
//  huiyi
//
//  Created by 王振兴 on 14-11-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface New_signUpInfoListVC : FatherViewController<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) NSString *meetint_id;
@property (nonatomic, strong) NSString *plugin_id;
@property (nonatomic, strong) NSString *titleName;
@property (nonatomic, strong) NSString *plugin_type;
@end
