//
//  New_signUpInfoListModel.m
//  huiyi
//
//  Created by 王振兴 on 14-11-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "New_signUpInfoListModel.h"

@implementation New_signUpInfoListModel
@synthesize modelImg,modelItem_id,modelMeeting_id,modelName,modelPlugin_id,modelSn,modelSummary,modelUpload_time;
@end
