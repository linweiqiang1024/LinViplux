//
//  New_signUpInfoListWebVC.h
//  huiyi
//
//  Created by 王振兴 on 14-11-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface New_signUpInfoListWebVC : FatherViewController<UIWebViewDelegate>
@property (nonatomic, retain) UIScrollView *scrollView;
@property (nonatomic,strong)NSString *summary;
@property (nonatomic,strong)NSString *titleName;

@end
