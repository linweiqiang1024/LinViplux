//
//  MeetTypeCollectionViewCell.m
//  huiyi
//
//  Created by 林伟强 on 16/7/28.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "MeetTypeCollectionViewCell.h"

@implementation MeetTypeCollectionViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

- (id)initWithCoder: (NSCoder *)aDecoder {
    self = [super initWithCoder: aDecoder];
    if (self) {
        self = [self sharedInit];
    }
    return self;
}

- (id)sharedInit {
    [self setup];
    return self;
}

- (void)setup {
    self.titleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.titleButton.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
    [self.titleButton setTitleColor:[UIColor colorWithHexString:@"#686868"] forState:UIControlStateNormal];
    [self.titleButton setTitleColor:[UIColor colorWithHexString:@"#0aaa08"] forState:UIControlStateSelected];
    [self.titleButton.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
    if (iPhone6 || iphone6Plus) {
        [self.titleButton.titleLabel setFont:[UIFont systemFontOfSize:13.0]];
    }
    [self.titleButton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.titleButton.layer setCornerRadius:15.0];
    [self.titleButton.layer setMasksToBounds:YES];
    [self.titleButton.layer setBorderWidth:0.5];
    [self.titleButton.layer setBorderColor:[[UIColor colorWithHexString:@"#686868"] CGColor]];
    [self.contentView addSubview:self.titleButton];
}

- (void)buttonAction:(UIButton *)sender
{    
    if (self.sendBlock) {
        self.sendBlock(sender);
    }
}

@end
