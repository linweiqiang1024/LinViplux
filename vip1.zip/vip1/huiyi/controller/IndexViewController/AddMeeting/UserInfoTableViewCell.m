//
//  UserInfoTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "UserInfoTableViewCell.h"

@implementation UserInfoTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andIsShowCompany:(BOOL)isShowCompany
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        BackGroundColor(self.contentView, whiteColor);
        
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(11, 6, 40, 40)];
        [_headImageView.layer setCornerRadius:CGRectGetHeight([_headImageView bounds])/2];
        _headImageView.layer.masksToBounds = YES;
        _headImageView.image = PNGIMAGE(@"mine_userheader@2x");
        [self.contentView addSubview:_headImageView];
        
        self.nameLB.backgroundColor = [UIColor clearColor];
        self.nameLB.font = YHUI(14);
        self.nameLB.textColor = [UIColor blackColor];
        
        if (isShowCompany) {
            self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+9, 10, ScreenWidth-130, 15)];
            _companyAndPosition = [[UILabel alloc]init];
            _companyAndPosition.frame = CGRectMake(CGRectGetMaxX(self.headImageView.frame)+9, 30, ScreenWidth-130, 15);
            _companyAndPosition.backgroundColor = [UIColor clearColor];
            _companyAndPosition.font = YHUI(12);
            _companyAndPosition.textColor = [UIColor lightGrayColor];
            [self.contentView addSubview:_companyAndPosition];
        }
        else {
            self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.headImageView.frame)+9, 6, 320-130, 40)];
        }
        [self.contentView addSubview:self.nameLB];
        
        self.timeLB = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth-145, 6, 120, 40)];
        self.timeLB.backgroundColor = [UIColor clearColor];
        self.timeLB.font = YHUI(12);
        self.timeLB.textAlignment = NSTextAlignmentRight;
        self.timeLB.textColor = [UIColor colorWithHexString:@"#a6a6a7"];
        [self.contentView addSubview:self.timeLB];

    }
    
    return self;
}

- (void)setIsEnd:(BOOL)isEnd
{
    if (isEnd) {
        UIView *line = [[UIView alloc]initWithFrame:CGRectMake(0, 52-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line, @"#c8c7cc");
        [self.contentView  addSubview:line];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
