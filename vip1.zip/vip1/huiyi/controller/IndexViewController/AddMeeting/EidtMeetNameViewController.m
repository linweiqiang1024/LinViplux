//
//  EidtMeetNameViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "EidtMeetNameViewController.h"
#import "RegistTextField.h"
#import "Helper.h"
@interface EidtMeetNameViewController ()<UITextFieldDelegate>
{
    NSMutableDictionary *reNameDic;
}
@end

@implementation EidtMeetNameViewController
- (void)ReturnBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)creatRightBtn
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(ScreenWidth-54, 20, 40, 44);
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    rightbtn.titleLabel.font = YHUI_BOLD(16);
    [rightbtn setTitle:@"完成" forState:UIControlStateNormal];
    [self.view addSubview:rightbtn];

}
- (void)postData:(NSDictionary *)dict{
    [MyDataService postModMeeting:dict callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
            [_delegate callBackInfoWith:[reNameDic objectForKey:_postKey] :_postKey];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
}

- (void)rightBtnClicked
{
    if ([_postKey isEqualToString:@"title"]) {
        if ([[reNameDic objectForKey:_postKey]length]<35&&[[reNameDic objectForKey:_postKey]length]>=2) {
            [self postData:reNameDic];
        }else{
            [Dialog toast:@"会议名称大于2个汉字小于35个汉字"];
        }
    }
    else if ([_postKey isEqualToString:@"posters_url"]) {
        [self postData:reNameDic];
    }
    else if ([_postKey isEqualToString:@"yqx_url"]) {
        [self postData:reNameDic];
    }
    else if ([_postKey isEqualToString:@"reply_email"]) {
        if ([[reNameDic objectForKey:_postKey] length] != 0 && ![Helper justEmail:[reNameDic objectForKey:_postKey]]) {
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动联系邮箱格式不正确" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
        else {
            [self postData:reNameDic];
        }
    }
    else {
        [MyDataService postModMeeting:reNameDic callback:^(id data) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
                [_delegate callBackInfoWith:[reNameDic objectForKey:_postKey] :_postKey];
                [self.navigationController popViewControllerAnimated:YES];
            }
        }];
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self creatRightBtn];
    self.titlelabel.text = _view_title;
    reNameDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [reNameDic setObject:_meet_id forKey:@"meeting_id"];
    if (_meet_title.length == 0) {
        [reNameDic setObject:@"" forKey:_postKey];
    }else{
        [reNameDic setObject:_meet_title forKey:_postKey];
    }
    
    UIView *editView = [[UIView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT + 14, ScreenWidth, 46)];
    editView.backgroundColor = [UIColor whiteColor];
    
    UILabel* headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLineLB, @"#c8c7cc");
    [editView  addSubview:headLineLB];
    
    UILabel* endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 45.5, ScreenWidth, 0.5)];
    BackGround16Color(endLineLB, @"#c8c7cc");
    [editView  addSubview:endLineLB];
    
    RegistTextField *nameField = [[RegistTextField alloc]initWithFrame:CGRectMake(13, 8, ScreenWidth-20, 30)];
    nameField.text = _meet_title;
    nameField.placeholder = self.placeHolde;
    [nameField addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
    nameField.placeHolderFont = 15;
    nameField.delegate=self;
    nameField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [editView addSubview:nameField];
    [self.view addSubview:editView];
    
    while([Helper widthOfString:self.placeHolde font:[UIFont systemFontOfSize:nameField.placeHolderFont] height:30] > nameField.width){
        nameField.placeHolderFont--;
    }
    
    // Do any additional setup after loading the view.
}
- (void)textChange:(RegistTextField *)textField
{
    [reNameDic setObject:textField.text forKey:_postKey];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
