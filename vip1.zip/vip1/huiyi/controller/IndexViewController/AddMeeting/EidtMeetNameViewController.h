//
//  EidtMeetNameViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@protocol callBackInfoDelegate <NSObject>

- (void)callBackInfoWith:(NSString *)content :(NSString *)postKey;

@end

@interface EidtMeetNameViewController : FatherViewController
@property(strong,nonatomic)NSString *view_title;
@property(strong,nonatomic)NSString *placeHolde;
@property(strong,nonatomic)NSString *meet_title;
@property(strong,nonatomic)NSString *meet_id;
@property(strong,nonatomic)NSString *postKey;

@property(weak,nonatomic)id<callBackInfoDelegate>delegate;

@end
