//
//  WebViewTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "WebViewTableViewCell.h"

@implementation WebViewTableViewCell
@synthesize infoWebView = _infoWebView;
@synthesize webHeight = _webHeight;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.infoWebView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, _webHeight)];
    
        self.infoWebView.backgroundColor = [UIColor blackColor];
        self.infoWebView.scrollView.scrollEnabled = NO;
        [self.contentView addSubview:_infoWebView];
        

    }
    
    return self;
}

- (void)setWebHeight:(int)webHeight
{
    if (webHeight!=0) {
        self.infoWebView.frame = CGRectMake(0, 0, ScreenWidth, webHeight);
    }
    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, webHeight+0.5, ScreenWidth, 0.5)];
    BackGround16Color(endLineLB, @"#c8c7cc");
    [self.contentView addSubview:endLineLB];

}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
