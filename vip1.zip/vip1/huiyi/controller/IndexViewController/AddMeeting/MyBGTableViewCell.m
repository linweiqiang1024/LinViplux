//
//  MyBGTableViewCell.m
//  huiyi
//
//  Created by qstx1 on 14-10-29.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MyBGTableViewCell.h"

@implementation MyBGTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
//        headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
//        BackGround16Color(headLineLB, @"#c8c7cc");
//        [self.contentView  addSubview:headLineLB];
        
        endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 44.5, ScreenWidth, 0.5)];
        BackGround16Color(endLineLB, @"#c8c7cc");
        [self.contentView  addSubview:endLineLB];
        
        midLB = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth/2, 0, 0.5, 43)];
        BackGround16Color(midLB, @"#c8c7cc");
        midLB.hidden = YES;
        [self.contentView  addSubview:midLB];

       
        

//        endLineLB.autoresizingMask
        _titleLB  = [[UILabel alloc]initWithFrame:CGRectMake(12, 0, ScreenWidth-50, 45)];
        _titleLB.backgroundColor = [UIColor clearColor];
        _titleLB.font = YHUI(16);
        _titleLB.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_titleLB];
        
        
        _meetTypeBtn1 = [UITypeButton buttonWithType:UIButtonTypeCustom];
        [_meetTypeBtn1 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateSelected];
        [_meetTypeBtn1 setImage:[UIImage imageNamed:@"cur_jc"] forState:UIControlStateNormal];
    
        [_meetTypeBtn1 setTitle:@"聚餐" forState:UIControlStateNormal];
        _meetTypeBtn1.frame = CGRectMake(90, 9, 65, 26);
        _meetTypeBtn1.tag = 50+1;
        _meetTypeBtn1.isShow = YES;
        [_meetTypeBtn1 addTarget:self action:@selector(selectMeetType:) forControlEvents:UIControlEventTouchUpInside];
        _meetTypeBtn1.backgroundColor = [UIColor clearColor];
        _meetTypeBtn1.titleLabel.font = YHUI(14);
        [_meetTypeBtn1 setTitleColor:[UIColor
                                      colorWithHexString:@"#676767"] forState:UIControlStateNormal];
        [self.contentView addSubview:_meetTypeBtn1];
        
        
        _meetTypeBtn2 = [UITypeButton buttonWithType:UIButtonTypeCustom];
        [_meetTypeBtn2 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateSelected];
        [_meetTypeBtn2 setImage:[UIImage imageNamed:@"cur_cg"] forState:UIControlStateNormal];
        [_meetTypeBtn2 addTarget:self action:@selector(selectMeetType:) forControlEvents:UIControlEventTouchUpInside];
        [_meetTypeBtn2 setTitle:@"娱乐" forState:UIControlStateNormal];
        _meetTypeBtn2.frame = CGRectMake(CGRectGetMaxX(_meetTypeBtn1.frame), 9, 65, 26);
        _meetTypeBtn2.isShow = YES;
        _meetTypeBtn2.tag = 50+2;
    
        _meetTypeBtn2.titleLabel.font = YHUI(14);
        [_meetTypeBtn2 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
        [self.contentView addSubview:_meetTypeBtn2];
        
        _meetTypeBtn3 = [UITypeButton buttonWithType:UIButtonTypeCustom];
        
        [_meetTypeBtn3 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateSelected];
        [_meetTypeBtn3 setImage:[UIImage imageNamed:@"cur_yd"] forState:UIControlStateNormal];
        
        [_meetTypeBtn3 setTitle:@"运动" forState:UIControlStateNormal];
        _meetTypeBtn3.frame = CGRectMake(CGRectGetMaxX(_meetTypeBtn2.frame), 9, 65, 26);
        [_meetTypeBtn3 addTarget:self action:@selector(selectMeetType:) forControlEvents:UIControlEventTouchUpInside];
        _meetTypeBtn3.isShow = YES;
        _meetTypeBtn3.tag = 50+3;
        [_meetTypeBtn3 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
        _meetTypeBtn3.titleLabel.font = YHUI(14);
        [self.contentView addSubview:_meetTypeBtn3];
        

        
        UIImage *buttonImageselected = [UIImage imageNamed:@"new_07"];
        buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImageselected.size.width/2) topCapHeight:floorf(buttonImageselected.size.height/2)];
        
        _costBtn = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
        _costBtn.frame = CGRectMake(90, 9, 76, 24);
        _costBtn.hidden = YES;
        _costBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
        [_costBtn setTitleColor:[UIColor colorWithHexString:@"#7082c7"] forState:UIControlStateNormal];

        [self.contentView addSubview:_costBtn];
        

        
        
    }
    return self;
}
- (void)selectMeetType:(UITypeButton *)btn
{
    [_delegate meetTypeChange:btn];
}
- (void)setIsHead:(BOOL)isHead
{
    if (isHead == YES) {
        headLineLB.hidden = NO;
    }else{
        headLineLB.hidden = YES;
    }
}
- (void)setIsEnd:(BOOL)isEnd
{
    if (isEnd) {
        endLineLB.frame = CGRectMake(0, 44.5, ScreenWidth, 0.5);
    }else{
        endLineLB.frame = CGRectMake(15, 44.5, ScreenWidth, 0.5);
    }
}
//- (void)setHaveMoreTitle:(BOOL)haveMoreTitle
//{
//    if (haveMoreTitle == YES) {
//        
//        _titleLB.frame = CGRectMake(13, 0, 35 ,43);
//        _contentLB.frame = CGRectMake(CGRectGetMaxX(_titleLB.frame)+22, 0, 58, 43);
//        _contentLB.hidden = NO;
//        _sharecontentLB.hidden = NO;
//        _shareTitleLB.hidden = NO;
//        midLB.hidden = NO;
//        
//    }else{
//        _titleLB.frame = CGRectMake(13, 0, 280, 43);
//        _contentLB.hidden = NO;
//        midLB.hidden = YES;
//    }
//}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
