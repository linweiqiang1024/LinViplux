//
//  UIContentVIew_02.h
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIContentVIew_02 : UIView
@property (nonatomic,strong)UILabel *nameLB;
@property (nonatomic,strong)UILabel *sTimeLB;
@property (nonatomic,strong)UILabel *eTimeLB;
@end
