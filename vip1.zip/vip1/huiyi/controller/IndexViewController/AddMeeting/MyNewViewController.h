//
//  MyNewViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-29.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@interface MyNewViewController : FatherViewController
{
    UIScrollView *_myMeetView;
}
@end
