//
//  UIContentVIew_02.m
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIContentVIew_02.h"

@implementation UIContentVIew_02

- (id)initWithFrame:(CGRect)frame
{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.nameLB = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 60, 41)];
        self.nameLB.backgroundColor = [UIColor clearColor];
        self.nameLB.textAlignment = NSTextAlignmentLeft;
        self.nameLB.font = YHUI(15);
        [self  addSubview:self.nameLB];
        
        
        self.sTimeLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_nameLB.frame)+28, 16, ScreenWidth-100, 14)];
        self.sTimeLB.backgroundColor = [UIColor clearColor];
        self.sTimeLB.textAlignment = NSTextAlignmentLeft;
        self.sTimeLB.textColor = [UIColor colorWithHexString:@"#7c7c7c"];
        self.sTimeLB.font = YHUI(15);
        [self  addSubview:self.sTimeLB];
        
        self.eTimeLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_nameLB.frame)+28, CGRectGetMaxY(_sTimeLB.frame)+10, ScreenWidth-100, 14)];
        self.eTimeLB.textColor = [UIColor colorWithHexString:@"#7c7c7c"];
        self.eTimeLB.backgroundColor = [UIColor clearColor];
        self.eTimeLB.textAlignment = NSTextAlignmentLeft;
        self.eTimeLB.font = YHUI(15);
        [self  addSubview:self.eTimeLB];
        
        UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(15, frame.size.height-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line, @"#c8c7cc");
        [self  addSubview:line];
        
    }
    return self;
}


@end
