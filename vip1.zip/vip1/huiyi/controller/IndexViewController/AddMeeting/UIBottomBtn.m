//
//  UIBottomBtn.m
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "UIBottomBtn.h"

@implementation UIBottomBtn

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        // Initialization code
    }
    return self;
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(81, 8, 24, 19);
}
- (CGRect)titleRectForContentRect:(CGRect)contentRect{
    
   
    return CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
}


@end
