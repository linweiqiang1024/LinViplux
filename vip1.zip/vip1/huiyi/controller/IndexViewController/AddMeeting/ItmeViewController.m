//
//  ItmeViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "ItmeViewController.h"
#import "SignUpFieldsModel.h"
@interface ItmeViewController ()
{
    NSArray *_optionsArr;
    NSMutableDictionary *postDic;
    NSMutableArray *dataArr;
}
@end

@implementation ItmeViewController

- (void)createNavRightBtn
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(240, _navheight+4, 80, 40);
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    rightbtn.titleLabel.font = YHUI_BOLD(16);
    [rightbtn setTitle:@"完成" forState:UIControlStateNormal];
    [self.view addSubview:rightbtn];
}
- (void)rightBtnClicked
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithCapacity:0];
    for (SignUpFieldsModel *info in dataArr) {
        if (info.selected == YES) {
            [dic setObject:@"1" forKey:info.postKey];
        }else{
            [dic setObject:@"0" forKey:info.postKey];
        }
    }
    NSDictionary *param = @{@"meeting_id":_meeting_id,@"fieldArr":dic};
    [MyDataService postSetBaseFieldsNew:param callback:^(id data) {
        NSLog(@"%@",data);
        [self.navigationController popViewControllerAnimated:YES];
    }];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    postDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    dataArr = [[NSMutableArray alloc]initWithCapacity:0];
    [self creatData];
    [self getConfigData];
    [self createNavRightBtn];
    
    // Do any additional setup after loading the view.
}
- (void)createUI
{
    self.titlelabel.text = @"参会者报名字段";
    CGFloat headViewHeight ;
    if (dataArr.count%3==0) {
        headViewHeight = 45+30+34*(dataArr.count/3);
    }else{
        headViewHeight = 45+30+34*(dataArr.count/3+1);
    }
    UIView *headview = [[UIView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT+14, ScreenWidth, headViewHeight)];
    headview.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:headview];
    
    UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLineLB, @"#c8c7cc");
    [headview addSubview:headLineLB];
    
    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(headview.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(endLineLB, @"#c8c7cc");
    [headview addSubview:endLineLB];
    
    UILabel *nameLB = [[UILabel alloc]initWithFrame:CGRectMake(18.5, 0.5, 250, 31)];
    nameLB.text = @"参会者报名字段";
    nameLB.font = YHUI(16);
    nameLB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    
    nameLB.backgroundColor = [UIColor clearColor];
    [headview addSubview:nameLB];

    for (int i = 0; i < dataArr.count; i++) {
        SignUpFieldsModel *info = (SignUpFieldsModel *)[dataArr objectAtIndex:i];
        UIButton *itemBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
        if (info.selected == YES) {
            itemBtn.selected = YES;
        }else{
            itemBtn.selected = NO;
        }
        itemBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        
        [itemBtn setTitleColor:[UIColor colorWithHexString:@"#5c677e"] forState:UIControlStateSelected];
        [itemBtn setTitleColor:[UIColor colorWithHexString:@"#080808"] forState:UIControlStateNormal];
        [itemBtn setTitle:info.title forState:UIControlStateNormal];
        itemBtn.frame = CGRectMake( 25+(25+73)*(i%3), CGRectGetMaxY(nameLB.frame)+35*(i/3), 73, 25);
        [itemBtn setBackgroundImage:[UIImage imageNamed:@"seleced_btn"] forState:UIControlStateSelected];
        [itemBtn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
        itemBtn.titleLabel.font = YHUI(16);
        itemBtn.backgroundColor = [UIColor clearColor];
        [itemBtn addTarget:self action:@selector(itemBtntnClicked:) forControlEvents:UIControlEventTouchUpInside];
        itemBtn.tag = 130+i;
        [headview addSubview:itemBtn];
    }
    UILabel *tailDiscribeLB = [[UILabel alloc]initWithFrame:CGRectMake(15, CGRectGetHeight(headview.frame)-51.5, ScreenWidth, 51)];
    tailDiscribeLB.text = @"选项不够用或需要更多报名类型？请发布完毕后，电脑上访问专业版管理后台配置报名选项";
    tailDiscribeLB.font = YHUI(14);
    tailDiscribeLB.numberOfLines = 0;
    tailDiscribeLB.lineBreakMode = NSLineBreakByCharWrapping;
    [headview addSubview:tailDiscribeLB];
     //[self getConfigData];
    
}
- (void)getConfigData
{
    NSDictionary *param = @{@"meeting_id":_meeting_id};
    [MyDataService postBaseFieldsNew:param callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"]isEqualToString:@"200"]) {
            NSDictionary *fieldDic = [[data objectForKey:@"content"] objectForKey:@"fieldArr"];
            for (SignUpFieldsModel *info in dataArr) {
                for (NSString  *key in [fieldDic allKeys]) {
                    if ([info.postKey isEqualToString:key]) {
                        if ([[fieldDic objectForKey:key]isEqualToString:@"1"]) {
                            info.selected = YES;
                        }else{
                            info.selected = NO;
                        }
                    }
                }
            }
            [self createUI];
        }
    }];
}
-(void)creatData
{
    switch ([_meet_type integerValue]-1) {
        case 0:
            
            break;
        case 1:
        case 2:
        case 3:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"remarks"];
            for (NSString *postkey in keys) {
                int index = [keys indexOfObject:postkey];
                if (index<3) {
                    SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                    info.postKey = postkey;
                    info.selected = YES;
                    info.title = [_optionsArr objectAtIndex:index];
                    [dataArr addObject:info];
                }else{
                    SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                    info.postKey = postkey;
                    info.selected = NO;
                    info.title = [_optionsArr objectAtIndex:index];
                    [dataArr addObject:info];
                }
            }
        }
            
            break;
        case 4:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"remarks"];
            for (NSString *postkey in keys) {
                int index = [keys indexOfObject:postkey];
                if (index<3) {
                    SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                    info.postKey = postkey;
                    info.selected = YES;
                    info.title = [_optionsArr objectAtIndex:index];
                    [dataArr addObject:info];
                }else{
                    SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                    info.postKey = postkey;
                    info.selected = NO;
                    info.title = [_optionsArr objectAtIndex:index];
                    [dataArr addObject:info];
                }
            }
        }
            break;
        case 5:
        case 6:{
            _optionsArr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职位",@"性别",@"是否住宿",@"专业领域",@"备注"];
            NSArray *keys = @[@"nickname",@"phone",@"email",@"company",@"position",@"sex",@"isstay",@"major",@"remarks"];
            for (NSString *postkey in keys) {
                int index = [keys indexOfObject:postkey];
                if (index<3) {
                    SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                    info.postKey = postkey;
                    info.selected = YES;
                    info.title = [_optionsArr objectAtIndex:index];
                    [dataArr addObject:info];
                }else{
                    SignUpFieldsModel *info = [[SignUpFieldsModel alloc]init];
                    info.postKey = postkey;
                    info.selected = NO;
                    info.title = [_optionsArr objectAtIndex:index];
                    [dataArr addObject:info];
                }
            }
        }
            break;
        default:
            break;
    }


}

- (void)itemBtntnClicked:(UIButton *)btn
{
    if (btn.tag > 131) {
        btn.selected = !btn.selected;
        SignUpFieldsModel *info = (SignUpFieldsModel *)[dataArr objectAtIndex:(btn.tag - 130)];
        if (btn.selected == YES) {
            info.selected = YES;
        }else{
            info.selected = NO;
        }
        [dataArr replaceObjectAtIndex:(btn.tag-130) withObject:info];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
