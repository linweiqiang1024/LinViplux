//
//  PartyViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-22.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"


@interface PartyViewController : FatherViewController
{
    int _type;
    NSString *_nav_title;
    NSArray *_optionsArr;
}
@property (nonatomic)int type;
@property (nonatomic, retain) NSArray *photos;
@property (nonatomic, strong) NSMutableArray *thumbs;
@property (nonatomic, strong) NSString *nav_title;
@end
