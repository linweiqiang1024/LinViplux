//
//  ActSheetCell.m
//  huiyi
//
//  Created by 王振兴 on 15-2-9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "ActSheetCell.h"

@implementation ActSheetCell

- (void)awakeFromNib {
    // Initialization code
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor colorWithHexString:@"#fbfbfb"];
        self.contentView.layer.borderWidth = 0.5;
        self.contentView.layer.masksToBounds =YES;
        self.contentView.layer.borderColor = [[UIColor colorWithHexString:@"d6d6d6"]CGColor];
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    _topRightImage = [[UIImageView alloc]init];
    _topRightImage.frame = CGRectMake(ScreenWidth-34-53, 0, 53, 56);
    _topRightImage.image = [UIImage imageNamed:@"actsheet_selected"];
    _topRightImage.hidden = YES;
    [self.contentView addSubview:_topRightImage];
    
    _titleLB = [[UILabel alloc]initWithFrame:CGRectMake(48, 17, ScreenWidth-20-48*2, 21)];
    _titleLB.font = YHUI(19);
    _titleLB.textColor = [UIColor colorWithHexString:@"#65a5bc"];
    _titleLB.backgroundColor = [UIColor clearColor];
    _titleLB.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_titleLB];
    
    _costLB = [[UILabel alloc]initWithFrame:CGRectMake(48, CGRectGetMaxY(_titleLB.frame) + 13, ScreenWidth-20-48*2, 19)];
    _costLB.font = YHUI(19);
    _costLB.textColor = [UIColor colorWithHexString:@"#c9a766"];
    _costLB.backgroundColor = [UIColor clearColor];
    _costLB.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_costLB];
    
    UIImageView *lineImageView = [[UIImageView alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(_costLB.frame)+11, ScreenWidth-60, 1)];
    lineImageView.image = [UIImage imageNamed:@"ticket_mid_line"];
    [self addSubview:lineImageView];
    
    UILabel *endTimeTitle = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_costLB.frame)+20, 97, 15)];
    endTimeTitle.backgroundColor = [UIColor clearColor];
    endTimeTitle.textColor = [UIColor colorWithHexString:@"#999b9f"];
    endTimeTitle.font = YHUI(15);
    endTimeTitle.text = @"报名截止时间:";
    [self addSubview:endTimeTitle];
    
    _endTimeLB = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(endTimeTitle.frame), CGRectGetMaxY(_costLB.frame)+20, ScreenWidth-32-CGRectGetMaxX(endTimeTitle.frame), 16)];
    _endTimeLB.font = YHUI(16);
    _endTimeLB.textColor = [UIColor colorWithHexString:@"#999b9f"];
    _endTimeLB.backgroundColor = [UIColor clearColor];
    _endTimeLB.textAlignment = NSTextAlignmentLeft;
    [self addSubview:_endTimeLB];
    
    _introLB = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_endTimeLB.frame)+10, ScreenWidth-44, 15)];
    _introLB.font = YHUI(15);
    _introLB.textColor = [UIColor colorWithHexString:@"#999b9f"];
    _introLB.backgroundColor = [UIColor clearColor];
    _introLB.lineBreakMode = NSLineBreakByWordWrapping;
    _introLB.numberOfLines = 0;
    _introLB.textAlignment = NSTextAlignmentLeft;
    [self addSubview:_introLB];
}
- (void)setIntroHeight:(NSString *)content
{
    CGSize size = [content sizeWithFont:YHUI(15) constrainedToSize:CGSizeMake(ScreenWidth-44, 500) lineBreakMode:NSLineBreakByWordWrapping];
    _introLB.size = CGSizeMake(_introLB.size.width, size.height);
}
- (void)setFrame:(CGRect)frame{
    frame.size.height -=14;
    frame.origin.x +=17;
    frame.size.width -=34;
    [super setFrame:frame];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
