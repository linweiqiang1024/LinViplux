//
//  IsOpenPhoneView.m
//  huiyi
//
//  Created by 王振兴 on 15-1-19.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "IsOpenPhoneView.h"

@implementation IsOpenPhoneView

- (instancetype)init
{
    self = [super init];
    if (self) {
        UIView *topLine = [[UIView alloc]init];
//        topLine.frame = cgr
    }
    return self;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
