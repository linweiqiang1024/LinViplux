//
//  UICostTypeButton.m
//  huiyi
//
//  Created by songhongshuai on 15/1/5.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UICostTypeButton.h"

@implementation UICostTypeButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = YHUI(14);
        [self setTitleColor:[UIColor colorWithHexString:@"#049dce"] forState:UIControlStateSelected];
        [self setTitleColor:[UIColor colorWithHexString:@"#cccccc"] forState:UIControlStateNormal];
        
    }
    return self;
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(self.frame.size.width-9, -7, 16 , 16);
}
- (CGRect)titleRectForContentRect:(CGRect)contentRect{
    
    return CGRectMake(0, 0, self.frame.size.width , self.frame.size.height);
    
}


@end
