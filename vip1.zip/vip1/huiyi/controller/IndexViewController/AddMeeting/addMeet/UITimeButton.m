//
//  UITimeButton.m
//  huiyi
//
//  Created by songhongshuai on 15/1/5.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UITimeButton.h"

@implementation UITimeButton
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
         self.titleLabel.textAlignment = NSTextAlignmentLeft;
    }
    return self;
}


- (CGRect)titleRectForContentRect:(CGRect)contentRect{

    return CGRectMake(0, 0, self.frame.size.width - 10, self.frame.size.height);

}
//- (CGRect)imageRectForContentRect:(CGRect)contentRect
//{
//    return CGRectMake(20, 15, 22, 19);
//}


@end
