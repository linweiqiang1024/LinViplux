//
//  UITypeButton.h
//  huiyi
//
//  Created by songhongshuai on 15/1/5.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITypeButton : UIButton
@property(nonatomic)BOOL isShow;
@end
