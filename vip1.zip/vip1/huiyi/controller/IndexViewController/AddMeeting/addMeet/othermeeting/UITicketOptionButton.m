//
//  UITicketOptionButton.m
//  huiyi
//
//  Created by songhongshuai on 15/1/24.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UITicketOptionButton.h"

@implementation UITicketOptionButton

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(26, 0, ScreenWidth-28-26-113, self.size.height);
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
