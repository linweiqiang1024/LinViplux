//
//  SDImageView.m
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import "SDImageView.h"

@implementation SDImageView
- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        
        _midImageView = [[UIImageView alloc]initWithFrame:CGRectMake(1, 1, frame.size.width-2, frame.size.height-5)];
        _midImageView.backgroundColor = [UIColor clearColor];
        [self addSubview:_midImageView];
        _iconImageView = [[UIImageView alloc]initWithFrame:CGRectMake(26, 41, 39, 18)];
        _iconImageView.hidden = YES;
        _iconImageView.backgroundColor = [UIColor clearColor];
        [self addSubview:_iconImageView];
        
        _delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _delBtn.frame = CGRectMake(0, 0, 50, 50);
        _delBtn.center = CGPointMake(frame.size.width, 0);
        [_delBtn setImage:[UIImage imageNamed:@"delPoster"] forState:UIControlStateNormal];
        _delBtn.hidden = NO;
        _delBtn.backgroundColor = [UIColor clearColor];
        [_delBtn addTarget:self action:@selector(deleteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_delBtn];

    }
    return self;
}
- (void)deleteBtnClick:(UIButton *)btn
{
    [_delegate deleteImage:btn];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
