//
//  TicketDontDeleteView.h
//  huiyi
//
//  Created by 林伟强 on 16/11/10.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TicketDontDeleteView : UIView

@property (nonatomic, strong) UIControl *mycontrol;
@property (nonatomic, strong) UIView    *bgView;
@property (nonatomic, strong) UILabel   *topLabel;
@property (nonatomic, strong) UILabel   *textLabel;
@property (nonatomic, strong) UIView    *lineView;
@property (nonatomic, strong) UILabel   *cancelLabel;
@property (nonatomic, strong) UIButton  *cancelButton;

- (void)reloadView:(NSString *)text;
- (void)show;
- (void)cancel;

@end
