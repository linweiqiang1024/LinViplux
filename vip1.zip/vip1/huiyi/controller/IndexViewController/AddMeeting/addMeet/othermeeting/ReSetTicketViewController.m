//
//  ReSetTicketViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/3/12.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "ReSetTicketViewController.h"
#import "TicketTableViewCell.h"
#import "SetTicketTypeTableViewCell.h"
#import "CostTableViewCell.h"
#import "New_managerViewController.h"
#import "InsertCostTableViewCell.h"
#import "DescripTableViewCell.h"
#import "SignUpEndTimeTableViewCell.h"
#import "OtherMeetTwoStpeModel.h"
#import "meetOptionTableViewCell.h"
#import "EndTableViewCell.h"
#import "STAlertView.h"
#import "MeetTypeViewController.h"
#import "DBManager.h"
#import "GTMBase64.h"
#import "LoginViewController.h"
#import "MyDataService.h"
#import "OptionViewController.h"
#import "SDTimeActiontSheet.h"
#import "OtherMeetTicketModel.h"
#import "CheckInfoTableViewCell.h"
#import "TicketTypeViewController.h"
#import "TicketEidtView.h"

@interface ReSetTicketViewController ()<UITableViewDataSource,UITableViewDelegate,addOtherMeetingDelegate,ShowCostDelegate,EndOfAddMeetTicketDelegate,UIScrollViewDelegate,checkDelegate,GetTicketTypeInfoDelegate,SDTimeActionSheetDelegate,callBackOptionItemsDelegate,TicketEidtViewDelegate>
{
    UITableView * ticketTpyeView;
    NSIndexPath *timeIndex;
    BOOL keyBoardShow;
    NSMutableArray *fieldArr;
    OtherMeetTicketModel *new_ticketInfo;
    NSMutableArray * new_ticketInfoArr;
}
@property (nonatomic,strong)SDTimeActiontSheet *dateActionSheet;
@end

@implementation ReSetTicketViewController

- (void)viewWillDisappear:(BOOL)animated
{
    if (self.dateActionSheet.isShow == YES) {
        [self.dateActionSheet tappedCancel];
    }
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"ReSetTicketViewController"];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    [MobClick beginLogPageView:@"ReSetTicketViewController"];
}

- (void)keyboardShow:(NSNotification*)notification {
    if (keyBoardShow == NO) {
        NSDictionary *userInfo = [notification userInfo];
        NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
        CGSize size = [aValue CGRectValue].size;
        ticketTpyeView.size = CGSizeMake(ScreenWidth, ticketTpyeView.size.height-size.height);
    }
    keyBoardShow = YES;
}

- (void)keyboardHide:(NSNotification*)notification {
    keyBoardShow = NO;
    ticketTpyeView.size = CGSizeMake(ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT);
    [UIView animateWithDuration:0.25 animations:^{
        
    }];
}

/*
- (void)ReturnBtn
{
    if (_isAdd == YES) {
        [_delegate delLastTicet];
    }
    [self.navigationController popViewControllerAnimated:YES];
}*/

- (void)viewDidLoad {
    [super viewDidLoad];
    
    fieldArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    new_ticketInfo = [[OtherMeetTicketModel alloc]init];
    new_ticketInfo = _ticketInfo;
    if(_isAdd == YES){
        _titlelabel.text = @"新票种类型";
    }else{
        _titlelabel.text = _view_title;
    }
    new_ticketInfoArr = [[NSMutableArray alloc]initWithCapacity:0];
    [new_ticketInfoArr addObjectsFromArray:_ticketInfoArr];
    ticketTpyeView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT+10, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT) style:UITableViewStylePlain];
    ticketTpyeView.sectionFooterHeight = 0;
    ticketTpyeView.sectionHeaderHeight = 0;
    ticketTpyeView.delegate = self;
    ticketTpyeView.dataSource = self;
    ticketTpyeView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    ticketTpyeView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:ticketTpyeView];
}

- (void)ticketEidt
{
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)_ticketInfo;
    
    OptionViewController *optionVC = [[OptionViewController alloc]init];
    optionVC.delegate = self;
    optionVC.all_partake_fields = _ticketInfoArr;
    optionVC.partake_fields = ticketInfo.fields ;
    optionVC.index = _section;
    [self.navigationController pushViewController:optionVC animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_ticket.showTicketPrice == NO) {
        if (_isTemp) {
            return 8;
        }
        else {
            return 7;
        }
    }else{
        if (_isTemp) {
            return 9;
        }
        else {
            return 8;
        }
    }
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)_ticket;
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)_ticketInfo;
    
    if (info.showTicketPrice == YES) {
        if (indexPath.row == 3) {
            TicketTypeViewController *vc = [[TicketTypeViewController alloc]init];
            vc.delegate = self;
            vc.section = indexPath.section;
            vc.summary = ticketInfo.ticketInfo;
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 4) {
            [self.view endEditing:YES];
            timeIndex = indexPath;
            if (NO == self.dateActionSheet.isShow) {
                self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
                self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
            }
            [self.dateActionSheet showInView:self.view];
        }
        if (_isTemp) {
            if (indexPath.row == 7) {
                
                for (NSDictionary *dic in [ticketInfo.fields allValues]) {
                    if (![[dic objectForKey:@"type"]isEqualToString:@"textField"]) {
                        UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该报名字段已在web端编辑，手机端不可修改" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        return;
                    }
                }
                
                OptionViewController *optionVC = [[OptionViewController alloc]init];
                optionVC.delegate = self;
                optionVC.all_partake_fields = _ticketInfoArr;
                optionVC.partake_fields = ticketInfo.fields ;
                optionVC.index = _section;
                [self.navigationController pushViewController:optionVC animated:YES];
            }
        }
        else {
            if (indexPath.row == 6) {
                
                for (NSDictionary *dic in [ticketInfo.fields allValues]) {
                    if (![[dic objectForKey:@"type"]isEqualToString:@"textField"]) {
                        UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该报名字段已在web端编辑，手机端不可修改" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        return;
                    }
                }
                
                if ([ticketInfo.partake_counts isEqualToString:@"0"] || _isAdd == YES) {
                    OptionViewController *optionVC = [[OptionViewController alloc]init];
                    optionVC.delegate = self;
                    optionVC.all_partake_fields = _ticketInfoArr;
                    optionVC.partake_fields = ticketInfo.fields ;
                    optionVC.index = _section;
                    [self.navigationController pushViewController:optionVC animated:YES];
                }
                else {
                    TicketEidtView *ticketEidtView = [[TicketEidtView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
                    ticketEidtView.delegate = self;
                    //[ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，修改报名字段，可能会造成已报名数据与修改后的字段内容不匹配或丢失！",ticketInfo.partake_counts]];
                    [ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，增、删、改报名字段，有可能会造成已报名数据与修改后的字段内容不匹配或填报数据丢失，您确认要修改报名字段吗？",ticketInfo.partake_counts]];
                    [ticketEidtView show];
                }
            }
        }
        /*
        if (indexPath.row == 6) {
            CATransition *animation = [CATransition animation];
            //animation.delegate = self;
            animation.duration = 0.5f;
            animation.timingFunction = UIViewAnimationCurveEaseInOut;
            animation.fillMode = kCAFillModeForwards;
            animation.type = kCATransitionPush;
            animation.subtype = kCATransitionFromBottom;
            [self.view.layer addAnimation:animation forKey:nil];
            OptionViewController *optionVC = [[OptionViewController alloc]init];
            optionVC.delegate = self;
            optionVC.all_partake_fields = _ticketInfoArr;
            optionVC.partake_fields = [ticketInfo.fields objectForKey:@"partake_fields"];
            optionVC.index = indexPath.section;
            [self.navigationController pushViewController:optionVC animated:NO];
        }*/
    }
    else {
        if (indexPath.row == 2) {
            TicketTypeViewController *vc = [[TicketTypeViewController alloc]init];
            vc.delegate = self;
            vc.section = _section;
            vc.summary = ticketInfo.ticketInfo;
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 3) {
            timeIndex = indexPath;
            [self.view endEditing:YES];
            if (NO == self.dateActionSheet.isShow) {
                self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
                self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
            }
            [self.dateActionSheet showInView:self.view];
        }
        if (_isTemp) {
            if (indexPath.row == 6) {
                
                for (NSDictionary *dic in [ticketInfo.fields allValues]) {
                    if (![[dic objectForKey:@"type"]isEqualToString:@"textField"]) {
                        UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该报名字段已在web端编辑，手机端不可修改" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        return;
                    }
                }
                
                if ([ticketInfo.partake_counts isEqualToString:@"0"] || _isAdd == YES) {
                    OptionViewController *optionVC = [[OptionViewController alloc]init];
                    optionVC.delegate = self;
                    optionVC.all_partake_fields = _ticketInfoArr;
                    optionVC.partake_fields = ticketInfo.fields ;
                    optionVC.index = _section;
                    [self.navigationController pushViewController:optionVC animated:YES];
                }
                else {
                    TicketEidtView *ticketEidtView = [[TicketEidtView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
                    ticketEidtView.delegate = self;
                    //[ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，修改报名字段，可能会造成已报名数据与修改后的字段内容不匹配或丢失！",ticketInfo.partake_counts]];
                    [ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，增、删、改报名字段，有可能会造成已报名数据与修改后的字段内容不匹配或填报数据丢失，您确认要修改报名字段吗？",ticketInfo.partake_counts]];
                    [ticketEidtView show];
                }
            }
        }
        else {
            if (indexPath.row == 5) {
                
                for (NSDictionary *dic in [ticketInfo.fields allValues]) {
                    if (![[dic objectForKey:@"type"]isEqualToString:@"textField"]) {
                        UIAlertView *alertview = [[UIAlertView alloc]initWithTitle:@"提示" message:@"该报名字段已在web端编辑，手机端不可修改" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        return;
                    }
                }
                
                if ([ticketInfo.partake_counts isEqualToString:@"0"] || _isAdd == YES) {
                    OptionViewController *optionVC = [[OptionViewController alloc]init];
                    optionVC.delegate = self;
                    optionVC.all_partake_fields = _ticketInfoArr;
                    optionVC.partake_fields = ticketInfo.fields ;
                    optionVC.index = _section;
                    [self.navigationController pushViewController:optionVC animated:YES];
                }
                else {
                    TicketEidtView *ticketEidtView = [[TicketEidtView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
                    ticketEidtView.delegate = self;
                    //[ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，修改报名字段，可能会造成已报名数据与修改后的字段内容不匹配或丢失！",ticketInfo.partake_counts]];
                    [ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，增、删、改报名字段，有可能会造成已报名数据与修改后的字段内容不匹配或填报数据丢失，您确认要修改报名字段吗？",ticketInfo.partake_counts]];
                    [ticketEidtView show];
                }
            }
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)_ticketInfo;
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel *)_ticket;
    
    if (info.showTicketPrice == YES) {
        
        if (indexPath.row == 0)
        {
            return 82;
        }
        if (indexPath.row == 1) {
            return 50;
        }
        if (indexPath.row == 2) {
            return 50;
        }
        if (indexPath.row == 3) {
            CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(16) constrainedToSize:CGSizeMake(ScreenWidth-20-66, 500) lineBreakMode:NSLineBreakByWordWrapping];
            return 82-16+size.height+5;
        }
        if (indexPath.row == 4) {
            return 50;
        }
        if (indexPath.row == 5) {
            return 50;
        }
        if (indexPath.row == 6) {
            return 50;
        }
        if (_isTemp) {
            if (indexPath.row == 7) {
                return 50;
            }
            if (indexPath.row == 8) {
                return 70;
            }
        }
        else {
            if (indexPath.row == 7) {
                return 70;
            }
        }
    }
    else {
        
        if (indexPath.row == 0)
        {
            return 82;
        }
        if (indexPath.row == 1) {
            return 50;
        }
        if (indexPath.row == 2) {
            CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(16) constrainedToSize:CGSizeMake(ScreenWidth-20-66, 500) lineBreakMode:NSLineBreakByWordWrapping];
            return 82-16+size.height+5;
        }
        if (indexPath.row == 3) {
            return 50;
        }
        if (indexPath.row == 4) {
            return 50;
        }
        if (indexPath.row == 5) {
            return 50;
        }
        if (_isTemp) {
            if (indexPath.row == 6) {
                return 50;
            }
            if (indexPath.row == 7) {
                return 70;
            }
        }
        else {
            if (indexPath.row == 6) {
                return 70;
            }
        }
    }
    return 0;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel *)_ticket;
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel *)_ticketInfo;
    
    if (indexPath.row == 0) {
        static NSString *CellIdentifier = @"setTicketCell";
        SetTicketTypeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[SetTicketTypeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        cell.contentTF.tag = 500000+indexPath.section;
        cell.contentTF.text = ticketInfo.ticketType;
        [cell.contentTF addTarget:self action:@selector(getContentInfo:) forControlEvents:UIControlEventEditingChanged];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    if (indexPath.row == 1) {
        static NSString *CellIdentifier = @"costCell";
        CostTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[CostTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        cell.titleLB.text = @"该类型是否收费";
        cell.delegate = self;
        if (info.showTicketPrice == YES) {
            cell.switchBtn.on = YES;
        }
        else {
            cell.switchBtn.on = NO;
        }
        cell.switchBtn.tag = indexPath.section +200000;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    if (info.showTicketPrice == NO) {
        if (indexPath.row == 2) {
            static NSString *CellIdentifier = @"DescripCell";
            DescripTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[DescripTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.contentLB = nil;
            if (ticketInfo.ticketInfo.length != 0) {
                [cell setContentLBWith:ticketInfo.ticketInfo];
                cell.contentLB.text = ticketInfo.ticketInfo;
                cell.contentLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
            }
            else {
                [cell setContentLBWith:@"多说说，说明一下包含的内容"];
                cell.contentLB.text = @"多说说，说明一下包含的内容";
                cell.contentLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (indexPath.row == 3) {
            static NSString *CellIdentifier = @"SignUpEndTimeCell";
            SignUpEndTimeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[SignUpEndTimeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.contentLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:ticketInfo.signUpEndTime]];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (indexPath.row == 4) {
            static NSString *CellIdentifier = @"CheckInfoCell";
            CheckInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[CheckInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            
            cell.delegate = self;
            cell.switchBtn.tag = indexPath.section +300000;
            cell.titleLB.text = @"报名需经我审核";
            if (ticketInfo.isCheck == YES) {
                cell.switchBtn.on = YES;
            }
            else {
                cell.switchBtn.on = NO;
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (_isTemp) {
            if (indexPath.row == 5) {
                static NSString *CellIdentifier = @"CheckTempCell";
                CheckInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[CheckInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                
                cell.delegate = self;
                cell.switchBtn.tag = indexPath.section +800000;
                cell.titleLB.text = @"隐藏无码签到";
                if ([ticketInfo.visible isEqualToString:@"0"]) {
                    cell.switchBtn.on = YES;
                }
                else {
                    cell.switchBtn.on = NO;
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 6) {
                static NSString *CellIdentifier = @"meetOptionCell";
                meetOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[meetOptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 7) {
                static NSString *CellIdentifier = @"EndCell";
                EndTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[EndTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.delegate = self;
                cell.btn.tag = indexPath.section +400000;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
        }
        else {
            if (indexPath.row == 5) {
                static NSString *CellIdentifier = @"meetOptionCell";
                meetOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[meetOptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 6) {
                static NSString *CellIdentifier = @"EndCell";
                EndTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[EndTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.delegate = self;
                cell.btn.tag = indexPath.section +400000;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
        }
    }
    if (info.showTicketPrice == YES) {
        
        if (indexPath.row == 2) {
            static NSString *CellIdentifier = @"InsertCostCell";
            InsertCostTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[InsertCostTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            if (![ticketInfo.cost isEqualToString:@"免费"]){
                cell.contentTF.text = [ticketInfo.cost substringToIndex:ticketInfo.cost.length-3];
            }
            else {
                cell.contentTF.text = @"";
            }
            cell.contentTF.tag = 600000+indexPath.section;
            [cell.contentTF addTarget:self action:@selector(getCostInfo:) forControlEvents:UIControlEventEditingChanged];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (indexPath.row == 3) {
            static NSString *CellIdentifier = @"DescripCell";
            DescripTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[DescripTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.contentLB = nil;
            if (ticketInfo.ticketInfo.length != 0) {
                [cell setContentLBWith:ticketInfo.ticketInfo];
                cell.contentLB.text = ticketInfo.ticketInfo;
                cell.contentLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
            }
            else {
                [cell setContentLBWith:@"多说说，说明一下包含的内容"];
                cell.contentLB.text = @"多说说，说明一下包含的内容";
                cell.contentLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (indexPath.row == 4) {
            static NSString *CellIdentifier = @"SignUpEndTimeCell";
            SignUpEndTimeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[SignUpEndTimeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.contentLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:ticketInfo.signUpEndTime]];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (indexPath.row == 5) {
            static NSString *CellIdentifier = @"CheckInfoCell";
            CheckInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[CheckInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.titleLB.text = @"报名需经我审核";
            if (ticketInfo.isCheck == YES) {
                cell.switchBtn.on = YES;
            }
            else {
                cell.switchBtn.on = NO;
            }
            cell.switchBtn.tag = 300000 +indexPath.section;
            cell.delegate = self;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            return cell;
        }
        if (_isTemp) {
            if (indexPath.row == 6) {
                static NSString *CellIdentifier = @"CheckTempCell";
                CheckInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[CheckInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                
                cell.delegate = self;
                cell.switchBtn.tag = indexPath.section +800000;
                cell.titleLB.text = @"隐藏无码签到";
                if ([ticketInfo.visible isEqualToString:@"0"]) {
                    cell.switchBtn.on = YES;
                }
                else {
                    cell.switchBtn.on = NO;
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 7) {
                static NSString *CellIdentifier = @"meetOptionCell";
                meetOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[meetOptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 8) {
                static NSString *CellIdentifier = @"EndCell";
                EndTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[EndTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.delegate = self;
                cell.btn.tag = indexPath.section +400000;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
        }
        else {
            if (indexPath.row == 6) {
                static NSString *CellIdentifier = @"meetOptionCell";
                meetOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[meetOptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 7) {
                static NSString *CellIdentifier = @"EndCell";
                EndTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[EndTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.delegate = self;
                cell.btn.tag = indexPath.section +400000;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
        }
    }
    return nil;
}

- (void)getTicketInfo:(NSString *)summary WithSection:(NSInteger)section
{
    if (summary.length == 0) {
        _ticketInfo.ticketInfo = @"";
    }else{
        _ticketInfo.ticketInfo = summary;
    }
    [ticketTpyeView reloadData];
}

#pragma mark --修改报名字段
- (void)callBackOptionItem:(NSDictionary *)OptionsDic with:(NSInteger)index
{
    _ticketInfo.fields = OptionsDic;
    NSLog(@"%@",OptionsDic);
}

#pragma mark --修改报名截止时间
- (void)cancelBtnClicked
{
    
}

- (void)returnData:(NSDate *)date Time:(NSTimeInterval)time
{
    OtherMeetTicketModel *info = [new_ticketInfoArr objectAtIndex:_section];
    info.signUpEndTime = [NSString stringWithFormat:@"%ld",(long)time];
    [new_ticketInfoArr replaceObjectAtIndex:timeIndex.section withObject:info];
    
    [ticketTpyeView reloadData];
}

#pragma mark --修改票价
- (void)getCostInfo:(UITextField *)textField
{
    if(textField.text.length==0){
        _ticketInfo.cost = @"免费";
    }else{
        _ticketInfo.cost = [NSString stringWithFormat:@"%@RMB",textField.text];
    }
}

#pragma mark --修改票的名称
- (void)getContentInfo:(UITextField *)textField
{
    _ticketInfo.ticketType = textField.text;
}

#pragma mark --ShowCostDelegate
- (void)showCostView:(SevenSwitch *)btn//btn.tag== 200000 显示票价编辑行
{
    _ticket.showTicketPrice = !_ticket.showTicketPrice;
    _ticketInfo.cost = @"免费";
    [ticketTpyeView reloadData];
}

#pragma mark --checkDelegate
- (void)checkSignUpInfo:(SevenSwitch *)btn//btn.tag== 300000 选择是否审核
{
    if (btn.tag == 300000) {
        _ticketInfo.isCheck = !_ticketInfo.isCheck;
    }
    else if (btn.tag == 800000) {
        if ([_ticketInfo.visible isEqualToString:@"0"]) {
            _ticketInfo.visible = @"1";
        }
        else if ([_ticketInfo.visible isEqualToString:@"1"]) {
            _ticketInfo.visible = @"0";
        }
    }
}

- (void)completeBtnClicked:(UIButton *)btn//完成编辑
{
    if (_ticketInfo.ticketType.length == 0) {
        [Dialog toastCenter:@"请填写票种名称"];
        [fieldArr removeAllObjects];
        return;
    }
    
    NSMutableArray *ticketTypeArray = [[NSMutableArray alloc]initWithCapacity:0];
    for (int i = 0; i < self.ticketTypeArr.count; i++) {
        if (i != self.section) {
            [ticketTypeArray addObject:self.ticketTypeArr[i]];
        }
    }
    for (NSString *ticketType in ticketTypeArray) {
        if ([ticketType isEqualToString:_ticketInfo.ticketType]) {
            [Dialog toastCenter:@"票种名称不可重复，请重新输入"];
            [fieldArr removeAllObjects];
            return;
        }
    }
    
    NSMutableDictionary *ticketPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    
    /*
    NSString *ticketType =_ticketInfo.ticketType;
    int chinese = 0;
    for(int i = 0; i < [ticketType length]; i++){
        int a = [ticketType characterAtIndex:i];
        if( a >= 0x4e00 && a <= 0x9fff)
            chinese++;
    }
    int length = [ticketType length]+chinese;
    if (length > 20) {
        [Dialog toastCenter:@"票种名称不可超过10个中文或20个英文字符"];
        [fieldArr removeAllObjects];
        return;
    }
    else {
        [ticketPostDic setObject:_ticketInfo.ticketType forKey:@"profile_name"];
    }*/
    [ticketPostDic setObject:_ticketInfo.ticketType forKey:@"profile_name"];
    
    if(_ticketInfo.signUpEndTime.length !=0){
        [ticketPostDic setObject:_ticketInfo.signUpEndTime forKey:@"partake_end_time"];
    }else{
        [ticketPostDic setObject:@"" forKey:@"partake_end_time"];
    }
    
    if (_meet_id.length != 0) {
        [ticketPostDic setObject:_meet_id forKey:@"meeting_id"];
    }else{
        [ticketPostDic setObject:@"" forKey:@"meeting_id"];
    }
    
    if (_ticketInfo.profile_id.length != 0) {
        [ticketPostDic setObject:_ticketInfo.profile_id forKey:@"profile_id"];
    }else{
        [ticketPostDic setObject:@"" forKey:@"profile_id"];
    }
    
    if (_ticketInfo.isCheck == YES) {
        [ticketPostDic setObject:@"1" forKey:@"with_approve"];
        
    }else{
        [ticketPostDic setObject:@"0" forKey:@"with_approve"];
    }
    
    if (![_ticketInfo.cost isEqualToString:@"免费"]){
        [ticketPostDic setObject:[_ticketInfo.cost substringToIndex:_ticketInfo.cost.length-3] forKey:@"price"];
    }
    else {
        [ticketPostDic setObject:@"0" forKey:@"price"];
    }
    
    [ticketPostDic setObject:_ticketInfo.ticketInfo forKey:@"note"];
    
    if (_ticketInfo.fields.count != 0) {
        [ticketPostDic setObject:_ticketInfo.fields forKey:@"partake_fields"];
    }
    else {
        [ticketPostDic setObject:@[] forKey:@"partake_fields"];
    }
    
    if ([_ticketInfo.visible isEqualToString:@"0"]) {
        [ticketPostDic setObject:@"0" forKey:@"visible"];
    }
    else {
        [ticketPostDic setObject:@"1" forKey:@"visible"];
    }
    
    [fieldArr addObject:ticketPostDic];

    [self SetBaseField];
}

- (void)SetBaseField
{
    NSDictionary *param = @{@"meeting_id":_meet_id,@"fieldArr":[fieldArr firstObject]};
    
    //[[Dialog Instance]showCenterProgressWithText:@"加载中..."];
    [[Dialog Instance]showHSHUDWithController:self];
    [MyDataService postSetBaseFieldsNew:param callback:^(id data) {
        NSLog(@"%@",data);
        //[[Dialog Instance]hideProgress];
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
            
            [_delegate callBackTicketInfo:_ticketInfo With:_section];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
