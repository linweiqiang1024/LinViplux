//
//  EndView.h
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UISwitchView.h"
#import "SDImageView.h"
#import "UIDesView.h"

@protocol AddPosterDelegate <NSObject>
- (void)changeEndViewHight:(CGFloat)hight;
- (void)addSelectImage;
- (void)showBigImage:(UITapGestureRecognizer *)tap;
- (void)deleteImageWith:(UIButton *)btn;
@end

@interface EndView : UIView
@property (nonatomic)CGFloat viewHeight;
@property (nonatomic,strong)UIScrollView*ImageScrollView;
@property (nonatomic,strong)UITextField *assistTextField;
@property (nonatomic,strong)id <AddPosterDelegate>delegate;
@property (nonatomic,strong)UISwitchView *putUpView;
@property (nonatomic,strong)UISwitchView *freeTrafficView;
@property (nonatomic,strong)UISwitchView *meetOpenView;
@property (nonatomic,strong)UIButton *addImageBtn;
@property (nonatomic,strong)UIDesView *desView;
@property (nonatomic,strong)NSArray * imageArr;

- (void)setImages:(UIImage *)img ImageArr:(NSArray *)imgArr;
- (void)setImage:(UIImage *)img Index:(NSInteger)index;
- (void)reloadImages:(NSArray *)imageArr;

@end
