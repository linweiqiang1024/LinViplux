//
//  OpenPersonalCell.h
//  huiyi
//
//  Created by 林伟强 on 16/12/27.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OpenPersonalCell : UITableViewCell

@property (nonatomic,strong)UILabel  *titleLab;
@property (nonatomic,strong)UIButton *btn;
@property (nonatomic,strong)UILabel  *topLine;
@property (nonatomic,strong)UILabel  *bottomLine;

@end
