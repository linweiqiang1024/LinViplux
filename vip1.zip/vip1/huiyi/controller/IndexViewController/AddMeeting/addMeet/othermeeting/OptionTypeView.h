//
//  OptionTypeView.h
//  huiyi
//
//  Created by 林伟强 on 16/12/6.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol OptionTypeViewDelegate <NSObject>

- (void)optionTypeAdd:(NSString *)text;

@end

@interface OptionTypeView : UIView

@property (nonatomic, strong) UIControl *mycontrol;
@property (nonatomic, strong) UIView    *bgView;
@property (nonatomic, strong) UILabel   *topLabel;
@property (nonatomic, strong) UIView    *textFieldBgView;
@property (nonatomic, strong) UITextField   *textField;
@property (nonatomic, strong) UIView    *lineView;
@property (nonatomic, strong) UILabel   *nextLabel;
@property (nonatomic, strong) UIButton  *nextButton;
@property (nonatomic, strong) UIView    *nextLineView;
@property (nonatomic, strong) UILabel   *cancelLabel;
@property (nonatomic, strong) UIButton  *cancelButton;
@property (nonatomic, weak)   id <OptionTypeViewDelegate> delegate;

- (void)reloadView:(CGSize)keyBoardSize;
- (void)show;
- (void)cancel;

@end
