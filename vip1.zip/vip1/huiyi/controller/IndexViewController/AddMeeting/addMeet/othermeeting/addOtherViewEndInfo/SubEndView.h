//
//  SubEndView.h
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SevenSwitch.h"
@protocol SubViewDelegate <NSObject>

- (void)ChangeViewFrame:(UISwitch *)btn;
- (void)numTextChange:(NSString*)text;

@end

@interface SubEndView : UIView
@property (nonatomic,strong)UITextField *phoneTextFiled;
@property (nonatomic,strong)SevenSwitch *swithBtn;
@property (nonatomic,weak)id <SubViewDelegate>delegate;
-(void)swithBtnClicke:(SevenSwitch *)btn;
@end
