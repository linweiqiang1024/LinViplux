//
//  CreateOtherMeetTool.h
//  huiyi
//
//  Created by songhongshuai on 15/3/9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CreateMeetEnd <NSObject>

- (void)CreateMeetEndMethod:(NSString*)meet_id;

@end

@interface CreateOtherMeetTool : NSObject

- (void)posterImage:(NSArray*)arr;
- (void)initData;
@property (nonatomic)NSInteger type;
@property (nonatomic)BOOL isReSet;//修改配置
@property (nonatomic,strong)NSArray *configArr;
@property (nonatomic,strong)NSString *meet_tittle;
@property (nonatomic,strong)NSString *meet_id;
@property (nonatomic,strong)NSString *partakTime;
@property (nonatomic,strong)NSDictionary *postDic;
@property (nonatomic,strong)NSArray *posterImageArr;//海报图片数组
@property (nonatomic,strong)NSArray *contentImageArr;//详情图片数组
@property (nonatomic,strong)NSString *signUpEndTime;
@property (nonatomic,weak)id<CreateMeetEnd>delegate;
@end
