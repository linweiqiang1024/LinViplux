//
//  CreatMeetTextField.h
//  huiyi
//
//  Created by songhongshuai on 15/2/10.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreatMeetTextField : UITextField

@end
