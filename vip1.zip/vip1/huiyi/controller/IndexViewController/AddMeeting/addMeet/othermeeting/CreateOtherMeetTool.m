//
//  CreateOtherMeetTool.m
//  huiyi
//
//  Created by songhongshuai on 15/3/9.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "CreateOtherMeetTool.h"
#import "OtherMeetTwoStpeModel.h"
#import "OtherMeetTicketModel.h"
#import "GTMBase64.h"
#import "PostImageTool.h"
#import "FatherViewController.h"
#import "New_managerViewController.h"
#import "Helper.h"

@interface CreateOtherMeetTool ()
{
    BOOL keyBoardShow;
    NSInteger _section;
    NSIndexPath *timeIndex;
    NSMutableArray *ticketArr;
    NSMutableArray *ticketInfoArr;
    NSMutableArray *fieldArr;
    NSMutableArray *oldPicUrlMuArr;
    UITableView  *ticketTpyeView;
    __block int imageIndex ;
    __block int imageCount ;
    __block Dialog *hud;
    NSMutableArray *picMuArr;//盛放详情图片的动态数组 上传一个删除一个图片
    NSMutableArray *picUrlMuArr;//盛放图片url
    NSMutableDictionary *new_postDic;
    NSMutableArray *posterMuArr;//盛放海报图片的动态数组 上传一个删除一个图片
    NSMutableArray *posterUrlMuArr;//盛放海报图片url
    NSMutableDictionary *postDataDic;
    NSString *insert_id;
}

@end

@implementation CreateOtherMeetTool

- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)initData
{
    imageIndex = 1;
    imageCount = _posterImageArr.count + _contentImageArr.count;
    new_postDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    ticketInfoArr = [[NSMutableArray alloc]initWithCapacity:0];
    [new_postDic addEntriesFromDictionary:_postDic];
    posterMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    [posterMuArr addObjectsFromArray:_posterImageArr];
    posterUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    oldPicUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    picUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    fieldArr = [[NSMutableArray alloc]initWithCapacity:0];
    picMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    postDataDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [picMuArr addObjectsFromArray:_contentImageArr];
    
    [postDataDic addEntriesFromDictionary:_postDic];
    hud = [[Dialog alloc]init];
}

- (NSString *)rePlaceUrl:(NSString*)content
{
    NSString *s = @"<(\\w+)\\s*src=\\\"a(\\w+.*?)\\\"\\s*/>";
    
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    if (picUrlMuArr.count < arrayOfAllMatches.count) {
        for (int i = 0; i<picUrlMuArr.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
            //content = [content stringByReplacingOccurrencesOfString:substringForMatch withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:i]]];
            //NSLog(@"%@",substringForMatch);
        }
        for (int j = picUrlMuArr.count; j< arrayOfAllMatches.count; j++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:j];
            //NSString* substringForMatch1 = [content substringWithRange:match.range];
            content = [content stringByReplacingCharactersInRange:match.range withString:@""];
        }
    }
    else {
        for (int i = 0; i < arrayOfAllMatches.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
        }
    }
    
    for (int index = 0; index < picUrlMuArr.count; index++) {
        content = [content stringByReplacingOccurrencesOfString:[oldPicUrlMuArr objectAtIndex:index] withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:index]]];
    }
    return content;
}

- (void)posterImage:(NSArray*)arr
{
    if (_posterImageArr.count == 0) {
        [new_postDic setObject:posterUrlMuArr forKey:@"img_file_list"];
        [self postImageWithImages:nil];
    }
    else {
        [hud showCenterProgressWithText:[NSString stringWithFormat:@"正在上传图片%d/%d",imageIndex,imageCount ]];
        UIImage * img = [posterMuArr firstObject];
        NSData * data;
        //data = UIImageJPEGRepresentation(img, 0.0001);
        data = [Helper imageData:img];
        NSString * imageStr = [GTMBase64 stringByEncodingData:data];
        NSDictionary *dic = @{@"iospic":imageStr,@"iospic_type":@"jpg"};
        
        [MyDataService postUploadPicture:dic callback:^(id data) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                [hud hideProgress];
                NSLog(@"%@",[[data objectForKey:@"content"] class]);
                [posterUrlMuArr addObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] ];
                
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%ld_imageCount",(long)_type]];
                [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%lu",(unsigned long)arr.count]  valueKey:[NSString stringWithFormat:@"type_%ld_imageCount",(long)_type]];
                [posterMuArr removeObjectAtIndex:0];
                imageIndex++;
                sleep(1);//不知道什么原因  连续上传多次图片 出现多张连续图片
                if (posterMuArr.count != 0) {
                    [self posterImage:nil];
                }
                else {
                    [postDataDic setObject:posterUrlMuArr forKey:@"img_file_list"];
                    [self postImageWithImages:nil];
                }
            }
        }];
    }
}
/**
 *  回调方式 队列上传
 *
 *  @param arr 图片数组
 */
- (void)postImageWithImages:(NSArray *)arr
{
    if (picMuArr.count!=0) {
        UIImage * img = [picMuArr firstObject];
        NSData * data;
        
        [hud showCenterProgressWithText:[NSString stringWithFormat:@"正在上传图片%d/%d",imageIndex,imageCount ]];
        //data = UIImageJPEGRepresentation(img, 0.0001);
        data = [Helper imageData:img];
        NSString *imageStr = [GTMBase64 stringByEncodingData:data];
        NSDictionary *dic = @{@"iospic":imageStr,@"iospic_type":@"jpg"};
        //NSDictionary *dic = @{@"ico_file":_imageStr};
        [MyDataService postUploadPicture:dic callback:^(id data) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                NSLog(@"%@",[[data objectForKey:@"content"] class]);
                //NSString *urlKey = [NSString stringWithFormat:@"url%d",(int)arr.count];
                [picUrlMuArr addObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] ];
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",(int)_type]];
                [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",(int)arr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",(int)_type]];
                [picMuArr removeObjectAtIndex:0];
                imageIndex++;
                sleep(1);//睡一秒  否则连续上传多张图片会出现重复的
                if (picMuArr.count != 0) {
                    [self postImageWithImages:picMuArr];
                }
                
                if (picMuArr.count == 0) {
                    NSString *content = [self rePlaceUrl:[_postDic objectForKey:@"summary"]];
                    [postDataDic setObject:content forKey:@"summary"];
                    
                    [hud hideProgress];
                    [[Dialog Instance] showCenterProgressWithLabel:@"上传中..."];
                    [MyDataService postAddMeeting:postDataDic callback:^(id data) {
                        NSLog(@"%@",data);
                        [hud hideProgress];
                        [[Dialog Instance] hideProgress];
                        if ([[data objectForKey:@"code"]isKindOfClass:[NSNumber class]]) {
                            [Dialog toastCenter:@"创建失败！"];
                            return ;
                        }
                        if([[data objectForKey:@"code"]isEqualToString:@"200"] || [[data objectForKey:@"code"] objectForKey:@"201"])
                        {
                            [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%ld",(long)(_type)]];
                            insert_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                        
                            [self creatTicketModelData];
                            
                            for (OtherMeetTicketModel *ticketModel in ticketInfoArr) {
                                NSMutableDictionary *ticketPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
                                [ticketPostDic setObject:insert_id forKey:@"meeting_id"];
                                [ticketPostDic setObject:ticketModel.signUpEndTime forKey:@"partake_end_time"];
                                [ticketPostDic setObject:ticketModel.ticketType forKey:@"profile_name"];
                                if (ticketModel.isCheck == YES) {
                                    [ticketPostDic setObject:@"1" forKey:@"with_approve"];
                                }
                                else {
                                    [ticketPostDic setObject:@"0" forKey:@"with_approve"];
                                }
                                if (![ticketModel.cost isEqualToString:@"免费"]) {
                                    [ticketPostDic setObject:[ticketModel.cost substringToIndex:ticketModel.cost.length-3] forKey:@"price"];
                                }
                                else {
                                    [ticketPostDic setObject:@"0" forKey:@"price"];
                                }
                                [ticketPostDic setObject:ticketModel.ticketInfo forKey:@"note"];
                                [ticketPostDic setObject:ticketModel.fields forKey:@"partake_fields"];
                                if (ticketModel.profile_id.length != 0) {
                                    [ticketPostDic setObject:ticketModel.profile_id forKey:@"profile_id"];
                                }
                                else {
                                    [ticketPostDic setObject:@"" forKey:@"profile_id"];
                                }
                                [fieldArr addObject:ticketPostDic];
                            }
                            [self SetBaseField];
                        }
                        else {
                            
                        }
                    }];
                }
                else {
                    [hud showCenterProgressWithText:[NSString stringWithFormat:@"正在上传图片%d/%d",imageIndex,imageCount ]];
                }
            }
            else {
                [hud hideProgress];
            }
        }];
    }
    else {
        [[Dialog Instance] showCenterProgressWithLabel:@"上传中..."];
        [MyDataService postAddMeeting:postDataDic callback:^(id data) {
            NSLog(@"%@",data);
            [[Dialog Instance] hideProgress];
            if ([[data objectForKey:@"code"]isKindOfClass:[NSNumber class]]) {
                [Dialog toastCenter:@"创建失败！"];
                return ;
            }
            if([[data objectForKey:@"code"]isEqualToString:@"200"] || [[data objectForKey:@"code"] objectForKey:@"201"])
            {
                [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(int)(_type)]];
                insert_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                
                [self creatTicketModelData];
                
                for (OtherMeetTicketModel *ticketModel in ticketInfoArr) {
                    NSMutableDictionary *ticketPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
                    [ticketPostDic setObject:insert_id forKey:@"meeting_id"];
                    [ticketPostDic setObject:ticketModel.signUpEndTime forKey:@"partake_end_time"];
                    [ticketPostDic setObject:ticketModel.ticketType forKey:@"profile_name"];
                    if (ticketModel.isCheck == YES) {
                        [ticketPostDic setObject:@"1" forKey:@"with_approve"];
                    }
                    else {
                        [ticketPostDic setObject:@"0" forKey:@"with_approve"];
                    }
                    if (![ticketModel.cost isEqualToString:@"免费"]) {
                        [ticketPostDic setObject:[ticketModel.cost substringToIndex:ticketModel.cost.length-3] forKey:@"price"];
                    }
                    else {
                        [ticketPostDic setObject:@"0" forKey:@"price"];
                    }
                    [ticketPostDic setObject:ticketModel.ticketInfo forKey:@"note"];
                    [ticketPostDic setObject:ticketModel.fields forKey:@"partake_fields"];
                    if (ticketModel.profile_id.length != 0) {
                        [ticketPostDic setObject:ticketModel.profile_id forKey:@"profile_id"];
                    }
                    else {
                        [ticketPostDic setObject:@"" forKey:@"profile_id"];
                    }
                    [fieldArr addObject:ticketPostDic];
                }
                [self SetBaseField];
            }
        }];
    }
}

- (void)creatTicketModelData
{
    OtherMeetTwoStpeModel *info = [[OtherMeetTwoStpeModel alloc]init];
    info.showMoreInfo = NO;
    info.showTicketPrice = NO;
    [ticketArr addObject:info];
    NSMutableDictionary * optionItemPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    for (int index = 0; index < 2; index++) {
        if (index == 0) {
            NSMutableDictionary *theOption = [[NSMutableDictionary alloc]initWithCapacity:0];
            [theOption setObject:@"姓名" forKey:@"name"];
            [theOption setObject:@"" forKey:@"extr"];
            [theOption setObject:@"0" forKey:@"sn"];
            [theOption setObject:@"1" forKey:@"required"];
            [theOption setObject:@"textField" forKey:@"type"];
            [optionItemPostDic setObject:theOption forKey:@"f_name"];
        }
        if (index == 1) {
            NSMutableDictionary *theOption = [[NSMutableDictionary alloc]initWithCapacity:0];
            [theOption setObject:@"手机" forKey:@"name"];
            [theOption setObject:@"" forKey:@"extr"];
            [theOption setObject:@"1" forKey:@"sn"];
            [theOption setObject:@"1" forKey:@"required"];
            [theOption setObject:@"textField" forKey:@"type"];
            [optionItemPostDic setObject:theOption forKey:@"f_phone"];
        }
    }
    OtherMeetTicketModel *ticketModel = [[OtherMeetTicketModel alloc]init];
    ticketModel.ticketInfo = @"";
    ticketModel.ticketType = _meet_tittle;
    ticketModel.cost = @"免费";
    ticketModel.fields = optionItemPostDic;
    ticketModel.signUpEndTime = _partakTime;
    ticketModel.isCheck = NO;
    [ticketInfoArr addObject:ticketModel];
}

- (void)SetBaseField
{
    NSDictionary *param = @{@"meeting_id":insert_id,@"fieldArr":[fieldArr firstObject]};
    NSLog(@"%@",[param JSONString]);
    [MyDataService postSetBaseFieldsNew:param callback:^(id data) {
        NSLog(@"%@",data);
        [fieldArr removeObjectAtIndex:0];
        if (fieldArr.count != 0) {
            [self SetBaseField];
        }
        else {
            [Dialog toastCenter:@"操作成功"];
            NSString *posterCount = [[DBManager sharedInstance]getPublicDBData:[NSString stringWithFormat:@"type_%d_posterImageCount",(int)_type]];
            FatherViewController *fatherVC = [[FatherViewController alloc]init];
                for (int i = 0; i<[posterCount integerValue]; i++) {
                    [fatherVC deleteFile:[NSString stringWithFormat:@"poster_%d",i] withMeetingType:[NSString stringWithFormat:@"%d",(int)_type]];
                }
            [_delegate CreateMeetEndMethod:insert_id];
        }
    }];
}

@end
