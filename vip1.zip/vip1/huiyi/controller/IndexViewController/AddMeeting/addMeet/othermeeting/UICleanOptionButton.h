//
//  UICleanOptionButton.h
//  huiyi
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICleanOptionButton : UIButton

@end
