//
//  UICleanOptionButton.m
//  huiyi
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UICleanOptionButton.h"

@implementation UICleanOptionButton

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(12, 12, 26, 26);
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
