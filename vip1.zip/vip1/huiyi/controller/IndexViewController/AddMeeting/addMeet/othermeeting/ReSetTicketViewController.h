//
//  ReSetTicketViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/3/12.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
#import "OtherMeetTicketModel.h"
#import "OtherMeetTwoStpeModel.h"

@protocol setTicketDelegate <NSObject>
- (void)callBackTicketInfo:(OtherMeetTicketModel *)ticketInfo With:(NSInteger)section;
- (void)delLastTicet;
@end

@interface ReSetTicketViewController : FatherViewController
@property (nonatomic,weak)id <setTicketDelegate>delegate;
@property (nonatomic,strong)OtherMeetTicketModel *ticketInfo;
@property (nonatomic,strong)OtherMeetTwoStpeModel *ticket;
@property (nonatomic,strong)NSArray * ticketInfoArr;
@property (nonatomic)NSInteger section;
@property (nonatomic)BOOL isAdd;
@property (nonatomic,strong)NSString *view_title;
@property (nonatomic,strong)NSString *meet_id;
@property (nonatomic)BOOL isTemp;
@property (nonatomic,strong)NSArray * ticketTypeArr;
@end
