//
//  UIShowInfoView.m
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import "UIShowInfoView.h"
#import "SDToolBarOfHideView.h"
#import "OrganizerCell.h"
#import "OpenPersonalCell.h"
#import "AddCompanyView.h"
#import <objc/runtime.h>

@interface UIShowInfoView() <HideKeyboardDelegate,UITableViewDataSource,UITableViewDelegate,OrganizerCellDelegate>

@property (nonatomic,strong)UIView *footView;
@property (nonatomic,strong)UITableView *organizerTV;
@property (nonatomic,strong)UIView *personalView;
@property (nonatomic,assign)CGFloat footHeight;

@end

@implementation UIShowInfoView

- (void)hideKeyboard
{
    [self endEditing:YES];
}

- (NSMutableArray *)companyNameArr
{
    if (!_companyNameArr) {
        _companyNameArr = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _companyNameArr;
}

- (NSMutableArray *)organizerNameArr
{
    if (!_organizerNameArr) {
        _organizerNameArr = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _organizerNameArr;
}

- (NSMutableArray *)personalArr
{
    if (!_personalArr) {
        _personalArr = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _personalArr;
}

- (UITableView *)organizerTV
{
    if (!_organizerTV) {
        _organizerTV = [[UITableView  alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 74+90+90+237+135) style:UITableViewStylePlain];
        _organizerTV.separatorStyle = UITableViewCellSeparatorStyleNone;
        _organizerTV.delegate = self;
        _organizerTV.dataSource = self;
        _organizerTV.scrollEnabled = NO;
        _organizerTV.backgroundColor = [UIColor whiteColor];
        _organizerTV.tag = 200;
    }
    return _organizerTV;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView.tag == 200) {
        return 2;
    }
    else if (tableView.tag == 201) {
        return 1;
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        if (section == 0) {
            return self.companyNameArr.count;
        }
        if (section == 1) {
            return self.organizerNameArr.count;
        }
        return 1;
    }
    else if (tableView.tag == 201) {
        return 3;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        return 45;
    }
    else if (tableView.tag == 201) {
        return 0.01f;
    }
    return 0.01f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        return 37;
    }
    else if (tableView.tag == 201) {
        return 0.01f;
    }
    return 0.01f;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        UIView *footView = [[UIView alloc ]initWithFrame:CGRectMake(0, 0, ScreenWidth, 45)];
        footView.backgroundColor = [UIColor whiteColor];
        
        UIButton *addBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        addBtn.frame = CGRectMake(0, 0, ScreenWidth, 45);
        addBtn.backgroundColor = [UIColor whiteColor];
        addBtn.tag = 100+section;
        [addBtn setImage:[UIImage imageNamed:@"addCompany"] forState:UIControlStateNormal];
        [addBtn addTarget:self action:@selector(addCompany:) forControlEvents:UIControlEventTouchUpInside];
        [footView addSubview:addBtn];
        
        UILabel *line = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(footView.frame)-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line, @"#c8c7cc");
        [footView addSubview:line];
        
        return footView;
    }
    else if (tableView.tag == 201) {
        return nil;
    }
    return nil;
}

- (void)addCompany:(UIButton *)btn
{
    if (btn.tag == 100) {
        [self.companyNameArr addObject:@""];
    }
    if (btn.tag == 101) {
        [self.organizerNameArr addObject:@""];
    }
    self.organizerTV.frame = CGRectMake(0, 0, ScreenWidth, 74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight);
    if ([_delegate respondsToSelector:@selector(callBackHeight:review:)]) {
        [_delegate callBackHeight:(74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight) review:YES];
    }
    [self.organizerTV reloadData];
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView.tag == 200) {
        NSArray *headTitleArr = @[@"主办方名称",@"承办方名称"];
        
        AddCompanyView * _headView = [[AddCompanyView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 37)];
        _headView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
        
        UILabel * _headTitltLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 16)];
        _headTitltLb.backgroundColor = [UIColor clearColor];
        _headTitltLb.font = YHUI(16);
        _headTitltLb.textColor = [UIColor colorWithHexString:@"#373737"];
        _headTitltLb.text = headTitleArr[section];
        [_headView addSubview:_headTitltLb];
        return _headView;
    }
    else if (tableView.tag == 201) {
        return nil;
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 200) {
        static NSString *Identifier = @"OrganizerCellID";
        OrganizerCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
        if (cell == nil) {
            cell = [[OrganizerCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
        }
        switch (indexPath.section) {
            case 0:
            {
                cell.content = self.companyNameArr[indexPath.row];
                //            cell.postKey = @"company_list";
            }
                break;
            case 1:
            {
                cell.content = self.organizerNameArr[indexPath.row];
                //            cell.postKey = @"organizer_list";
            }
                break;
            default:
                break;
        }
        cell.postKey = @"";
        cell.indexPath = indexPath;
        /*
         if (indexPath.section == 0&&indexPath.row == self.companyNameArr.count-1) {
         cell.isEndLine = YES;
         }else if (indexPath.section == 1&&indexPath.row == self.organizerNameArr.count-1){
         cell.isEndLine = YES;
         }else{
         cell.isEndLine = NO;
         }*/
        cell.isEndLine = NO;
        
        cell.delegate = self;
        
        return cell;
    }
    else if (tableView.tag == 201) {
        static NSString *Identifier = @"OpenPersonalCellID";
        OpenPersonalCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
        if (!cell) {
            cell = [[OpenPersonalCell alloc]
                    initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
        }
        
        cell.titleLab.text = self.personalArr[indexPath.row];
        
        cell.btn.selected = NO;
        if (self.select == indexPath.row) {
            cell.btn.selected = YES;
            //[[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%d",(int)self.select] forKey:@"personal_data_sw"];
            if ([_delegate respondsToSelector:@selector(changePersonalData:)]) {
                [_delegate changePersonalData:[NSString stringWithFormat:@"%d",(int)self.select]];
            }
        }
        
        switch (indexPath.row) {
            case 0:
            {
                cell.topLine.hidden = YES;
                cell.bottomLine.hidden = YES;
            }
                break;
            case 1:
            {
                cell.topLine.hidden = NO;
                cell.bottomLine.hidden = YES;
            }
                break;
            case 2:
            {
                cell.topLine.hidden = NO;
                cell.bottomLine.hidden = NO;
            }
                break;
            default:
                break;
        }
        
        cell.contentView.backgroundColor = [UIColor whiteColor];
        
        return cell;
    }
    return nil;
}

- (void)callBackOrganizerName:(NSString *)OrganizerName withIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        [self.companyNameArr replaceObjectAtIndex:indexPath.row withObject:OrganizerName];
    }
    if (indexPath.section == 1) {
        [self.organizerNameArr replaceObjectAtIndex:indexPath.row withObject:OrganizerName];
    }
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self.organizerNameArr addObject:@""];
        [self.companyNameArr addObject:@""];
        self.personalArr = [@[@"公开姓名",@"仅公开姓氏（例：张**）",@"公开姓名、单位、职务"]mutableCopy];
        
        self.select = 0;
        
        self.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
        self.userInteractionEnabled = YES;
        [self addSubview:self.organizerTV];
        
        self.footView = [[UIView alloc]init];
        self.footView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
        
        UIView *midView = [[UIView alloc]init];
        midView.backgroundColor = [UIColor whiteColor];
        [self.footView addSubview:midView];
        
        UIView *serviceView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 37)];
        serviceView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
        [midView addSubview:serviceView];
        
        UILabel *serviceLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 0, ScreenWidth-30, 37)];
        serviceLb.textColor = [UIColor colorWithHexString:@"#373737"];
        serviceLb.text = @"为参会人提供的服务";
        serviceLb.font = YHUI(16);
        [serviceView addSubview:serviceLb];
        
        UILabel *line4 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(serviceView.frame), ScreenWidth, 0.5)];
        BackGround16Color(line4, @"#c8c7cc");
        [midView addSubview:line4];
        
        UILabel *_titleLb = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(line4.frame)+3.5, 250, 37)];
        _titleLb.text = @"免费食宿";
        _titleLb.textColor = [UIColor colorWithHexString:@"#373737"];
        _titleLb.backgroundColor = [UIColor clearColor];
        _titleLb.font = [UIFont systemFontOfSize:16];
        [midView addSubview:_titleLb];
        
        _staySwitchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, CGRectGetMaxY(line4.frame)+8, 46, 28)];
        _staySwitchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
        [midView addSubview:_staySwitchBtn];
        
        UILabel *line5 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(line4.frame)+45, ScreenWidth-12, 0.5)];
        BackGround16Color(line5, @"#c8c7cc");
        [midView addSubview:line5];
        
        UILabel *_pickUpTitleLb = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(line5.frame)+3.5, 250, 37)];
        _pickUpTitleLb.text = @"免费接送";
        _pickUpTitleLb.textColor = [UIColor colorWithHexString:@"#373737"];
        _pickUpTitleLb.backgroundColor = [UIColor clearColor];
        _pickUpTitleLb.font = [UIFont systemFontOfSize:16];
        [midView addSubview:_pickUpTitleLb];
        
        _signUpSwitchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, CGRectGetMaxY(line5.frame)+8, 46, 28)];
         _signUpSwitchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
        [midView addSubview:_signUpSwitchBtn];
        
        UILabel *line6 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(line5.frame)+44.5, ScreenWidth, 0.5)];
        BackGround16Color(line6, @"#c8c7cc");
        [midView addSubview:line6];
        
        midView.frame = CGRectMake(0, 0, ScreenWidth, CGRectGetMaxY(line6.frame));
        midView.backgroundColor = [UIColor whiteColor];
        
        
        UIView *endView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(midView.frame)+10, ScreenWidth, 45)];
        endView.backgroundColor = [UIColor whiteColor];
        [self.footView addSubview:endView];
        
        UILabel *line7 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(line7, @"#c8c7cc");
        [endView addSubview:line7];
        
        UILabel *_openTitleLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 4, 250, 37)];
        _openTitleLb.text = @"公开活动（发布到会议广场）";
        _openTitleLb.textColor = [UIColor colorWithHexString:@"#373737"];
        _openTitleLb.backgroundColor = [UIColor clearColor];
        _openTitleLb.font = [UIFont systemFontOfSize:16];
        [endView addSubview:_openTitleLb];
        
        _openSwitchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, 8.5, 46, 28)];
        _openSwitchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
        [endView addSubview:_openSwitchBtn];
        
        UILabel *line8 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(endView.frame)-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line8, @"#c8c7cc");
        [endView addSubview:line8];
        
        //公开报名者信息
        self.personalView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(endView.frame)+10, ScreenWidth, 45)];
        self.personalView.backgroundColor = [UIColor whiteColor];
        [self.footView addSubview:self.personalView];
        
        UILabel *line9 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(line9, @"#c8c7cc");
        [self.personalView addSubview:line9];
        
        UILabel *_personalTitleLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 4, 250, 37)];
        _personalTitleLb.text = @"公开报名者信息";
        _personalTitleLb.textColor = [UIColor colorWithHexString:@"#373737"];
        _personalTitleLb.backgroundColor = [UIColor clearColor];
        _personalTitleLb.font = [UIFont systemFontOfSize:16];
        [self.personalView addSubview:_personalTitleLb];
        
        _personalSwitchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, 8.5, 46, 28)];
        _personalSwitchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
        [self.personalView addSubview:_personalSwitchBtn];
        
        UILabel *line10 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.personalView.frame)-0.5, ScreenWidth, 0.5)];
        BackGround16Color(line10, @"#c8c7cc");
        [self.personalView addSubview:line10];
        
        [self.footView addSubview:self.personalTableView];
        
        self.footHeight = CGRectGetMaxY(self.personalTableView.frame);
        self.footView.frame = CGRectMake(0, 0, ScreenWidth, self.footHeight);
        
        self.organizerTV.tableFooterView = self.footView;
    }
    return self;
}

- (UITableView *)personalTableView
{
    if (!_personalTableView) {
        _personalTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.personalView.frame) , ScreenWidth, 135)];
        _personalTableView.backgroundColor = [UIColor whiteColor];
        _personalTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _personalTableView.delegate = self;
        _personalTableView.dataSource = self;
        _personalTableView.scrollEnabled = NO;
        _personalTableView.tag = 201;
    }
    return _personalTableView;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 200) {
        
    }
    if (tableView.tag == 201) {
        self.select = indexPath.row;
        [self.personalTableView reloadData];
    }
}

- (void)setChangeFrame:(BOOL)changeFrame
{
    if (changeFrame == YES) {
        //[self chagePersonalTableViewFrame:CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 45*self.personalArr.count)];
        
        self.personalTableView.frame = CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 135);
        self.footHeight = CGRectGetMaxY(self.personalTableView.frame);
        self.footView.frame = CGRectMake(0, 0, ScreenWidth, self.footHeight);
        self.organizerTV.frame = CGRectMake(0, 0, ScreenWidth, 74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight);
        if ([_delegate respondsToSelector:@selector(callBackHeight:review:)]) {
            [_delegate callBackHeight:(74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight) review:YES];
        }
    }
    else {
        //[self chagePersonalTableViewFrame:CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 0)];
        
        [UIView animateWithDuration:0.5 animations:^{
            self.personalTableView.frame = CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 0);
            self.footHeight = CGRectGetMaxY(self.personalTableView.frame);
            self.footView.frame = CGRectMake(0, 0, ScreenWidth, self.footHeight);
            self.organizerTV.frame = CGRectMake(0, 0, ScreenWidth, 74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight);
            if ([_delegate respondsToSelector:@selector(callBackHeight:review:)]) {
                [_delegate callBackHeight:(74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight) review:YES];
            }
            
        } completion:^(BOOL finished) {
            
        }];
    }
}

- (void)setPersonalChangeFrame:(BOOL)personalChangeFrame
{
    if (personalChangeFrame == YES) {
        //[self chagePersonalTableViewFrame:CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 45*self.personalArr.count)];
        
        self.personalTableView.frame = CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 135);
        self.footHeight = CGRectGetMaxY(self.personalTableView.frame);
        self.footView.frame = CGRectMake(0, 0, ScreenWidth, self.footHeight);
        self.organizerTV.frame = CGRectMake(0, 0, ScreenWidth, 74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight);
        if ([_delegate respondsToSelector:@selector(callBackHeight:review:)]) {
            [_delegate callBackHeight:(74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight) review:NO];
        }
    }
    else {
        //[self chagePersonalTableViewFrame:CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 0)];
        
        [UIView animateWithDuration:0.5 animations:^{
            self.personalTableView.frame = CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 0);
            self.footHeight = CGRectGetMaxY(self.personalTableView.frame);
            self.footView.frame = CGRectMake(0, 0, ScreenWidth, self.footHeight);
            self.organizerTV.frame = CGRectMake(0, 0, ScreenWidth, 74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight);
            if ([_delegate respondsToSelector:@selector(callBackHeight:review:)]) {
                [_delegate callBackHeight:(74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight) review:NO];
            }
            
        } completion:^(BOOL finished) {
            
        }];
    }
}

- (void)chagePersonalTableViewFrame:(CGRect)frame
{
    [UIView animateWithDuration:0.5 animations:^{
        self.personalTableView.frame = frame;
        self.footHeight = CGRectGetMaxY(self.personalTableView.frame);
        self.footView.frame = CGRectMake(0, 0, ScreenWidth, self.footHeight);
        self.organizerTV.frame = CGRectMake(0, 0, ScreenWidth, 74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight);
        if ([_delegate respondsToSelector:@selector(callBackHeight:review:)]) {
            [_delegate callBackHeight:(74+(self.companyNameArr.count+self.organizerNameArr.count+2)*45+self.footHeight) review:YES];
        }
        
    } completion:^(BOOL finished) {
        
    }];
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
