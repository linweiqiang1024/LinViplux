//
//  OrganizerCell.m
//  huiyi
//
//  Created by songhongshuai on 15/8/18.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "OrganizerCell.h"

@interface OrganizerCell ()<UITextFieldDelegate>
@property (nonatomic,strong)UITextField *organizerTF;
@property (nonatomic,strong)NSArray *headPlaceHolderArr;
@end

@implementation OrganizerCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}

- (void)setPostKey:(NSString *)postKey
{
    if ([postKey isEqualToString:@"company_list"]) {
        _headPlaceHolderArr = @[@"输入主办方名称"];
    }
    else if ([postKey isEqualToString:@"organizer_list"]) {
        _headPlaceHolderArr = @[@"输入承办方名称"];
    }
    else {
        _headPlaceHolderArr = @[@"输入主办方名称",@"输入承办方名称"];
    }
}

- (void)setIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath) {
        _indexPath = indexPath;
        [self.contentView addSubview:self.organizerTF];
        self.organizerTF.placeholder = self.headPlaceHolderArr[indexPath.section];
    }
}

- (void)textChange:(UITextField *)textField
{
    if ([_delegate respondsToSelector:@selector(callBackOrganizerName: withIndexPath:)]) {
        [_delegate callBackOrganizerName:textField.text withIndexPath:self.indexPath];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

- (UITextField *)organizerTF
{
    if (!_organizerTF) {
        _organizerTF = [[UITextField alloc]initWithFrame:CGRectMake(12, 0.5, ScreenWidth-25, 44)];
        _organizerTF.backgroundColor = [UIColor clearColor];
        _organizerTF.delegate = self;
        _organizerTF.returnKeyType = UIReturnKeyDone;
        _organizerTF.font = [UIFont systemFontOfSize:16];
        _organizerTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        [_organizerTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
        _organizerTF.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return _organizerTF;
}

- (void)setContent:(NSString *)content
{
    if (content) {
        self.organizerTF.text = content;
    }
}

- (void)drawRect:(CGRect)rect
{
    UIBezierPath * BezierPath;
    BezierPath = [[UIBezierPath alloc]init];
    [BezierPath moveToPoint:CGPointMake(_isEndLine?0:12, rect.size.height-0.5)];
    [BezierPath addLineToPoint:CGPointMake(rect.size.width, rect.size.height-0.5)];
    [[UIColor colorWithHexString:@"#c8c7cc"] setStroke];
    BezierPath.lineWidth = 0.5f;
    [BezierPath stroke];
}

@end
