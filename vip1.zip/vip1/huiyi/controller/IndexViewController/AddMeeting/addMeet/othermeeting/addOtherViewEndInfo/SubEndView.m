//
//  SubEndView.m
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import "SubEndView.h"
#import "SDToolBarOfHideView.h"

@interface SubEndView()<HideKeyboardDelegate>
{
    UILabel *midline;
    UILabel *endline;
}
@end

@implementation SubEndView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self creatUI];
    }
    return self;
}

- (void)creatUI
{
    UILabel *topline = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(topline, @"#c8c7cc");
    [self  addSubview:topline];
    
    midline = [[UILabel alloc]initWithFrame:CGRectMake(0, 44.5, ScreenWidth, 0.5)];
    BackGround16Color(midline, @"#c8c7cc");
    [self addSubview:midline];
    
    self.backgroundColor = [UIColor clearColor];
    
    UILabel *phoneLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 0.5, 250, 44)];
    phoneLB.text = @"公开活动联系人手机号";
    phoneLB.font = [UIFont systemFontOfSize:16];
    phoneLB.textColor = [UIColor colorWithHexString:@"#373737"];
    [self addSubview:phoneLB];
    
    _swithBtn = [[ SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, 9, 46, 28)];
    _swithBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
    [_swithBtn addTarget:self action:@selector(swithBtnClicke:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_swithBtn];
    
    _phoneTextFiled = [[UITextField alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(midline.frame)+5, ScreenWidth-24, 35)];
    _phoneTextFiled.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    _phoneTextFiled.backgroundColor = [UIColor clearColor];
    _phoneTextFiled.keyboardType = UIKeyboardTypeNumberPad;
    [_phoneTextFiled addTarget:self action:@selector(numberChange:) forControlEvents:UIControlEventEditingChanged];
    _phoneTextFiled.placeholder = @"请输入手机号 将显示在会议详情页";
    _phoneTextFiled.font = [UIFont systemFontOfSize:16];
    
    SDToolBarOfHideView *toolBar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
    toolBar.SDdelegate = self;
    _phoneTextFiled.inputAccessoryView = toolBar;
    
    endline = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_phoneTextFiled.frame)+4.5, ScreenWidth, 0.5)];
    
    BackGround16Color(endline, @"#c8c7cc");
}

- (void)numberChange:(UITextField *)textField
{
    [_delegate numTextChange:textField.text];
}

- (void)hideKeyboard
{
    [self endEditing:YES];
}

-(void)swithBtnClicke:(SevenSwitch *)btn
{
    if (btn.on == YES) {
        [self addSubview:endline];
        [self addSubview:_phoneTextFiled];
        
        _phoneTextFiled.frame = CGRectMake(12, CGRectGetMaxY(midline.frame)+5, ScreenWidth-24, 35);
        midline.frame = CGRectMake(12, midline.frame.origin.y, ScreenWidth-12, 0.5);

        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, ScreenWidth, 45*2);
        endline.frame = CGRectMake(0, self.frame.size.height-0.5, ScreenWidth, 0.5);
        
    }else{
        [_phoneTextFiled removeFromSuperview];
        [endline removeFromSuperview];
        _phoneTextFiled.frame = CGRectMake(12, CGRectGetMaxY(midline.frame), ScreenWidth-24, 0);
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, ScreenWidth, CGRectGetMaxY(_phoneTextFiled.frame));
        midline.frame = CGRectMake(0, midline.frame.origin.y, ScreenWidth, 0.5);
    
    }
    [_delegate ChangeViewFrame:btn];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
