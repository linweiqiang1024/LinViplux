//
//  TicketDontDeleteView.m
//  huiyi
//
//  Created by 林伟强 on 16/11/10.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "TicketDontDeleteView.h"
#import "Helper.h"

@implementation TicketDontDeleteView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initSubViews];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initSubViews];
}

- (void)initSubViews {
    
    self.mycontrol = [[UIControl alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    [self.mycontrol addGestureRecognizer:tap];
    [self.mycontrol setBackgroundColor:[[UIColor blackColor] colorWithAlphaComponent:0.5]];
    [self.mycontrol setUserInteractionEnabled:NO];
    [self addSubview:self.mycontrol];
    
    self.bgView = [[UIView alloc] initWithFrame:CGRectMake((ScreenWidth-260)/2, (ScreenHeight-200)/2, 260, 200)];
    [self.bgView setBackgroundColor:[UIColor whiteColor]];
    [self.bgView.layer setCornerRadius:15.0];
    [self.bgView.layer setMasksToBounds:YES];
    [self addSubview:self.bgView];
    
    self.topLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 22, self.bgView.frame.size.width, 18)];
    [self.topLabel setText:@"不可删除"];
    [self.topLabel setFont:[UIFont boldSystemFontOfSize:18.0]];
    [self.topLabel setTextColor:[UIColor colorWithHexString:@"#000000"]];
    [self.topLabel setTextAlignment:NSTextAlignmentCenter];
    [self.topLabel setBackgroundColor:[UIColor clearColor]];
    [self.bgView addSubview:self.topLabel];
    
    self.textLabel = [[UILabel alloc] initWithFrame:CGRectMake(22, CGRectGetMaxY(self.topLabel.frame)+11, self.bgView.frame.size.width-44, 100)];
    [self.textLabel setFont:[UIFont systemFontOfSize:15.0]];
    [self.textLabel setTextColor:[UIColor colorWithHexString:@"#333333"]];
    [self.textLabel setTextAlignment:NSTextAlignmentLeft];
    [self.textLabel setBackgroundColor:[UIColor clearColor]];
    [self.textLabel setNumberOfLines:0];
    [self.bgView addSubview:self.textLabel];
    
    self.lineView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.textLabel.frame)+22, self.bgView.frame.size.width, 0.5)];
    [self.lineView setBackgroundColor:[UIColor colorWithHexString:@"#c7c7c7"]];
    [self.bgView addSubview:self.lineView];
    
    self.cancelLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.textLabel.frame)+22, self.bgView.frame.size.width, 45)];
    [self.cancelLabel setText:@"确定"];
    [self.cancelLabel setFont:[UIFont systemFontOfSize:18.0]];
    [self.cancelLabel setTextColor:[UIColor colorWithHexString:@"#0074ff"]];
    [self.cancelLabel setTextAlignment:NSTextAlignmentCenter];
    [self.cancelLabel setBackgroundColor:[UIColor clearColor]];
    [self.bgView addSubview:self.cancelLabel];
    
    self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.cancelButton setFrame:CGRectMake(0, CGRectGetMaxY(self.textLabel.frame)+22, self.bgView.frame.size.width, 45)];
    [self.cancelButton setBackgroundColor:[UIColor clearColor]];
    [self.cancelButton addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.cancelButton];
}

- (void)reloadView:(NSString *)text {
    [self.textLabel setText:text];
    CGFloat height = [Helper heightOfString:text font:[UIFont systemFontOfSize:15.0] width:self.bgView.frame.size.width-44];
    [self.textLabel setFrame:CGRectMake(22, CGRectGetMaxY(self.topLabel.frame)+11, self.bgView.frame.size.width-44, height)];
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc]initWithString:self.textLabel.text];
    NSRange range = NSMakeRange(3, text.length-27);
    UIColor *color = [UIColor colorWithHexString:@"#17b6eb"];
    [string addAttribute:NSForegroundColorAttributeName value:color range:range];
    [self.textLabel setAttributedText:string];
    
    [self.lineView setFrame:CGRectMake(0, CGRectGetMaxY(self.textLabel.frame)+22, self.bgView.frame.size.width, 0.5)];
    [self.cancelLabel setFrame:CGRectMake(0, CGRectGetMaxY(self.textLabel.frame)+22, self.bgView.frame.size.width, 45)];
    [self.cancelButton setFrame:CGRectMake(0, CGRectGetMaxY(self.textLabel.frame)+22, self.bgView.frame.size.width, 45)];
    [self.bgView setFrame:CGRectMake((ScreenWidth-260)/2, (ScreenHeight-118-height)/2, 260, 118+height)];
}

- (UIImage *)creatImageWithColol:(UIColor *)color Size:(CGSize)imageSize
{
    UIGraphicsBeginImageContextWithOptions(imageSize, 0, [UIScreen mainScreen].scale);
    [color set];
    UIRectFill(CGRectMake(0, 0, imageSize.width, imageSize.height));
    UIImage *pressedColorImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return pressedColorImg;
}

- (void)show
{
    [UIView animateWithDuration:0.5 animations:^{
        [[UIApplication sharedApplication].keyWindow addSubview:self];
    }];
}

- (void)cancel
{
    [UIView animateWithDuration:0.5 animations:^{
        //[self performSelector:@selector(hidden) withObject:nil afterDelay:0.5];
        [self hidden];
    }];
}

- (void)hidden
{
    [self removeFromSuperview];
}

- (void)tapAction:(UITapGestureRecognizer *)tap
{
    [self cancel];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
