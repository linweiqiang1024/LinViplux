//
//  SDImageView.h
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DeleteImageDelegate <NSObject>

- (void)deleteImage:(UIButton *)btn;

@end
@interface SDImageView : UIView
{
    
}
@property (nonatomic,strong)UIButton *delBtn;
@property (nonatomic,strong)UIImageView *bgImageView;
@property (nonatomic,strong)UIImageView *midImageView;
@property (nonatomic,strong)UIImageView *iconImageView;
@property (nonatomic,weak)id <DeleteImageDelegate>delegate;
@end
