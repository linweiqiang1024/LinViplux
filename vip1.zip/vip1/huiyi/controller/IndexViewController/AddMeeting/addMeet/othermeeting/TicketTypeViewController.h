//
//  TicketTypeViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@protocol GetTicketTypeInfoDelegate <NSObject>

- (void)getTicketInfo:(NSString *)summary WithSection:(NSInteger)section;

@end

@interface TicketTypeViewController : FatherViewController
@property (nonatomic,strong)NSString *summary;
@property (nonatomic)NSInteger section;
@property (nonatomic,weak)id <GetTicketTypeInfoDelegate>delegate;
@end
