//
//  SDAlertView.h
//  huiyi
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void (^SDAlertViewBlock)();
typedef void (^SDAlertViewStringBlock)(NSString*);
@interface SDAlertView : NSObject<UIAlertViewDelegate>

@property (nonatomic, strong) UIAlertView* alertView;

- (id) initWithTitle:(NSString *)title
             message:(NSString*)message
       textFieldHint:(NSString *)textFieldMessage
      textFieldValue:(NSString *)texttFieldValue
   cancelButtonTitle:(NSString *)cancelButtonTitle
   otherButtonTitles:(NSString *)otherButtonTitles
   cancelButtonBlock:(SDAlertViewBlock)cancelButtonBlock
    otherButtonBlock:(SDAlertViewStringBlock)otherButtonBlock;

@end
