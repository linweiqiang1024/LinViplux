//
//  UIDesView.h
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIShowInfoView.h"

@protocol changeViewFrame <NSObject>

- (void)changeFrameView:(UIButton *)btn;
- (void)changeFrameHeight:(CGFloat)height;
- (void)changePersonalData:(NSString *)personalData;

@end
/**
 *  提示语句
 */
@interface UIDesView : UIView
@property (nonatomic,strong)UIShowInfoView *otherInfoView;
@property (nonatomic,weak)id <changeViewFrame> delegate;
@property (nonatomic)CGFloat desViewHeight;
@end
