//
//  OpenPersonalCell.m
//  huiyi
//
//  Created by 林伟强 on 16/12/27.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "OpenPersonalCell.h"

@implementation OpenPersonalCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    self.topLine = [[UILabel alloc] initWithFrame:CGRectMake(12, 0, ScreenWidth-12, 0.5)];
    [self.topLine setBackgroundColor:[UIColor colorWithHexString:@"#c8c7cc"]];
    [self.contentView addSubview:self.topLine];
    
    self.bottomLine = [[UILabel alloc] initWithFrame:CGRectMake(0, 44.5, ScreenWidth, 0.5)];
    [self.bottomLine setBackgroundColor:[UIColor colorWithHexString:@"#c8c7cc"]];
    [self.contentView addSubview:self.bottomLine];
    
    self.titleLab = [[UILabel alloc] initWithFrame:CGRectMake(12, 0, ScreenWidth-72, 45)];
    [self.titleLab setHidden:NO];
    [self.titleLab setFont:[UIFont systemFontOfSize:16]];
    [self.titleLab setTextColor:[UIColor colorWithHexString:@"#666666"]];
    [self.titleLab setTextAlignment:NSTextAlignmentLeft];
    [self.titleLab setBackgroundColor:[UIColor clearColor]];
    [self.contentView addSubview:self.titleLab];
    
    self.btn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btn.userInteractionEnabled = NO;
    self.btn.frame = CGRectMake(ScreenWidth-40, 12.5, 20, 20);
    [self.btn setBackgroundImage:[UIImage imageNamed:@"unselectOpenPersonal"] forState:UIControlStateNormal];
    [self.btn setBackgroundImage:[UIImage imageNamed:@"selectOpenPersonal"] forState:UIControlStateSelected];
    [self.contentView addSubview:self.btn];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
