//
//  OptionViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@protocol callBackOptionItemsDelegate <NSObject>

- (void)callBackOptionItem:(NSDictionary *)OptionsDic with:(NSInteger)index;

@end

@interface OptionViewController : FatherViewController
@property (nonatomic,weak)id<callBackOptionItemsDelegate>delegate;
@property (nonatomic)NSInteger index;
@property (nonatomic,strong)NSArray * all_partake_fields;
@property (nonatomic,strong)NSDictionary * partake_fields;
@end
