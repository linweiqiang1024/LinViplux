//
//  NewCreateOtherMeetPartOneVC.h
//  huiyi
//
//  Created by 林伟强 on 2017/8/7.
//  Copyright © 2017年 linweiqiang. All rights reserved.
//

#import "FatherViewController.h"

@interface NewCreateOtherMeetPartOneVC : FatherViewController

@property (nonatomic, strong) NSString * titleName;
@property (nonatomic, assign) NSInteger type;

@end
