//
//  AddCompanyView.m
//  huiyi
//
//  Created by songhongshuai on 15/8/19.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "AddCompanyView.h"

@implementation AddCompanyView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    UIBezierPath * BezierPath;
    BezierPath = [[UIBezierPath alloc]init];
    [BezierPath moveToPoint:CGPointMake(0, rect.size.height-0.5)];
    [BezierPath addLineToPoint:CGPointMake(rect.size.width, rect.size.height-0.5)];
    [LINE_COLOR setStroke];
    BezierPath.lineWidth = 0.5f;
    [BezierPath stroke];
    
    
    [BezierPath moveToPoint:CGPointMake(0, 0)];
    [BezierPath addLineToPoint:CGPointMake(rect.size.width, 0)];
    [LINE_COLOR setStroke];
    BezierPath.lineWidth = 0.5f;
    [BezierPath stroke];
}


@end
