//
//  UIShowInfoView.h
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SevenSwitch.h"

@protocol UIShowInfoViewDelegate <NSObject>

- (void)callBackHeight:(CGFloat)height review:(BOOL)review;
- (void)changePersonalData:(NSString *)personalData;

@end

/**
 *  收起 展开
 */
@interface UIShowInfoView : UIView<UITextFieldDelegate>
{
    UIView *_titleView;
}
@property (nonatomic,strong)NSMutableArray *organizerNameArr;
@property (nonatomic,strong)NSMutableArray *companyNameArr;
@property (nonatomic,strong)NSMutableArray *personalArr;
@property (nonatomic,strong)UITextField *titleTF;
@property (nonatomic,strong)UITextField *subTitleTF;
@property (nonatomic,strong)SevenSwitch *staySwitchBtn;
@property (nonatomic,strong)SevenSwitch *signUpSwitchBtn;
@property (nonatomic,strong)SevenSwitch *openSwitchBtn;
@property (nonatomic,strong)SevenSwitch *personalSwitchBtn;
@property (nonatomic,strong)UITableView *personalTableView;
@property (nonatomic,assign)NSInteger select;
@property (nonatomic,assign)BOOL changeFrame;
@property (nonatomic,assign)BOOL personalChangeFrame;
@property (nonatomic,strong)id<UIShowInfoViewDelegate>delegate;
@end
