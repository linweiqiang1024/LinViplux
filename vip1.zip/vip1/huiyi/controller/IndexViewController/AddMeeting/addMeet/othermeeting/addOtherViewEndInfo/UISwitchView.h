//
//  UISwitchView.h
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol SwitchBtnDelegate <NSObject>

- (void)ChangeValue:(UISwitch *)btn;

@end
@interface UISwitchView : UIView
@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UISwitch *switchBtn;
@property (nonatomic,weak)id <SwitchBtnDelegate>delegate;
@end
