//
//  CreateOtherMeetPartOneVC.h
//  huiyi
//
//  Created by 王振兴 on 15-1-19.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface CreateOtherMeetPartOneVC : FatherViewController
@property (nonatomic)int type;
@property (nonatomic,strong)NSString *titleName;//导航的标题名称
@property (nonatomic,strong)NSDictionary *meet_label;
@property (nonatomic,strong)NSDictionary *meetnew_label;
@end
