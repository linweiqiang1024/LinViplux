//
//  OptionTypeView.m
//  huiyi
//
//  Created by 林伟强 on 16/12/6.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "OptionTypeView.h"

#define MAX_LIMIT_NUMS 60

@interface OptionTypeView () <UITextFieldDelegate>

@end

@implementation OptionTypeView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initSubViews];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initSubViews];
}

- (void)initSubViews {
    
    self.mycontrol = [[UIControl alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    [self.mycontrol addGestureRecognizer:tap];
    [self.mycontrol setBackgroundColor:[[UIColor blackColor] colorWithAlphaComponent:0.5]];
    [self.mycontrol setUserInteractionEnabled:NO];
    [self addSubview:self.mycontrol];
    
    self.bgView = [[UIView alloc] initWithFrame:CGRectMake((ScreenWidth-260)/2, (ScreenHeight-137)/2, 260, 137)];
    [self.bgView setBackgroundColor:[UIColor colorWithHexString:@"#F0F8FF"]];
    [self.bgView.layer setCornerRadius:15.0];
    [self.bgView.layer setMasksToBounds:YES];
    [self addSubview:self.bgView];
    
    self.topLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 22, self.bgView.frame.size.width, 18)];
    [self.topLabel setText:@"请输入报名字段名称"];
    [self.topLabel setFont:[UIFont boldSystemFontOfSize:18.0]];
    [self.topLabel setTextColor:[UIColor colorWithHexString:@"#000000"]];
    [self.topLabel setTextAlignment:NSTextAlignmentCenter];
    [self.topLabel setBackgroundColor:[UIColor clearColor]];
    [self.bgView addSubview:self.topLabel];
    
    self.textFieldBgView = [[UIView alloc] initWithFrame:CGRectMake(18, CGRectGetMaxY(self.topLabel.frame)+15, self.bgView.frame.size.width-36, 25)];
    [self.textFieldBgView setBackgroundColor:[UIColor whiteColor]];
    //[self.textFieldBgView.layer setCornerRadius:5.0];
    //[self.textFieldBgView.layer setMasksToBounds:YES];
    [self.textFieldBgView.layer setBorderWidth:0.5];
    [self.textFieldBgView.layer setBorderColor:[[UIColor colorWithHexString:@"#696969"] CGColor]];
    [self.bgView addSubview:self.textFieldBgView];
    
    self.textField = [[UITextField alloc] initWithFrame:CGRectMake(22, CGRectGetMaxY(self.topLabel.frame)+19, self.bgView.frame.size.width-44, 18)];
    [self.textField setFont:[UIFont systemFontOfSize:15.0]];
    [self.textField setBackgroundColor:[UIColor clearColor]];
    [self.textField setDelegate:self];
    [self.textField addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
    [self.bgView addSubview:self.textField];
    
    self.lineView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width, 0.5)];
    [self.lineView setBackgroundColor:[UIColor colorWithHexString:@"#c7c7c7"]];
    [self.bgView addSubview:self.lineView];
    
    //self.nextLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2, 45)];
    self.nextLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.bgView.frame.size.width/2+0.5, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2-0.5, 45)];
    [self.nextLabel setText:@"确定"];
    [self.nextLabel setFont:[UIFont systemFontOfSize:18.0]];
    [self.nextLabel setTextColor:[UIColor colorWithHexString:@"#0074ff"]];
    [self.nextLabel setTextAlignment:NSTextAlignmentCenter];
    [self.nextLabel setBackgroundColor:[UIColor clearColor]];
    [self.bgView addSubview:self.nextLabel];
    
    self.nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    //[self.nextButton setFrame:CGRectMake(0, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2, 45)];
    [self.nextButton setFrame:CGRectMake(self.bgView.frame.size.width/2+0.5, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2-0.5, 45)];
    [self.nextButton setBackgroundColor:[UIColor clearColor]];
    [self.nextButton addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.nextButton];
    
    self.nextLineView = [[UIView alloc] initWithFrame:CGRectMake(self.bgView.frame.size.width/2, CGRectGetMaxY(self.textFieldBgView.frame)+12, 0.5, 45)];
    [self.nextLineView setBackgroundColor:[UIColor colorWithHexString:@"#c7c7c7"]];
    [self.bgView addSubview:self.nextLineView];
    
    //self.cancelLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.bgView.frame.size.width/2+0.5, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2-0.5, 45)];
    self.cancelLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2, 45)];
    [self.cancelLabel setText:@"取消"];
    [self.cancelLabel setFont:[UIFont boldSystemFontOfSize:18.0]];
    [self.cancelLabel setTextColor:[UIColor colorWithHexString:@"#0074ff"]];
    [self.cancelLabel setTextAlignment:NSTextAlignmentCenter];
    [self.cancelLabel setBackgroundColor:[UIColor clearColor]];
    [self.bgView addSubview:self.cancelLabel];
    
    self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    //[self.cancelButton setFrame:CGRectMake(self.bgView.frame.size.width/2+0.5, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2-0.5, 45)];
    [self.cancelButton setFrame:CGRectMake(0, CGRectGetMaxY(self.textFieldBgView.frame)+12, self.bgView.frame.size.width/2, 45)];
    [self.cancelButton setBackgroundColor:[UIColor clearColor]];
    [self.cancelButton addTarget:self action:@selector(cancel) forControlEvents:UIControlEventTouchUpInside];
    [self.bgView addSubview:self.cancelButton];
}

- (void)reloadView:(CGSize)keyBoardSize
{
    [self.bgView setFrame:CGRectMake((ScreenWidth-260)/2, (ScreenHeight-137-keyBoardSize.height)/2, 260, 137)];
}

- (UIImage *)creatImageWithColol:(UIColor *)color Size:(CGSize)imageSize
{
    UIGraphicsBeginImageContextWithOptions(imageSize, 0, [UIScreen mainScreen].scale);
    [color set];
    UIRectFill(CGRectMake(0, 0, imageSize.width, imageSize.height));
    UIImage *pressedColorImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return pressedColorImg;
}

- (void)show
{
    [UIView animateWithDuration:0.5 animations:^{
        [[UIApplication sharedApplication].keyWindow addSubview:self];
    }];
    [self.textField becomeFirstResponder];
}

- (void)next
{
    [self.textField resignFirstResponder];
    if (self.delegate && [self.delegate respondsToSelector:@selector(optionTypeAdd:)]) {
        [self.delegate optionTypeAdd:self.textField.text];
        [self hidden];
    }
}

- (void)cancel
{
    [self.textField resignFirstResponder];
    [UIView animateWithDuration:0.5 animations:^{
        //[self performSelector:@selector(hidden) withObject:nil afterDelay:0.5];
        [self hidden];
    }];
}

- (void)hidden
{
    [self removeFromSuperview];
}

- (void)tapAction:(UITapGestureRecognizer *)tap
{
    [self cancel];
}

- (void)textChange:(UITextField *)textField
{
    UITextRange *selectedRange = [textField markedTextRange];
    //获取高亮部分
    UITextPosition *pos = [textField positionFromPosition:selectedRange.start offset:0];
    //如果在变化中是高亮部分在变，就不要计算字符了
    if (selectedRange && pos) {
        return;
    }
    
    if ([self stringContainsEmoji:textField.text]) {
        [self next];
        return;
    }
    
    NSString *nsTextContent = textField.text;
    NSMutableString *newText = [NSMutableString stringWithCapacity:0];
    int len = 0;
    for (int i = 0; i < nsTextContent.length; i++) {
        NSRange rang = NSMakeRange(i, 1);
        NSString *str = [nsTextContent substringWithRange:rang];
        if (strlen([str UTF8String]) == 3) {
            len += 2;
        }
        else {
            len += 1;
        }
        if (len > MAX_LIMIT_NUMS) {
            if (strlen([str UTF8String]) == 3) {
                len -= 2;
            }else{
                len -= 1;
            }
            [textField setText:newText];
            break;
        }
        [newText appendString:str];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField.text isEqualToString:@"\n"]) {
        [self next];
        return NO;
    }
    
    BOOL isMax = NO;
    
    NSString *nsTextContent = textField.text;
    NSMutableString *newText = [NSMutableString stringWithCapacity:0];
    int len = 0;
    for (int i = 0; i < nsTextContent.length; i++) {
        NSRange rang = NSMakeRange(i, 1);
        NSString *str = [nsTextContent substringWithRange:rang];
        if (strlen([str UTF8String]) == 3) {
            len += 2;
        }
        else {
            len += 1;
        }
        isMax = NO;
        if (len > MAX_LIMIT_NUMS) {
            if (strlen([str UTF8String]) == 3) {
                len -= 2;
            }else{
                len -= 1;
            }
            isMax = YES;
            break;
        }
        [newText appendString:str];
    }
    
    NSString *comcatstr = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    UITextRange *selectedRange = [textField markedTextRange];
    //获取高亮部分
    UITextPosition *pos = [textField positionFromPosition:selectedRange.start offset:0];
    //获取高亮部分内容
    //NSString * selectedtext = [textView textInRange:selectedRange];
    //如果有高亮且当前字数开始位置小于最大限制时允许输入
    if (selectedRange && pos) {
        if (!isMax) {
            if (len < MAX_LIMIT_NUMS) {
                return YES;
            }
            else {
                NSInteger caninputlen = newText.length - comcatstr.length;
                if (caninputlen >= 0) {
                    return YES;
                }
                else {
                    return NO;
                }
            }
        }else{
            return YES;
        }
    }
    
    if (!isMax) {
        if (len < MAX_LIMIT_NUMS) {
            return YES;
        }
        else {
            NSInteger caninputlen = newText.length - comcatstr.length;
            if (caninputlen >= 0) {
                return YES;
            }
            else {
                return NO;
            }
        }
    }
    else {
        [textField setText:newText];
        return NO;
    }
}

//是否含有表情
- (BOOL)stringContainsEmoji:(NSString *)string
{
    __block BOOL returnValue = NO;
    
    [string enumerateSubstringsInRange:NSMakeRange(0, [string length])
                               options:NSStringEnumerationByComposedCharacterSequences
                            usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
                                const unichar hs = [substring characterAtIndex:0];
                                if (0xd800 <= hs && hs <= 0xdbff) {
                                    if (substring.length > 1) {
                                        const unichar ls = [substring characterAtIndex:1];
                                        const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                                        if (0x1d000 <= uc && uc <= 0x1f77f) {
                                            returnValue = YES;
                                        }
                                    }
                                } else if (substring.length > 1) {
                                    const unichar ls = [substring characterAtIndex:1];
                                    if (ls == 0x20e3) {
                                        returnValue = YES;
                                    }
                                } else {
                                    if (0x2100 <= hs && hs <= 0x27ff) {
                                        returnValue = YES;
                                    } else if (0x2B05 <= hs && hs <= 0x2b07) {
                                        returnValue = YES;
                                    } else if (0x2934 <= hs && hs <= 0x2935) {
                                        returnValue = YES;
                                    } else if (0x3297 <= hs && hs <= 0x3299) {
                                        returnValue = YES;
                                    } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                                        returnValue = YES;
                                    }
                                }
                            }];
    
    return returnValue;
}

@end
