//
//  CreateOtherMeetPartOneVC.m
//  huiyi
//
//  Created by 王振兴 on 15-1-19.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "CreateOtherMeetPartOneVC.h"
#import <QuartzCore/QuartzCore.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "CreatMeetTextField.h"
#import "New_managerViewController.h"
#import "MinePutOutViewController.h"
#import "SlideAttachmentCell.h"
#import "EmotionAttachmentCell.h"
#import <CoreText/CoreText.h>
#import "UIImage-Extensions.h"
#import "LoginViewController.h"
#import "NSAttributedString+TextUtil.h"
#import "TextConfig.h"
#import "TextParagraph.h"
#import "MD5Util.h"
#import "CreateOtherMeetTool.h"
#import "MHFacebookImageViewer.h"
#import "MWPhotoBrowser.h"
#import "SDImageView.h"//海报
#import "UITypeButton.h"
#import "SevenSwitch.h"
#import "PureLayout.h"
#import "SDToolBarView.h"
#import "GTMBase64.h"
#import "UIDesView.h"
#import "LocalPhotoViewController.h"
#import "SubEndView.h"
#import "EndView.h"
#import "ReplyEmailView.h"
#import "TwoMeetStepViewController.h"
#import "SDToolBarOfHideView.h"
#import "FastTextView.h"
#import "UICostTypeButton.h"
#import "SDTimeActiontSheet.h"
#import "UIButton+WebCache.h"
#import "TOCropViewController.h"

#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <CoreLocation/CoreLocation.h>

#import "Helper.h"
#import "HintAlertView.h"

#define NAVBAR_HEIGHT 44.0f
#define TABBAR_HEIGHT 49.0f
#define STATUS_HEIGHT 20.0f

#define TOP_VIEW_HEIGHT 35.0f
#define TOP_VIEW_WIDTH 48.0f
#define ARRSIZE(a) (sizeof(a) / sizeof(a[0]))

#define MAX_NUMS 5

@interface CreateOtherMeetPartOneVC ()<UITextFieldDelegate,SDTimeActionSheetDelegate,SDToolBarDelegage,UIAlertViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,SubViewDelegate,changeViewFrame,AddPosterDelegate,SelectPhotoDelegate,HideKeyboardDelegate,MWPhotoBrowserDelegate,CreateMeetEnd,TOCropViewControllerDelegate,FastTextViewDelegate,ReplyEmailViewDelegate,HintAlertViewDelegate>
{
    BOOL startBtnSelect;
    BOOL endBtnSelect;
    BOOL isAddSlide;
    BOOL keyBoardShow;
    BOOL eidtTextFiled;
    BOOL isCreating;
    BOOL isCamera;//选择相机；
    BOOL isPoster;//选择海报；
    CGFloat origin_y;
    NSInteger imageId;//记录图片放入缓存的id
    CGSize keyBoardSize;
    UILabel *line;
    UILabel *line1;
    UILabel *line2;
    
    BOOL _didSetupConstraints;
    
    SubEndView *view;
    NSMutableDictionary *picMuDict;
    UISegmentedControl *_segmentedControl;
    SDTimeActiontSheet * _dateActionSheet;
    NSMutableDictionary *_postDic;
    NSMutableArray *picMuArr;
    NSMutableArray *picCacheArr;
    NSMutableArray *picUrlMuArr;//详情图片URL
    NSMutableArray *oldPicUrlMuArr;
    NSMutableArray *_posterUrlMuArr;//海报
    NSMutableArray *meetTypeArr;
    NSString *costStr;
    __block int imageIndex ;
    __block int imageCount ;
    __block Dialog *hud;
    
    NSString *contentStr;//记录Html化的content
}
@property (nonatomic,strong)UILabel *titltLb;
@property (nonatomic,strong)UILabel *contentTitleLB;
@property (nonatomic,strong)UILabel *contentSepLb;
@property (nonatomic,strong)UILabel *descTitleLB2;
@property (nonatomic,strong)UILabel *descTitleLB;

@property (nonatomic,strong)SDToolBarOfHideView *tfToolbar;
@property (nonatomic,strong)NSMutableArray *posterMuArr;
@property (nonatomic,strong)NSArray *photos;
@property (nonatomic,strong)SDTimeActiontSheet *dateActionSheet;
@property (nonatomic,strong)UIScrollView *mainScrollView;
@property (nonatomic,strong)UIView *titleView;
@property (nonatomic,strong)CreatMeetTextField *titleTF;
@property (nonatomic,strong)UIView *contentView;
@property (nonatomic,strong)UIView *detailView;

@property (nonatomic,strong)FastTextView *contentTextView;
@property (nonatomic,strong)SDToolBarView *toolBar;

@property (nonatomic,strong)UIView *descView;
@property (nonatomic,strong)UILabel *sTimeBtn;
@property (nonatomic,strong)UILabel *eTimeBtn;
@property (nonatomic,strong)UILabel *line5;
@property (nonatomic,strong)UIImageView *timeImageView1;

@property (nonatomic,strong)UITypeButton *meetTypeBtn1;
@property (nonatomic,strong)UITypeButton *meetTypeBtn2;
@property (nonatomic,strong)UITypeButton *meetTypeBtn3;

@property (nonatomic,strong)UICostTypeButton *costTypeBtn1;
@property (nonatomic,strong)UICostTypeButton *costTypeBtn2;
@property (nonatomic,strong)UICostTypeButton *costTypeBtn3;
@property (nonatomic,strong)UICostTypeButton *costTypeBtn4;

@property (nonatomic,strong)UIButton *scleanBtn;
@property (nonatomic,strong)UIButton *enCleanBtn;


@property (nonatomic,strong)UIDesView *desView;
@property (nonatomic,strong)CreatMeetTextField *addressTF;
@property (nonatomic,strong)UIView *endDescView;

@property (nonatomic,strong)ReplyEmailView *replyEmailView;
@property (nonatomic,strong)EndView *endView;

@end

@implementation CreateOtherMeetPartOneVC

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if( self.dateActionSheet.isShow == YES) {
        [self.dateActionSheet tappedCancel];
    }
    keyBoardShow = NO;
    self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width,ScreenHeight-self.F_NAV_HEIGHT );
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [MobClick endLogPageView:@"CreateOtherMeetPartOneVC"];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

/**
 *  从content里获取<img src=""/>
 *
 *  @param content 页面内容
 *
 *  @return 多个<img src=""/>
 */
- (NSArray *)getHtmlUrl:(NSString *)content
{
    NSString *s = @"<(\\w+)\\s*src=\\\"(\\w+.*?)\\\"\\s*/>";
    NSMutableArray *muUrlArr = [[NSMutableArray alloc]initWithCapacity:0];
    NSError *error;
    // NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [content substringWithRange:match.range];
        substringForMatch = [substringForMatch substringFromIndex:10];
        substringForMatch = [substringForMatch substringWithRange:NSMakeRange(0,substringForMatch.length-4)];
        [muUrlArr addObject:substringForMatch];
    }
    NSArray *arr = muUrlArr;
    return arr;
}
/**
 *  获取图片的真正地址
 *
 *  @param htmlTap <img src="askjdlkasjdalsd"/>
 *
 *  @return URL
 */
- (NSString *)getImageUrl:(NSString *)htmlTap
{
    NSString *s = @"\"(\\w+.*?)\\\"";
    NSError *error;
    //NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:htmlTap options:0 range:NSMakeRange(0, [htmlTap length])];
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [htmlTap substringWithRange:match.range];
        substringForMatch = [substringForMatch substringWithRange:NSMakeRange(1,substringForMatch.length-2)];
        [picUrlMuArr addObject:substringForMatch];
        return substringForMatch;
    }
    return nil;
}

- (void)ReturnBtn
{
    NSArray * arr = [NSArray arrayWithArray:picMuArr];
    [picCacheArr removeAllObjects];
    if (contentStr != 0) {
        [_postDic setObject:contentStr forKey:@"summary"];
        NSArray *urlArr = [self getHtmlUrl:contentStr];
        for (int i = 0; i<urlArr.count; i++) {
            NSString *url = [urlArr objectAtIndex:i];
            int index = [[url substringWithRange:NSMakeRange(1, 1)] integerValue];
            [picCacheArr addObject:[arr objectAtIndex:index-1]];
            [self saveImageToDocument:[arr objectAtIndex:index-1] imageName:url withMeetingType:[NSString stringWithFormat:@"%d",_type]];
        }
    }
    else {
        
    }
    for (int i = 0; i<_posterMuArr.count; i++) {
        [self saveImageToDocument:[_posterMuArr objectAtIndex:i] imageName:[NSString stringWithFormat:@"poster_%d",i] withMeetingType:[NSString stringWithFormat:@"%d",_type]];
    }
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
    [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%lu",(unsigned long)picCacheArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
    
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_posterImageCount",_type]];
    [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%lu",(unsigned long)_posterMuArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_posterImageCount",_type]];
   
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
    [[DBManager sharedInstance] insertDataToPublicDB:[_postDic JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
    
    [_contentTextView removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)keyboardWillShow:(NSNotification *)notification
{
    NSDictionary* info = [notification userInfo];
    keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    
    if (keyBoardShow == YES && eidtTextFiled == NO) {//选中文本域时
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width, ScreenHeight-self.F_NAV_HEIGHT-origin_y-keyBoardSize.height-TOP_VIEW_HEIGHT );
        self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
        self.toolBar.hideBtn.hidden = NO;//显示完成按钮
        self.toolBar.frame = CGRectMake(0, ScreenHeight-keyBoardSize.height-35, ScreenWidth,TOP_VIEW_HEIGHT );
        [self.view addSubview:self.toolBar];
        [self.view bringSubviewToFront:self.toolBar];//改变toolbar的位置
    }
    else {//选中文本框时 不操作toolbar
       self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width, ScreenHeight-self.F_NAV_HEIGHT-origin_y-keyBoardSize.height );
    }
    //self.mainScrollView.contentSize = CGSizeMake(0, CGRectGetMaxY(self.desView.frame));
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    NSDictionary* info = [notification userInfo];
    keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    
    if (keyBoardShow == YES) {
        if (self.contentTextView.contentSize.height < 70) {
            
        }
        else {
            
        }
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width,ScreenHeight-self.F_NAV_HEIGHT );
        self.toolBar.delBtn.hidden = NO;//隐藏删除按钮
        self.toolBar.hideBtn.hidden = YES;//显示完成按钮
        self.toolBar.frame = CGRectMake(0, _contentView.size.height-TOP_VIEW_HEIGHT, ScreenWidth, TOP_VIEW_HEIGHT );
        [self.contentView addSubview:self.toolBar];
        [self.contentView bringSubviewToFront:self.toolBar];//改变toolbar的位置
    }
    else {
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width, ScreenHeight-self.F_NAV_HEIGHT );
    }
    //self.mainScrollView.contentSize = CGSizeMake(0, CGRectGetMaxY(self.desView.frame));
}

- (void)selectImage
{
    [self.view endEditing:YES];
    isPoster = NO;
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"打开照相机",@"从手机相册获取",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    /*
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if (![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
        sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    }
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    //[picker.navigationItem.backBarButtonItem setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]} forState:UIControlStateNormal];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = sourceType;
    
    switch (buttonIndex) {
        case 0:  //打开照相机拍照
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentViewController:picker animated:YES completion:^{
                [[UIApplication sharedApplication] setStatusBarHidden:YES];
            }];
            break;
        case 1:  //打开本地相册
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [self presentViewController:picker animated:YES completion:nil];
            break;
    }*/
    
    if (0 == buttonIndex) {
        //相机权限
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (authStatus ==AVAuthorizationStatusRestricted ||//此应用程序没有被授权访问的照片数据。可能是家长控制权限
            authStatus ==AVAuthorizationStatusDenied)  //用户已经明确否认了这一照片数据的应用程序访问
        {
            /*
            // 无权限 引导去开启
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }*/
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无访问权限" message:@"会议邦只有获得您的相机权限才能正常使用。请按照以下步骤开启：系统设置->隐私->相机->会议邦（打开）" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"立即设置",nil];
            [alert setTag:2600];
            [alert show];
        }
        else {
            //相机
            isCamera = YES;
            UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
            pickerController.delegate = self;
            pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            pickerController.allowsEditing = NO;
            [self presentViewController:pickerController animated:NO completion:^{
                [[UIApplication sharedApplication] setStatusBarHidden:YES];
            }];
        }
        
    }
    else if (1 == buttonIndex) {
        //相册权限
        ALAuthorizationStatus author = [ALAssetsLibrary authorizationStatus];
        if (author ==kCLAuthorizationStatusRestricted || author ==kCLAuthorizationStatusDenied)
        {
            /*
            //无权限 引导去开启
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }*/
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无访问权限" message:@"会议邦只有获得您的照片权限才能正常使用。请按照以下步骤开启：系统设置->隐私->照片->会议邦（打开）" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"立即设置",nil];
            [alert setTag:2600];
            [alert show];
        }
        else {
            //相册
            isCamera = NO;
            LocalPhotoViewController *pick=[[LocalPhotoViewController alloc] init];
            self.navigationItem.backBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleBordered target:nil action:nil];
            pick.isFromCreateMeet = YES;
            if (isPoster == YES) {
                //添加海报
                pick.isPoster = YES;
            }
            else {
                //添加详情
                pick.isPoster = NO;
            }
            pick.selectPhotoDelegate = self;
            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:pick];
            [self presentViewController:navigationController animated:YES completion:false];
        }
    }
}

- (void)delContent
{
    [_postDic setObject:@"" forKey:@"summary"];
    [oldPicUrlMuArr removeAllObjects];
    [picMuArr removeAllObjects];
    [picUrlMuArr removeAllObjects];
    
    self.contentTextView.text = @"";
    self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
    self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(self.contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    line2.frame = CGRectMake(0, CGRectGetHeight(self.contentView.frame) - 0.5, ScreenWidth, 0.5);
    view.frame = CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, view.size.height);
    self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, self.contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)HideKeyBoard
{
    [self.view endEditing:YES] ;
}

- (NSString *)replaceBr:(NSString *)content
{
    NSString *s = @"<br>";
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
        for (int i = 0; i<arrayOfAllMatches.count; i++) {
            content = [content stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
            
        }
    return content;
}

- (NSString *)rePlaceUrl:(NSString*)content
{
    NSString *s = @"<(\\w+)\\s*src=\\\"a(\\w+.*?)\\\"\\s*/>";
    NSError *error;
    //NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    if (picUrlMuArr.count < arrayOfAllMatches.count) {
        for (int i = 0; i<picUrlMuArr.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
            content = [content stringByReplacingOccurrencesOfString:substringForMatch withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:i]]];
        }
        for (int j = picUrlMuArr.count; j< arrayOfAllMatches.count; j++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:j];
            //NSString* substringForMatch1 = [content substringWithRange:match.range];
            content = [content stringByReplacingCharactersInRange:match.range withString:@""];
        }
    }
    else {
        for (int i = 0; i<arrayOfAllMatches.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
        }
    }
    for (int index = 0; index<picUrlMuArr.count; index++) {
        content = [content stringByReplacingOccurrencesOfString:[oldPicUrlMuArr objectAtIndex:index] withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:index]]];
    }
    return content;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.titlelabel.text = _titleName;
    
    hud = [[Dialog alloc]init];
    
    imageId = 0;
    imageIndex = 1;
    
    picCacheArr = [[NSMutableArray alloc]initWithCapacity:0];//缓存图片
    picMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    picUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    picMuDict = [[NSMutableDictionary alloc]initWithCapacity:0];
    oldPicUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    _posterMuArr = [[NSMutableArray alloc]initWithCapacity:0];//海报图片
    _posterUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];//海报图片
    
    _postDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [_postDic setObject:@"0" forKey:@"personal_data_sw"];
    [_postDic setObject:@"1" forKey:@"openstatus"];
    [_postDic setObject:@"0" forKey:@"stay_sw"];
    [_postDic setObject:@"0" forKey:@"shuttle_sw"];
    [_postDic setObject:@"0" forKey:@"phone_sw"];
    self.view.backgroundColor = [UIColor colorWithHexString:@"efeff4"];
    
    int maxImageCount = [[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"type_%d_imageCount",_type] ] intValue];
    if (maxImageCount > 0) {
        //[imageDic addEntriesFromDictionary:[[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]] JSONValue]];
        for (int imageID = 0; imageID < maxImageCount; imageID++) {
            NSString *key = [NSString stringWithFormat:@"a%d.jpg",imageID +1];
            UIImage *image = [self getImageFormDocument:key withMeetingType:@"1"];
            [picCacheArr addObject:image];
        }
    }
    [self creatUI];
}

- (void)textChange:(UITextField*)textField
{
    if (textField.tag == 101) {
        [_postDic setObject:textField.text forKey:@"title"];
    }
    if (textField.tag == 102) {
        [_postDic setObject:textField.text forKey:@"location"];
    }
}

- (void)creatRightNav
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(ScreenWidth-60, _navheight+10, 50, 25);
    [rightbtn setTitle:@"创建" forState:UIControlStateNormal];
    rightbtn.layer.cornerRadius = 2.0f;
    rightbtn.clipsToBounds = YES;
    [rightbtn setBackgroundImage:[self creatImageWithColol:RGBCOLOR(100, 198, 81) Size:rightbtn.frame.size] forState:UIControlStateNormal];
    rightbtn.titleLabel.font = YHUI(14);
    rightbtn.contentMode = UIViewContentModeScaleAspectFit;
    [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightbtn];
}

- (void)creatPostData
{
    [_postDic setObject:self.meet_label forKey:@"meet_label"];
    [_postDic setObject:self.meetnew_label forKey:@"new_label"];
    [_postDic setObject:contentStr forKey:@"summary"];
    [_postDic setObject:_posterUrlMuArr forKey:@"img_file_list"];
    NSMutableArray *tempArr = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSString *name in self.desView.otherInfoView.companyNameArr) {
        if (name.length != 0) {
            [tempArr addObject:name];
        }
    }
    [_postDic setObject:tempArr forKey:@"company_list"];
    NSMutableArray *tempArr1 = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSString *name in self.desView.otherInfoView.organizerNameArr) {
        if (name.length != 0) {
            [tempArr1 addObject:name];
        }
    }
    [_postDic setObject:tempArr1 forKey:@"organizer_list"];
    [_postDic setObject:[NSString stringWithFormat:@"%d",(_type)] forKey:@"type"];
    if ([[_postDic objectForKey:@"title"] length] == 0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动主题不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"title"] length] < 2) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动主题至少两个字 ,请重新输入" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"summary"] length] <= 0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请输入更多活动详情内容" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"begin_time"] length] == 0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动开始时间不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"location"] length] == 0) {
        if(_type == 1) {
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动地点不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
        else {
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动地址不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
        return;
    }
    else if ([[_postDic objectForKey:@"phone"] length] != 0 && ![Helper justMobile:[_postDic objectForKey:@"phone"]]) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动联系人手机号格式不正确" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }
    else if ([[_postDic objectForKey:@"reply_email"] length] != 0 && ![Helper justEmail:[_postDic objectForKey:@"reply_email"]]) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动联系邮箱格式不正确" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }
    else {
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] != 0) {
            
            if ([[_postDic objectForKey:@"reply_email"] length] != 0) {
                NSString *reply_email = [_postDic objectForKey:@"reply_email"];
                NSString *message = [NSString stringWithFormat:@"您填写的活动联系邮箱：%@非常重要！是参会者收到Email时回复电子邮件时的默认地址，如果填写错误您将无法收到参会者的回复邮件！您确认该邮箱正确可用吗？",reply_email];
                HintAlertView *hintAlertView = [[HintAlertView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
                hintAlertView.delegate = self;
                [hintAlertView reloadViewWithTitle:@"提示" message:message range:NSMakeRange(11, message.length-74) cancelButtonTitle:@"取消" otherButtonTitle:@"确认可用"  messageAlignment:NSTextAlignmentLeft];
                [hintAlertView show];
            }
            else {
                if (isCreating == NO) {
                    isCreating = YES;
                    CreateOtherMeetTool *vc = [[CreateOtherMeetTool alloc]init];
                    vc.meet_tittle = [_postDic objectForKey:@"title"];
                    vc.postDic = _postDic;
                    vc.type = _type;
                    vc.delegate = self;
                    vc.posterImageArr = _posterMuArr;
                    vc.contentImageArr = picMuArr;
                    vc.partakTime = [_postDic objectForKey:@"begin_time"];
                    [vc initData];
                    [vc posterImage:nil];
                }
            }
        }
        else {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"是否登录会议邦?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            alertView.tag = 10000;
            [alertView show];
        }
    }
}

- (void)hintAlertViewAction
{
    if (isCreating == NO) {
        isCreating = YES;
        CreateOtherMeetTool *vc = [[CreateOtherMeetTool alloc]init];
        vc.meet_tittle = [_postDic objectForKey:@"title"];
        vc.postDic = _postDic;
        vc.type = _type;
        vc.delegate = self;
        vc.posterImageArr = _posterMuArr;
        vc.contentImageArr = picMuArr;
        vc.partakTime = [_postDic objectForKey:@"begin_time"];
        [vc initData];
        [vc posterImage:nil];
    }
}

- (void)CreateMeetEndMethod:(NSString*)meet_id
{
    isCreating = NO;
    New_managerViewController *managerViewController = [[New_managerViewController alloc]init];
    managerViewController.isCreate = YES;
    managerViewController.meeting_id = meet_id;
    [self.navigationController pushViewController:managerViewController animated:YES];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 2501 || alertView.tag == 2502) {
        
    }
    if (alertView.tag == 10000) {
        if (buttonIndex == 0) {
            NSLog(@"取消");
        }
        if (buttonIndex == 1) {
            LoginViewController *loginVC = [[LoginViewController alloc]init];
            UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVC];
            loginVC.fromSignVC = YES;
            NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
            if (!LoginCompanyArray.count)
            {
                loginVC.isPush = YES;
            }
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
    }
    if (alertView.tag == 10010) {
        if (buttonIndex == 1) {
            NSArray * arr = [NSArray arrayWithArray:picMuArr];
            [picMuArr removeAllObjects];
            if (contentStr != 0) {
                [_postDic setObject:contentStr forKey:@"summary"];
                NSArray *urlArr = [self getHtmlUrl:contentStr];
                for (int i = 0; i<urlArr.count; i++) {
                    NSString *url = [urlArr objectAtIndex:i];
                    int index = [[url substringWithRange:NSMakeRange(1, 1)] integerValue];
                    [picMuArr addObject:[arr objectAtIndex:index-1]];
                    [self saveImageToDocument:[arr objectAtIndex:index-1] imageName:url withMeetingType:@"1"];
                }
            }
            else {
                
            }
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
            [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%lu",(unsigned long)picMuArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
            
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
            [[DBManager sharedInstance] insertDataToPublicDB:[_postDic JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
            
            [_contentTextView removeFromSuperview];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    if (alertView.tag == 2600) {
        if (buttonIndex == 0) {
            NSLog(@"取消");
        }
        if (buttonIndex == 1) {
            // 无权限 引导去开启
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }
        }
    }
}

- (void)rightBtnClicked
{
    [self creatPostData];
    NSLog(@"%@",_postDic);
}

- (void)changeViewHight:(CGFloat)hight
{
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, hight);
}

#pragma mark - SubViewDelegate
- (void)ChangeViewFrame:(UISwitch *)btn
{
    if (btn.on == YES) {
        self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
        self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
        self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.frame.size.height);
        [_postDic setObject:@"1" forKey:@"phone_sw"];
        
    }
    else {
        self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
        self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
        self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.frame.size.height);
        [_postDic setObject:@"0" forKey:@"phone_sw"];
    }
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
}

#pragma mark - changeViewFrame
- (void)changeFrameHeight:(CGFloat)height
{
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    [_mainScrollView setContentOffset:CGPointMake(0,_mainScrollView.contentSize.height-_mainScrollView.bounds.size.height) animated:YES];
}

- (void)changeFrameView:(UIButton *)btn
{
    if (btn.selected == YES) {
         self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, 45);
        _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
        [_mainScrollView setContentOffset:CGPointMake(0,0) animated:YES];
    }
    else {
        self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.desViewHeight);
        _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
        [_mainScrollView setContentOffset:CGPointMake(0,_mainScrollView.contentSize.height-_mainScrollView.bounds.size.height) animated:YES];
    }
}

- (void)changePersonalData:(NSString *)personalData
{
    if ([personalData isEqualToString:@"1"]) {
        personalData = @"2";
    }
    else if ([personalData isEqualToString:@"2"]) {
        personalData = @"1";
    }
    
    [_postDic setObject:personalData forKey:@"personal_data_sw"];
}

#pragma mark - AddPosterDelegate
- (void)addSelectImage
{
    if (_posterMuArr.count >= MAX_NUMS) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"最多只能上传5张图片" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertView show];
    }
    else {
        [self.view endEditing:YES];
        isPoster = YES;
        UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:nil
                                      delegate:self
                                      cancelButtonTitle:@"取消"
                                      destructiveButtonTitle:nil
                                      otherButtonTitles:@"打开照相机",@"从手机相册获取",nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
        [actionSheet showInView:self.view];
    }
}

- (void)showBigImage:(UITapGestureRecognizer *)tap
{
    NSMutableArray *photos = [[NSMutableArray alloc] init];
    BOOL displayActionButton = NO;
    BOOL displaySelectionButtons = NO;
    BOOL displayNavArrows = NO;
    BOOL enableGrid = NO;
    BOOL startOnGrid = NO;
    for (int i = 0; i < _posterMuArr.count; i++) {
        MWPhoto *photo = [MWPhoto photoWithImage:[_posterMuArr objectAtIndex:i]];
        //photo.caption = [NSString stringWithFormat:@"%d/%lu \n %@",i+1,(unsigned long)_imageUrlArr.count,[[info.imageUrlArr objectAtIndex:i] objectForKey:@"summary"]];
        [photos addObject:photo];
        
    }
    self.photos = photos;
    //self.thumbs = thumbs;
    //Create browser
    MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
    browser.rightNavButtonIsHiden = NO;
    browser.displayActionButton = displayActionButton;
    browser.displayNavArrows = displayNavArrows;
    browser.displaySelectionButtons = displaySelectionButtons;
    browser.alwaysShowControls = displaySelectionButtons;
    //browser.navTitle = info.title;
    browser.delegate = self;
    browser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
    browser.wantsFullScreenLayout = YES;
#endif
    browser.enableGrid = enableGrid;
    browser.startOnGrid = startOnGrid;
    browser.enableSwipeToDismiss = YES;
    browser.isFromFeedback = YES;
    [browser setCurrentPhotoIndex:tap.view.tag-10];
    // Show
    if (_segmentedControl.selectedSegmentIndex == 0) {
        // Push
        [self.navigationController pushViewController:browser animated:YES];
    }
    else {
        // Modal
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:browser];
        nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [self presentViewController:nc animated:YES completion:nil];
    }
    
    // Release
    
    // Deselect
    
    // Test reloading of data after delay
    double delayInSeconds = 3;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
    });
}

- (void)deleteImageWith:(UIButton *)btn
{
    [_posterMuArr removeObjectAtIndex:(btn.tag-100)];
    [self.endView reloadImages:_posterMuArr];
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

- (void)numTextChange:(NSString *)text
{
    [_postDic setObject:text forKey:@"phone"];
}

- (SDToolBarOfHideView*)tfToolbar
{
    if (!_tfToolbar) {
        _tfToolbar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
        _tfToolbar.SDdelegate = self;
        
    }
    return _tfToolbar;
}

- (UILabel*)titltLb
{
    if (!_titltLb) {
        _titltLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 14)];
        _titltLb.backgroundColor = [UIColor clearColor];
        NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:@"主题（必填）"];
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,2)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,2)];
        [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(2,4)];
        [tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
        _titltLb.attributedText = tittle_str;
    }
    return _titltLb;
}

- (UIScrollView *)mainScrollView
{
    if(!_mainScrollView){
        _mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    }
    return _mainScrollView;
}

- (CreatMeetTextField *)titleTF
{
    if (!_titleTF) {
        _titleTF = [[CreatMeetTextField alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(self.titltLb.frame)+20, ScreenWidth-25, 20)];
        _titleTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _titleTF.placeholder = @"输入活动主题";
        _titleTF.returnKeyType = UIReturnKeyDone;
        _titleTF.delegate = self;
        _titleTF.font = YHUI(16);
        _titleTF.tag = 101;
        [_titleTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
        _titleTF.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return _titleTF;
}

- (UIView *)titleView
{
    if (!_titleView) {
        _titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 70)];
        BackGroundColor(_titleView, whiteColor);
    }
    return _titleView;
}

- (UIView *)contentView
{
    if (!_contentView) {
        _contentView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_titleView.frame)+10, ScreenWidth, 128)];
        _contentView.backgroundColor = [UIColor whiteColor];
    }
    return _contentView;
}

- (SDToolBarView*)toolBar
{
    if (!_toolBar) {
        _toolBar = [[SDToolBarView alloc]initWithFrame:CGRectMake(0, _contentView.size.height-35, ScreenWidth, 35)];
        _toolBar.delegate = self;
        _toolBar.hideBtn.hidden = YES;
    }
    return _toolBar;
}

- (UIView *)detailView
{
    if (!_detailView) {
        _detailView = [[UIView alloc]init];
        _detailView.backgroundColor = [UIColor clearColor];
    }
    return _detailView;
}

- (UILabel *)contentTitleLB
{
    if (!_contentTitleLB) {
        NSMutableAttributedString *contenttittle_str = [[NSMutableAttributedString alloc] initWithString:@"详情（必填）"];
        [contenttittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,2)];
        [contenttittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,2)];
        [contenttittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(2,4)];
        [contenttittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
        
        _contentTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 14)];
        _contentTitleLB.backgroundColor = [UIColor clearColor];
        _contentTitleLB.font = YHUI(16);
        _contentTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
        _contentTitleLB.attributedText = contenttittle_str;
    }
    return _contentTitleLB;
}

- (UILabel *)contentSepLb
{
    if (!_contentSepLb) {
        _contentSepLb = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(self.contentTitleLB.frame)+5, 100, 30)];
        _contentSepLb.text = @"输入活动详情";
        _contentSepLb.font = YHUI(16);
        _contentSepLb.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
        _contentSepLb.backgroundColor = [UIColor clearColor];
    }
    return _contentSepLb;
}

- (FastTextView *)contentTextView
{
    if (!_contentTextView) {
        _contentTextView = [[FastTextView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.contentTitleLB.frame), self.view.bounds.size.width, 70)];
        _contentTextView.scrollEnabled = NO;
        _contentTextView.attributeConfig = [TextConfig editorAttributeConfig];
        _contentTextView.delegate = (id<FastTextViewDelegate>)self;
        _contentTextView.font = [UIFont systemFontOfSize:16];
        _contentTextView.pragraghSpaceHeight = 0;
        _contentTextView.backgroundColor = [UIColor clearColor];
        //view.userInteractionEnabled = YES;
    }
    return _contentTextView;
}

- (UIView *)descView
{
    if (!_descView) {
        _descView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 163)];
        BackGroundColor(_descView, whiteColor);
    }
    return _descView;
}

- (UILabel *)line5
{
    if (!_line5) {
        _line5 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_eTimeBtn.frame)+8, ScreenWidth-12, 0.5)];
        BackGround16Color(_line5, @"#c8c7cc");
    }
    return _line5;
}

- (UILabel *)descTitleLB2
{
    if (!_descTitleLB2) {
        _descTitleLB2 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(self.line5.frame) + 8, ScreenWidth-25, 16)];
        _descTitleLB2.backgroundColor = [UIColor clearColor];
        _descTitleLB2.font = YHUI(14);
        NSMutableAttributedString *des_str = [[NSMutableAttributedString alloc] initWithString:@"活动地点（必填）"];
        [des_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
        [des_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0, 4)];
        [des_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
        [des_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(4, 4)];
        _descTitleLB2.attributedText = des_str;
    }
    return _descTitleLB2;
}

- (UILabel *)descTitleLB
{
    if (!_descTitleLB) {
        _descTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 14)];
        _descTitleLB.backgroundColor = [UIColor clearColor];
        _descTitleLB.font = YHUI(16);
        _descTitleLB.text = @"活动时间";
        _descTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    }
    return _descTitleLB;
}

- (UITextField *)addressTF
{
    if (!_addressTF) {
        _addressTF = [[CreatMeetTextField alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(self.descTitleLB2.frame)+20, ScreenWidth-25, 20)];
        _addressTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _addressTF.font = YHUI(16);
        _addressTF.placeholder = @"请输入活动地址";
        _addressTF.delegate = self;
        _addressTF.tag = 102;
        _addressTF.returnKeyType = UIReturnKeyDone;
        if ([[_postDic objectForKey:@"location"] length] != 0) {
            _addressTF.text = [_postDic objectForKey:@"location"];
        }
        [_addressTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
        _addressTF.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return _addressTF;
}

- (UIImageView *)timeImageView1
{
    if (!_timeImageView1) {
        _timeImageView1 = [[UIImageView alloc]initWithFrame:CGRectMake(19, CGRectGetMaxY(self.descTitleLB.frame)+19, 10, 47)];
        BackGroundColor(_timeImageView1, clearColor);
        _timeImageView1.image = [UIImage imageNamed:@"dot_03"];
    }
    return _timeImageView1;
}

- (UILabel *)sTimeBtn
{
    if (!_sTimeBtn) {
        _sTimeBtn = [[UILabel alloc] init];
        _sTimeBtn.frame = CGRectMake(CGRectGetMaxX(self.timeImageView1.frame)+4, CGRectGetMaxY(self.descTitleLB.frame)+14, 200, 18);
        _sTimeBtn.userInteractionEnabled = YES;
        UITapGestureRecognizer* singleRecognizer;
        singleRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(startTimeBtnClick:)];
        singleRecognizer.numberOfTapsRequired = 1; // 单击
        [_sTimeBtn addGestureRecognizer:singleRecognizer];
        NSMutableAttributedString *s_time_str = [[NSMutableAttributedString alloc] initWithString:@"开始时间（必填）"];
        [s_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
        [s_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
        [s_time_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(4, 4)];
        _sTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
        _sTimeBtn.attributedText = s_time_str;
        _sTimeBtn.tag = 70+1;
        _sTimeBtn.backgroundColor = [UIColor clearColor];
    }
    return _sTimeBtn;
}

- (UILabel *)eTimeBtn
{
    if (!_eTimeBtn) {
        _eTimeBtn = [[UILabel alloc]init];
        _eTimeBtn.frame = CGRectMake(CGRectGetMaxX(self.timeImageView1.frame)+4, CGRectGetMaxY(_sTimeBtn.frame)+20, 200, 18);
        NSMutableAttributedString *e_time_str = [[NSMutableAttributedString alloc] initWithString:@"结束时间（选填）"];
        [e_time_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(4, 4)];
        [e_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
        [e_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
        _eTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
        _eTimeBtn.attributedText = e_time_str;
        _eTimeBtn.userInteractionEnabled = YES;
        UITapGestureRecognizer* GestureRecognizer;
        GestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(endTimeBtnClick:)];
        GestureRecognizer.numberOfTapsRequired = 1; // 单击
        [_eTimeBtn addGestureRecognizer:GestureRecognizer];
        _eTimeBtn.tag = 70+2;
        _eTimeBtn.backgroundColor = [UIColor clearColor];
    }
    return _eTimeBtn;
}

- (UIButton *)scleanBtn
{
    if (_scleanBtn) {
        _scleanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _scleanBtn.frame = CGRectMake(ScreenWidth-35, CGRectGetMaxY(self.sTimeBtn.frame)-15, 15, 15);
        _scleanBtn.tag = 10020;
        _scleanBtn.hidden=YES;
        [_scleanBtn addTarget:self action:@selector(cleanTime:) forControlEvents:UIControlEventTouchUpInside];
        [_scleanBtn setImage:[UIImage imageNamed:@"text_clean_btn"] forState:UIControlStateNormal];
    }
    return _scleanBtn;
}

- (UIButton *)enCleanBtn
{
    if (!_enCleanBtn) {
        _enCleanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _enCleanBtn.frame = CGRectMake(ScreenWidth-35, CGRectGetMaxY(self.eTimeBtn.frame)-15, 15, 15);
        _enCleanBtn.tag = 10030;
        _enCleanBtn.hidden=YES;
        [_enCleanBtn addTarget:self action:@selector(cleanTime:) forControlEvents:UIControlEventTouchUpInside];
        [_enCleanBtn setImage:[UIImage imageNamed:@"text_clean_btn"] forState:UIControlStateNormal];
    }
    return _enCleanBtn;
}

- (UIDesView *)desView
{
    if (!_desView) {
        _desView = [[UIDesView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, 45)];
        _desView.delegate = self;
        _desView.otherInfoView.staySwitchBtn.tag = 103;
        _desView.otherInfoView.signUpSwitchBtn.tag = 104;
        _desView.otherInfoView.openSwitchBtn.tag = 105;
        _desView.otherInfoView.personalSwitchBtn.tag = 106;
        [_desView.otherInfoView.staySwitchBtn addTarget:self action:@selector(swithValueChange:) forControlEvents:UIControlEventValueChanged];
        [_desView.otherInfoView.openSwitchBtn addTarget:self action:@selector(swithValueChange:) forControlEvents:UIControlEventValueChanged];
        [_desView.otherInfoView.signUpSwitchBtn addTarget:self action:@selector(swithValueChange:) forControlEvents:UIControlEventValueChanged];
        [_desView.otherInfoView.personalSwitchBtn addTarget:self action:@selector(swithValueChange:) forControlEvents:UIControlEventValueChanged];
    }
    return _desView;
}

- (EndView *)endView
{
    if (!_endView) {
        //上传活动海报
        _endView = [[EndView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_replyEmailView.frame)+10, ScreenWidth, 200)];
        _endView.frame =CGRectMake(0, CGRectGetMaxY(_replyEmailView.frame)+10, ScreenWidth, _endView.viewHeight);
        _endView.delegate = self;
        _endView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
        _endView.desView.delegate = self;
    }
    return _endView;
}

- (ReplyEmailView *)replyEmailView
{
    if (!_replyEmailView) {
        _replyEmailView = [[ReplyEmailView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, 80)];
        _replyEmailView.delegate = self;
    }
    return _replyEmailView;
}

- (void)creatUI
{
    [self creatRightNav];
    
    NSString *jsonStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
    [_postDic setValuesForKeysWithDictionary:[jsonStr JSONValue]];

    [self.view addSubview:self.mainScrollView];
    [self.mainScrollView addSubview:self.titleView];
    
    UILabel *topLine = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(topLine, @"#c8c7cc");
    [self.titleView addSubview:topLine];
    
    [self.titleView addSubview:self.titltLb];
    
    if ([[_postDic objectForKey:@"title"] length] != 0) {
        self.titleTF.text = [_postDic objectForKey:@"title"];
    }
    [self.titleView addSubview:self.titleTF];

    line = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.titleView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line, @"#c8c7cc");
    [self.titleView addSubview:line];
    
    [self.mainScrollView addSubview:self.contentView];
    [self.contentView addSubview:self.contentTitleLB];
    
    line1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line1, @"#c8c7cc");
    [self.contentView addSubview:line1];
    
    line2 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(_contentView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line2, @"#c8c7cc");
    [self.contentView  addSubview:line2];

    [self.contentView addSubview:self.contentSepLb];
    
    if ([[_postDic objectForKey:@"summary"] length] != 0) {
        [self addSumarryWithContent:[self replaceBr:[_postDic objectForKey:@"summary"] ]];
    }
    
    [self.contentView addSubview:self.toolBar];
    [self.contentView addSubview:self.contentTextView];
    [self.mainScrollView addSubview:self.detailView];
    [self.detailView addSubview:self.descView];
    
    [self.descView addSubview:self.descTitleLB];
    [self.descView addSubview:self.timeImageView1];
    [self.descView addSubview:self.sTimeBtn];
    [self.descView addSubview:self.scleanBtn];
    [self.descView addSubview:self.eTimeBtn];
    
    if ([[_postDic objectForKey:@"begin_time"] length] != 0) {
        self.sTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[_postDic objectForKey:@"begin_time"]];
        self.sTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        self.scleanBtn.hidden = NO;
    }
    if ([[_postDic objectForKey:@"end_time"] length] != 0) {
        self.eTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[_postDic objectForKey:@"end_time"]];
        self.eTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        self.enCleanBtn.hidden = NO;
    }
    
    [self.descView addSubview:self.enCleanBtn];
    [self.descView addSubview:self.line5];
    [self.descView addSubview:self.descTitleLB2];
    [self.descView addSubview:self.addressTF];
    
    //_addressTF.inputAccessoryView = self.tfToolbar;
    self.descView.frame = CGRectMake(self.descView.origin.x,self.descView.origin.x, self.descView.size.width, CGRectGetMaxY(self.addressTF.frame)+8);
    
    UILabel *line3 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line3, @"#c8c7cc");
    [self.descView addSubview:line3];
    
    UILabel *line4 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.descView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line4, @"#c8c7cc");
    [self.descView addSubview:line4];
    
    self.detailView.frame = CGRectMake(0, CGRectGetMaxY(self.contentView.frame)+10, ScreenWidth, CGRectGetMaxY(self.descView.frame)+11);
    
    view = [[SubEndView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, 45)];
    view.delegate = self;
    view.phoneTextFiled.tag = 100;
    view.phoneTextFiled.delegate = self;
    if ([[_postDic objectForKey:@"phone"] length] != 0) {
        view.phoneTextFiled.text = [_postDic objectForKey:@"phone"];
    }
    if ([[_postDic objectForKey:@"phone_sw"] isEqualToString:@"0"]) {
        view.swithBtn.on = NO;
    }
    if ([[_postDic objectForKey:@"phone_sw"] isEqualToString:@"1"]) {
        view.swithBtn.on = YES;
    }
    [view swithBtnClicke:(view.swithBtn)];
    [view.phoneTextFiled addTarget:self action:@selector(textFieldValueChange:) forControlEvents:UIControlEventEditingChanged];
    view.backgroundColor = [UIColor whiteColor];
    [_mainScrollView addSubview:view];
    
    SDToolBarOfHideView *toolbar = [[SDToolBarOfHideView alloc]init];
    toolbar.SDdelegate = self;
    [view.phoneTextFiled.inputAccessoryView addSubview:toolbar];
    
    if ([[_postDic objectForKey:@"reply_email"] length] != 0) {
        self.replyEmailView.emailTextFiled.text = [_postDic objectForKey:@"reply_email"];
    }
    [_mainScrollView addSubview:self.replyEmailView];

    [_mainScrollView addSubview:self.endView];
    
    if ([[_postDic objectForKey:@"company_list"] isKindOfClass:[NSArray class]] && [[_postDic objectForKey:@"company_list"] count] != 0) {
        self.desView.otherInfoView.companyNameArr = [_postDic objectForKey:@"company_list"];
    }
    
    if ([[_postDic objectForKey:@"organizer_list"] isKindOfClass:[NSArray class]] && [[_postDic objectForKey:@"organizer_list"] count] != 0) {
        self.desView.otherInfoView.organizerNameArr = [_postDic objectForKey:@"organizer_list"];
    }
    
    if ([[_postDic objectForKey:@"stay_sw"] isEqualToString:@"0"]) {
        self.endView.desView.otherInfoView.staySwitchBtn.on = NO;
    }
    if ([[_postDic objectForKey:@"stay_sw"] isEqualToString:@"1"]) {
        self.desView.otherInfoView.staySwitchBtn.on = YES;
    }
    
    if ([[_postDic objectForKey:@"shuttle_sw"] isEqualToString:@"0"]) {
        self.desView.otherInfoView.signUpSwitchBtn.on = NO;
    }
    if ([[_postDic objectForKey:@"shuttle_sw"] isEqualToString:@"1"]) {
        self.desView.otherInfoView.signUpSwitchBtn.on = YES;
    }
    
    if ([[_postDic objectForKey:@"openstatus"] isEqualToString:@"1"]) {
        self.desView.otherInfoView.openSwitchBtn.on = YES;
    }
    if ([[_postDic objectForKey:@"openstatus"] isEqualToString:@"0"]) {
        self.desView.otherInfoView.openSwitchBtn.on = NO;
    }
    
    if ([[_postDic objectForKey:@"personal_data_sw"] isEqualToString:@"-1"]) {
        self.desView.otherInfoView.personalSwitchBtn.on = NO;
        self.desView.otherInfoView.personalChangeFrame = NO;
    }
    else {
        self.desView.otherInfoView.personalSwitchBtn.on = YES;
        self.desView.otherInfoView.personalChangeFrame = YES;
        if ([[_postDic objectForKey:@"personal_data_sw"] isEqualToString:@"1"]) {
            self.desView.otherInfoView.select = 2;
        }
        else if ([[_postDic objectForKey:@"personal_data_sw"] isEqualToString:@"2"]) {
            self.desView.otherInfoView.select = 1;
        }
        else {
            self.desView.otherInfoView.select = [[_postDic objectForKey:@"personal_data_sw"] integerValue];
        }
    }
    
    [_mainScrollView addSubview:self.desView];
    
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    NSString *posterCount = [[DBManager sharedInstance]getPublicDBData:[NSString stringWithFormat:@"type_%d_posterImageCount",_type]];
    for (int i = 0; i < [posterCount integerValue]; i++) {
        [_posterMuArr addObject: [self getImageFormDocument:[NSString stringWithFormat:@"poster_%d",i] withMeetingType:[NSString stringWithFormat:@"%d",_type]]];
    }
    [self.endView reloadImages:_posterMuArr];
}

- (void)textFieldValueChange:(UITextField *)textFiled
{
    if (textFiled.tag == 100) {
        [_postDic setObject:textFiled.text forKey:@"phone"];
    }
}

- (void)swithValueChange:(SevenSwitch *)btn
{
    if (btn.tag == 103) {
        if (btn.on == YES) {
            [_postDic setObject:@"1" forKey:@"stay_sw"];
        }
        else {
            [_postDic setObject:@"0" forKey:@"stay_sw"];
        }
    }
    if (btn.tag == 104) {
        if (btn.on == YES) {
            [_postDic setObject:@"1" forKey:@"shuttle_sw"];
        }
        else {
            [_postDic setObject:@"0" forKey:@"shuttle_sw"];
        }
    }
    if (btn.tag == 105) {
        if (btn.on == YES) {
            [_postDic setObject:@"1" forKey:@"openstatus"];
        }
        else {
            [_postDic setObject:@"0" forKey:@"openstatus"];
        }
    }
    if (btn.tag == 106) {
        if (btn.on == YES) {
            self.desView.otherInfoView.changeFrame = YES;
            //NSString *personal_data_sw = [[NSUserDefaults standardUserDefaults] objectForKey:@"personal_data_sw"];
            //[_postDic setObject:personal_data_sw forKey:@"personal_data_sw"];
            [self.desView.otherInfoView.personalTableView reloadData];
        }
        else {
            self.desView.otherInfoView.changeFrame = NO;
            [_postDic setObject:@"-1" forKey:@"personal_data_sw"];
        }
    }
}

- (void)cancelBtnClicked
{
    if (endBtnSelect == YES) {
        endBtnSelect = NO;
    }
    if (startBtnSelect == YES) {
        startBtnSelect = NO;
    }
}

- (void)replyEmailChange:(NSString *)replyEmail
{
    [_postDic setObject:replyEmail forKey:@"reply_email"];
}

#pragma mark - SDTimeActionSheet
- (void)returnData:(NSDate*)date Time:(NSTimeInterval)time
{
    if (endBtnSelect == YES) {
        if ([[_postDic objectForKey:@"begin_time"] integerValue]>=time) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"结束时间必须大于开始时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            av.tag = 2501;
            [av show];
            return;
        }
        _eTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
        _eTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _eTimeBtn.font = YHUI(16);
        [_postDic setObject:[NSString stringWithFormat:@"%0.f",time] forKey:@"end_time"];
        endBtnSelect = NO;
        self.enCleanBtn.hidden = NO;
    }
    if (startBtnSelect == YES) {
        if ([self currentTime] > time) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"开始时间必须大于当前时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            av.tag = 2501;
            [av show];
            return;
        }
        _sTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
        [_postDic setObject:[NSString stringWithFormat:@"%0.f",time] forKey:@"begin_time"];
        _sTimeBtn.font = YHUI(16);
        _sTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        startBtnSelect = NO;
        self.scleanBtn.hidden = NO;
    }
}

- (void)cleanTime:(UIButton*)btn
{
    if (btn.tag == 10020) {
        if ([[_postDic objectForKey:@"begin_time"] length]!=0) {
            NSMutableAttributedString *s_time_str = [[NSMutableAttributedString alloc] initWithString:@"开始时间（必填）"];
            [s_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
            [s_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
            _sTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
            _sTimeBtn.attributedText = s_time_str;
            [_postDic setObject:@"" forKey:@"begin_time"];
            btn.hidden = YES;
        }
    }
    if (btn.tag == 10030) {
        if ([[_postDic objectForKey:@"end_time"] length]!=0) {
            NSMutableAttributedString *e_time_str = [[NSMutableAttributedString alloc] initWithString:@"结束时间（选填）"];
            [e_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
            [e_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
            _eTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
            _eTimeBtn.attributedText = e_time_str;
            [_postDic setObject:@"" forKey:@"end_time"];
            btn.hidden = YES;
        }
    }
}

- (void)endTimeBtnClick:(UITapGestureRecognizer *)gesture
{
    [self.view endEditing:YES];
    endBtnSelect = YES;
    startBtnSelect = NO;
    if (NO == self.dateActionSheet.isShow) {
        self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
        self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    [self.dateActionSheet showInView:self.view];
}

- (void)startTimeBtnClick:(UITapGestureRecognizer *)gesture
{
    [self.view endEditing:YES];
    startBtnSelect = YES;
    endBtnSelect = NO;
    if (NO == self.dateActionSheet.isShow) {
        self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
        self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    [self.dateActionSheet showInView:self.view];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width,ScreenHeight-self.F_NAV_HEIGHT-keyBoardSize.height );
    keyBoardShow = NO;
    eidtTextFiled = YES;
    //_toolBar.imageBtn.hidden = YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    //_toolBar.imageBtn.hidden = NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

//- (NSDictionary *)defaultAttributes
//{
//    NSString *fontName = @"Helvetica";
//    CGFloat fontSize= 17.0f;
//    UIColor *color = [UIColor blackColor];
//    //UIColor *strokeColor = [UIColor whiteColor];
//    //CGFloat strokeWidth = 0.0;
//    CGFloat paragraphSpacing = 0.0;
//    CGFloat lineSpacing = 0.0;
//    //CGFloat minimumLineHeight=24.0f;
//    CTFontRef fontRef = CTFontCreateWithName((__bridge CFStringRef)fontName,
//                                             fontSize, NULL);
//    CTParagraphStyleSetting settings[] = {
//        { kCTParagraphStyleSpecifierParagraphSpacing, sizeof(CGFloat), &paragraphSpacing },
//        { kCTParagraphStyleSpecifierLineSpacing, sizeof(CGFloat), &lineSpacing },
//        // { kCTParagraphStyleSpecifierMinimumLineHeight, sizeof(CGFloat), &minimumLineHeight },
//    };
//    CTParagraphStyleRef paragraphStyle = CTParagraphStyleCreate(settings, ARRSIZE(settings));
//    //apply the current text style //2
//    /* NSDictionary* attrs = [NSDictionary dictionaryWithObjectsAndKeys:
//     (id)color.CGColor, kCTForegroundColorAttributeName,
//     (__bridge id)fontRef, kCTFontAttributeName,
//     (id)strokeColor.CGColor, (NSString *) kCTStrokeColorAttributeName,
//     (id)[NSNumber numberWithFloat: strokeWidth], (NSString *)kCTStrokeWidthAttributeName,
//     (__bridge id) paragraphStyle, (NSString *) kCTParagraphStyleAttributeName,
//     nil];
//     */
//    NSDictionary* attrs = [NSDictionary dictionaryWithObjectsAndKeys:
//                           (id)color.CGColor, kCTForegroundColorAttributeName,
//                           (__bridge id)fontRef, kCTFontAttributeName,
//                           //(id)strokeColor.CGColor, (NSString *) kCTStrokeColorAttributeName,
//                           //                           (id)[NSNumber numberWithFloat: strokeWidth], (NSString *)kCTStrokeWidthAttributeName,
//                           //(__bridge id) paragraphStyle, (NSString *) kCTParagraphStyleAttributeName,
//                           nil];
//    CFRelease(fontRef);
//    return attrs;
//}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

#pragma mark -
#pragma mark UITextViewDelegate

#pragma mark -
#pragma mark fastTextViewDelegate

- (BOOL)fastTextViewShouldBeginEditing:(FastTextView *)textView
{
    keyBoardShow = YES;
    eidtTextFiled = NO;
    self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
    self.toolBar.hideBtn.hidden = NO;//显示完成按钮
    self.toolBar.frame = CGRectMake(0, ScreenHeight-keyBoardSize.height-35, ScreenWidth, TOP_VIEW_HEIGHT);
    [self.view addSubview:self.toolBar];
    [self.view bringSubviewToFront:self.toolBar];//改变toolbar的位置
    return YES;
}

- (BOOL)fastTextViewShouldEndEditing:(FastTextView *)textView
{
    self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
    self.toolBar.hideBtn.hidden = NO;//显示完成按钮
    self.toolBar.frame = CGRectMake(0, _contentView.size.height-TOP_VIEW_HEIGHT, ScreenWidth, TOP_VIEW_HEIGHT);
    [_contentView addSubview:self.toolBar];
    [_contentView bringSubviewToFront:self.toolBar];//改变toolbar的位置
    return YES;
}

- (void)fastTextViewDidBeginEditing:(FastTextView *)textView
{
    
}

- (void)fastTextViewDidChange:(FastTextView *)textView
{
    //UIView * myView = self.contentTextView.subviews.firstObject;
    //_contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, ScreenWidth, myView.size.height);
    
    if (self.contentTextView.text.length == 0) {
        self.contentSepLb.hidden = NO;
    }
    else {
        self.contentSepLb.hidden = YES;
    }
    
    if (self.contentTextView.contentSize.height < 70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    line2.frame = CGRectMake(0, CGRectGetHeight(self.contentView.frame) - 0.5, ScreenWidth, 0.5);
    self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(self.contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    view.frame = CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, view.size.height);
    self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
}

- (void)fastTextViewDidEndEditing:(FastTextView *)textView
{
    [self htmlStringWithAttachmentPath:(NSString *)textView.attributedString];
}

- (NSString *)htmlStringWithAttachmentPath:(NSString *)attachpath
{
    NSString *storeString = @"";
    if (self.contentTextView.text.length == 0) {
        self.contentSepLb.hidden = NO;
    }
    else {
        self.contentSepLb.hidden = YES;
    }
    NSAttributedString *newAttrStr = _contentTextView.attributedString;
    NSMutableDictionary *textParagraphMap = [[NSMutableDictionary alloc]init];
    
    TextParagraph *textParagraph;
    NSRange longRange;
    unsigned int longPos = 0;
    while ((longPos < [newAttrStr length]) &&
           (textParagraph = [newAttrStr attribute:FastTextParagraphAttributeName atIndex:longPos longestEffectiveRange:&longRange inRange:NSMakeRange(0, [newAttrStr length])])) {
        
        NSLog(@"textParagraph %@",textParagraph);
        [textParagraphMap setValue:NSStringFromRange(longRange) forKey:textParagraph.key];
        
        longPos = longRange.location + longRange.length;
    }
    
    NSDictionary *effectiveAttributes;
    NSRange range;
    unsigned int pos = 0;
    [picMuArr removeAllObjects];
    while ((pos < [newAttrStr length]) &&
           (effectiveAttributes = [newAttrStr attributesAtIndex:pos effectiveRange:&range])) {
        
        NSString *plainString = [[newAttrStr attributedSubstringFromRange:range] string];
        
        //一下三个替换步骤不可错误！
        //替换img的魔术占位符
        unichar attachmentCharacter = FastTextAttachmentCharacter;
        plainString = [plainString stringByReplacingOccurrencesOfString:[NSString stringWithCharacters:&attachmentCharacter length:1] withString:@" "];
        //编码html标签
        
        //替换\n为<br/>标签
        plainString = [plainString stringByReplacingOccurrencesOfString:@"\n" withString:@"<br>"];
        
        NSRange paragraphRange = NSMakeRange(NSNotFound, NSNotFound) ;
        TextParagraph *textParagraph = [effectiveAttributes objectForKey:FastTextParagraphAttributeName];
        
        if (textParagraph != nil) {
            NSString *rangstr = [textParagraphMap objectForKey: [MD5Util md5:[textParagraph description]]];
            paragraphRange = NSRangeFromString(rangstr);
        }
        if (paragraphRange.location != NSNotFound && paragraphRange.location == range.location) {
            storeString = [storeString stringByAppendingString:@"<p>"];
        }
        
        //附件处理
        id<FastTextAttachmentCell> attachmentcell = [effectiveAttributes objectForKey:FastTextAttachmentAttributeName];
        NSInteger ifile = 1;
        if (attachmentcell && [attachmentcell isKindOfClass:[SlideAttachmentCell class]])
        {
            SlideAttachmentCell *slideCell = (SlideAttachmentCell *)attachmentcell;
            FileWrapperObject  *fileWrapper = slideCell.fileWrapperObject;
            if (fileWrapper != nil) {
                
                NSString *filepath = fileWrapper.filePath;
                
                NSString *name = fileWrapper.fileName;
                name = [name substringWithRange:NSMakeRange(name.length-3,3)];
                
                UIImage *attimg = [UIImage imageWithContentsOfFile:filepath];
                
                if ([name isEqualToString:@"jpg"]) {
                    [picMuArr addObject:attimg];
                }
                ifile++;
                if ([attachmentcell isKindOfClass:[SlideAttachmentCell class]]) {
                    //SlideAttachmentCell *cell=(SlideAttachmentCell*) attachmentcell;
                    NSInteger thumbImageWidth = DEFAULT_thumbImageWidth;
                    NSInteger thumbImageHeight = DEFAULT_thumbImageHeight;
                    if (attimg != nil) {
                        CGSize size = [attimg sizeByScalingProportionallyToSize:CGSizeMake(thumbImageWidth, thumbImageHeight)];
                        thumbImageWidth = size.width;
                        thumbImageHeight = size.height;
                    }
                    storeString = [storeString stringByAppendingFormat:@"<img src=\"%@\" " ,fileWrapper.fileName];
                    storeString = [storeString stringByAppendingString:@"/>"];
                }
            }
        }
        else {
            //文本
            storeString=[storeString stringByAppendingFormat:@"%@", plainString];
        }
        if (paragraphRange.length != NSNotFound && (paragraphRange.location+paragraphRange.length) == (range.location+range.length)) {
            storeString = [storeString stringByAppendingString:@"</p>"];
        }
        pos = range.location + range.length;
    }
    
    if (storeString.length != 0) {
        if (self.contentTextView.contentSize.height<70) {
            self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
            self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
        }
        else {
            self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
            self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
        }
        line2.frame = CGRectMake(0, CGRectGetHeight(self.contentView.frame) - 0.5, ScreenWidth, 0.5);
        self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(self.contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, 70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
        line2.frame = CGRectMake(0, CGRectGetHeight(self.contentView.frame) - 0.5, ScreenWidth, 0.5);
        self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(self.contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    }
    view.frame = CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, view.size.height);
    self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    
    NSLog(@"%@",storeString);
    
    contentStr = storeString;
    
    return storeString;
}

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void)addSumarryWithContent:(NSString *)content
{
    content = [content stringByReplacingOccurrencesOfString:@"<br>" withString:@""];
    NSString *s = @"<(\\w+)\\s*src=\\\"(\\w+.*?)\\\"\\s*/>";
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    __block NSString *imageUrl;
    self.contentTextView.text = content;
    for (int j = 0; j < arrayOfAllMatches.count; j++) {
        
    }
    
    NSInteger DLen = 0;
    NSMutableAttributedString *mutableAttributedString;
    for (NSTextCheckingResult *match in arrayOfAllMatches) {
        
        NSString* substringForMatch = [_contentTextView.attributedString.string substringWithRange:(NSRange){ match.range.location-DLen, match.range.length }];
        
        imageUrl = [self getImageUrl:substringForMatch];
        
        UITextRange *selectedTextRange = [FastIndexedRange rangeWithNSRange:(NSRange){ match.range.location-DLen, match.range.length }];
        
        if (!selectedTextRange) {
            UITextPosition *endOfDocument = [self.contentTextView endOfDocument];
            selectedTextRange = [self.contentTextView textRangeFromPosition:endOfDocument toPosition:endOfDocument];
        }
        UITextPosition *startPosition = [selectedTextRange start] ; // hold onto this since the edit will drop
        
        unichar attachmentCharacter = FastTextAttachmentCharacter;
        [self.contentTextView replaceRange:selectedTextRange withText:[NSString stringWithFormat:@"%@",[NSString stringWithCharacters:&attachmentCharacter length:1]]];
        
        startPosition = [self.contentTextView positionFromPosition:startPosition inDirection:UITextLayoutDirectionRight offset:0];
        UITextPosition *endPosition = [self.contentTextView positionFromPosition:startPosition offset:0];
        selectedTextRange = [self.contentTextView textRangeFromPosition:startPosition toPosition:endPosition];
        if (imageUrl.length != 0) {
            NSString *imageIndexs = [imageUrl substringWithRange:NSMakeRange(1, 1)];
            UIImage *image = [picCacheArr objectAtIndex:([imageIndexs integerValue]-1)];
            [picMuArr addObject:image];
            if(image) {
                NSString *newfilename=[NSAttributedString scanAttachmentsForNewFileName:_contentTextView.attributedString];
                NSArray *_paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                NSString * _documentDirectory = [[NSString alloc] initWithString:[_paths objectAtIndex:0]];
                
                NSString *pngPath=[_documentDirectory stringByAppendingPathComponent:newfilename];
                UIImage *thumbimg=[image imageByScalingProportionallyToSize:CGSizeMake(1024,6000)];
                [UIImageJPEGRepresentation(thumbimg,0.7)writeToFile:pngPath atomically:YES];
                
                __block NSMutableAttributedString *mutableAttributedString=[self.contentTextView.attributedString mutableCopy];
                
                NSUInteger st = ((FastIndexedPosition *)(selectedTextRange.start)).index;
                NSUInteger en = ((FastIndexedPosition *)(selectedTextRange.end)).index;
                //NSDictionary *dic = @{@"st":[NSString stringWithFormat:@"%lu",(unsigned long)st],@"en":[NSString stringWithFormat:@"%lu",(unsigned long)en],};
                //[strArr addObject:dic];
                if (en < st) {
                    return;
                }
                NSUInteger contentLength = [[self.contentTextView.attributedString string] length];
                if (en > contentLength) {
                    en = contentLength; // but let's not crash
                }
                if (st > en)
                    st = en;
                NSRange cr = [[self.contentTextView.attributedString string] rangeOfComposedCharacterSequencesForRange:(NSRange){ st, en - st }];
                if (cr.location + cr.length > contentLength) {
                    cr.length = ( contentLength - cr.location ); // but let's not crash
                }
                
                FileWrapperObject *fileWp = [[FileWrapperObject alloc] init];
                [fileWp setFileName:newfilename];
                [fileWp setFilePath:pngPath];
                
                SlideAttachmentCell *cell = [[SlideAttachmentCell alloc] initWithFileWrapperObject:fileWp] ;
                
                //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
                //cell.isNeedThumb = YES;
                CGFloat i;
                CGFloat imgW = image.size.width;
                CGFloat imgH = image.size.height;
                if (imgW < imgH) {
                    i = 320*image.size.width/image.size.height;
                }
                else {
                    i = image.size.height/image.size.width;
                }
                cell.thumbImageWidth = ScreenWidth ;
                cell.thumbImageHeight = 200;
                //cell.txtdesc = @"幻灯片测试";
                UIColor *textColor = [UIColor colorWithHexString:@"1b9ecc"];
                UIFont *font = [UIFont systemFontOfSize:16];
                CTFontRef aFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
                if (!aFont) return;
                CTFontRef newFont = CTFontCreateCopyWithSymbolicTraits(aFont, 0.0, NULL, kCTFontItalicTrait, kCTFontBoldTrait);    //将默认黑体字设置为其它字体
                [mutableAttributedString removeAttribute:(NSString*)kCTFontAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString addAttribute:(NSString*)kCTFontAttributeName value:(__bridge id)newFont range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString removeAttribute:(NSString*)kCTForegroundColorAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)textColor.CGColor range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString addAttribute:FastTextAttachmentAttributeName value:cell range:cr];
                if (mutableAttributedString) {
                    self.contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
                }
            }
            else {
                
            }
        }
        DLen += (match.range.length-1);
    }
    if (arrayOfAllMatches.count == 0) {
        mutableAttributedString = [self.contentTextView.attributedString mutableCopy];
        UIColor *textColor = [UIColor colorWithHexString:@"1b9ecc"];
        UIFont *font = [UIFont systemFontOfSize:16];
        CTFontRef aFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
        if (!aFont) return;
        CTFontRef newFont = CTFontCreateCopyWithSymbolicTraits(aFont, 0.0, NULL, kCTFontItalicTrait, kCTFontBoldTrait);    //将默认黑体字设置为其它字体
        [mutableAttributedString removeAttribute:(NSString*)kCTFontAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
        [mutableAttributedString addAttribute:(NSString*)kCTFontAttributeName value:(__bridge id)newFont range:NSMakeRange(0, mutableAttributedString.string.length)];
        [mutableAttributedString removeAttribute:(NSString*)kCTForegroundColorAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
        [mutableAttributedString addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)textColor.CGColor range:NSMakeRange(0, mutableAttributedString.string.length)];
        if (mutableAttributedString) {
            self.contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
        }
    }
    
    if (self.contentTextView.contentSize.height < 70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(self.contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    line2.frame = CGRectMake(0, CGRectGetHeight(self.contentView.frame) - 0.5, ScreenWidth, 0.5);
    view.frame = CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, view.size.height);
    self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, self.contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)_addAttachmentFromImage:(UIImage*)image
{
    NSString *key = [NSString stringWithFormat:@"a%ld.jpg",(long)imageId +1];
    imageId++;
    [self saveImageToDocument:image imageName:key withMeetingType:@"1"];
    NSData *data = UIImageJPEGRepresentation(image, 1);
    //NSFileWrapper *wrapper = [[NSFileWrapper alloc] initRegularFileWithContents:data];
    //wrapper.filename = [[rep url] lastPathComponent];
    UIImage *img=[UIImage imageWithData:data];
    [picMuArr addObject:img];
    //[self postPicViewList:img];
    NSString *newfilename=[NSAttributedString scanAttachmentsForNewFileName:_contentTextView.attributedString];
    
    NSArray *_paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * _documentDirectory = [[NSString alloc] initWithString:[_paths objectAtIndex:0]];
    
    UIImage *thumbimg = [img imageByScalingProportionallyToSize:CGSizeMake(1024,6000)];
    
    NSString *pngPath = [_documentDirectory stringByAppendingPathComponent:newfilename];
    
    //[[AppDelegate documentDirectory] stringByAppendingPathComponent:@"tmp.jpg"];
    
    [UIImageJPEGRepresentation(thumbimg,0.7)writeToFile:pngPath atomically:YES];
    
    UITextRange *selectedTextRange = [_contentTextView selectedTextRange];
    if (!selectedTextRange) {
        UITextPosition *endOfDocument = [_contentTextView endOfDocument];
        selectedTextRange = [_contentTextView textRangeFromPosition:endOfDocument toPosition:endOfDocument];
    }
    UITextPosition *startPosition = [selectedTextRange start] ; // hold onto this since the edit will drop
    
    unichar attachmentCharacter = FastTextAttachmentCharacter;
    [_contentTextView replaceRange:selectedTextRange withText:[NSString stringWithFormat:@"\n%@\n",[NSString stringWithCharacters:&attachmentCharacter length:1]]];
    
    startPosition = [_contentTextView positionFromPosition:startPosition inDirection:UITextLayoutDirectionRight offset:1];
    UITextPosition *endPosition = [_contentTextView positionFromPosition:startPosition offset:1];
    selectedTextRange = [_contentTextView textRangeFromPosition:startPosition toPosition:endPosition];
    
    NSMutableAttributedString *mutableAttributedString = [_contentTextView.attributedString mutableCopy];
    
    NSUInteger st = ((FastIndexedPosition *)(selectedTextRange.start)).index;
    NSUInteger en = ((FastIndexedPosition *)(selectedTextRange.end)).index;
    //NSDictionary *dic = @{@"st":[NSString stringWithFormat:@"%lu",(unsigned long)st],@"en":[NSString stringWithFormat:@"%lu",(unsigned long)en],};
    //[strArr addObject:dic];
    if (en < st) {
        return;
    }
    NSUInteger contentLength = [[_contentTextView.attributedString string] length];
    if (en > contentLength) {
        en = contentLength; // but let's not crash
    }
    if (st > en)
        st = en;
    NSRange cr = [[_contentTextView.attributedString string] rangeOfComposedCharacterSequencesForRange:(NSRange){ st, en - st }];
    if (cr.location + cr.length > contentLength) {
        cr.length = ( contentLength - cr.location ); // but let's not crash
    }
    
    FileWrapperObject *fileWp = [[FileWrapperObject alloc] init];
    [fileWp setFileName:newfilename];
    [fileWp setFilePath:pngPath];
    
    SlideAttachmentCell *cell = [[SlideAttachmentCell alloc] initWithFileWrapperObject:fileWp] ;
    
    //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
    //cell.isNeedThumb=YES;
    CGFloat i;
    CGFloat imgW = img.size.width;
    CGFloat imgH = img.size.height;
    if (imgW < imgH) {
        i = 320*img.size.width/img.size.height;
    }
    else {
        i = img.size.height/img.size.width;
    }
    if(i*2 > 0.5) {
        
    }
    
    cell.thumbImageWidth = 200*img.size.width/img.size.height;
    cell.thumbImageHeight = 200*imgH/imgW;
    //cell.txtdesc=@"幻灯片测试";
    
    [mutableAttributedString addAttribute: FastTextAttachmentAttributeName value:cell  range:cr];
    
    //[mutableAttributedString addAttribute:fastTextAttachmentAttributeName value:cell  range:selectedTextRange];
    
    if (mutableAttributedString) {
        _contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
    }
    
    //[_editor setValue:attachment forAttribute:OAAttachmentAttributeName inRange:selectedTextRange];
    
    //[self htmlStringWithAttachmentPath:mutableAttributedString];
    
    if (self.contentTextView.contentSize.height<70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
    view.frame = CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, view.size.height);
    self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, self.contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)_addAttachmentFromAsset:(ALAsset *)asset
{
    ALAssetRepresentation *rep = [asset defaultRepresentation];
    NSMutableData *data = [NSMutableData dataWithLength:[rep size]];
    NSError *error = nil;
    if ([rep getBytes:[data mutableBytes] fromOffset:0 length:[rep size] error:&error] == 0) {
        NSLog(@"error getting asset data %@", [error debugDescription]);
    }
    else {
        //NSFileWrapper *wrapper = [[NSFileWrapper alloc] initRegularFileWithContents:data];
        //wrapper.filename = [[rep url] lastPathComponent];
        UIImage *img=[UIImage imageWithData:data];
        NSString *key = [NSString stringWithFormat:@"a%d.png",(int)imageId +1];
        imageId++;
        [self saveImageToDocument:img imageName:key withMeetingType:@"1"];
        [picMuArr addObject:img];
        //[self postPicViewList:img];
        NSString *newfilename = [NSAttributedString scanAttachmentsForNewFileName:_contentTextView.attributedString];
        NSArray *_paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString * _documentDirectory = [[NSString alloc] initWithString:[_paths objectAtIndex:0]];
        
        UIImage *thumbimg = [img imageByScalingProportionallyToSize:CGSizeMake(1024,6000)];
        
        NSString *pngPath = [_documentDirectory stringByAppendingPathComponent:newfilename];
        
        //[[AppDelegate documentDirectory] stringByAppendingPathComponent:@"tmp.jpg"];
        
        [UIImageJPEGRepresentation(thumbimg,0.7)writeToFile:pngPath atomically:YES];
        
        UITextRange *selectedTextRange = [_contentTextView selectedTextRange];
        if (!selectedTextRange) {
            UITextPosition *endOfDocument = [_contentTextView endOfDocument];
            selectedTextRange = [_contentTextView textRangeFromPosition:endOfDocument toPosition:endOfDocument];
        }
        UITextPosition *startPosition = [selectedTextRange start] ; // hold onto this since the edit will drop
        
        unichar attachmentCharacter = FastTextAttachmentCharacter;
        [_contentTextView replaceRange:selectedTextRange withText:[NSString stringWithFormat:@"\n%@\n",[NSString stringWithCharacters:&attachmentCharacter length:1]]];
        
        startPosition=[_contentTextView positionFromPosition:startPosition inDirection:UITextLayoutDirectionRight offset:1];
        UITextPosition *endPosition = [_contentTextView positionFromPosition:startPosition offset:1];
        selectedTextRange = [_contentTextView textRangeFromPosition:startPosition toPosition:endPosition];
        
        NSMutableAttributedString *mutableAttributedString = [_contentTextView.attributedString mutableCopy];
        
        NSUInteger st = ((FastIndexedPosition *)(selectedTextRange.start)).index;
        NSUInteger en = ((FastIndexedPosition *)(selectedTextRange.end)).index;
        //NSDictionary *dic = @{@"st":[NSString stringWithFormat:@"%lu",(unsigned long)st],@"en":[NSString stringWithFormat:@"%lu",(unsigned long)en],};
        //[strArr addObject:dic];
        if (en < st) {
            return;
        }
        NSUInteger contentLength = [[_contentTextView.attributedString string] length];
        if (en > contentLength) {
            en = contentLength; // but let's not crash
        }
        if (st > en)
            st = en;
        NSRange cr = [[_contentTextView.attributedString string] rangeOfComposedCharacterSequencesForRange:(NSRange){ st, en - st }];
        if (cr.location + cr.length > contentLength) {
            cr.length = ( contentLength - cr.location ); // but let's not crash
        }
        
        if(isAddSlide) {
            
            FileWrapperObject *fileWp = [[FileWrapperObject alloc] init];
            [fileWp setFileName:newfilename];
            [fileWp setFilePath:pngPath];
            
            SlideAttachmentCell *cell = [[SlideAttachmentCell alloc] initWithFileWrapperObject:fileWp] ;
            
            //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
            //cell.isNeedThumb=YES;
            CGFloat i;
            CGFloat imgW = img.size.width;
            CGFloat imgH = img.size.height;
            if (imgW < imgH) {
                i = 320*img.size.width/img.size.height;
            }
            else {
                i = img.size.height/img.size.width;
            }
            if(i*2 > 0.5) {
                
            }
            cell.thumbImageWidth = 200*img.size.width/img.size.height;
            cell.thumbImageHeight = 200*imgH/imgW;
            //cell.txtdesc=@"幻灯片测试";
            [mutableAttributedString addAttribute: FastTextAttachmentAttributeName value:cell  range:cr];
        }
        else {
            
        }
        
        if (mutableAttributedString) {
            self.contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
        }
    }
    
    if (self.contentTextView.contentSize.height<70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    self.detailView.frame = CGRectMake(self.detailView.origin.x, CGRectGetMaxY(self.contentView.frame)+10, self.detailView.size.width, self.detailView.size.height);
    line2.frame = CGRectMake(0, CGRectGetHeight(self.contentView.frame) - 0.5, ScreenWidth, 0.5);
    view.frame = CGRectMake(0, CGRectGetMaxY(self.detailView.frame), ScreenWidth, view.size.height);
    self.replyEmailView.frame = CGRectMake(0, CGRectGetMaxY(view.frame)+10, ScreenWidth, self.replyEmailView.size.height);
    self.endView.frame = CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, self.endView.size.height);
    self.desView.frame = CGRectMake(0, CGRectGetMaxY(self.endView.frame), ScreenWidth, self.desView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(self.desView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, self.contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

//更改图片大小
- (CGSize)getImageSize:(CGSize)imageSize
{
    CGFloat num1 = (imageSize.width)/(imageSize.height);
    NSLog(@"%f",num1);
    CGFloat num = (imageSize.height)/(imageSize.width);
    NSLog(@"%f",num);
    CGFloat num2 = 1024/1024;
    CGRect cellImageFrame;
    if (imageSize.height > 1024) {
        if (num1 >= num2) {
            cellImageFrame = CGRectMake(0, (1024-1024*num)/2, 1024, 1024*num);
        }
        else {
            cellImageFrame = CGRectMake((1024-1024*num1)/2, 0, 1024*num1, 1024);
        }
    }
    else {
        if (num1 >= num2) {
            if (imageSize.width >= 1024) {
                cellImageFrame = CGRectMake(0, (1024-1024*num)/2, 1024, 1024*num);
            }
            else {
                cellImageFrame = CGRectMake((1024-imageSize.width)/2, (1024-imageSize.height)/2, imageSize.width ,imageSize.height);
            }
        }
        else {
            cellImageFrame = CGRectMake((1024-imageSize.width)/2, (1024-imageSize.height)/2, imageSize.width, imageSize.height);
        }
    }
    return CGSizeMake(cellImageFrame.size.width, cellImageFrame.size.height);
}

- (UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize
{
    // Create a graphics image context
    UIGraphicsBeginImageContext(newSize);
    
    // Tell the old image to draw in this new context, with the desired
    // new size
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    
    // Get the new image from the context
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // End the context
    UIGraphicsEndImageContext();
    
    // Return the new image.
    return newImage;
}

- (void)getSelectedImage:(UIImage *)image
{
    //image = [self imageWithImage:image scaledToSize: [self getImageSize:image.size]];
    if (isPoster == YES) {
        //添加海报
        [_posterMuArr addObject:image];
        [self.endView reloadImages:_posterMuArr];
    }
    else {
        //添加详情
        //[self.contentTextView insertText:@" "];
        [self _addAttachmentFromImage:image];
    }
}

- (void)getSelectedPhoto:(NSMutableArray *)photos
{
    for (ALAsset *asset in photos) {
        
        //CGImageRef posterImageRef = [asset thumbnail];
        //UIImage *selectedImage = [UIImage imageWithCGImage:posterImageRef];
        
        ALAssetRepresentation *posterImageRap = [asset defaultRepresentation];
        CGImageRef posterImageRef = [posterImageRap fullScreenImage];
        UIImage *selectedImage = [UIImage imageWithCGImage:posterImageRef];
        
        NSData * newData = UIImageJPEGRepresentation(selectedImage, 0.0001);
        UIImage * img = [UIImage imageWithData:newData];
        img = [self imageWithImage:img scaledToSize: [self getImageSize:img.size]];
        
        if (isPoster == YES) {//添加海报
            [_posterMuArr addObject:img];
            [self.endView reloadImages:_posterMuArr];
        }
        else {//添加详情
            //[self.contentTextView insertText:@" "];
            [self _addAttachmentFromImage:selectedImage];
        }
    }
}

#define ImagePlace 25
#pragma mark - QBImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *selectedImage = nil;
    selectedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    
    if (nil == selectedImage) {
        selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    
    // 保存图片到相册中
    SEL selectorToCall = @selector(imageWasSavedSuccessfully:didFinishSavingWithError:contextInfo:);
    UIImageWriteToSavedPhotosAlbum(selectedImage, self,selectorToCall, NULL);
    
    [self dismissViewControllerAnimated:NO completion:^{
        TOCropViewController *cropController = [[TOCropViewController alloc] initWithImage:selectedImage];
        if (isPoster == YES) {
            //添加海报
            cropController.ratio = YES;
            cropController.aspectRatio = CGSizeMake(1.0f, 2.0f);
        }
        else {
            //添加详情
            //cropController.aspectRatio = CGSizeMake(1.0f, 1.0f);
        }
        cropController.delegate = self;
        [self presentViewController:cropController animated:NO completion:nil];
    }];
    
    /*
    if (isPoster == YES) {
        NSData * newData = UIImageJPEGRepresentation(selectedImage, 0.0001);
        selectedImage=[UIImage imageWithData:newData];
        selectedImage=[self imageWithImage:selectedImage scaledToSize: [self getImageSize:selectedImage.size]];
        [_posterMuArr addObject:selectedImage];
        [self.endView reloadImages:_posterMuArr];
        //[self postImageWithImages:@[selectedImage]];
    }
    else {
        [self _addAttachmentFromImage:selectedImage];
    }
    
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];*/
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];
}

// 保存图片后到相册后，调用的相关方法，查看是否保存成功
- (void)imageWasSavedSuccessfully:(UIImage *)paramImage didFinishSavingWithError:(NSError *)paramError contextInfo:(void *)paramContextInfo{
    if (paramError == nil){
        NSLog(@"Image was saved successfully.");
    } else {
        NSLog(@"An error happened while saving the image.");
        NSLog(@"Error = %@", paramError);
    }
}

- (void)cropViewController:(TOCropViewController *)cropViewController didCropToImage:(UIImage *)image withRect:(CGRect)cropRect angle:(NSInteger)angle{
    
    [self getSelectedImage:image];
    
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];
}

- (void)deleteImage:(NSInteger)index
{
    [_posterMuArr removeObjectAtIndex:index];
    [self.endView reloadImages:_posterMuArr];
    
    NSMutableArray *photos = [[NSMutableArray alloc] init];
    for (int i = 0; i < _posterMuArr.count; i++) {
        MWPhoto *photo = [MWPhoto photoWithImage:[_posterMuArr objectAtIndex:i]];
        [photos addObject:photo];
    }
    _photos = photos;
}

- (MWPhoto *)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index
{
    if (index < _photos.count)
        return [_photos objectAtIndex:index];
    return nil;
}

- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser
{
    return _photos.count;
}

- (void)postImageWithImages:(NSArray *)arr
{
    UIImage * img = [_posterMuArr firstObject];
    NSData * data;
    
    data = UIImageJPEGRepresentation(img, 0.0001);
    NSString * imageStr = [GTMBase64 stringByEncodingData:data];
    NSDictionary *dic = @{@"iospic":imageStr,@"iospic_type":@"jpg"};
    //NSDictionary *dic = @{@"ico_file":_imageStr};
    [MyDataService postUploadPicture:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
            NSLog(@"%@",[[data objectForKey:@"content"] class]);
            //NSString *urlKey = [NSString stringWithFormat:@"url%lu",(unsigned long)arr.count];
            [_posterUrlMuArr addObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] ];
            [_posterMuArr removeObjectAtIndex:0];
            if (_posterMuArr.count != 0) {
                [self postImageWithImages:_posterUrlMuArr];
            }
            else {
                [self.endView reloadImages:_posterUrlMuArr];
            }
        }
        else {
            [hud hideProgress];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
