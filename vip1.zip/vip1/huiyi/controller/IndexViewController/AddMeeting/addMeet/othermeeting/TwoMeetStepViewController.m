//
//  TwoMeetStepViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/1/20.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "TwoMeetStepViewController.h"
#import "TicketTableViewCell.h"
#import "SetTicketTypeTableViewCell.h"
#import "CostTableViewCell.h"
#import "New_managerViewController.h"
#import "InsertCostTableViewCell.h"
#import "DescripTableViewCell.h"
#import "SignUpEndTimeTableViewCell.h"
#import "OtherMeetTwoStpeModel.h"
#import "meetOptionTableViewCell.h"
#import "EndTableViewCell.h"
#import "STAlertView.h"
#import "MeetTypeViewController.h"
#import "DBManager.h"
#import "GTMBase64.h"
#import "ReSetTicketViewController.h"
#import "LoginViewController.h"
#import "MyDataService.h"
#import "OptionViewController.h"
#import "SDTimeActiontSheet.h"
#import "OtherMeetTicketModel.h"
#import "CheckInfoTableViewCell.h"
#import "TicketTypeViewController.h"
#import "TicketDontDeleteView.h"
#import "TicketEidtView.h"
@interface TwoMeetStepViewController ()<UITableViewDataSource,UITableViewDelegate,addOtherMeetingDelegate,ShowCostDelegate,EndOfAddMeetTicketDelegate,UIScrollViewDelegate,checkDelegate,GetTicketTypeInfoDelegate,SDTimeActionSheetDelegate,callBackOptionItemsDelegate,setTicketDelegate,TicketEidtViewDelegate>
{
    BOOL keyBoardShow;
    NSInteger _section;
    NSIndexPath *timeIndex;
    NSMutableArray *ticketArr;
    NSMutableArray *ticketInfoArr;
    NSMutableArray *ticketTypeArr;
    NSMutableArray *fieldArr;
    NSMutableArray *oldPicUrlMuArr;
    UITableView  *ticketTpyeView;
    __block int imageIndex ;
    __block int imageCount ;
    __block Dialog *hud;
    NSMutableArray *picMuArr;//盛放详情图片的动态数组 上传一个删除一个图片
    NSMutableArray *picUrlMuArr;//盛放图片url
    NSMutableDictionary *new_postDic;
    NSMutableArray *posterMuArr;//盛放海报图片的动态数组 上传一个删除一个图片
    NSMutableArray *posterUrlMuArr;//盛放海报图片url
    NSMutableDictionary *postDataDic;
    NSString *insert_id;
    
    NSString *_version;//配置版本号
    NSMutableDictionary *_configDic;//配置文件 Net
    NSMutableArray *_configArray;//配置文件 组织好的数据
    
    NSInteger _ticketEidt;
}
@property (nonatomic,strong)SDTimeActiontSheet *dateActionSheet;
@end

@implementation TwoMeetStepViewController

- (void)viewWillDisappear:(BOOL)animated
{
    if (self.dateActionSheet.isShow == YES) {
        [self.dateActionSheet tappedCancel];
    }
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    [super viewWillDisappear:animated];
}

- (void)viewWillAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardHide:) name:UIKeyboardWillHideNotification object:nil];
    [super viewWillAppear:animated];
    
    [self getMeetConfigData];
}

- (void)keyboardShow:(NSNotification*)notification {
    if (keyBoardShow == NO) {
        NSDictionary *userInfo = [notification userInfo];
        NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
        CGSize size = [aValue CGRectValue].size;
        ticketTpyeView.size = CGSizeMake(ScreenWidth, ticketTpyeView.size.height-size.height);
    }
    keyBoardShow = YES;
}

- (void)keyboardHide:(NSNotification*)notification {
    keyBoardShow = NO;
    ticketTpyeView.size = CGSizeMake(ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT);
    [UIView animateWithDuration:0.25 animations:^{
        
    }];
}

- (NSString *)rePlaceUrl:(NSString*)content
{
    NSString *s = @"<(\\w+)\\s*src=\\\"a(\\w+.*?)\\\"\\s*/>";
    
    NSError *error;
    // NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    if (picUrlMuArr.count < arrayOfAllMatches.count) {
        for (int i = 0; i<picUrlMuArr.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
            //            content = [content stringByReplacingOccurrencesOfString:substringForMatch withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:i]]];
            //            　　 NSLog(@"%@",substringForMatch);
            
        }
        for (int j = picUrlMuArr.count; j< arrayOfAllMatches.count; j++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:j];
            NSString* substringForMatch1 = [content substringWithRange:match.range];
            content = [content stringByReplacingCharactersInRange:match.range withString:@""];
        }
    }else{
        for (int i = 0; i<arrayOfAllMatches.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
            
        }
    }
    for (int index = 0; index<picUrlMuArr.count; index++) {
        content = [content stringByReplacingOccurrencesOfString:[oldPicUrlMuArr objectAtIndex:index] withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:index]]];
    }
    return content;
}

- (void)posterImage:(NSArray*)arr
{
    if (_posterImageArr.count == 0) {
        [new_postDic setObject:posterUrlMuArr forKey:@"img_file_list"];
        [self postImageWithImages:nil];
    }else{
        [hud showCenterProgressWithText:[NSString stringWithFormat:@"%d/%d",imageIndex,imageCount ]];
        UIImage * img = [posterMuArr firstObject];
        NSData * data;
        data = UIImageJPEGRepresentation(img, 0.0001);
        NSString * imageStr = [GTMBase64 stringByEncodingData:data];
        NSDictionary *dic = @{@"iospic":imageStr,@"iospic_type":@"jpg"};
        //NSDictionary *dic = @{@"ico_file":_imageStr};
        [MyDataService postUploadPicture:dic callback:^(id data) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                
                NSLog(@"%@",[[data objectForKey:@"content"] class]);
                [posterUrlMuArr addObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] ];
                
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
                [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",arr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
                [posterMuArr removeObjectAtIndex:0];
                imageIndex++;
                if (posterMuArr.count != 0) {
                    [self posterImage:nil];
                }else{
                    [postDataDic setObject:posterUrlMuArr forKey:@"img_file_list"];
                    [self postImageWithImages:nil];
                }
            }
        }];
    }
}

/**
 *  回调方式 队列上传
 *
 *  @param arr 图片数组
 */
- (void)postImageWithImages:(NSArray *)arr
{
    if (picMuArr.count!=0) {
        UIImage * img = [picMuArr firstObject];
        NSData * data;
        
        [hud showCenterProgressWithText:[NSString stringWithFormat:@"%d/%d",imageIndex,imageCount ]];
        data = UIImageJPEGRepresentation(img, 0.0001);
        NSString * imageStr = [GTMBase64 stringByEncodingData:data];
        NSDictionary *dic = @{@"iospic":imageStr,@"iospic_type":@"jpg"};
        //NSDictionary *dic = @{@"ico_file":_imageStr};
        [MyDataService postUploadPicture:dic callback:^(id data) {
            NSLog(@"%@",data);
            
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                NSLog(@"%@",[[data objectForKey:@"content"] class]);
                NSString *urlKey = [NSString stringWithFormat:@"url%d",arr.count];
                
                [picUrlMuArr addObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] ];
                
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
                [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",arr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
                
                [picMuArr removeObjectAtIndex:0];
                imageIndex++;
                if (picMuArr.count != 0) {
                    [self postImageWithImages:picMuArr];
                }
                
                if (picMuArr.count==0) {
                    
                    NSString *content = [self rePlaceUrl:[_postDic objectForKey:@"summary"]];
                    [postDataDic setObject:content forKey:@"summary"];
                    
                    [hud hideProgress];
                    [MyDataService postAddMeeting:postDataDic callback:^(id data) {
                        NSLog(@"%@",data);
                        [hud hideProgress];
                        [[Dialog Instance]hideProgress];
                        if([[data objectForKey:@"code"]isEqualToString:@"200"]||[[data objectForKey:@"code"] objectForKey:@"201"])
                        {
                            [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                            insert_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                            for (OtherMeetTicketModel *ticketModel in ticketInfoArr) {
                                NSMutableDictionary *ticketPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
                                
                                [ticketPostDic setObject:insert_id forKey:@"meeting_id"];
                                [ticketPostDic setObject:ticketModel.signUpEndTime forKey:@"partake_end_time"];
                                [ticketPostDic setObject:ticketModel.ticketType forKey:@"profile_name"];
                                if (ticketModel.isCheck == YES) {
                                    [ticketPostDic setObject:@"1" forKey:@"with_approve"];
                                }else{
                                    [ticketPostDic setObject:@"0" forKey:@"with_approve"];
                                }
                                if (![ticketModel.cost isEqualToString:@"免费"]){
                                    [ticketPostDic setObject:[ticketModel.cost substringToIndex:ticketModel.cost.length-3] forKey:@"price"];
                                }else{
                                    [ticketPostDic setObject:@"0" forKey:@"price"];
                                }
                                [ticketPostDic setObject:ticketModel.ticketInfo forKey:@"note"];
                                
                                
                                [ticketPostDic setObject:ticketModel.fields forKey:@"partake_fields"];
                                if (ticketModel.profile_id.length != 0) {
                                    [ticketPostDic setObject:ticketModel.profile_id forKey:@"profile_id"];
                                }else{
                                    [ticketPostDic setObject:@"" forKey:@"profile_id"];
                                }
                                [fieldArr addObject:ticketPostDic];
                            }
                            [self SetBaseField];
                        }
                    }];
                    
                }else{
                    [hud showCenterProgressWithText:[NSString stringWithFormat:@"%d/%d",imageIndex,imageCount ]];
                }
            }else{
                [hud hideProgress];
            }
        }];
    }else{
        [MyDataService postAddMeeting:postDataDic callback:^(id data) {
            NSLog(@"%@",data);
            [hud hideProgress];
            [[Dialog Instance]hideProgress];
            if([[data objectForKey:@"code"]isEqualToString:@"200"]||[[data objectForKey:@"code"] objectForKey:@"201"])
            {
                [[DBManager sharedInstance]deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                insert_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                for (OtherMeetTicketModel *ticketModel in ticketInfoArr) {
                    NSMutableDictionary *ticketPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
                    
                    [ticketPostDic setObject:insert_id forKey:@"meeting_id"];
                    [ticketPostDic setObject:ticketModel.signUpEndTime forKey:@"partake_end_time"];
                    [ticketPostDic setObject:ticketModel.ticketType forKey:@"profile_name"];
                    if (ticketModel.isCheck == YES) {
                        [ticketPostDic setObject:@"1" forKey:@"with_approve"];
                    }else{
                        [ticketPostDic setObject:@"0" forKey:@"with_approve"];
                    }
                    if (![ticketModel.cost isEqualToString:@"免费"]){
                        [ticketPostDic setObject:[ticketModel.cost substringToIndex:ticketModel.cost.length-3] forKey:@"price"];
                    }else{
                        [ticketPostDic setObject:@"0" forKey:@"price"];
                    }
                    [ticketPostDic setObject:ticketModel.ticketInfo forKey:@"note"];
                    [ticketPostDic setObject:ticketModel.fields forKey:@"partake_fields"];
                    if (ticketModel.profile_id.length != 0) {
                        [ticketPostDic setObject:ticketModel.profile_id forKey:@"profile_id"];
                    }else{
                        [ticketPostDic setObject:@"" forKey:@"profile_id"];
                    }
                    [fieldArr addObject:ticketPostDic];
                }
                [self SetBaseField];
            }
        }];
    }
}

- (void)rightBtnClicked
{
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length]!=0){
        
        if (_configArr.count == 0) {//创建
            for (OtherMeetTicketModel *ticketModel in ticketInfoArr) {
                if (ticketModel.ticketType.length == 0) {
                    [Dialog toast:@"必填项不能为空！"];
                    [fieldArr removeAllObjects];
                    return;
                }
            }
            [self posterImage:nil];
        }else{//修改
            for (OtherMeetTicketModel *ticketModel in ticketInfoArr) {
                NSMutableDictionary *ticketPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
                if(ticketModel.signUpEndTime.length !=0){
                    [ticketPostDic setObject:ticketModel.signUpEndTime forKey:@"partake_end_time"];
                }else{
                    [ticketPostDic setObject:@"" forKey:@"partake_end_time"];
                }
                if (_meet_id.length != 0) {
                    [ticketPostDic setObject:_meet_id forKey:@"meeting_id"];
                }else{
                    [ticketPostDic setObject:@"" forKey:@"meeting_id"];
                }
                
                if (ticketModel.ticketType.length != 0) {
                    [ticketPostDic setObject:ticketModel.ticketType forKey:@"profile_name"];
                }else{
                    [Dialog toast:@"请填写报名类型！"];
                    [fieldArr removeAllObjects];
                    return;
                }
                if (ticketModel.profile_id.length != 0) {
                    [ticketPostDic setObject:ticketModel.profile_id forKey:@"profile_id"];
                }else{
                    [ticketPostDic setObject:@"" forKey:@"profile_id"];
                }
                if (ticketModel.isCheck == YES) {
                    [ticketPostDic setObject:@"1" forKey:@"with_approve"];
                    
                }else{
                    [ticketPostDic setObject:@"0" forKey:@"with_approve"];
                }
                if (![ticketModel.cost isEqualToString:@"免费"]){
                    [ticketPostDic setObject:[ticketModel.cost substringToIndex:ticketModel.cost.length-3] forKey:@"price"];
                }else{
                    [ticketPostDic setObject:@"0" forKey:@"price"];
                }
   
                    [ticketPostDic setObject:ticketModel.ticketInfo forKey:@"note"];
                
                if (ticketModel.fields.count != 0) {
                    [ticketPostDic setObject:ticketModel.fields forKey:@"partake_fields"];
                }else{
                    [ticketPostDic setObject:@[] forKey:@"partake_fields"];
                }
                [fieldArr addObject:ticketPostDic];
            }
            
            [self SetBaseField];
            
        }
    }else{
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"是否登录会议邦?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        alertView.tag = 10000;
        [alertView show];
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 10000) {
        if (buttonIndex == 0) {
            NSLog(@"取消");
        }
        if (buttonIndex == 1) {
            LoginViewController *loginVC = [[LoginViewController alloc]init];
            UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVC];
            loginVC.fromSignVC = YES;
            NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
            if (!LoginCompanyArray.count)
            {
                loginVC.isPush = YES;
            }
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
    }
}

- (void)SetBaseField
{
    NSDictionary *param;
    if (_isReSet) {
        param = @{@"meeting_id":_meet_id,@"fieldArr":[fieldArr firstObject]};
    }else{
        param = @{@"meeting_id":insert_id,@"fieldArr":[fieldArr firstObject]};
    }
    
    NSLog(@"%@",[param JSONString]);
    [MyDataService postSetBaseFieldsNew:param callback:^(id data) {
        NSLog(@"%@",data);
        [fieldArr removeObjectAtIndex:0];
        if (fieldArr.count != 0) {
            
            [self SetBaseField];
        }else{
            [Dialog toast:@"操作成功"];
            if (_isReSet == YES) {
                [_delegate callBackInfo];
                [self.navigationController popViewControllerAnimated:YES];
            }else{
                NSString *posterCount = [[DBManager sharedInstance]getPublicDBData:[NSString stringWithFormat:@"type_%d_posterImageCount",_type]];
                for (int i = 0; i<[posterCount integerValue]; i++) {
                    [self deleteFile:[NSString stringWithFormat:@"poster_%d",i] withMeetingType:[NSString stringWithFormat:@"%d",_type]];
                }
                
                New_managerViewController *managerViewController = [[New_managerViewController alloc]init];
                managerViewController.isCreate = YES;
                managerViewController.meeting_id = insert_id;
                [self.navigationController pushViewController:managerViewController animated:YES];
            }
        }
    }];
}

- (void)creatRightNav
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(ScreenWidth-60, _navheight+12, 50, 22);
    if (_isReSet == NO) {
        [rightbtn setImage:[UIImage imageNamed:@"cj_btn"] forState:UIControlStateNormal];
    }else{
        [rightbtn setTitle:@"确定" forState:UIControlStateNormal];
        rightbtn.titleLabel.font = YHUI(16);
        [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightbtn];
}

- (void)getMeetConfigData
{
    [_configArray removeAllObjects];
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"partake_%@",_meet_id]] length]!=0) {
        _version = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"partake_%@",_meet_id]];
    }else{
        _version = @"0";
    }
    NSDictionary *dic;
    dic = @{@"meeting_id": _meet_id,@"partake_version":_version};
    //[[Dialog Instance]showCenterProgressWithLabel:@"加载中..."];
    //[[Dialog Instance]showHSHUDWithController:self];
    [MyDataService postMeetingconfig:dic callback:^(id data) {
        NSLog(@"%@",data);
        
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"]floatValue]==200) {
                //[[Dialog Instance]hideProgress];
                //[[Dialog Instance]hiddenHSHUD];
                [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:@"firstConfig"];
                _version = [[data objectForKey:@"content"] objectForKey:[NSString stringWithFormat:@"version"]];
                [[NSUserDefaults standardUserDefaults] setObject:_version forKey:[NSString stringWithFormat:@"partake_%@",_meet_id]];
                [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                if ([[[data objectForKey:@"content"] objectForKey:@"state"] isEqualToString:@"1"]) {
                    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@config",_meet_id]];
                    [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"%@config",_meet_id]];
                    /*
                     NSArray *arr = [NSArray arrayWithArray:[[data objectForKey:@"content"] objectForKey:@"block_list"]];
                     NSMutableArray *mutArr = [NSMutableArray array];
                     for (NSDictionary *dic in arr) {
                     if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                     [mutArr addObject:dic];
                     }
                     }
                     [[data objectForKey:@"content"] setObject:mutArr forKey:@"block_list"];*/
                    
                    _configDic = [data objectForKey:@"content"];
                    [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isCache"];//当配置文件发生改变时  以后的缓存全都废弃 1发生了改变 0没有发生改变  （没有他  当配置文件发生改变时  后面的页面会宕掉）
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                }else{
                    //读文件
                    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isCache"];
                    [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
                    
                    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@config",_meet_id]];
                    
                    NSMutableDictionary *configDic = [NSMutableDictionary dictionaryWithDictionary:[[dataStr JSONValue] objectForKey:@"content"]];
                    /*
                     NSArray *arr = [NSArray arrayWithArray:[configDic objectForKey:@"block_list"]];
                     NSMutableArray *mutArr = [NSMutableArray array];
                     for (NSDictionary *dic in arr) {
                     if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                     [mutArr addObject:dic];
                     }
                     }
                     [configDic setObject:mutArr forKey:@"block_list"];*/
                    
                    _configDic = configDic;
                    
                }
                NSArray *arr = [NSArray arrayWithArray:[[data objectForKey:@"content"] objectForKey:@"block_list"]];
                
                for (NSDictionary *dic in arr) {
                    NSMutableDictionary *tickt = [[NSMutableDictionary alloc]initWithCapacity:0];
                    [tickt setObject:[dic objectForKey:@"note"] forKey:@"ticketInfo"];
                    [tickt setObject:[dic objectForKey:@"partake_end_time"]
                              forKey:@"signUpEndTime"];
                    [tickt setObject:[dic objectForKey:@"with_approve"] forKey:@"with_approve"];
                    [tickt setObject:[dic objectForKey:@"name"] forKey:@"ticketType"];
                    //                    [tickt setObject:[dic objectForKey:@"block_id"] forKey:@"profile_id"];
                    [tickt setObject:[dic objectForKey:@"price"] forKey:@"cost"];
                    [tickt setObject:[dic objectForKey:@"visible"] forKey:@"visible"];
                    [tickt setObject:[dic objectForKey:@"partake_counts"] forKey:@"partake_counts"];
                    NSMutableDictionary *fields = [[NSMutableDictionary alloc]initWithCapacity:0];
                    NSDictionary *blockDic = [[dic objectForKey:@"block_list"] objectAtIndex:0];
                    
                    [tickt setObject:[blockDic objectForKey:@"profile_id"] forKey:@"profile_id"];
                    NSArray *field = [blockDic objectForKey:@"field_list"];
                    if (field.count!=0) {
                        for (int i = 0; i<field.count; i++) {
                            
                            NSDictionary * fieldDic = [field objectAtIndex:i];
                            
                            NSMutableDictionary *muField = [[NSMutableDictionary alloc]initWithCapacity:0];
                            
                            
                            [muField setObject:[fieldDic objectForKey:@"required"] forKey:@"required"];
                            [muField setObject:[NSString stringWithFormat:@"%d",i] forKey:@"sn"];
                            [muField setObject:[fieldDic objectForKey:@"type"] forKey:@"type"];
                            [muField setObject:[fieldDic objectForKey:@"name"] forKey:@"name"];
                            [muField setObject:[fieldDic objectForKey:@"extr"] forKey:@"extr"];
                            [fields setObject:muField forKey:[fieldDic objectForKey:@"field_name"]];
                            [tickt setObject:fields forKey:@"fields"];
                        }
                    }
                    [_configArray addObject:tickt];
                    /*
                     if (![[dic objectForKey:@"visible"] isEqualToString:@"0"]) {
                     [_configArr addObject:tickt];
                     }*/
                }
                _configArr = _configArray;
                [self creatNetTicketData];
                [ticketTpyeView reloadData];
            }
        }
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //[self creatRightNav];
    hud = [[Dialog alloc]init];
    imageIndex = 1;
    imageCount = _posterImageArr.count + _contentImageArr.count;
    
    if(_isReSet == YES){
        self.titlelabel.text = @"修改报名设置（票种类型）";
    }else{
        self.titlelabel.text = @"2/2 报名设置";
    }

    new_postDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [new_postDic addEntriesFromDictionary:_postDic];
    posterMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    [posterMuArr addObjectsFromArray:_posterImageArr];
    posterUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    oldPicUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    picUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    fieldArr = [[NSMutableArray alloc]initWithCapacity:0];
    picMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    postDataDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    _configArray = [[NSMutableArray alloc]initWithCapacity:0];
    [picMuArr addObjectsFromArray:_contentImageArr];
    
    [postDataDic addEntriesFromDictionary:_postDic];
    ticketTpyeView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT) style:UITableViewStyleGrouped];
    ticketTpyeView.sectionFooterHeight = 0;
    ticketTpyeView.delegate = self;
    ticketTpyeView.dataSource = self;
    ticketTpyeView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:ticketTpyeView];
    
    UIView *footerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 74)];
    footerView.backgroundColor = [UIColor clearColor];
    ticketTpyeView.tableFooterView = footerView;
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[self getAdaptImage:[UIImage imageNamed:@"add_tickettype_btn_n_bg"]] forState:UIControlStateNormal];
    [btn setTitle:@"添加新的票种类型" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithHexString:@"#373737"] forState:UIControlStateNormal];
    [btn setImage:[self getAdaptImage:[UIImage imageNamed:@"add_tickettye_btn"]] forState:UIControlStateNormal];
    btn.imageView.origin = CGPointMake(btn.imageView.origin.x-5, btn.imageView.origin.y);
    [btn addTarget:self action:@selector(addTicketType) forControlEvents:UIControlEventTouchUpInside];
    btn.titleLabel.font = YHUI(16);
    btn.adjustsImageWhenHighlighted = NO;
    btn.frame = CGRectMake(50, 17, ScreenWidth-100, 40);
    btn.imageEdgeInsets = UIEdgeInsetsMake(0, btn.imageEdgeInsets.left-5, 0, 0);
    
    [footerView addSubview:btn];
    ticketTypeArr = [[NSMutableArray alloc]initWithCapacity:0];
    ticketInfoArr = [[NSMutableArray alloc]initWithCapacity:0];
    ticketArr =  [[NSMutableArray alloc]initWithCapacity:0];
    if (_isReSet == YES) {
        [self creatNetTicketData];//网络数据或缓存数据  用于修改
    }else{
        [self creatTicketModelData];//第一次进来时 默认一张票  title=会议title  报名截止时间=会议开始时间
    }
    // Do any additional setup after loading the view.
}

/**
 *  添加票  同时创建默认值  调用creatTicketModelData
 */

- (void)addTicketType
{
    [self creatTicketModelData];
    //[ticketTpyeView reloadData];
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr lastObject];
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr lastObject];
    ReSetTicketViewController *vc = [[ReSetTicketViewController alloc]init];
    vc.ticketTypeArr = ticketTypeArr;
    vc.ticketInfoArr = ticketInfoArr;
    vc.ticketInfo = ticketInfo;
    vc.section = ticketArr.count-1;
    vc.ticket = info;
    vc.isAdd = YES;
    vc.meet_id = _meet_id;
    vc.delegate = self;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if( self.dateActionSheet.isShow == YES){
        _section = MAXFLOAT;
        
        [self.dateActionSheet tappedCancel];
    }
}

- (void)creatNetTicketData
{
    [ticketArr removeAllObjects];
    [ticketInfoArr removeAllObjects];
    [ticketTypeArr removeAllObjects];
    for (NSDictionary *dic in _configArr) {
        OtherMeetTwoStpeModel *info = [[OtherMeetTwoStpeModel alloc]init];
        info.showMoreInfo = NO;
        if ([[dic objectForKey:@"cost"] length]==0||[[dic objectForKey:@"cost"]isEqualToString:@"0.00"]||(int)dic[@"cost"]<=0) {
            info.showTicketPrice = NO;
        }else{
            info.showTicketPrice = YES;
        }
        [ticketArr addObject:info];
        
        OtherMeetTicketModel *ticketModel = [[OtherMeetTicketModel alloc]init];
        ticketModel.partake_counts = [dic objectForKey:@"partake_counts"];
        ticketModel.visible = [dic objectForKey:@"visible"];
        ticketModel.ticketInfo = [dic objectForKey:@"ticketInfo"];
        ticketModel.ticketType = [dic objectForKey:@"ticketType"];
        ticketModel.profile_id = [dic objectForKey:@"profile_id"];
        NSString *cost = [dic objectForKey:@"cost"];
        
        if ([cost length]==0||[cost integerValue]==0) {
            ticketModel.cost = @"免费";
        }else{
            ticketModel.cost = [NSString stringWithFormat:@"%@RMB",[cost substringToIndex:(cost.length - 3)]];
        }
        
        ticketModel.fields = [dic objectForKey:@"fields"];
        ticketModel.signUpEndTime = [dic objectForKey:@"signUpEndTime"];
        if ([[dic objectForKey:@"with_approve"] isEqualToString:@"1"]) {
            ticketModel.isCheck = YES;
        }
        if ([[dic objectForKey:@"with_approve"] isEqualToString:@"0"]) {
            ticketModel.isCheck = NO;
        }
        [ticketInfoArr addObject:ticketModel];
        [ticketTypeArr addObject:ticketModel.ticketType];
    }
}

- (void)creatTicketModelData
{
    OtherMeetTwoStpeModel *info = [[OtherMeetTwoStpeModel alloc]init];
    info.showMoreInfo = NO;
    info.showTicketPrice = NO;
    [ticketArr addObject:info];
    NSMutableDictionary * optionItemPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    for (int index = 0; index < 2; index++) {
        if (index == 0) {
            NSMutableDictionary *theOption = [[NSMutableDictionary alloc]initWithCapacity:0];
            [theOption setObject:@"姓名" forKey:@"name"];
            [theOption setObject:@"" forKey:@"extr"];
            [theOption setObject:@"0" forKey:@"sn"];
            [theOption setObject:@"1" forKey:@"required"];
            [theOption setObject:@"textField" forKey:@"type"];
            [optionItemPostDic setObject:theOption forKey:@"f_name"];
        }
        if (index == 1) {
            NSMutableDictionary *theOption = [[NSMutableDictionary alloc]initWithCapacity:0];
            [theOption setObject:@"手机" forKey:@"name"];
            [theOption setObject:@"" forKey:@"extr"];
            [theOption setObject:@"1" forKey:@"sn"];
            [theOption setObject:@"1" forKey:@"required"];
            [theOption setObject:@"textField" forKey:@"type"];
            [optionItemPostDic setObject:theOption forKey:@"f_phone"];
        }
    }
    OtherMeetTicketModel *ticketModel = [[OtherMeetTicketModel alloc]init];
    ticketModel.visible = @"1";
    ticketModel.ticketInfo = @"";
    ticketModel.ticketType = @"";
    ticketModel.cost = @"免费";
    ticketModel.fields = optionItemPostDic;
    ticketModel.signUpEndTime = _partakTime;
    ticketModel.isCheck = NO;
    [ticketInfoArr addObject:ticketModel];
}

- (void)getTicketInfo:(NSString *)summary WithSection:(NSInteger)section
{
    OtherMeetTicketModel *info = (OtherMeetTicketModel *)[ticketInfoArr objectAtIndex:section];
    if (summary.length == 0) {
        info.ticketInfo = @"";
    }else{
        info.ticketInfo = summary;
    }
    [ticketInfoArr replaceObjectAtIndex:section withObject:info];
    [ticketTpyeView reloadData];
}

- (void)makeTicketModelWithKey:(NSString *)key :(NSString *)content
{
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return ticketArr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel *)[ticketArr objectAtIndex:section];
    if (info.showMoreInfo == NO) {
        return 1;
    }
    if (info.showMoreInfo == YES) {
        if (info.showTicketPrice == NO) {
            return 8;
        }else{
            return 9;
        }
    }
    return 0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr objectAtIndex:indexPath.section];
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:indexPath.section];
    
    if (info.showTicketPrice == YES) {
        if (indexPath.row == 4) {
            TicketTypeViewController *vc = [[TicketTypeViewController alloc]init];
            vc.delegate = self;
            vc.section = indexPath.section;
            vc.summary = ticketInfo.ticketInfo;
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 5) {
            [self.view endEditing:YES];
            timeIndex = indexPath;
            if (NO == self.dateActionSheet.isShow) {
                self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
                self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
            }
            _section = indexPath.section;
            [self.dateActionSheet showInView:self.view];
        }
        if (indexPath.row == 7) {
            CATransition *animation = [CATransition animation];
            //animation.delegate = self;
            animation.duration = 0.5f;
            animation.timingFunction = UIViewAnimationCurveEaseInOut;
            animation.fillMode = kCAFillModeForwards;
            animation.type = kCATransitionPush;
            animation.subtype = kCATransitionFromBottom;
             [self.view.layer addAnimation:animation forKey:nil];
            OptionViewController *optionVC = [[OptionViewController alloc]init];
            optionVC.delegate = self;
            optionVC.all_partake_fields = ticketInfoArr;
            optionVC.partake_fields = [ticketInfo.fields objectForKey:@"partake_fields"];
            optionVC.index = indexPath.section;
            [self.navigationController pushViewController:optionVC animated:NO];
        }
    }else{
        if (indexPath.row == 3) {
            TicketTypeViewController *vc = [[TicketTypeViewController alloc]init];
            vc.delegate = self;
            vc.section = indexPath.section;
            vc.summary = ticketInfo.ticketInfo;
            [self.navigationController pushViewController:vc animated:YES];
        }
        if (indexPath.row == 4) {
            timeIndex = indexPath;
            [self.view endEditing:YES];
            if (NO == self.dateActionSheet.isShow) {
                self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
                self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
            }
            _section = indexPath.section;
            [self.dateActionSheet showInView:self.view];
        }
        if (indexPath.row == 6) {
            OptionViewController *optionVC = [[OptionViewController alloc]init];
            optionVC.delegate = self;
            optionVC.all_partake_fields = ticketInfoArr;
            optionVC.partake_fields = ticketInfo.fields ;
            optionVC.index = indexPath.section;
            [self.navigationController pushViewController:optionVC animated:YES];
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:indexPath.section];
    
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel *)[ticketArr objectAtIndex:indexPath.section];
    if (info.showMoreInfo == NO) {
        if (indexPath.row == 0) {
            if (ticketInfo.ticketInfo.length == 0) {
                return 140-15;
            }
            else {
                CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(15) constrainedToSize:CGSizeMake(ScreenWidth-44, 500) lineBreakMode:NSLineBreakByWordWrapping];
                return 140-15+size.height;
            }
        }
    }
    if (info.showMoreInfo == YES) {
        if (info.showTicketPrice == YES) {
            if (indexPath.row == 0) {
                CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(15) constrainedToSize:CGSizeMake(ScreenWidth-44, 500) lineBreakMode:NSLineBreakByWordWrapping];
                return 140-15+size.height;
            }
            if (indexPath.row == 1)
            {
                return 82;
            }
            if (indexPath.row == 2) {
                return 50;
            }
            if (indexPath.row == 3) {
                return 50;
            }
            if (indexPath.row == 4) {
                CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(16) constrainedToSize:CGSizeMake(ScreenWidth-20-66, 500) lineBreakMode:NSLineBreakByWordWrapping];
                return 82-16+size.height+5;
            }
            if (indexPath.row == 5) {
                return 50;
            }
            if (indexPath.row == 6) {
                return 50;
            }
            if (indexPath.row == 7) {
                return 50;
            }
            if (indexPath.row == 8) {
                return 70;
            }
            
        }else{
            if (indexPath.row == 0) {
                CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(15) constrainedToSize:CGSizeMake(ScreenWidth-44, 500) lineBreakMode:NSLineBreakByWordWrapping];
                return 150-15+size.height;
            }
            if (indexPath.row == 1)
            {
                return 82;
            }
            if (indexPath.row == 2) {
                return 50;
            }
            if (indexPath.row == 3) {
                CGSize size = [ticketInfo.ticketInfo sizeWithFont:YHUI(16) constrainedToSize:CGSizeMake(ScreenWidth-20-66, 500) lineBreakMode:NSLineBreakByWordWrapping];
                return 82-16+size.height+5;
            }
            if (indexPath.row == 4) {
                return 50;
            }
            if (indexPath.row == 5) {
                return 50;
            }
            if (indexPath.row == 6) {
                return 50;
            }
            if (indexPath.row == 7) {
                return 70;
            } 
        }
    }
    return 0;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel *)[ticketArr objectAtIndex:indexPath.section];
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel *)[ticketInfoArr objectAtIndex:indexPath.section];
    
    if (indexPath.row == 0) {
        static NSString *CellIdentifier = @"ticketCell";
        TicketTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[TicketTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        
        cell.titleLB.text = ticketInfo.ticketType;
        cell.costLB.text = ticketInfo.cost;
        cell.endTimeLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:ticketInfo.signUpEndTime]];
        cell.introLB.text = ticketInfo.ticketInfo;
        [cell.introLB sizeToFit];
        [cell setIntroHeight:ticketInfo.ticketInfo];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate =self;
        
        /*
        if(indexPath.section == 0)
        {
            cell.cleanBtn.hidden = YES;
        }else{
            cell.cleanBtn.hidden = NO;
        }*/
        if (ticketArr.count > 2) {
            if (indexPath.section == ticketArr.count-1) {
                cell.cleanBtn.hidden = YES;
            }
            else {
                cell.cleanBtn.hidden = NO;
            }
        }
        else {
            cell.cleanBtn.hidden = YES;
        }
        
        if (indexPath.section == ticketArr.count-1) {
            cell.hideImageView.hidden = NO;
        }
        else {
            cell.hideImageView.hidden = YES;
        }
        
        cell.eidtBtn.tag = 10000+indexPath.section;
        cell.cleanBtn.tag = 100000+indexPath.section;
        return cell;
    }
    
    if (indexPath.row == 1) {
        static NSString *CellIdentifier = @"setTicketCell";
        SetTicketTypeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[SetTicketTypeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        cell.contentTF.tag = 500000+indexPath.section;
        cell.contentTF.text = ticketInfo.ticketType;
        [cell.contentTF addTarget:self action:@selector(getContentInfo:) forControlEvents:UIControlEventEditingChanged];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    
    if (indexPath.row == 2) {
        static NSString *CellIdentifier = @"costCell";
        CostTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[CostTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        
        cell.titleLB.text = @"该类型是否收费";
        cell.delegate = self;
        if (info.showTicketPrice == YES) {
            cell.switchBtn.on = YES;
        }else{
            cell.switchBtn.on = NO;
        }
        
        cell.switchBtn.tag = indexPath.section +200000;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
    
    if (info.showMoreInfo == YES) {
        if (info.showTicketPrice == NO) {
            if (indexPath.row == 3) {
                static NSString *CellIdentifier = @"DescripCell";
                DescripTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[DescripTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.contentLB = nil;
                if (ticketInfo.ticketInfo.length != 0) {
                    
                    [cell setContentLBWith:ticketInfo.ticketInfo];
                    cell.contentLB.text = ticketInfo.ticketInfo;
                    cell.contentLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
                }else{
                    [cell setContentLBWith:@"多说说，说明一下包含的内容"];
                    cell.contentLB.text = @"多说说，说明一下包含的内容";
                    cell.contentLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 4) {
                static NSString *CellIdentifier = @"SignUpEndTimeCell";
                SignUpEndTimeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[SignUpEndTimeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.contentLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:ticketInfo.signUpEndTime]];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 5) {
                static NSString *CellIdentifier = @"CheckInfoCell";
                CheckInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[CheckInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                
                cell.delegate = self;
                cell.switchBtn.tag = indexPath.section +300000;
                cell.titleLB.text = @"报名需经我审核";
                if (ticketInfo.isCheck == YES) {
                    cell.switchBtn.on = YES;
                }else{
                    cell.switchBtn.on = NO;
                }
                
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 6) {
                static NSString *CellIdentifier = @"meetOptionCell";
                meetOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[meetOptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 7) {
                static NSString *CellIdentifier = @"EndCell";
                EndTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[EndTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.delegate = self;
                cell.btn.tag = indexPath.section +400000;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
        }
        if (info.showTicketPrice == YES){
            if (indexPath.row == 3) {
                static NSString *CellIdentifier = @"InsertCostCell";
                InsertCostTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[InsertCostTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                if (![ticketInfo.cost isEqualToString:@"免费"]){
                    cell.contentTF.text = [ticketInfo.cost substringToIndex:ticketInfo.cost.length-3];
                }else{
                    cell.contentTF.text = @"";
                }
                cell.contentTF.tag = 600000+indexPath.section;
                [cell.contentTF addTarget:self action:@selector(getCostInfo:) forControlEvents:UIControlEventEditingChanged];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 4) {
                static NSString *CellIdentifier = @"DescripCell";
                DescripTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[DescripTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                if (ticketInfo.ticketInfo.length != 0) {
                    cell.contentLB = nil;
                    [cell setContentLBWith:ticketInfo.ticketInfo];
                    cell.contentLB.text = ticketInfo.ticketInfo;
                    cell.contentLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
                }else{
                    if (ticketInfo.ticketInfo.length != 0) {
                        
                        [cell setContentLBWith:ticketInfo.ticketInfo];
                        cell.contentLB.text = ticketInfo.ticketInfo;
                        cell.contentLB.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
                    }else{
                        [cell setContentLBWith:@"多说说，说明一下包含的内容"];
                        cell.contentLB.text = @"多说说，说明一下包含的内容";
                        cell.contentLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
                    }
                    
                    cell.contentLB.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 5) {
                static NSString *CellIdentifier = @"SignUpEndTimeCell";
                SignUpEndTimeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[SignUpEndTimeTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                
                cell.contentLB.text = [NSString stringWithFormat:@"%@",[self formatter:@"yyyy.MM.dd HH:mm" ToTime:ticketInfo.signUpEndTime]];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 6) {
                static NSString *CellIdentifier = @"CheckInfoCell";
                CheckInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[CheckInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                
                cell.titleLB.text = @"报名需经我审核";
                if (ticketInfo.isCheck == YES) {
                    cell.switchBtn.on = YES;
                }else{
                    cell.switchBtn.on = NO;
                }
                cell.switchBtn.tag = 300000 +indexPath.section;
                cell.delegate = self;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 7) {
                static NSString *CellIdentifier = @"meetOptionCell";
                meetOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[meetOptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
            if (indexPath.row == 8) {
                static NSString *CellIdentifier = @"EndCell";
                EndTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
                if (cell == nil) {
                    cell = [[EndTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
                }
                cell.delegate = self;
                cell.btn.tag = indexPath.section +400000;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                
                return cell;
            }
        }
    }
    return nil;
}

- (void)delLastTicet{
    [ticketInfoArr removeLastObject];
    [ticketArr removeLastObject];
    [ticketTpyeView reloadData];
}

- (void)callBackTicketInfo:(OtherMeetTicketModel *)ticketInfo With:(NSInteger)section
{
    [_delegate callBackInfo];
    [ticketInfoArr replaceObjectAtIndex:section withObject:ticketInfo];
    [ticketTpyeView reloadData];
}

#pragma mark --修改报名字段
- (void)callBackOptionItem:(NSDictionary *)OptionsDic with:(NSInteger)index
{
//    NSDictionary *partake_fields = [NSDictionary dictionaryWithObject:OptionsDic forKey:@"partake_fields"];
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel *)[ticketInfoArr objectAtIndex:index];
    ticketInfo.fields = OptionsDic;
    [ticketInfoArr replaceObjectAtIndex:index withObject:ticketInfo];
    NSLog(@"%@",OptionsDic);
}

#pragma mark --修改报名截止时间
- (void)cancelBtnClicked
{
    
}

- (void)returnData:(NSDate *)date Time:(NSTimeInterval)time
{
    OtherMeetTicketModel *info = [ticketInfoArr objectAtIndex:timeIndex.section];
    info.signUpEndTime = [NSString stringWithFormat:@"%ld",(long)time];
    [ticketInfoArr replaceObjectAtIndex:timeIndex.section withObject:info];
    
    [ticketTpyeView reloadData];
}

#pragma mark --修改票价
- (void)getCostInfo:(UITextField *)textField
{
    OtherMeetTicketModel *info = (OtherMeetTicketModel *)[ticketInfoArr objectAtIndex:textField.tag-600000];
    if(textField.text.length==0){
        info.cost = @"免费";
    }else{
        
        info.cost = [NSString stringWithFormat:@"%@RMB",textField.text];
    }
    [ticketInfoArr replaceObjectAtIndex:(textField.tag-600000) withObject:info];
}

#pragma mark --修改票的名称
- (void)getContentInfo:(UITextField *)textField
{
    OtherMeetTicketModel *info = (OtherMeetTicketModel *)[ticketInfoArr objectAtIndex:textField.tag-500000];
    info.ticketType = textField.text;
    [ticketInfoArr replaceObjectAtIndex:(textField.tag-500000) withObject:info];
}

#pragma mark --addOtherMeetingDelegate
- (void)meetTicketEidt:(UIButton *)btn  //btn.tag== 10000 编辑票
{
    _ticketEidt = btn.tag-10000;
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr objectAtIndex:btn.tag-10000];
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:btn.tag-10000];
    //if ([ticketInfo.partake_counts isEqualToString:@"0"]) {
        ReSetTicketViewController *vc = [[ReSetTicketViewController alloc]init];
        vc.ticketTypeArr = ticketTypeArr;
        vc.ticketInfoArr = ticketInfoArr;
        vc.ticketInfo = ticketInfo;
        vc.view_title = ticketInfo.ticketType;
        vc.section = btn.tag-10000;
        vc.ticket = info;
        vc.meet_id = _meet_id;
        vc.delegate = self;
        
        if (btn.tag-10000 == ticketArr.count-1) {
            vc.isTemp = NO;
        }
        else {
            vc.isTemp = NO;
        }
        
        [self.navigationController pushViewController:vc animated:YES];
    //}
    //else {
        /*
        TicketEidtView *ticketEidtView = [[TicketEidtView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        ticketEidtView.delegate = self;
        [ticketEidtView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，修改报名字段，可能会造成已报名数据与修改后的字段内容不匹配或丢失！",ticketInfo.partake_counts]];
        [ticketEidtView show];*/
    //}
    /*
    for (int i = 0; i<ticketArr.count; i++) {
        OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr objectAtIndex:i];
        OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:i];
        if (i == btn.tag-10000) {
            ReSetTicketViewController *vc = [[ReSetTicketViewController alloc]init];
            vc.ticketTypeArr = ticketTypeArr;
            vc.ticketInfoArr = ticketInfoArr;
            vc.ticketInfo = ticketInfo;
            vc.view_title = ticketInfo.ticketType;
            vc.section = btn.tag-10000;
            vc.ticket = info;
            vc.meet_id = _meet_id;
            vc.delegate = self;
            
            if (i == ticketArr.count-1) {
                vc.isTemp = YES;
            }
            else {
                vc.isTemp = NO;
            }
            
            [self.navigationController pushViewController:vc animated:YES];
        }else{
            info.sureTicketType = NO;
            info.showMoreInfo = NO;
            [ticketArr replaceObjectAtIndex:i withObject:info];
        }
    }
    [ticketTpyeView reloadData];*/
}

- (void)ticketEidt
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr objectAtIndex:_ticketEidt];
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:_ticketEidt];
    
    ReSetTicketViewController *vc = [[ReSetTicketViewController alloc]init];
    vc.ticketTypeArr = ticketTypeArr;
    vc.ticketInfoArr = ticketInfoArr;
    vc.ticketInfo = ticketInfo;
    vc.view_title = ticketInfo.ticketType;
    vc.section = _ticketEidt;
    vc.ticket = info;
    vc.meet_id = _meet_id;
    vc.delegate = self;
    
    if (_ticketEidt == ticketArr.count-1) {
        vc.isTemp = YES;
    }
    else {
        vc.isTemp = NO;
    }
    
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)delegateTicket:(NSDictionary *)dic
{
    [MyDataService postDelBaseFields:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"]isEqualToString:@"200"]||[[data objectForKey:@"code"]isEqualToString:@"201"]){
            //[[NSNotificationCenter defaultCenter]postNotificationName:@"refreshConfig" object:nil];
        }
    }];
}

- (void)meetTicketCleaned:(UIButton *)btn  //btn.tag== 100000 删除票
{
    OtherMeetTicketModel *info = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:btn.tag-100000];
    if ([info.partake_counts isEqualToString:@"0"]) {
        if (_isReSet == YES) {
            NSDictionary *param = @{@"meeting_id":_meet_id,@"profile_id":info.profile_id};
            [self delegateTicket:param];
        }
        [ticketArr removeObjectAtIndex:btn.tag -100000];
        [ticketInfoArr removeObjectAtIndex:btn.tag -100000];
        [ticketTypeArr removeObjectAtIndex:btn.tag -100000];
        [ticketTpyeView reloadData];
    }
    else {
        TicketDontDeleteView *ticketDontDeleteView = [[TicketDontDeleteView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        [ticketDontDeleteView reloadView:[NSString stringWithFormat:@"已有 %@ 位参会者报名，若要删除需将所有参会者取消报名。",info.partake_counts]];
        [ticketDontDeleteView show];
    }
}

#pragma mark --ShowCostDelegate
- (void)showCostView:(SevenSwitch *)btn  //btn.tag== 200000 显示票价编辑行
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr objectAtIndex:btn.tag-200000];
    info.showTicketPrice = !info.showTicketPrice;
    [ticketArr replaceObjectAtIndex:btn.tag-200000 withObject:info];
    
    OtherMeetTicketModel *ticketInfo = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:btn.tag-200000];
    ticketInfo.cost = @"免费";
    [ticketInfoArr replaceObjectAtIndex:btn.tag-200000 withObject:ticketInfo];
    
    [ticketTpyeView reloadData];
}

#pragma mark --checkDelegate
- (void)checkSignUpInfo:(SevenSwitch *)btn  //btn.tag== 300000 选择是否审核
{
    OtherMeetTicketModel *info = (OtherMeetTicketModel*)[ticketInfoArr objectAtIndex:btn.tag-300000];
    info.isCheck = !info.isCheck;
    [ticketInfoArr replaceObjectAtIndex:btn.tag-300000 withObject:info];
    [ticketTpyeView reloadData];
}

- (void)completeBtnClicked:(UIButton *)btn  //完成编辑
{
    OtherMeetTwoStpeModel *info = (OtherMeetTwoStpeModel*)[ticketArr objectAtIndex:btn.tag-400000];
    if (info.showMoreInfo == YES) {
        info.showMoreInfo = !info.showMoreInfo;
        info.sureTicketType = YES;
        [ticketArr replaceObjectAtIndex:btn.tag-400000 withObject:info];
    }
    [ticketTpyeView reloadData];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 20)];
    UILabel *titleLB = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, ScreenWidth, 20)];
    titleLB.backgroundColor = [UIColor clearColor];
    //titleLB.text = [NSString stringWithFormat:@"类型%d",section+1];
    titleLB.font = YHUI(19);
    [headView addSubview:titleLB];
    headView.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    return headView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
