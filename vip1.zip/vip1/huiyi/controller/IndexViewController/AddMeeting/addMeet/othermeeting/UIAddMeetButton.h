//
//  UIAddMeetButton.h
//  huiyi
//
//  Created by songhongshuai on 15/1/22.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAddMeetButton : UIButton

@end
