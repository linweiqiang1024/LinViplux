//
//  CreatMeetTextField.m
//  huiyi
//
//  Created by songhongshuai on 15/2/10.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "CreatMeetTextField.h"

@implementation CreatMeetTextField

- (void)drawPlaceholderInRect:(CGRect)rect

{
    
    //CGContextRef context = UIGraphicsGetCurrentContext();
    
    //CGContextSetFillColorWithColor(context, [UIColor yellowColor].CGColor);
    
    [[UIColor colorWithHexString:@"#b4b4b5"] setFill];
    [[self placeholder] drawInRect:rect withFont:[UIFont systemFontOfSize:16]];
    
}

@end
