//
//  UISwitchView.m
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import "UISwitchView.h"

@implementation UISwitchView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self createUI];
    }
    return self;
}
- (void)createUI
{
    UILabel *topline = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 0.5)];
    topline.backgroundColor = [UIColor lightGrayColor];
    [self  addSubview:topline];
    
    _titleLb = [[UILabel alloc]initWithFrame:CGRectMake(15, 0, 250, self.frame.size.height)];
    _titleLb.text = @"ajlaksmd;alsmd";
    _titleLb.backgroundColor = [UIColor clearColor];
    _titleLb.font = [UIFont systemFontOfSize:16];
    [self addSubview:_titleLb];
    
    
    _switchBtn = [[UISwitch alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-65, 9, 46, 28)];
    [_switchBtn addTarget:self action:@selector(switchBtnClick:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_switchBtn];
    UILabel *endline = [[UILabel alloc]initWithFrame:CGRectMake(0, self.frame.size.height-0.5, [UIScreen mainScreen].bounds.size.width, 0.5)];
    endline.backgroundColor = [UIColor yellowColor];
    [self  addSubview:endline];

}
- (void)switchBtnClick:(UISwitch *)btn
{
    [_delegate ChangeValue:btn];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
