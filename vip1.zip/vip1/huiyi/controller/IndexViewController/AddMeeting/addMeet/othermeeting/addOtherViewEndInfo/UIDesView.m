//
//  UIDesView.m
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/27.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import "UIDesView.h"
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
#define ScreenWidth [UIScreen mainScreen].bounds.size.width

@interface UIDesView ()<UIShowInfoViewDelegate>

@end

@implementation UIDesView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        UIButton *showBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [showBtn setImage:[UIImage imageNamed:@"showMore"] forState:UIControlStateNormal];
        [showBtn setImage:[UIImage imageNamed:@"showLess"] forState:UIControlStateSelected];
        [showBtn setTitleColor:[UIColor colorWithHexString:@"#373737"] forState:UIControlStateNormal];
        [showBtn setTitleColor:[UIColor colorWithHexString:@"#373737"] forState:UIControlStateSelected];
        showBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -50, 0, 0);
        showBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 80, 0, 0);
        [showBtn setTitle:@"更多" forState:UIControlStateSelected];
        [showBtn setTitle:@"收起" forState:UIControlStateNormal];
        showBtn.selected = YES;
        showBtn.frame = CGRectMake(0, 0, ScreenWidth, 44);
        [showBtn addTarget:self action:@selector(showBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        showBtn.backgroundColor = [UIColor whiteColor];
        [self addSubview:showBtn];
        
        UILabel *line1= [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(showBtn.frame), ScreenWidth, 0.5)];
        BackGround16Color(line1, @"#c8c7cc");
        [self  addSubview:line1];
        _otherInfoView = [[UIShowInfoView alloc]init ];
        _otherInfoView.delegate = self;
        _otherInfoView.frame = CGRectMake(0, CGRectGetMaxY(line1.frame), ScreenWidth, 74+90+90+237+135);
        _otherInfoView.clipsToBounds = YES;
        _desViewHeight = CGRectGetMaxY(_otherInfoView.frame);

    }
    return self;
}
- (void)callBackHeight:(CGFloat)height review:(BOOL)review
{
    _otherInfoView.frame = CGRectMake(0, _otherInfoView.frame.origin.y, ScreenWidth, height);
    _desViewHeight = CGRectGetMaxY(_otherInfoView.frame);
    
    if (review) {
        if ([_delegate respondsToSelector:@selector(changeFrameHeight:)]) {
            [_delegate changeFrameHeight:_desViewHeight];
        }
    }
}
- (void)changePersonalData:(NSString *)personalData
{
    if ([_delegate respondsToSelector:@selector(changePersonalData:)]) {
        [_delegate changePersonalData:personalData];
    }
}
- (void)showBtnClick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    if (btn.selected == YES) {
        [_otherInfoView removeFromSuperview];
    }else{
        [self addSubview:_otherInfoView];

    }
    [_delegate changeFrameView:btn];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
