//
//  TicketTypeViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "TicketTypeViewController.h"
#import "SDToolBarOfHideView.h"
@interface TicketTypeViewController ()<UITextViewDelegate,HideKeyboardDelegate>
{
    UITextView *textFieldName;
    MBProgressHUD *HUD;
    void (^summaryBlock)( NSString *str);
}
@end

@implementation TicketTypeViewController
-(id)initWithComplentSummary:(void(^)( NSString *str))summary{
    self = [super init];
    if (self) {
        summaryBlock = [summary copy];
    }
    
    return self;
}
- (void) customizeAboveToolbar
{
    UIButton *rightBack = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBack.backgroundColor = [UIColor clearColor];
    [rightBack setFrame:CGRectMake(ScreenWidth-60, 25, 44, 34)];
    [rightBack setTitle:@"确定" forState:UIControlStateNormal];
    [rightBack setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    rightBack.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [rightBack addTarget:self action:@selector(commitAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightBack];
    
    
}
- (void)commitAction:(UIButton *)btn
{
    [_delegate getTicketInfo:textFieldName.text WithSection:_section];
    [self.view endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self customizeAboveToolbar];
    self.titlelabel.text = @"票种类型说明";
    textFieldName = [[UITextView alloc] initWithFrame:CGRectMake(5, self.F_NAV_HEIGHT + 9, ScreenWidth-10, 200)];
    textFieldName.text = self.summary;
    textFieldName.delegate = self;
    textFieldName.layer.cornerRadius = 3.0;
    textFieldName.font = [UIFont systemFontOfSize:16];
    textFieldName.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    [self.view addSubview:textFieldName];
    SDToolBarOfHideView *toolBar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
    toolBar.SDdelegate = self;
    textFieldName.inputAccessoryView = toolBar;

}
- (void)hideKeyboard{
    [textFieldName resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
