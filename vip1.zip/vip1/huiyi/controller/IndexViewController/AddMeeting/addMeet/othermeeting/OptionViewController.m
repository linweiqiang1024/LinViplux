//
//  OptionViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/1/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "OptionViewController.h"
#import "OptionTableViewCell.h"
#import "MeetTicketOptionModel.h"
#import "SDAlertView.h"
#import "LXActionSheet.h"
#import "OtherMeetTicketModel.h"
#import "OptionTypeView.h"

@interface OptionViewController ()<UITableViewDataSource,UITableViewDelegate,OptionDelegate,UIAlertViewDelegate,LXActionSheetDelegate,OptionTypeViewDelegate>
{
    __block UITableView *ticketTpyeView;
    NSInteger optionNum;
    __block NSMutableArray *optionMuArr;
    NSMutableDictionary *optionDic;
    LXActionSheet *_actionSheet;
    NSMutableArray *ticketArr;//存放所有的票的信息
}
@property (nonatomic,assign) CGSize keyBoardSize;
@property (nonatomic,strong) OptionTypeView *optionTypeView;
@end

@implementation OptionViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"OptionViewController"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"OptionViewController"];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification *)notification {
    
    NSDictionary* info = [notification userInfo];
    self.keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    [self.optionTypeView reloadView:self.keyBoardSize];
}

- (void)keyboardWillHide:(NSNotification *)notification {
    
    NSDictionary* info = [notification userInfo];
    self.keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    [self.optionTypeView reloadView:self.keyBoardSize];
}

- (void)ReturnBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)creatRightBtn
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(ScreenWidth-54, 20, 44, 44);
    rightbtn.titleLabel.font = YHUI_BOLD(16);
    [rightbtn setTitle:@"完成" forState:UIControlStateNormal];
    [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:rightbtn];
}

- (void)rightBtnClicked
{
    NSMutableDictionary * optionItemPostDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    NSInteger snIndex = 0;
    for (MeetTicketOptionModel *model in optionMuArr) {
        if (model.selectOption == YES) {
            NSMutableDictionary *theOption = [[NSMutableDictionary alloc]initWithCapacity:0];
            [theOption setObject:model.title forKey:@"name"];
            [theOption setObject:model.extr forKey:@"extr"];
            [theOption setObject:[NSString stringWithFormat:@"%d",(int)snIndex] forKey:@"sn"];
            if (model.profile_id.length == 0) {
                [theOption setObject:@"" forKey:@"profile_id"];
            }else{
                [theOption setObject:model.profile_id forKey:@"profile_id"];
            }
            snIndex ++;
            [theOption setObject:model.required forKey:@"required"];
            [theOption setObject:model.type forKey:@"type"];
            [optionItemPostDic setObject:theOption forKey:model.postKey];
        }
    }
    [_delegate callBackOptionItem:optionItemPostDic with:_index];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.titlelabel.text = @"选择报名字段";
    
    [self creatRightBtn];
    [self.leftnavbtn setImage:[UIImage imageNamed:@"title-closeicon"] forState:UIControlStateNormal];
    ticketArr = [NSMutableArray arrayWithArray:_all_partake_fields];
    [ticketArr removeObjectAtIndex:_index];
    
    optionNum = 5;
    optionMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    optionDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    
    UIView *footerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 103)];
    footerView.backgroundColor = [UIColor clearColor];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(14, 23, ScreenWidth-28, 57);
    btn.adjustsImageWhenHighlighted = NO;
    btn.titleLabel.font = YHUI(16);
    btn.imageEdgeInsets = UIEdgeInsetsMake(0, btn.imageEdgeInsets.left-5, 0, 0);
    btn.imageView.origin = CGPointMake(btn.imageView.origin.x-5, btn.imageView.origin.y);
    [btn setBackgroundImage:[self getAdaptImage:[UIImage imageNamed:@"option_enselect_bg"]] forState:UIControlStateNormal];
    [btn setTitle:@"添加新的报名类型" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor colorWithHexString:@"#373737"] forState:UIControlStateNormal];
    [btn setImage:[self getAdaptImage:[UIImage imageNamed:@"add_tickettye_btn"]] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(addOptionType) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:btn];
    
    ticketTpyeView = [[UITableView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    ticketTpyeView.sectionFooterHeight = 0;
    ticketTpyeView.delegate = self;
    ticketTpyeView.dataSource = self;
    ticketTpyeView.tableFooterView = footerView;
    ticketTpyeView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:ticketTpyeView];
    
    [self creatOptionData];
    
    /*
    UIButton *copyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    copyBtn.frame = CGRectMake(14, CGRectGetMaxY(btn.frame) + 23, ScreenWidth-28, 57);
    [copyBtn setBackgroundImage:[self getAdaptImage:[UIImage imageNamed:@"option_enselect_bg"]] forState:UIControlStateNormal];
    [copyBtn setTitle:@"在已有字段中复制" forState:UIControlStateNormal];
    [copyBtn addTarget:self action:@selector(CopeOptionType) forControlEvents:UIControlEventTouchUpInside];
    [copyBtn setTitleColor:[UIColor colorWithHexString:@"#373737"] forState:UIControlStateNormal];
    copyBtn.imageView.origin = CGPointMake(btn.imageView.origin.x-5, btn.imageView.origin.y);
    copyBtn.titleLabel.font = YHUI(16);
    copyBtn.adjustsImageWhenHighlighted = NO;
    copyBtn.imageEdgeInsets = UIEdgeInsetsMake(0, btn.imageEdgeInsets.left-5, 0, 0);
    [footerView addSubview:copyBtn];*/
}

#pragma mark - LXActionSheetDelegate

- (void)didClickOnButtonIndex:(NSInteger)buttonIndex
{
    NSLog(@"%d",(int)buttonIndex);
    NSInteger index = 0;
    OtherMeetTicketModel *info = [ticketArr objectAtIndex:(NSInteger)buttonIndex];
    NSMutableDictionary *MuDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [MuDic addEntriesFromDictionary:info.fields];
    
    for (int i = 0; i < optionMuArr.count; i++) {
        MeetTicketOptionModel *model = [optionMuArr objectAtIndex:i];
        for (NSString *key in [MuDic allKeys]) {//移除一样的字段
            NSDictionary *dic = [info.fields objectForKey:key];
            if ([[dic objectForKey:@"name"]isEqualToString:model.title]) {
                model.selectOption = YES;
                model.required = [dic objectForKey:@"required"];
                if ([[dic objectForKey:@"required"] isEqualToString:@"1"]) {
                    model.sureOption = YES;
                }else{
                    model.sureOption = NO;
                }
                model.profile_id = [dic objectForKey:@"profile_id"];
                model.extr = [dic objectForKey:@"extr"];
                model.sn = [NSString stringWithFormat:@"%d",(int)index];
                [optionMuArr replaceObjectAtIndex:i withObject:model];
                if (model.selectOption == YES) {
                    
                }
                [MuDic removeObjectForKey:key];
                index++;
            }
        }
    }
    
    for (NSString *key in [MuDic allKeys]) {//添加copy的字段
        MeetTicketOptionModel *model = [[MeetTicketOptionModel alloc]init];
        NSDictionary *dic = [MuDic objectForKey:key];
        model.profile_id = [dic objectForKey:@"profile_id"];
        model.extr = [dic objectForKey:@"extr"];
        model.sn = [NSString stringWithFormat:@"%d",(int)index];
        model.selectOption = YES;
        model.required = [dic objectForKey:@"required"];
        model.title = [dic objectForKey:@"name"];
        if ([[dic objectForKey:@"required"] isEqualToString:@"1"]) {
            model.sureOption = YES;
        }else{
            model.sureOption = NO;
        }
        //model.sn = [NSString stringWithFormat:@"%d",i];
        model.postKey = key;
        [optionMuArr addObject:model];
        index ++;
    }
    [ticketTpyeView reloadData];
}

- (void)didClickOnDestructiveButton
{
    NSLog(@"destructuctive");
}

- (void)didClickOnCancelButton
{
    NSLog(@"cancelButton");
}

- (void)CopeOptionType
{
    if (_all_partake_fields.count == 1) {
        [Dialog toastCenter:@"没有其他类型的票"];
    }else{
        NSMutableArray *titleArr = [[NSMutableArray alloc]initWithCapacity:0];
        
        for (int i = 0; i<ticketArr.count; i++) {
            [titleArr addObject:[NSString stringWithFormat:@"类型%d",(i+1)]];
        }
        _actionSheet = [[LXActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:titleArr];
        [_actionSheet showInView:self.view];
    }
}

- (void)creatOptionData
{
    NSInteger index = 0;
    NSMutableDictionary *MuDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [MuDic addEntriesFromDictionary:_partake_fields];
    NSArray *arr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职务"];
    NSArray *postKeyArr = @[@"f_name",@"f_phone",@"f_email",@"f_company",@"f_position"];
    //NSArray *arr = @[@"姓名",@"手机"];
    //NSArray *postKeyArr = @[@"f_name",@"f_phone"];
    for (int i = 0; i < arr.count; i++) {
        MeetTicketOptionModel *model = [[MeetTicketOptionModel alloc]init];
        model.title = [arr objectAtIndex:i];
        for (NSString *key in [_partake_fields allKeys]) {
            NSDictionary *dic = [_partake_fields objectForKey:key];
            if ([[dic objectForKey:@"name"]isEqualToString:model.title]) {
                model.selectOption = YES;
                model.required = [dic objectForKey:@"required"];
                if ([[dic objectForKey:@"required"] isEqualToString:@"1"]) {
                    model.sureOption = YES;
                }
                else {
                    model.sureOption = NO;
                }
                model.profile_id = [dic objectForKey:@"profile_id"];
                model.extr = [dic objectForKey:@"extr"];
                model.sn = [NSString stringWithFormat:@"%d",(int)index];
                [MuDic removeObjectForKey:key];
                index++;
            }
        }
        model.postKey = [postKeyArr objectAtIndex:i];
        if (i < 2) {
            model.selectOption = YES;
            model.sureOption = YES;
            model.required = @"1";
        }
        [optionMuArr addObject:model];
    }
    
    for (NSString *key in [MuDic allKeys]) {
        MeetTicketOptionModel *model = [[MeetTicketOptionModel alloc]init];
        NSDictionary *dic = [MuDic objectForKey:key];
        model.profile_id = [dic objectForKey:@"profile_id"];
        model.extr = [dic objectForKey:@"extr"];
        model.sn = [dic objectForKey:@"sn"];
        model.selectOption = YES;
        model.required = [dic objectForKey:@"required"];
        model.title = [dic objectForKey:@"name"];
        if ([[dic objectForKey:@"required"] isEqualToString:@"1"]) {
            model.sureOption = YES;
        }
        else {
            model.sureOption = NO;
        }
        model.postKey = key;
        [optionMuArr addObject:model];
        index ++;
    }
    if (MuDic.count != 0) {
        [self sort];
    }
}

- (void)sort
{
    NSMutableArray *tempArr = [[NSMutableArray alloc]initWithCapacity:0];
    int index = 0;
    for (MeetTicketOptionModel *info in optionMuArr) {
        if (index >= 5) {
            [tempArr addObject:info];
        }
        index ++;
    }
    NSInteger sum = [optionMuArr count];
    for (int mun = 5; mun <= sum-1; mun++) {
        [optionMuArr removeLastObject];
    }
    int i,j;
    for(i = 0; i < (int)([tempArr count]-1); i++)
    {
        for(j = 0; j < (int)([tempArr count]-1-i); j++){
            MeetTicketOptionModel *info = [tempArr objectAtIndex:j];
            NSInteger sn = [info.sn integerValue];
            MeetTicketOptionModel *nextInfo = [tempArr objectAtIndex:(j+1)];
            NSInteger nextSn = [nextInfo.sn integerValue];
            if(sn > nextSn)
            {
                MeetTicketOptionModel *tempInfo = info;
                [tempArr replaceObjectAtIndex:(j) withObject:nextInfo];
                [tempArr replaceObjectAtIndex:(j+1) withObject:tempInfo];
            }
        }
    }
    [optionMuArr addObjectsFromArray:tempArr];
    [ticketTpyeView reloadData];
}

- (void)addOptionType
{
    /*
    UIAlertView *_alertView = [[UIAlertView alloc] initWithTitle:@"请输入报名字段名称" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    _alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    [_alertView show];*/
    
    self.optionTypeView = [[OptionTypeView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    self.optionTypeView.delegate = self;
    [self.optionTypeView show];
}

- (void)optionTypeAdd:(NSString *)text
{
    if ([self stringContainsEmoji:text]) {
        [Dialog toastCenter:@"不支持表情符号，请重新输入"];
        return;
    }
    
    int len = 0;
    for (int i = 0; i < text.length; i++) {
        NSRange rang = NSMakeRange(i, 1);
        NSString *str = [text substringWithRange:rang];
        if (strlen([str UTF8String]) == 3) {
            len += 2;
        }
        else {
            len += 1;
        }
    }
    if (len > 60) {
        [Dialog toastCenter:@"字段名称不可超过30个中文或60个英文字符"];
        return;
    }
    
    //NSArray *arr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职务"];
    //NSArray *arr = @[@"姓名",@"手机"];
    for (MeetTicketOptionModel *model in optionMuArr) {
        if ([text isEqualToString:model.title]) {
            [Dialog toastCenter:@"字段名称不可重复，请重新输入"];
            return;
        }
    }
    
    if (text.length != 0) {
        MeetTicketOptionModel *model = [[MeetTicketOptionModel alloc]init];
        model.selectOption = YES;
        model.sureOption = NO;
        model.required = @"0";
        model.title = text;
        model.sn = [NSString stringWithFormat:@"%d",(int)optionMuArr.count];
        model.postKey = [NSString stringWithFormat:@"_%d",(int)optionMuArr.count];
        [optionMuArr addObject:model];
        [ticketTpyeView reloadData];
    }
    else {
        [Dialog toastCenter:@"字段名称不能为空，请重新输入"];
        return;
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *text = [alertView textFieldAtIndex:0].text;
    if (buttonIndex == 1) {
        if (text.length != 0) {
            if ([self stringContainsEmoji:text]) {
                [Dialog toastCenter:@"不支持表情符号，请重新输入"];
            }
            else {
                int len = 0;
                for (int i = 0; i < text.length; i++) {
                    NSRange rang = NSMakeRange(i, 1);
                    NSString *str = [text substringWithRange:rang];
                    if (strlen([str UTF8String]) == 3) {
                        len += 2;
                    }
                    else {
                        len += 1;
                    }
                }
                if (len > 60) {
                    [Dialog toastCenter:@"字段名称不可超过30个中文或60个英文字符"];
                }
                else {
                    //NSArray *arr = @[@"姓名",@"手机",@"邮箱",@"单位",@"职务"];
                    //NSArray *arr = @[@"姓名",@"手机"];
                    BOOL isRepeat = NO;
                    for (MeetTicketOptionModel *model in optionMuArr) {
                        if ([text isEqualToString:model.title]) {
                            isRepeat = YES;
                        }
                    }
                    if (isRepeat) {
                        [Dialog toastCenter:@"字段名称不可重复，请重新输入"];
                    }
                    else {
                        MeetTicketOptionModel *model = [[MeetTicketOptionModel alloc]init];
                        model.selectOption = YES;
                        model.sureOption = NO;
                        model.required = @"0";
                        model.title = [alertView textFieldAtIndex:0].text;
                        model.sn = [NSString stringWithFormat:@"%d",(int)optionMuArr.count];
                        model.postKey = [NSString stringWithFormat:@"_%d",(int)optionMuArr.count];
                        [optionMuArr addObject:model];
                        [ticketTpyeView reloadData];
                    }
                }
            }
        }
        else {
            [Dialog toast:@"字段名称不能为空，请重新输入"];
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return optionMuArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 77;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MeetTicketOptionModel *model = [optionMuArr objectAtIndex:indexPath.row];
    static NSString *CellIdentifier = @"OptionsCell";
    OptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[OptionTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    }
    cell.index = indexPath.row;
    cell.delegate = self;
    cell.cleanBtn.tag = 50000+indexPath.row;
    cell.selectBtn.tag = indexPath.row+10000;
    cell.swichBtn.tag = indexPath.row+100000;
    cell.cellTitle = model.title;
    cell.selectBtn.selected = model.selectOption;
    cell.swichBtn.selected = model.sureOption;
    
    if (cell.selectBtn.selected == NO) {
        cell.swichBtn.hidden = YES;
    }
    else {
        cell.swichBtn.hidden = NO;
    }
    
    if (indexPath.row < 5) {
        cell.cleanBtn.hidden = YES;
    }
    else {
        cell.cleanBtn.hidden = NO;
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark --OptionDelegate
- (void)sureOption:(UIButton *)btn
{
    MeetTicketOptionModel *model = [optionMuArr objectAtIndex:(btn.tag-100000)];
    if ((btn.tag-100000) > 1) {
        btn.selected = !btn.selected;
    }
    model.sureOption = btn.selected;
    if (btn.selected == YES) {
        model.required = @"1";
    }else{
        model.required = @"0";
    }
    [optionMuArr replaceObjectAtIndex:(btn.tag-100000) withObject:model];
}

- (void)selectOption:(UIButton *)btn
{
    MeetTicketOptionModel *model = [optionMuArr objectAtIndex:(btn.tag-10000)];
    
    if ((btn.tag-10000) > 1 && (btn.tag-10000) < 5) {
        btn.selected = !btn.selected;
    }
    if (btn.selected == NO) {
        model.sureOption = NO;
        model.required = @"0";
    }

    model.selectOption = btn.selected;
    [optionMuArr replaceObjectAtIndex:(btn.tag-10000) withObject:model];
    [ticketTpyeView reloadData];
    int optionIndex = 0;
    for (int i = 0; i < optionMuArr.count; i++) {
        MeetTicketOptionModel *model = [optionMuArr objectAtIndex:i];
        if (model.selectOption == YES) {
            model.sn = [NSString stringWithFormat:@"%d",optionIndex];
            [optionMuArr replaceObjectAtIndex:i withObject:model];
            optionIndex++;
        }
    }
}

- (void)cleanOption:(UIButton *)btn
{
    [optionMuArr removeObjectAtIndex:btn.tag-50000];
    [ticketTpyeView reloadData];
}

//是否含有表情
- (BOOL)stringContainsEmoji:(NSString *)string
{
    __block BOOL returnValue = NO;
    
    [string enumerateSubstringsInRange:NSMakeRange(0, [string length])
                               options:NSStringEnumerationByComposedCharacterSequences
                            usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
                                const unichar hs = [substring characterAtIndex:0];
                                if (0xd800 <= hs && hs <= 0xdbff) {
                                    if (substring.length > 1) {
                                        const unichar ls = [substring characterAtIndex:1];
                                        const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                                        if (0x1d000 <= uc && uc <= 0x1f77f) {
                                            returnValue = YES;
                                        }
                                    }
                                } else if (substring.length > 1) {
                                    const unichar ls = [substring characterAtIndex:1];
                                    if (ls == 0x20e3) {
                                        returnValue = YES;
                                    }
                                } else {
                                    if (0x2100 <= hs && hs <= 0x27ff) {
                                        returnValue = YES;
                                    } else if (0x2B05 <= hs && hs <= 0x2b07) {
                                        returnValue = YES;
                                    } else if (0x2934 <= hs && hs <= 0x2935) {
                                        returnValue = YES;
                                    } else if (0x3297 <= hs && hs <= 0x3299) {
                                        returnValue = YES;
                                    } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                                        returnValue = YES;
                                    }
                                }
                            }];
    
    return returnValue;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
