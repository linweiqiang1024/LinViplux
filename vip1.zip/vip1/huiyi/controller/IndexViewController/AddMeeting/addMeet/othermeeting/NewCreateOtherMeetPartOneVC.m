//
//  NewCreateOtherMeetPartOneVC.m
//  huiyi
//
//  Created by 林伟强 on 2017/8/7.
//  Copyright © 2017年 linweiqiang. All rights reserved.
//

#import "NewCreateOtherMeetPartOneVC.h"
#import "NSString+URL.h"
#import "New_MyPublishViewController.h"

@interface NewCreateOtherMeetPartOneVC () <UIWebViewDelegate>

@property (nonatomic, strong) UIWebView * mainweb;

@end

@implementation NewCreateOtherMeetPartOneVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    
    self.titlelabel.text = _titleName;
    
    UIWebView * mainWeb = [[UIWebView alloc]initWithFrame:CGRectMake(0, 64, ScreenWidth, ScreenHeight-64)];
    mainWeb.scrollView.bounces = NO;
    
    //企业地址
    NSString * companyAddr = [[NSUserDefaults standardUserDefaults] objectForKey:@"companyAddr"];
    
    NSString * auth_session = [[NSUserDefaults standardUserDefaults] objectForKey:@"auth_session"];
    
    NSString * urlencodeStr;
    
    if (self.type == 0)
    {
        urlencodeStr = [[NSString stringWithFormat:@"/huiyi/static/dist/publishEvent.html?eventType=event&type=create"] URLEncodedString];
    }
    else
    {
        urlencodeStr = [[NSString stringWithFormat:@"/huiyi/static/dist/publishEvent.html?eventType=party&type=create"] URLEncodedString];
    }
    
    NSString * urlString = [NSString stringWithFormat:@"http://%@/huiyi/Act/Through/innerLink?xess=%@&href=%@", companyAddr, [auth_session URLEncodedString], urlencodeStr];
    
    NSURLRequest * request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    mainWeb.delegate = self;
    [mainWeb setScalesPageToFit:YES];
    [mainWeb loadRequest:request];
    [self.view addSubview:mainWeb];
    self.mainweb = mainWeb;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString * urlStr = [request URL].absoluteString;
    
    urlStr = [urlStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSRange range = [urlStr rangeOfString:@"manageEvent.html"];
    if (range.location != NSNotFound)
    {
        New_MyPublishViewController * myPublishVC = [[New_MyPublishViewController alloc]init];
        myPublishVC.isMyPublish = YES;
        myPublishVC.isFromMeetTypeVC = YES;
        [self.navigationController pushViewController:myPublishVC animated:YES];
        
        return NO;
    }
    
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
