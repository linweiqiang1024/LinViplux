//
//  AddCompanyView.h
//  huiyi
//
//  Created by songhongshuai on 15/8/19.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddCompanyView : UIView


@end
