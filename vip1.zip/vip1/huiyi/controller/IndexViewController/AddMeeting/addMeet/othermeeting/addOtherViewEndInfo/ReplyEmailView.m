//
//  ReplyEmailView.m
//  huiyi
//
//  Created by 林伟强 on 16/12/29.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "ReplyEmailView.h"
#import "Helper.h"

@interface ReplyEmailView () <UITextFieldDelegate>

@end

@implementation ReplyEmailView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self creatUI];
    }
    return self;
}

- (void)creatUI
{
    UILabel *topline = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(topline, @"#c8c7cc");
    [self  addSubview:topline];
    
    UILabel *endline = [[UILabel alloc]initWithFrame:CGRectMake(0, 79.5, ScreenWidth, 0.5)];
    BackGround16Color(endline, @"#c8c7cc");
    [self addSubview:endline];
    
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *emailLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 0.5, 250, 44)];
    emailLB.text = @"活动联系邮箱";
    emailLB.font = [UIFont systemFontOfSize:16];
    emailLB.textColor = [UIColor colorWithHexString:@"#373737"];
    [self addSubview:emailLB];
    
    NSString *placeholderText = @"参会者收到email时回复电子邮件时的默认地址";
    NSInteger placeHolderFont = 16;
    
    self.emailTextFiled = [[UITextField alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(emailLB.frame), ScreenWidth-24, 30)];
    self.emailTextFiled.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
    self.emailTextFiled.backgroundColor = [UIColor clearColor];
    self.emailTextFiled.keyboardType = UIKeyboardTypeASCIICapable;
    self.emailTextFiled.returnKeyType = UIReturnKeyDone;
    self.emailTextFiled.placeholder = placeholderText;
    self.emailTextFiled.font = [UIFont systemFontOfSize:placeHolderFont];
    self.emailTextFiled.delegate = self;
    [self.emailTextFiled addTarget:self action:@selector(textFiledChange:) forControlEvents:UIControlEventEditingChanged];
    [self addSubview:self.emailTextFiled];
    
    /*
    if ([Helper widthOfString:placeholderText font:[UIFont systemFontOfSize:16] height:35] > self.emailTextFiled.width) {
        self.emailTextFiled.font = [UIFont systemFontOfSize:14];
    }*/
    
    while ([Helper widthOfString:placeholderText font:[UIFont systemFontOfSize:placeHolderFont] height:35] > self.emailTextFiled.width) {
        placeHolderFont--;
        self.emailTextFiled.font = [UIFont systemFontOfSize:placeHolderFont];
    }
}

- (void)textFiledChange:(UITextField *)textField
{
    if ([_delegate respondsToSelector:@selector(replyEmailChange:)]) {
        [_delegate replyEmailChange:textField.text];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
