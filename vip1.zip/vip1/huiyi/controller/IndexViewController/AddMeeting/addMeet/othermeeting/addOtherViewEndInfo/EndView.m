//
//  EndView.m
//  NewTicketDemo
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 浙江海宁山顶汇聚信息科技有限公司. All rights reserved.
//

#import "EndView.h"
#import "UIImageView+WebCache.h"
#import "UIDesView.h"
#import "Helper.h"

#define ImagePlace 15

@interface EndView() <DeleteImageDelegate,UITableViewDataSource,UITableViewDelegate,changeViewFrame>
{
    BOOL isCamera;
    UITableView *tableViews;
    UILabel *endline ;
}
@end

@implementation EndView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self creatUI];
    }
    return self;
}

- (void)creatUI
{
    self.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    
    UILabel *topline = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(topline, @"#c8c7cc");
    [self addSubview:topline];
    
    UIView *addImageView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(topline.frame), ScreenWidth, 0)];
    addImageView.backgroundColor = [UIColor whiteColor];
    [self addSubview:addImageView];
    
    NSMutableAttributedString *e_time_str = [[NSMutableAttributedString alloc] initWithString:@"上传活动海报（推荐上传横版图片）"];
    [e_time_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0, 6)];
    [e_time_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(6, 10)];
    [e_time_str addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:16] range:NSMakeRange(0, e_time_str.string.length)];
    
    UILabel *imageTitleLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 0, ScreenWidth-24, 43)];
    imageTitleLb.backgroundColor = [UIColor clearColor];
    imageTitleLb.font = [UIFont systemFontOfSize:16];
    imageTitleLb.attributedText = e_time_str;
    [addImageView addSubview:imageTitleLb];
    
    tableViews = [[UITableView alloc] init];
    tableViews.delegate = self;
    tableViews.dataSource = self;
    tableViews.backgroundColor = [UIColor clearColor];
    tableViews.pagingEnabled = NO;
    tableViews.showsHorizontalScrollIndicator = NO;
    tableViews.showsVerticalScrollIndicator = NO;
    //tableViews.contentOffset = CGPointMake(0, 320);
    //[tableViews.layer setAnchorPoint:CGPointMake(0.0, 0.0)];
    //tableview逆时针旋转90度。
    tableViews.transform = CGAffineTransformMakeRotation(-M_PI /2);
    tableViews.frame = CGRectMake(12, CGRectGetMaxY(imageTitleLb.frame)-14, ScreenWidth-24, 80);
    tableViews.separatorStyle = UITableViewCellSeparatorStyleNone;
    [addImageView addSubview:tableViews];
    
    UILabel *midline = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(tableViews.frame)+20, ScreenWidth, 0.5)];
    BackGround16Color(midline, @"#c8c7cc");
    [addImageView addSubview:midline];
    
    addImageView.size = CGSizeMake(ScreenWidth, CGRectGetMaxY(midline.frame));
    NSString *str = @"提示：发布违法反动活动信息或冒用他人、组织名义发起活动，将依据记录提交公安机关处理。";
    //CGSize size = [str sizeWithFont:[UIFont systemFontOfSize:14] constrainedToSize:CGSizeMake(ScreenWidth-30, 300) lineBreakMode:NSLineBreakByCharWrapping ];
    CGFloat strHeight = [Helper heightOfString:str font:[UIFont systemFontOfSize:14] width:ScreenWidth-24];
    
    UILabel * desLable = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(addImageView.frame)+10, ScreenWidth-24, strHeight)];
    desLable.backgroundColor = [UIColor clearColor];
    desLable.font = [UIFont systemFontOfSize:14];
    desLable.text = @"提示：发布违法反动活动信息或冒用他人、组织名义发起活动，将依据记录提交公安机关处理。";
    desLable.textColor = [UIColor colorWithHexString:@"#a39f9f"];
    desLable.lineBreakMode = NSLineBreakByCharWrapping;
    desLable.numberOfLines = 0;
    [self addSubview:desLable];
    
    endline = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(desLable.frame)+10, ScreenWidth, 0.5)];
    BackGround16Color(endline, @"#c8c7cc");
    [self addSubview:endline];
    
    _viewHeight = CGRectGetMaxY(endline.frame);
}

- (void)changeEndViewHight:(CGFloat)height
{
    if ([_delegate respondsToSelector:@selector(changeEndViewHight:)]) {
        [_delegate changeEndViewHight:CGRectGetMaxY(endline.frame)];
    }
}

- (void)selectImage
{
    [_delegate addSelectImage];
}

- (void)reloadImages:(NSArray *)imageArr
{
    _imageArr = imageArr;
    [tableViews reloadData];
}

//- (void)setImage:(UIImage *)img Index:(NSInteger)index
//{
//    
//
//    for (int i=0; i<_ImageScrollView .subviews.count; i++) {
//        UIImageView *imageView = [_ImageScrollView .subviews objectAtIndex:i];
//        if (imageView.tag == index+100) {
//            SDImageView *view = (SDImageView*)imageView;
//            view.midImageView.image = img;
//            imageView.hidden = NO;
//            
//            _addImageBtn.frame = CGRectMake(12+(94+ImagePlace)*(index+1), 10, 94, 58);
//            _ImageScrollView.contentSize = CGSizeMake(CGRectGetMaxX(_addImageBtn.frame), 78);
//
//        }
//    }
//    
//}

- (void)setImages:(UIImage *)img ImageArr:(NSArray *)imgArr
{
    _imageArr = imgArr;
    [tableViews reloadData];
}

- (void)deleteBtnClick:(UIButton *)btn
{
    [_delegate deleteImageWith:btn];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (_imageArr.count < 5) {
        return _imageArr.count+1;
    }
    else{
        return _imageArr.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 119;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"TableViewCell";
    
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
    
    cell.transform = CGAffineTransformMakeRotation(M_PI/2);
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.contentView.backgroundColor = [UIColor clearColor];
    
    if (indexPath.row == _imageArr.count && _imageArr.count < 5) {
        UIButton *addImageBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
        addImageBtn.frame = CGRectMake(0, 20, 94, 58);
        addImageBtn.backgroundColor = [UIColor clearColor];
        addImageBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
        [addImageBtn setImage:[UIImage imageNamed:@"addPosterBtn"] forState:UIControlStateNormal];
        [addImageBtn addTarget:self action:@selector(selectImage) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:addImageBtn];
    }
    else {
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 20, 94, 58)];
        //[imageView sd_setImageWithURL:[NSURL URLWithString:[_imageArr objectAtIndex:indexPath.row]] placeholderImage:[UIImage imageNamed:@"poster_bg"]];
        BackGroundColor(imageView, clearColor);
        imageView.image = [_imageArr objectAtIndex:indexPath.row];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        imageView.layer.borderWidth = 1;
        imageView.layer.borderColor = [[UIColor colorWithHexString:@"#d3d3d3"] CGColor];
        imageView.tag = indexPath.row+10;
        imageView.userInteractionEnabled = YES;
        UIGestureRecognizer *oneFingerOneTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Gesture:)];
        [imageView addGestureRecognizer:oneFingerOneTaps];
        [cell.contentView addSubview:imageView];
        
        UIImageView *FirstView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 39, 18)];
        FirstView.center = CGPointMake(imageView.center.x, 58-10);
        FirstView.backgroundColor = [UIColor clearColor];
        FirstView.image = [UIImage imageNamed:@"first_page"];
        if (indexPath.row == 0) {
            FirstView.hidden = NO;
        }
        else {
            FirstView.hidden = YES;
        }
        [imageView addSubview:FirstView];
        
        UIButton *_delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _delBtn.frame = CGRectMake(0, 0, 50, 50);
        _delBtn.center = CGPointMake(CGRectGetMaxX(imageView.frame), 20);
        _delBtn.tag = indexPath.row+100;
        _delBtn.hidden = NO;
        _delBtn.backgroundColor = [UIColor clearColor];
        [_delBtn setImage:[UIImage imageNamed:@"delPoster"] forState:UIControlStateNormal];
        [_delBtn addTarget:self action:@selector(deleteBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:_delBtn];
    }
    return cell;
}

- (void)Gesture:(UITapGestureRecognizer *)tap
{
    [_delegate showBigImage:tap];
}

- (void)deleteImage:(UIButton *)btn
{
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
