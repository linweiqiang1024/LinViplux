//
//  OrganizerCell.h
//  huiyi
//
//  Created by songhongshuai on 15/8/18.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol OrganizerCellDelegate <NSObject>

- (void)callBackOrganizerName:(NSString*)OrganizerName withIndexPath:(NSIndexPath *)indexPath;

@end

@interface OrganizerCell : UITableViewCell
@property (nonatomic,strong)NSString *postKey;
@property (nonatomic,strong)NSString *content;
@property (nonatomic,strong)NSIndexPath *indexPath;
@property (nonatomic,weak)id<OrganizerCellDelegate>delegate;
@property (nonatomic)BOOL isEndLine;

@end
