//
//  HintAlertView.h
//  huiyi
//
//  Created by 林伟强 on 16/12/29.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HintAlertViewDelegate <NSObject>

- (void)hintAlertViewAction;

@end

@interface HintAlertView : UIView

@property (nonatomic, strong) UIControl *mycontrol;
@property (nonatomic, strong) UIView    *bgView;
@property (nonatomic, strong) UILabel   *topLabel;
@property (nonatomic, strong) UILabel   *textLabel;
@property (nonatomic, strong) UIView    *lineView;
@property (nonatomic, strong) UILabel   *nextLabel;
@property (nonatomic, strong) UIButton  *nextButton;
@property (nonatomic, strong) UIView    *nextLineView;
@property (nonatomic, strong) UILabel   *cancelLabel;
@property (nonatomic, strong) UIButton  *cancelButton;
@property (nonatomic, weak)   id <HintAlertViewDelegate> delegate;

- (void)reloadViewWithTitle:(NSString *)title message:(NSString *)message range:(NSRange)range cancelButtonTitle:(NSString *)cancelButtonTitle otherButtonTitle:(NSString *)otherButtonTitle  messageAlignment:(NSTextAlignment)messageAlignment;
- (void)show;
- (void)cancel;

@end
