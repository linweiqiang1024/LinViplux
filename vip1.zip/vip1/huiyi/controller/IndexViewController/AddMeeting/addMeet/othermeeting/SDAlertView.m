//
//  SDAlertView.m
//  huiyi
//
//  Created by songhongshuai on 15/1/26.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SDAlertView.h"

typedef enum {
    STAlertViewTypeNormal,
    STAlertViewTypeTextField
} STAlertViewType;

@implementation SDAlertView
{
    SDAlertViewBlock cancelButtonBlock;
    SDAlertViewBlock otherButtonBlock;
    
    SDAlertViewStringBlock textFieldBlock;
}
- (void) alertView:(UIAlertView *)theAlertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0 && cancelButtonBlock)
        cancelButtonBlock();
    else if (buttonIndex == 1 && theAlertView.tag == STAlertViewTypeNormal && otherButtonBlock)
        otherButtonBlock();
    else if (buttonIndex == 1 && theAlertView.tag == STAlertViewTypeTextField && textFieldBlock)
        textFieldBlock([_alertView textFieldAtIndex:0].text);
    
}

- (void) alertViewCancel:(UIAlertView *)theAlertView
{
    if (cancelButtonBlock)
        cancelButtonBlock();
}
- (id)initWithTitle:(NSString *)title              message:(NSString*)message
      textFieldHint:(NSString*)textFieldMessage
     textFieldValue:(NSString *)texttFieldValue
  cancelButtonTitle:(NSString *)cancelButtonTitle
  otherButtonTitles:(NSString *)otherButtonTitles
  cancelButtonBlock:(SDAlertViewBlock)theCancelButtonBlock
   otherButtonBlock:(SDAlertViewStringBlock)theOtherButtonBlock{
    cancelButtonBlock = [theCancelButtonBlock copy];
    textFieldBlock = [theOtherButtonBlock copy];
    
    _alertView = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:cancelButtonTitle otherButtonTitles:otherButtonTitles, nil];
    _alertView.tag = STAlertViewTypeTextField;
    
    _alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    [[_alertView textFieldAtIndex:0] setPlaceholder:textFieldMessage];
    [[_alertView textFieldAtIndex:0] setText:texttFieldValue];

    [_alertView show];
    
    return self;
}
@end
