//
//  SDToolBarView.h
//  huiyi
//
//  Created by songhongshuai on 15/1/6.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol SDToolBarDelegage <NSObject>
/**
 *  呼出自定义相册
 */
- (void)selectImage;
/**
 *  删除详情内容
 */
- (void)delContent;
/**
 *  隐藏键盘
 */
- (void)HideKeyBoard;

@end
@interface SDToolBarView : UIView
@property (nonatomic,weak)id<SDToolBarDelegage>delegate;
@property (nonatomic,strong)UIButton *delBtn;
@property (nonatomic,strong)UIButton *hideBtn;
@property (nonatomic,strong)UIButton *imageBtn;

@end
