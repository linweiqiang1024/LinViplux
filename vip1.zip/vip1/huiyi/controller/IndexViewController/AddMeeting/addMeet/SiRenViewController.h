//
//  SiRenViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/1/4.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface SiRenViewController : FatherViewController
@property (nonatomic)int type;
@property (nonatomic,strong) NSString * titleName;
@property (nonatomic,strong) NSDictionary *meet_label;
@property (nonatomic,strong) NSDictionary *meetnew_label;
@end
