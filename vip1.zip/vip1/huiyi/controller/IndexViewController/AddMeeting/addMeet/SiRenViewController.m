//
//  SiRenViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/1/4.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SiRenViewController.h"
#import "New_managerViewController.h"
#import <QuartzCore/QuartzCore.h>
#import <AssetsLibrary/AssetsLibrary.h>
//#import "ImageAttachmentCell.h"
#import "MinePutOutViewController.h"
#import "SlideAttachmentCell.h"
#import "EmotionAttachmentCell.h"
#import <CoreText/CoreText.h>
#import "UIImage-Extensions.h"
#import "LoginViewController.h"
#import "NSAttributedString+TextUtil.h"
#import "TextConfig.h"
#import "TextParagraph.h"
#import "MD5Util.h"
#import "UITypeButton.h"
#import "SevenSwitch.h"
#import "PureLayout.h"
#import "GTMBase64.h"
#import "LocalPhotoViewController.h"
#import "SDToolBarOfHideView.h"
#import "SDToolBarView.h"
#import "FastTextView.h"
#import "UICostTypeButton.h"
#import "SDTimeActiontSheet.h"
#import "CreatMeetTextField.h"
#import "OpenPersonalCell.h"
#import "TOCropViewController.h"

#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <CoreLocation/CoreLocation.h>

#import "Helper.h"
#import "ReplyEmailView.h"
#import "HintAlertView.h"

#define NAVBAR_HEIGHT 44.0f
#define TABBAR_HEIGHT 49.0f
#define STATUS_HEIGHT 20.0f

#define TOP_VIEW_HEIGHT 35.0f
#define TOP_VIEW_WIDTH 48.0f
#define ARRSIZE(a) (sizeof(a) / sizeof(a[0]))

@interface SiRenViewController () <UITextFieldDelegate,SDTimeActionSheetDelegate,SDToolBarDelegage,UIAlertViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,SDToolBarDelegage,HideKeyboardDelegate,SelectPhotoDelegate,TOCropViewControllerDelegate,UITableViewDelegate,UITableViewDataSource,ReplyEmailViewDelegate,HintAlertViewDelegate>
{
    BOOL startBtnSelect;
    BOOL endBtnSelect;
    BOOL isAddSlide;
    BOOL keyBoardShow;
    BOOL eidtTextFiled;
    BOOL isCamera;//选择相机；
    CGFloat origin_y;
    NSInteger imageId;//记录图片放入缓存的id
    CGSize keyBoardSize;
    UILabel *line;
    UILabel *line1;
    UILabel *line2;
    UILabel *contentSepLb;
    UIView *detailView;
    BOOL _didSetupConstraints;
    UIButton *scleanBtn;
    UIButton *enCleanBtn;
    
    NSMutableDictionary *picMuDict;
    
    SDTimeActiontSheet * _dateActionSheet;
    NSMutableDictionary *_postDic;
    NSMutableArray *picMuArr;
    NSMutableArray *picCacheArr;
    NSMutableArray *picUrlMuArr;
    NSMutableArray *oldPicUrlMuArr;
    NSMutableArray *meetTypeArr;
    NSString *costStr;
    __block int imageIndex ;
    __block int imageCount ;
    __block Dialog *hud;
    NSString * insert_id;
    NSString *contentStr;//记录Html化的content
}
@property (nonatomic,strong)SDTimeActiontSheet *dateActionSheet;
@property (nonatomic,strong)UIScrollView *mainScrollView;
@property (nonatomic,strong)UIView *titleView;
@property (nonatomic,strong)CreatMeetTextField *titleTF;
@property (nonatomic,strong)UIView *contentView;

@property (nonatomic,strong)FastTextView *contentTextView;
@property (nonatomic,strong)SDToolBarView *toolBar;

@property (nonatomic,strong)UIView *descView;
@property (nonatomic,strong)UILabel *sTimeBtn;
@property (nonatomic,strong)UILabel *eTimeBtn;

@property (nonatomic,strong)UITypeButton *meetTypeBtn1;
@property (nonatomic,strong)UITypeButton *meetTypeBtn2;
@property (nonatomic,strong)UITypeButton *meetTypeBtn3;

@property (nonatomic,strong)UICostTypeButton *costTypeBtn1;
@property (nonatomic,strong)UICostTypeButton *costTypeBtn2;
@property (nonatomic,strong)UICostTypeButton *costTypeBtn3;
@property (nonatomic,strong)UICostTypeButton *costTypeBtn4;


@property (nonatomic,strong)CreatMeetTextField *addressTF;
@property (nonatomic,strong)UIView *endDescView;
@property (nonatomic,strong)UIView *endView;
@property (nonatomic,strong)UILabel *endLb;
@property (nonatomic,strong)UIView *personalView;
@property (nonatomic,strong)UITableView *personalTableView;
@property (nonatomic,strong)NSMutableArray *personalArr;
@property (nonatomic,assign)NSInteger select;
@property (nonatomic,assign)BOOL personalChangeFrame;
@property (nonatomic,strong)ReplyEmailView *replyEmailView;
@end

@implementation SiRenViewController

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if (self.dateActionSheet.isShow == YES) {
        [self.dateActionSheet tappedCancel];
    }
    keyBoardShow = NO;
    self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width,ScreenHeight-self.F_NAV_HEIGHT );
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [MobClick endLogPageView:@"SiRenViewController"];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}
/**
 *  从content里获取<img src=""/>
 *
 *  @param content 页面内容
 *
 *  @return 多个<img src=""/>
 */
- (NSArray *)getHtmlUrl:(NSString *)content
{
    NSString *s = @"<(\\w+)\\s*src=\\\"(\\w+.*?)\\\"\\s*/>";
    NSMutableArray *muUrlArr = [[NSMutableArray alloc]initWithCapacity:0];
    NSError *error;
    //NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [content substringWithRange:match.range];
        substringForMatch = [substringForMatch substringFromIndex:10];
        substringForMatch = [substringForMatch substringWithRange:NSMakeRange(0,substringForMatch.length-4)];
        [muUrlArr addObject:substringForMatch];
    }
    NSArray *arr = muUrlArr;
    return arr;
}
/**
 *  获取图片的真正地址
 *
 *  @param htmlTap <img src="askjdlkasjdalsd"/>
 *
 *  @return URL
 */
- (NSString *)getImageUrl:(NSString *)htmlTap
{
    NSString *s = @"\"(\\w+.*?)\\\"";
    NSError *error;
    //NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:htmlTap options:0 range:NSMakeRange(0, [htmlTap length])];
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [htmlTap substringWithRange:match.range];
        substringForMatch = [substringForMatch substringWithRange:NSMakeRange(1,substringForMatch.length-2)];
        [picUrlMuArr addObject:substringForMatch];
        return substringForMatch;
    }
    return nil;
}

- (void)ReturnBtn
{
    NSArray * arr = [NSArray arrayWithArray:picMuArr];
    [picCacheArr removeAllObjects];
    if (contentStr != 0) {
        [_postDic setObject:contentStr forKey:@"summary"];
        NSArray *urlArr = [self getHtmlUrl:contentStr];
        for (int i = 0; i<urlArr.count; i++) {
            NSString *url = [urlArr objectAtIndex:i];
            int index = [[url substringWithRange:NSMakeRange(1, 1)] integerValue];
            [picCacheArr addObject:[arr objectAtIndex:index-1]];
            [self saveImageToDocument:[arr objectAtIndex:index-1] imageName:url withMeetingType:@"1"];
        }
    }
    else {
        
    }
    
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
    [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",(int)picCacheArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
    
    NSString *meetType = [meetTypeArr componentsJoinedByString:@","];
    NSString *meetTypes = [meetType stringByReplacingOccurrencesOfString:@"0," withString:@""]
    ;
    meetTypes = [meetTypes stringByReplacingOccurrencesOfString:@"0" withString:@""];
    if (meetTypes.length) {
        if (meetTypes.length%2 == 0) {
            meetTypes = [meetTypes substringToIndex:(meetTypes.length - 1)];
        }
    }
    
    [_postDic setObject:meetTypes forKey:@"activity"];
    [_postDic setObject:costStr forKey:@"expenses"];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [dic setObject:@"1" forKey:@"nickname"];
    [dic setObject:@"1" forKey:@"phone"];
    [_postDic setObject:[dic JSONString] forKey:@"fieldArr"];
    [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
    [[DBManager sharedInstance] insertDataToPublicDB:[_postDic JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
    
    [_contentTextView removeFromSuperview];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)keyboardWillShow:(NSNotification *)notification
{
    NSDictionary* info = [notification userInfo];
    keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    
    if (keyBoardShow == YES && eidtTextFiled == NO) {//选中文本域时
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width, ScreenHeight-self.F_NAV_HEIGHT-origin_y-keyBoardSize.height-TOP_VIEW_HEIGHT );
        self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
        self.toolBar.hideBtn.hidden = NO;//显示完成按钮
        self.toolBar.frame = CGRectMake(0, ScreenHeight-keyBoardSize.height-35, ScreenWidth,TOP_VIEW_HEIGHT );
        [self.view addSubview:self.toolBar];
        [self.view bringSubviewToFront:self.toolBar];//改变toolbar的位置
    }
    else {//选中文本框时 不操作toolbar
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width, ScreenHeight-self.F_NAV_HEIGHT-origin_y-keyBoardSize.height );
    }
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    NSDictionary* info = [notification userInfo];
    keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    if (keyBoardShow == YES) {
        if (_contentTextView.contentSize.height < 70) {
            
        }
        else {
            
        }
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width,ScreenHeight-self.F_NAV_HEIGHT );
        self.toolBar.delBtn.hidden = NO;//隐藏删除按钮
        self.toolBar.hideBtn.hidden = YES;//显示完成按钮
        self.toolBar.frame = CGRectMake(0, _contentView.size.height-TOP_VIEW_HEIGHT, ScreenWidth, TOP_VIEW_HEIGHT);
        [_contentView addSubview:self.toolBar];
        [_contentView bringSubviewToFront:self.toolBar];//改变toolbar的位置
    }
    else {
        self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width, ScreenHeight-self.F_NAV_HEIGHT );
    }
}

- (void)selectImage
{
    [self.view endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                  initWithTitle:nil
                                  delegate:self
                                  cancelButtonTitle:@"取消"
                                  destructiveButtonTitle:nil
                                  otherButtonTitles:@"打开照相机",@"从手机相册获取",nil];
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    /*
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if (![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) {
        sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    }
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    //[picker.navigationItem.backBarButtonItem setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]} forState:UIControlStateNormal];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = sourceType;
    
    switch (buttonIndex) {
        case 0:  //打开照相机拍照
            picker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentViewController:picker animated:YES completion:^{
                [[UIApplication sharedApplication] setStatusBarHidden:YES];
            }];
            break;
        case 1:  //打开本地相册
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [self presentViewController:picker animated:YES completion:nil];
            break;
    }*/
    
    if (0 == buttonIndex) {
        //相机权限
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        if (authStatus ==AVAuthorizationStatusRestricted ||//此应用程序没有被授权访问的照片数据。可能是家长控制权限
            authStatus ==AVAuthorizationStatusDenied)  //用户已经明确否认了这一照片数据的应用程序访问
        {
            /*
             // 无权限 引导去开启
             NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
             if ([[UIApplication sharedApplication] canOpenURL:url]) {
             [[UIApplication sharedApplication] openURL:url];
             }*/
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无访问权限" message:@"会议邦只有获得您的相机权限才能正常使用。请按照以下步骤开启：系统设置->隐私->相机->会议邦（打开）" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"立即设置",nil];
            [alert setTag:2600];
            [alert show];
        }
        else {
            //相机
            isCamera = YES;
            UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
            pickerController.delegate = self;
            pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            pickerController.allowsEditing = NO;
            [self presentViewController:pickerController animated:NO completion:^{
                [[UIApplication sharedApplication] setStatusBarHidden:YES];
            }];
        }
        
    }
    else if (1 == buttonIndex) {
        //相册权限
        ALAuthorizationStatus author = [ALAssetsLibrary authorizationStatus];
        if (author ==kCLAuthorizationStatusRestricted || author ==kCLAuthorizationStatusDenied)
        {
            /*
             //无权限 引导去开启
             NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
             if ([[UIApplication sharedApplication] canOpenURL:url]) {
             [[UIApplication sharedApplication] openURL:url];
             }*/
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"无访问权限" message:@"会议邦只有获得您的照片权限才能正常使用。请按照以下步骤开启：系统设置->隐私->照片->会议邦（打开）" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"立即设置",nil];
            [alert setTag:2600];
            [alert show];
        }
        else {
            //相册
            isCamera = NO;
            LocalPhotoViewController *pick=[[LocalPhotoViewController alloc] init];
            self.navigationItem.backBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleBordered target:nil action:nil];
            pick.isFromCreateMeet = YES;
            pick.isPoster = NO;
            pick.selectPhotoDelegate = self;
            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:pick];
            [self presentViewController:navigationController animated:YES completion:false];
        }
    }
}

- (void)delContent
{
    [_postDic setObject:@"" forKey:@"summary"];
    [oldPicUrlMuArr removeAllObjects];
    [picMuArr removeAllObjects];
    [picUrlMuArr removeAllObjects];
    
    _contentTextView.text = @"";
    _contentTextView.frame = CGRectMake(_contentTextView.origin.x, _contentTextView.origin.y, _contentTextView.contentSize.width,70);
    _contentView.frame = CGRectMake(_contentView.origin.x, _contentView.origin.y, _contentView.size.width, 128);
    line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
    _toolBar.frame=CGRectMake(0, CGRectGetHeight(_contentView.frame)-35, ScreenWidth, 35);
    detailView.frame = CGRectMake(detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, detailView.size.width, detailView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame)+11);
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, self.contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)HideKeyBoard
{
    [self.view endEditing:YES] ;
}

- (NSString *)replaceBr:(NSString *)content
{
    NSString *s = @"<br>";
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    for (int i = 0; i < arrayOfAllMatches.count; i++) {
        content = [content stringByReplacingOccurrencesOfString:@"<br>" withString:@"\n"];
    }
    return content;
}

- (NSString *)rePlaceUrl:(NSString*)content
{
    NSString *s = @"<(\\w+)\\s*src=\\\"a(\\w+.*?)\\\"\\s*/>";
    NSError *error;
    //NSString *regulaStr = @"\\bhttps?://[a-zA-Z0-9\\-.]+(?::(\\d+))?(?:(?:/[a-zA-Z0-9\\-._?,'+\\&%$=~*!():@\\\\]*)+)?";
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    if (picUrlMuArr.count < arrayOfAllMatches.count) {
        for (int i = 0; i < picUrlMuArr.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
            content = [content stringByReplacingOccurrencesOfString:substringForMatch withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:i]]];
            NSLog(@"%@",substringForMatch);
        }
        for (int j = picUrlMuArr.count; j< arrayOfAllMatches.count; j++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:j];
            //NSString* substringForMatch1 = [content substringWithRange:match.range];
            content = [content stringByReplacingCharactersInRange:match.range withString:@""];
        }
    }
    else {
        for (int i = 0; i<arrayOfAllMatches.count; i++) {
            NSTextCheckingResult *match = [arrayOfAllMatches objectAtIndex:i];
            NSString* substringForMatch = [content substringWithRange:match.range];
            [oldPicUrlMuArr addObject:substringForMatch];
        }
    }
    for (int index = 0; index<picUrlMuArr.count; index++) {
        content = [content stringByReplacingOccurrencesOfString:[oldPicUrlMuArr objectAtIndex:index] withString:[NSString stringWithFormat:@"<img src=\"%@\"/>",[picUrlMuArr objectAtIndex:index]]];
    }
    return content;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.titlelabel.text = _titleName;
    
    hud = [[Dialog alloc]init];
    
    _type = 1;
    imageId = 0;
    imageIndex = 1;
    
    picCacheArr = [[NSMutableArray alloc]initWithCapacity:0];//缓存图片
    picMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    picUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    picMuDict = [[NSMutableDictionary alloc]initWithCapacity:0];
    oldPicUrlMuArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    meetTypeArr = [[NSMutableArray alloc]initWithCapacity:0];
    [meetTypeArr addObject:@"1"];
    [meetTypeArr addObject:@"0"];
    [meetTypeArr addObject:@"0"];
    
    costStr = @"4";//费用 默认4 待定
    
    self.select = 0;
    self.personalArr = [[NSMutableArray alloc]initWithCapacity:0];
    self.personalArr = [@[@"公开姓名",@"仅公开姓氏（例：张**）",@"公开姓名、单位、职务"]mutableCopy];
    
    _postDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [_postDic setObject:@"1" forKey:@"openstatus"];
    [_postDic setObject:@"0" forKey:@"personal_data_sw"];
    self.view.backgroundColor = [UIColor colorWithHexString:@"efeff4"];
    
    int maxImageCount = [[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"type_%d_imageCount",_type] ] intValue];
    if (maxImageCount > 0) {
        //[imageDic addEntriesFromDictionary:[[[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"cache_meetingType_%d",_type+1]] JSONValue]];
        for (int imageID = 0; imageID < maxImageCount; imageID++) {
            NSString *key = [NSString stringWithFormat:@"a%d.jpg",imageID +1];
            UIImage *image = [self getImageFormDocument:key withMeetingType:@"1"];
            [picCacheArr addObject:image];
        }
    }
    [self creatUI];
}

- (void)textChange:(UITextField*)textField
{
    if (textField.tag == 101) {
         [_postDic setObject:textField.text forKey:@"title"];
    }
    if (textField.tag == 102) {
        [_postDic setObject:textField.text forKey:@"location"];
    }
}

- (void)creatRightNav
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(ScreenWidth-60, _navheight+10, 50, 25);
    [rightbtn setTitle:@"创建" forState:UIControlStateNormal];
    [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    rightbtn.layer.cornerRadius = 2.0f;
    rightbtn.clipsToBounds = YES;
    rightbtn.titleLabel.font = YHUI(14);
    [rightbtn setBackgroundImage:[self creatImageWithColol:RGBCOLOR(100, 198, 81) Size:rightbtn.frame.size] forState:UIControlStateNormal];
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    rightbtn.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:rightbtn];
}

- (void)creatPostData
{
    [_postDic setObject:self.meet_label forKey:@"meet_label"];
    [_postDic setObject:self.meetnew_label forKey:@"new_label"];
    [_postDic setObject:contentStr forKey:@"summary"];
    NSString *meetType = [meetTypeArr componentsJoinedByString:@","];
    NSString *meetTypes = [meetType stringByReplacingOccurrencesOfString:@"0," withString:@""];
    meetTypes = [meetTypes stringByReplacingOccurrencesOfString:@"0" withString:@""];
    if (meetTypes.length%2 == 0) {
        meetTypes = [meetTypes substringToIndex:(meetTypes.length - 1)];
    }
    [_postDic setObject:meetTypes forKey:@"activity"];
    [_postDic setObject:costStr forKey:@"expenses"];
    //NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithCapacity:0];
    //[dic setObject:@"1" forKey:@"nickname"];
    //[dic setObject:@"1" forKey:@"phone"];
    //[_postDic setObject:[dic JSONString] forKey:@"fieldArr"];
    if ([[_postDic objectForKey:@"title"] length] == 0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动主题不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"title"] length] < 1) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动主题大于1个汉字" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"summary"] length] < 1) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请输入更多活动详情内容" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"begin_time"] length] == 0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动开始时间不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
        return;
    }
    else if ([[_postDic objectForKey:@"location"] length] == 0) {
        if(_type == 1) {
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动地点不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
        else {
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"会议地址不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            [alertView show];
        }
        return;
    }
    else if ([[_postDic objectForKey:@"activity"] length] == 0) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请选择活动形式" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }
    else if ([[_postDic objectForKey:@"reply_email"] length] != 0 && ![Helper justEmail:[_postDic objectForKey:@"reply_email"]]) {
        UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"活动联系邮箱格式不正确" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alertView show];
    }
    else {
        [_postDic setObject:[NSString stringWithFormat:@"%d",(_type)] forKey:@"type"];
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] != 0) {
            if ([[_postDic objectForKey:@"reply_email"] length] != 0) {
                NSString *reply_email = [_postDic objectForKey:@"reply_email"];
                NSString *message = [NSString stringWithFormat:@"您填写的活动联系邮箱：%@非常重要！是参会者收到Email时回复电子邮件时的默认地址，如果填写错误您将无法收到参会者的回复邮件！您确认该邮箱正确可用吗？",reply_email];
                HintAlertView *hintAlertView = [[HintAlertView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
                hintAlertView.delegate = self;
                [hintAlertView reloadViewWithTitle:@"提示" message:message range:NSMakeRange(11, message.length-74) cancelButtonTitle:@"取消" otherButtonTitle:@"确认可用"  messageAlignment:NSTextAlignmentLeft];
                [hintAlertView show];
            }
            else {
                [_postDic setObject:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]forKey:@"user_id"];
                if (picMuArr.count == 0) {
                    [[Dialog Instance] showCenterProgressWithLabel:@"上传中..."];
                    [MyDataService postAddMeeting:_postDic callback:^(id data) {
                        NSLog(@"%@",data);
                        [[Dialog Instance] hideProgress];
                        if([[data objectForKey:@"code"]isEqualToString:@"200"] || [[data objectForKey:@"code"] objectForKey:@"201"])
                        {
                            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                            [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                            insert_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                            [self SetBaseField];
                        }
                    }];
                }
                else {
                    imageCount = picMuArr.count;
                    [picUrlMuArr removeAllObjects];
                    [self postImageWithImages:picMuArr];
                    NSLog(@"%@",_postDic);
                }
            }
        }
        else {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提示" message:@"是否登录会议邦?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            alertView.tag = 10000;
            [alertView show];
        }
    }
}

- (void)hintAlertViewAction
{
    [_postDic setObject:[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]forKey:@"user_id"];
    if (picMuArr.count == 0) {
        [[Dialog Instance] showCenterProgressWithLabel:@"上传中..."];
        [MyDataService postAddMeeting:_postDic callback:^(id data) {
            NSLog(@"%@",data);
            [[Dialog Instance] hideProgress];
            if([[data objectForKey:@"code"]isEqualToString:@"200"] || [[data objectForKey:@"code"] objectForKey:@"201"])
            {
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                insert_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                [self SetBaseField];
            }
        }];
    }
    else {
        imageCount = picMuArr.count;
        [picUrlMuArr removeAllObjects];
        [self postImageWithImages:picMuArr];
        NSLog(@"%@",_postDic);
    }
}

- (void)SetBaseField
{
    NSDictionary*partake_fields = @{
                                    @"partake_fields":@{
                                        @"f_phone":@{
                                            @"name":@"手机",
                                            @"sn":@"1",
                                            @"type":@"textField",
                                            @"extr":@"",
                                            @"required":@"1"
                                        },
                                        @"f_name":@{
                                            @"name":@"姓名",
                                            @"sn":@"0",
                                            @"type":@"textField",
                                            @"extr":@"",
                                            @"required":@"1"
                                        }
                                        },
                                    @"partake_end_time":[_postDic objectForKey:@"begin_time"],
                                    @"profile_name":[_postDic objectForKey:@"title"],
                                    @"profile_id":@"",
                                    @"with_approve":@"0",
                                    @"note":@"",
                                    @"meeting_id":insert_id,
                                    @"price":@"0"
                                    };
    NSDictionary * param = @{
                             @"meeting_id":insert_id,
                            
                             @"fieldArr":partake_fields,
                             
                             };
    
    NSLog(@"%@",[param JSONString]);
    [MyDataService postSetBaseFieldsNew:param callback:^(id data) {
        NSLog(@"%@",data);
        if([[data objectForKey:@"code"]isEqualToString:@"200"] || [[data objectForKey:@"code"] objectForKey:@"201"])
        {
            New_managerViewController *managerViewController = [[New_managerViewController alloc]init];
            managerViewController.isCreate = YES;
            managerViewController.meeting_id = insert_id;
            [_contentTextView removeFromSuperview];
            [self.navigationController pushViewController:managerViewController animated:YES];
        }
    }];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 2501 || alertView.tag == 2502) {
        
    }
    if (alertView.tag == 10000) {
        if (buttonIndex == 0) {
            NSLog(@"取消");
        }
        if (buttonIndex == 1) {
            LoginViewController *loginVC = [[LoginViewController alloc]init];
            loginVC.fromAddVC = YES;
            NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
            if (!LoginCompanyArray.count)
            {
                loginVC.isPush = YES;
            }
            UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:loginVC];
            [self presentViewController:nav animated:YES completion:^{
                
            }];
        }
    }
    if (alertView.tag == 10010) {
        if (buttonIndex == 1) {
            NSArray * arr = [NSArray arrayWithArray:picMuArr];
            [picMuArr removeAllObjects];
            if (contentStr != 0) {
                [_postDic setObject:contentStr forKey:@"summary"];
                NSArray *urlArr = [self getHtmlUrl:contentStr];
                for (int i = 0; i<urlArr.count; i++) {
                    NSString *url = [urlArr objectAtIndex:i];
                    int index = [[url substringWithRange:NSMakeRange(1, 1)] integerValue];
                    [picMuArr addObject:[arr objectAtIndex:index-1]];
                    [self saveImageToDocument:[arr objectAtIndex:index-1] imageName:url withMeetingType:@"1"];
                }
            }
            else {
                
            }
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
            [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",(int)picMuArr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
            
            NSString *meetType = [meetTypeArr componentsJoinedByString:@","];
            NSString *meetTypes = [meetType stringByReplacingOccurrencesOfString:@"0," withString:@""];
            meetTypes = [meetTypes stringByReplacingOccurrencesOfString:@"0" withString:@""];
            if (meetTypes.length%2 == 0) {
                meetTypes = [meetTypes substringToIndex:(meetTypes.length - 1)];
            }
   
            [_postDic setObject:meetTypes forKey:@"activity"];
            [_postDic setObject:costStr forKey:@"expenses"];
            NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithCapacity:0];
            [dic setObject:@"1" forKey:@"nickname"];
            [dic setObject:@"1" forKey:@"phone"];
            [_postDic setObject:[dic JSONString] forKey:@"fieldArr"];
            
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
            [[DBManager sharedInstance] insertDataToPublicDB:[_postDic JSONString] valueKey:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];

            [_contentTextView removeFromSuperview];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
    if (alertView.tag == 2600) {
        if (buttonIndex == 0) {
            NSLog(@"取消");
        }
        if (buttonIndex == 1) {
            // 无权限 引导去开启
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }
        }
    }
}

- (void)rightBtnClicked
{
    [self creatPostData];
    NSLog(@"%@",_postDic);
}

- (void)creatUI
{
    [self creatRightNav];
    
    NSString *jsonStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
    [_postDic setValuesForKeysWithDictionary:[jsonStr JSONValue]];
    
    NSString *personalSelect = [_postDic objectForKey:@"personal_data_sw"];
    if (personalSelect.length) {
        if (![personalSelect isEqualToString:@"-1"]) {
            if ([personalSelect isEqualToString:@"1"]) {
                self.select = 2;
            }
            else if ([personalSelect isEqualToString:@"2"]) {
                self.select = 1;
            }
            else {
                self.select = [personalSelect integerValue];
            }
        }
    }
    
    _mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    [self.view addSubview:self.mainScrollView];
    
    _titleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 70)];
    BackGroundColor(_titleView, whiteColor);
    [self.mainScrollView addSubview:self.titleView];
    
    UILabel *topLine = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(topLine, @"#c8c7cc");
    [_titleView addSubview:topLine];
    
    UILabel *titltLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 14)];
    titltLb.backgroundColor = [UIColor clearColor];
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:@"主题（必填）"];
    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,2)];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,2)];
    [tittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(2,4)];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
    titltLb.attributedText = tittle_str;
    [_titleView addSubview:titltLb];
    
    if (!_titleTF) {
        _titleTF = [[CreatMeetTextField alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(titltLb.frame)+20, ScreenWidth-25, 20)];
        _titleTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _titleTF.placeholder = @"输入聚会主题";
        if ([[_postDic objectForKey:@"title"] length] != 0) {
            _titleTF.text = [_postDic objectForKey:@"title"];
        }
        _titleTF.delegate = self;
        _titleTF.font = YHUI(16);
        _titleTF.tag = 101;
        [_titleTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
        _titleTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        [_titleView addSubview:_titleTF];
        
        SDToolBarOfHideView *toolBar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
        toolBar.SDdelegate = self;
        _titleTF.inputAccessoryView = toolBar;
    }
    
    line = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_titleView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line, @"#c8c7cc");
    [_titleView  addSubview:line];
    
    _contentView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_titleView.frame)+10, ScreenWidth, 128)];
    _contentView.backgroundColor = [UIColor whiteColor];
    [self.mainScrollView addSubview:self.contentView];
   
    NSMutableAttributedString *contenttittle_str = [[NSMutableAttributedString alloc] initWithString:@"详情（必填）"];
    [contenttittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0,2)];
    [contenttittle_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0,2)];
    [contenttittle_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(2,4)];
    [contenttittle_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(2,4)];
    
    UILabel *contentTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 14)];
    contentTitleLB.backgroundColor = [UIColor clearColor];
    contentTitleLB.font = YHUI(16);
    contentTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    contentTitleLB.attributedText = contenttittle_str;
    [_contentView addSubview:contentTitleLB];
    
    line1 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line1, @"#c8c7cc");
    [_contentView  addSubview:line1];

    line2 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(_contentView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line2, @"#c8c7cc");
    [_contentView addSubview:line2];
    
    contentSepLb = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(contentTitleLB.frame)+5, 100, 30)];
    contentSepLb.text = @"输入活动详情";
    contentSepLb.font = YHUI(16);
    contentSepLb.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    contentSepLb.backgroundColor = [UIColor clearColor];
    [_contentView addSubview:contentSepLb];

    _contentTextView = [[FastTextView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(contentTitleLB.frame), self.view.bounds.size.width, 70)];
    _contentTextView.scrollEnabled = NO;
    //_contentTextView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _contentTextView.attributeConfig = [TextConfig editorAttributeConfig];
    _contentTextView.delegate = (id<FastTextViewDelegate>)self;
    //_contentTextView.placeHolder = @"输入聚会详情";
    _contentTextView.font = [UIFont systemFontOfSize:16];
    _contentTextView.pragraghSpaceHeight = 0;
    _contentTextView.backgroundColor = [UIColor clearColor];
    //view.userInteractionEnabled = YES;
    [self.contentView addSubview:_contentTextView];
    
    if ([[_postDic objectForKey:@"summary"] length] != 0) {
         [self addSumarryWithContent:[self replaceBr:[_postDic objectForKey:@"summary"]]];
    }
    
    _toolBar = [[SDToolBarView alloc]initWithFrame:CGRectMake(0, _contentView.size.height-35, ScreenWidth, 35)];
    _toolBar.delegate = self;
    _toolBar.hideBtn.hidden = YES;
    [_contentView addSubview:_toolBar];
    
    
    /*
    NSString *default_txt = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"a.txt"];
    #endif
    NSString *base_content = @"  HTML 解析demo。<img src = \@\"http:\/\/www.baidu.com\/img\/bNSLogo.png\"> Demo 解析了某个网站（具体可在代码中查看）的html网页，提取了图片以及标题。 ";
    //NSError *error;
    //NSString *base_content = [NSString stringWithContentsOfFile:default_txt encoding:NSUTF8StringEncoding error:&error];
    NSMutableAttributedString *parseStr = [[NSMutableAttributedString alloc]initWithString:base_content];
    [parseStr addAttributes:[self defaultAttributes] range:NSMakeRange(0, [parseStr length])];
    self.contentTextView.attributedString = parseStr;
    [view becomeFirstResponder];*/
    
    
    detailView = [[UIView alloc]init];
    detailView.backgroundColor = [UIColor clearColor];
    [self.mainScrollView addSubview:detailView];
    
    _descView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 163)];
    BackGroundColor(_descView, whiteColor);
    [detailView addSubview:self.descView];
    
    UILabel *descTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 9, ScreenWidth-25, 14)];
    descTitleLB.backgroundColor = [UIColor clearColor];
    descTitleLB.font = YHUI(16);
    descTitleLB.text = @"活动时间";
    descTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    [_descView addSubview:descTitleLB];

    UIImageView *timeImageView1 = [[UIImageView alloc]initWithFrame:CGRectMake(19, CGRectGetMaxY(descTitleLB.frame)+19, 10, 47)];
    BackGroundColor(timeImageView1, clearColor);
    timeImageView1.image = [UIImage imageNamed:@"dot_03"];
    [_descView addSubview:timeImageView1];
    
    _sTimeBtn = [[UILabel alloc] init];
    _sTimeBtn.frame = CGRectMake(CGRectGetMaxX(timeImageView1.frame)+4, CGRectGetMaxY(descTitleLB.frame)+14, 200, 18);
    _sTimeBtn.userInteractionEnabled = YES;
    
    UITapGestureRecognizer* singleRecognizer;
    singleRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(startTimeBtnClick:)];
    singleRecognizer.numberOfTapsRequired = 1; // 单击
    [_sTimeBtn addGestureRecognizer:singleRecognizer];
    
    NSMutableAttributedString *s_time_str = [[NSMutableAttributedString alloc] initWithString:@"开始时间（必填）"];
    [s_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
    [s_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
    [s_time_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(4, 4)];
    _sTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    _sTimeBtn.attributedText = s_time_str;
    _sTimeBtn.tag = 70+1;
    _sTimeBtn.backgroundColor = [UIColor clearColor];
    [_descView addSubview:_sTimeBtn];
    
    scleanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    scleanBtn.frame = CGRectMake(ScreenWidth-35, CGRectGetMaxY(_sTimeBtn.frame)-15, 14, 14);
    scleanBtn.tag = 10020;
    scleanBtn.hidden=YES;
    [scleanBtn addTarget:self action:@selector(cleanTime:) forControlEvents:UIControlEventTouchUpInside];
    [scleanBtn setImage:[UIImage imageNamed:@"text_clean_btn"] forState:UIControlStateNormal];
    [_descView addSubview:scleanBtn];
    
    _eTimeBtn = [[UILabel alloc]init];
    _eTimeBtn.frame = CGRectMake(CGRectGetMaxX(timeImageView1.frame)+4, CGRectGetMaxY(_sTimeBtn.frame)+20, 200, 18);
    NSMutableAttributedString *e_time_str = [[NSMutableAttributedString alloc] initWithString:@"结束时间（非必填）"];
    [e_time_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(4, 5)];
    [e_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
    [e_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 5)];
    
    _eTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
    _eTimeBtn.attributedText = e_time_str;
    _eTimeBtn.userInteractionEnabled = YES;
    UITapGestureRecognizer* GestureRecognizer;
       GestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(endTimeBtnClick:)];
    GestureRecognizer.numberOfTapsRequired = 1; // 单击
    [_eTimeBtn addGestureRecognizer:GestureRecognizer];
    _eTimeBtn.tag = 70+2;
    _eTimeBtn.backgroundColor = [UIColor clearColor];
    [_descView addSubview:_eTimeBtn];

    enCleanBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    enCleanBtn.frame = CGRectMake(ScreenWidth-35, CGRectGetMaxY(_eTimeBtn.frame)-15, 14, 14);
    enCleanBtn.tag = 10030;
    enCleanBtn.hidden = YES;
    [enCleanBtn addTarget:self action:@selector(cleanTime:) forControlEvents:UIControlEventTouchUpInside];
    [enCleanBtn setImage:[UIImage imageNamed:@"text_clean_btn"] forState:UIControlStateNormal];
    
    if ([[_postDic objectForKey:@"begin_time"] length] != 0) {
        _sTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[_postDic objectForKey:@"begin_time"]];
        _sTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        scleanBtn.hidden = NO;
    }
    if ([[_postDic objectForKey:@"end_time"] length] != 0) {
        _eTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[_postDic objectForKey:@"end_time"]];
        _eTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        enCleanBtn.hidden = NO;
    }

    [_descView addSubview:enCleanBtn];
    
    UILabel *line5 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_eTimeBtn.frame)+8, ScreenWidth-12, 0.5)];
    BackGround16Color(line5, @"#c8c7cc");
    [_descView addSubview:line5];
    
    UILabel *descTitleLB2 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(line5.frame) + 8, ScreenWidth-25, 16)];
    descTitleLB2.backgroundColor = [UIColor clearColor];
    descTitleLB2.font = YHUI(14);
    NSMutableAttributedString *des_str = [[NSMutableAttributedString alloc] initWithString:@"活动地点（必填）"];
    [des_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
    [des_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#373737"] range:NSMakeRange(0, 4)];
    
    [des_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
    [des_str addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#9b9b9b"] range:NSMakeRange(4, 4)];
    descTitleLB2.attributedText = des_str;
    [_descView addSubview:descTitleLB2];
    
    if (!_addressTF) {
        _addressTF = [[CreatMeetTextField alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(descTitleLB2.frame)+20, ScreenWidth-25, 20)];
        _addressTF.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _addressTF.font = YHUI(16);
        _addressTF.placeholder = @"请输入活动地址";
        _addressTF.delegate = self;
        _addressTF.tag = 102;
        if ([[_postDic objectForKey:@"location"] length] != 0) {
            _addressTF.text = [_postDic objectForKey:@"location"];
        }
        [_addressTF addTarget:self action:@selector(textChange:) forControlEvents:UIControlEventEditingChanged];
        _addressTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        
        [_descView addSubview:_addressTF];
        
        SDToolBarOfHideView *toolBar = [[SDToolBarOfHideView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 44)];
        toolBar.SDdelegate = self;
        _addressTF.inputAccessoryView = toolBar;
    }
    _descView.frame = CGRectMake(_descView.origin.x,_descView.origin.x, _descView.size.width, CGRectGetMaxY(_addressTF.frame)+8);
    
    UILabel * line3 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line3, @"#c8c7cc");
    [_descView  addSubview:line3];

    UILabel * line4 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(_descView.frame) - 0.5, ScreenWidth, 0.5)];
    BackGround16Color(line4, @"#c8c7cc");
    [_descView  addSubview:line4];
    
    _endDescView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_descView.frame)+10, ScreenWidth, 109)];
    BackGroundColor(_endDescView, whiteColor);
    [detailView addSubview:self.endDescView];
    
    UILabel * line6 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line6, @"#c8c7cc");
    [_endDescView  addSubview:line6];
    
    UILabel *endDescTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(line6.frame) + 9, 70, 14)];
    endDescTitleLB.backgroundColor = [UIColor clearColor];
    endDescTitleLB.font = YHUI(16);
    endDescTitleLB.text = @"活动形式";
    endDescTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    [_endDescView addSubview:endDescTitleLB];
    
    //活动形式  3个Button
    NSArray *meettype = [[_postDic objectForKey:@"activity"] componentsSeparatedByString:@","];
    _meetTypeBtn1 = [UITypeButton buttonWithType:UIButtonTypeCustom];
    _meetTypeBtn1.frame = CGRectMake(CGRectGetMaxX(endDescTitleLB.frame)+5, 5, 60, 26);
    _meetTypeBtn1.tag = 50+1;
    [_meetTypeBtn1 addTarget:self action:@selector(selectMeetTypes:) forControlEvents:UIControlEventTouchUpInside];
    _meetTypeBtn1.backgroundColor = [UIColor clearColor];
    _meetTypeBtn1.titleLabel.font = YHUI(14);
    _meetTypeBtn1.selected = YES;
    [_meetTypeBtn1 setTitle:@"聚餐" forState:UIControlStateNormal];
    [_meetTypeBtn1 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
    [_meetTypeBtn1 setImage:[UIImage imageNamed:@"cur_jc"] forState:UIControlStateNormal];
    [_meetTypeBtn1 setImage:[UIImage imageNamed:@"jc"] forState:UIControlStateSelected];
    [_endDescView addSubview:_meetTypeBtn1];
    
    _meetTypeBtn2 = [UITypeButton buttonWithType:UIButtonTypeCustom];
    _meetTypeBtn2.frame = CGRectMake(CGRectGetMaxX(_meetTypeBtn1.frame)+18, 5, 60, 26);
    _meetTypeBtn2.tag = 50+2;
    [_meetTypeBtn2 addTarget:self action:@selector(selectMeetTypes:) forControlEvents:UIControlEventTouchUpInside];
    _meetTypeBtn2.titleLabel.font = YHUI(14);
    [_meetTypeBtn2 setTitle:@"娱乐" forState:UIControlStateNormal];
    [_meetTypeBtn2 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
    [_meetTypeBtn2 setImage:[UIImage imageNamed:@"cur_cg"] forState:UIControlStateNormal];
    [_meetTypeBtn2 setImage:[UIImage imageNamed:@"cg"] forState:UIControlStateSelected];
    [_endDescView addSubview:_meetTypeBtn2];
    
    _meetTypeBtn3 = [UITypeButton buttonWithType:UIButtonTypeCustom];
    _meetTypeBtn3.frame = CGRectMake(CGRectGetMaxX(_meetTypeBtn2.frame)+18, 5, 60, 26);
    _meetTypeBtn3.tag = 50+3;
    [_meetTypeBtn3 addTarget:self action:@selector(selectMeetTypes:) forControlEvents:UIControlEventTouchUpInside];
    _meetTypeBtn3.titleLabel.font = YHUI(14);
    [_meetTypeBtn3 setTitle:@"运动" forState:UIControlStateNormal];
    [_meetTypeBtn3 setTitleColor:[UIColor colorWithHexString:@"#676767"] forState:UIControlStateNormal];
    [_meetTypeBtn3 setImage:[UIImage imageNamed:@"cur_yd"] forState:UIControlStateNormal];
    [_meetTypeBtn3 setImage:[UIImage imageNamed:@"yd"] forState:UIControlStateSelected];
    [_endDescView addSubview:_meetTypeBtn3];
    
    for (NSString *index in meettype) {
        if ([index isEqualToString:@"1"]) {
            _meetTypeBtn1.selected = YES;
        }
        if ([index isEqualToString:@"2"]) {
            _meetTypeBtn2.selected = YES;
        }
        if ([index isEqualToString:@"3"]) {
            _meetTypeBtn3.selected = YES;
        }
    }
    
    UILabel * line7 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(_meetTypeBtn1.frame)+5, ScreenWidth-12, 0.5)];
    BackGround16Color(line7, @"#c8c7cc");
    [_endDescView  addSubview:line7];
    
    UILabel *endDescTitleLB2 = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(line7.frame) + 9, 70, 14)];
    endDescTitleLB2.backgroundColor = [UIColor clearColor];
    endDescTitleLB2.font = YHUI(16);
    endDescTitleLB2.text = @"活动费用";
    endDescTitleLB2.textColor = [UIColor colorWithHexString:@"#373737"];
    [_endDescView addSubview:endDescTitleLB2];
    
    UIImage *buttonImage = [UIImage imageNamed:@"mr_k"];
    buttonImage = [buttonImage stretchableImageWithLeftCapWidth:floorf(buttonImage.size.width/2) topCapHeight:floorf(buttonImage.size.height/2)];
    
    UIImage *buttonImageselected = [UIImage imageNamed:@"new_07"];
    buttonImageselected = [buttonImageselected stretchableImageWithLeftCapWidth:floorf(buttonImage.size.width/2) topCapHeight:floorf(buttonImage.size.height/2)];
    
    _costTypeBtn1 = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
    _costTypeBtn1.frame = CGRectMake(13,CGRectGetMaxY(endDescTitleLB2.frame)+13, 56, 24);
    _costTypeBtn1.tag = 60+1;
    _costTypeBtn1.backgroundColor = [UIColor clearColor];
    _costTypeBtn1.titleLabel.font = YHUI(14);
    [_costTypeBtn1 setTitle:@"我请客" forState:UIControlStateNormal];
    [_costTypeBtn1 addTarget:self action:@selector(selectCostTypeBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_costTypeBtn1 setBackgroundImage :buttonImage forState:UIControlStateNormal];
    [_costTypeBtn1 setBackgroundImage:buttonImageselected forState:UIControlStateSelected];
    [_costTypeBtn1 setImage:[UIImage imageNamed:@"new_03"] forState:UIControlStateSelected];
    [_endDescView addSubview:_costTypeBtn1];
    
    _costTypeBtn2 = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
    _costTypeBtn2.frame = CGRectMake(CGRectGetMaxX(_costTypeBtn1.frame)+10, CGRectGetMaxY(endDescTitleLB2.frame)+13, 64, 24);
    _costTypeBtn2.tag = 60+2;
    _costTypeBtn2.backgroundColor = [UIColor clearColor];
    _costTypeBtn2.titleLabel.font = YHUI(14);
    [_costTypeBtn2 setTitle:@"AA" forState:UIControlStateNormal];
    [_costTypeBtn2 addTarget:self action:@selector(selectCostTypeBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_costTypeBtn2 setBackgroundImage :buttonImage forState:UIControlStateNormal];
    [_costTypeBtn2 setBackgroundImage:buttonImageselected forState:UIControlStateSelected];
    [_costTypeBtn2 setImage:[UIImage imageNamed:@"new_03"] forState:UIControlStateSelected];
    [_endDescView addSubview:_costTypeBtn2];
    
    _costTypeBtn3 = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
    _costTypeBtn3.frame = CGRectMake(CGRectGetMaxX(_costTypeBtn2.frame)+10, CGRectGetMaxY(endDescTitleLB2.frame)+13, 76, 24);
    _costTypeBtn3.tag = 60+3;
    _costTypeBtn3.backgroundColor = [UIColor clearColor];
    _costTypeBtn3.titleLabel.font = YHUI(14);
    [_costTypeBtn3 setTitle:@"有活动费用" forState:UIControlStateNormal];
    [_costTypeBtn3 addTarget:self action:@selector(selectCostTypeBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_costTypeBtn3 setBackgroundImage :buttonImage forState:UIControlStateNormal];
    [_costTypeBtn3 setBackgroundImage:buttonImageselected forState:UIControlStateSelected];
    [_costTypeBtn3 setImage:[UIImage imageNamed:@"new_03"] forState:UIControlStateSelected];
    [_endDescView addSubview:_costTypeBtn3];
    
    _costTypeBtn4 = [UICostTypeButton buttonWithType:UIButtonTypeCustom];
    _costTypeBtn4.frame = CGRectMake(CGRectGetMaxX(_costTypeBtn3.frame)+10, CGRectGetMaxY(endDescTitleLB2.frame)+13, 64, 24);
    _costTypeBtn4.tag = 60+4;
    _costTypeBtn4.selected = YES;
    _costTypeBtn4.backgroundColor = [UIColor clearColor];
    _costTypeBtn4.titleLabel.font = YHUI(14);
    [_costTypeBtn4 setTitle:@"其它" forState:UIControlStateNormal];
    [_costTypeBtn4 addTarget:self action:@selector(selectCostTypeBtn:) forControlEvents:UIControlEventTouchUpInside];
    [_costTypeBtn4 setBackgroundImage :buttonImage forState:UIControlStateNormal];
    [_costTypeBtn4 setBackgroundImage:buttonImageselected forState:UIControlStateSelected];
    [_costTypeBtn4 setImage:[UIImage imageNamed:@"new_03"] forState:UIControlStateSelected];
    [_endDescView addSubview:_costTypeBtn4];
    
    
    if ([_postDic objectForKey:@"expenses"]) {
        [self whichBtnSelectWithString:[_postDic objectForKey:@"expenses"]];
    }
    
    
    UILabel * line8 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(_endDescView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line8, @"#c8c7cc");
    [_endDescView  addSubview:line8];

    _endView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_endDescView.frame)+10, ScreenWidth, 45)];
    BackGroundColor(_endView, whiteColor);
    [detailView addSubview:self.endView];

    UILabel * line9 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line9, @"#c8c7cc");
    [_endView addSubview:line9];
    
    UILabel * line10 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(_endView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line10, @"#c8c7cc");
    [_endView  addSubview:line10];
    
    UILabel *endTitleLB = [[UILabel alloc]initWithFrame:CGRectMake(12, 4, ScreenWidth-80, 37)];
    endTitleLB.backgroundColor = [UIColor clearColor];
    endTitleLB.font = [UIFont systemFontOfSize:16];
    endTitleLB.text = @"公开活动（发布到会议广场）";
    endTitleLB.textColor = [UIColor colorWithHexString:@"#373737"];
    [_endView addSubview:endTitleLB];
    
    SevenSwitch* switchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, 8.5, 46, 28)];
    switchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
    //switchBtn.offImage = [UIImage imageNamed:@"off"];
    //switchBtn.onImage = [UIImage imageNamed:@"on"];
    if ([[_postDic objectForKey:@"openstatus"] isEqualToString:@"0"]) {
        switchBtn.on = NO;
    }
    else {
        switchBtn.on = YES;
    }
    switchBtn.tag = 11111;
    [switchBtn addTarget:self action:@selector(switchBtnClick:) forControlEvents:UIControlEventValueChanged];
    [_endView addSubview:switchBtn];
    
    if ([[_postDic objectForKey:@"reply_email"] length] != 0) {
        self.replyEmailView.emailTextFiled.text = [_postDic objectForKey:@"reply_email"];
    }
    [detailView addSubview:self.replyEmailView];
    
    //公开报名者信息
    self.personalView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.replyEmailView.frame)+10, ScreenWidth, 45)];
    self.personalView.backgroundColor = [UIColor whiteColor];
    [detailView addSubview:self.personalView];
    
    UILabel *line11 = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(line11, @"#c8c7cc");
    [self.personalView addSubview:line11];
    
    UILabel *_personalTitleLb = [[UILabel alloc]initWithFrame:CGRectMake(12, 4, 250, 37)];
    _personalTitleLb.text = @"公开报名者信息";
    _personalTitleLb.textColor = [UIColor colorWithHexString:@"#373737"];
    _personalTitleLb.backgroundColor = [UIColor clearColor];
    _personalTitleLb.font = [UIFont systemFontOfSize:16];
    [self.personalView addSubview:_personalTitleLb];
    
    SevenSwitch *personalSwitchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-46-12, 8.5, 46, 28)];
    personalSwitchBtn.onColor = [UIColor colorWithHexString:@"1b9ecc"];
    if ([[_postDic objectForKey:@"personal_data_sw"] isEqualToString:@"-1"]) {
        personalSwitchBtn.on = NO;
        self.personalChangeFrame = NO;
    }
    else {
        personalSwitchBtn.on = YES;
        self.personalChangeFrame = YES;
    }
    personalSwitchBtn.tag = 22222;
    [personalSwitchBtn addTarget:self action:@selector(switchBtnClick:) forControlEvents:UIControlEventValueChanged];
    [self.personalView addSubview:personalSwitchBtn];
    
    UILabel *line12 = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.personalView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(line12, @"#c8c7cc");
    [self.personalView addSubview:line12];
    
    [detailView addSubview:self.personalTableView];
    
    NSString *str = @"提示：发布违法反动活动信息或冒用他人、组织名义发起活动，将依据记录提交公安机关处理。";
    CGFloat strHeight = [Helper heightOfString:str font:[UIFont systemFontOfSize:14] width:ScreenWidth-24];
    
    self.endLb = [[UILabel alloc]initWithFrame:CGRectMake(12, CGRectGetMaxY(self.personalTableView.frame)+10, ScreenWidth-24, strHeight)];
    BackGroundColor(self.endLb, clearColor);
    self.endLb.textColor = [UIColor colorWithHexString:@"#a39f9f"];
    self.endLb.font = [UIFont systemFontOfSize:14];
    self.endLb.numberOfLines = 0;
    self.endLb.lineBreakMode = NSLineBreakByWordWrapping;
    self.endLb.text = @"提示：发布违法反动活动信息或冒用他人、组织名义发起活动，将依据记录提交公安机关处理。";
    [detailView addSubview:self.endLb];
    
    detailView.frame = CGRectMake(0, CGRectGetMaxY(_contentView.frame)+10, ScreenWidth, CGRectGetMaxY(self.endLb.frame)+10);
    
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
}

- (ReplyEmailView *)replyEmailView
{
    if (!_replyEmailView) {
        _replyEmailView = [[ReplyEmailView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_endView.frame)+10, ScreenWidth, 80)];
        _replyEmailView.delegate = self;
    }
    return _replyEmailView;
}

- (void)replyEmailChange:(NSString *)replyEmail
{
    [_postDic setObject:replyEmail forKey:@"reply_email"];
}

- (UITableView *)personalTableView
{
    if (!_personalTableView) {
        _personalTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.personalView.frame) , ScreenWidth, 135)];
        _personalTableView.backgroundColor = [UIColor whiteColor];
        _personalTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _personalTableView.delegate = self;
        _personalTableView.dataSource = self;
        _personalTableView.scrollEnabled = NO;
    }
    return _personalTableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"OpenPersonalCellID";
    OpenPersonalCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
    if (!cell) {
        cell = [[OpenPersonalCell alloc]
                initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
    }
    
    cell.titleLab.text = self.personalArr[indexPath.row];
    
    cell.btn.selected = NO;
    if (self.select == indexPath.row) {
        cell.btn.selected = YES;
        if (self.select == 1) {
            [_postDic setObject:[NSString stringWithFormat:@"%d",2] forKey:@"personal_data_sw"];
        }
        else if (self.select == 2) {
            [_postDic setObject:[NSString stringWithFormat:@"%d",1] forKey:@"personal_data_sw"];
        }
        else {
            [_postDic setObject:[NSString stringWithFormat:@"%d",(int)self.select] forKey:@"personal_data_sw"];
        }
    }
    
    switch (indexPath.row) {
        case 0:
        {
            cell.topLine.hidden = YES;
            cell.bottomLine.hidden = YES;
        }
            break;
        case 1:
        {
            cell.topLine.hidden = NO;
            cell.bottomLine.hidden = YES;
        }
            break;
        case 2:
        {
            cell.topLine.hidden = NO;
            cell.bottomLine.hidden = NO;
        }
            break;
        default:
            break;
    }
    
    cell.contentView.backgroundColor = [UIColor whiteColor];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.select = indexPath.row;
    [self.personalTableView reloadData];
}

- (void)setPersonalChangeFrame:(BOOL)personalChangeFrame
{
    if (personalChangeFrame == YES) {
        [UIView animateWithDuration:0.5 animations:^{
            self.personalTableView.frame = CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 135);
            self.endLb.frame = CGRectMake(self.endLb.origin.x, CGRectGetMaxY(self.personalTableView.frame)+10, self.endLb.size.width, self.endLb.size.height);
            detailView.frame = CGRectMake(detailView.origin.x, detailView.origin.y, detailView.size.width, CGRectGetMaxY(self.endLb.frame)+10);
            _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
        } completion:^(BOOL finished) {
            
        }];
    }
    else {
        [UIView animateWithDuration:0.5 animations:^{
            self.personalTableView.frame = CGRectMake(self.personalTableView.frame.origin.x, self.personalTableView.frame.origin.y, self.personalTableView.frame.size.width, 0);
            self.endLb.frame = CGRectMake(self.endLb.origin.x, CGRectGetMaxY(self.personalTableView.frame)+10, self.endLb.size.width, self.endLb.size.height);
            detailView.frame = CGRectMake(detailView.origin.x, detailView.origin.y, detailView.size.width, CGRectGetMaxY(self.endLb.frame)+10);
            _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
        } completion:^(BOOL finished) {
            
        }];
    }
}

- (void)cancelBtnClicked
{
    if (endBtnSelect == YES) {
        endBtnSelect = NO;
    }
    if (startBtnSelect == YES) {
        startBtnSelect = NO;
    }
}

#pragma mark SDTimeActionSheet
- (void)returnData:(NSDate*)date Time:(NSTimeInterval)time
{
    if (endBtnSelect == YES) {
        if ([[_postDic objectForKey:@"begin_time"] integerValue] >= time) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"结束时间必须大于开始时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            av.tag = 2501;
            [av show];
            return;
        }
        _eTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
        _eTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _eTimeBtn.font = YHUI(16);
        [_postDic setObject:[NSString stringWithFormat:@"%0.f",time] forKey:@"end_time"];
        endBtnSelect = NO;
        enCleanBtn.hidden = NO;
    }
    if (startBtnSelect == YES) {
        if ([self currentTime] > time) {
            UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"提示" message:@"开始时间必须大于当前时间！" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
            av.tag = 2501;
            [av show];
            return;
        }
        _sTimeBtn.text = [self formatter:@"yyyy-MM-dd HH:mm:ss" ToTime:[NSString stringWithFormat:@"%f",time]];
        _sTimeBtn.textColor = [UIColor colorWithHexString:@"#1b9ecc"];
        _sTimeBtn.font = YHUI(16);
        [_postDic setObject:[NSString stringWithFormat:@"%0.f",time] forKey:@"begin_time"];
        startBtnSelect = NO;
        scleanBtn.hidden = NO;
    }
}

- (void)cleanTime:(UIButton*)btn
{
    if (btn.tag == 10020) {
        if ([[_postDic objectForKey:@"begin_time"] length]!=0) {
            NSMutableAttributedString *s_time_str = [[NSMutableAttributedString alloc] initWithString:@"开始时间（必填）"];
            [s_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
            [s_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
            _sTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
            _sTimeBtn.attributedText = s_time_str;
            [_postDic setObject:@"" forKey:@"begin_time"];
            btn.hidden = YES;
        }
    }
    if (btn.tag == 10030) {
        if ([[_postDic objectForKey:@"end_time"] length]!=0) {
            NSMutableAttributedString *e_time_str = [[NSMutableAttributedString alloc] initWithString:@"结束时间（选填）"];
            [e_time_str addAttribute:NSFontAttributeName value:YHUI(16) range:NSMakeRange(0, 4)];
            [e_time_str addAttribute:NSFontAttributeName value:YHUI(14) range:NSMakeRange(4, 4)];
            _eTimeBtn.textColor = [UIColor colorWithHexString:@"#b4b4b5"];
            _eTimeBtn.attributedText = e_time_str;
            [_postDic setObject:@"" forKey:@"end_time"];
            btn.hidden = YES;
        }
    }
}

- (void)endTimeBtnClick:(UITapGestureRecognizer *)gesture
{
    [self.view endEditing:YES];
    endBtnSelect = YES;
    startBtnSelect = NO;
    if (NO == self.dateActionSheet.isShow) {
        self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
        self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    [self.dateActionSheet showInView:self.view];
}

- (void)startTimeBtnClick:(UITapGestureRecognizer *)gesture
{
    [self.view endEditing:YES];
    startBtnSelect = YES;
    endBtnSelect = NO;
    if (NO == self.dateActionSheet.isShow) {
        self.dateActionSheet = [[SDTimeActiontSheet alloc] initWithType:2 delegate:self];
        self.dateActionSheet.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    }
    [self.dateActionSheet showInView:self.view];
}

- (void)switchBtnClick:(SevenSwitch*)btn
{
    if (btn.tag == 11111) {
        if (btn.on == YES) {
            NSLog(@"switch btn on!!!!!");
            [_postDic setObject:@"1" forKey:@"openstatus"];
        }
        else {
            [_postDic setObject:@"0" forKey:@"openstatus"];
        }
    }
    else if(btn.tag == 22222) {
        if (btn.on == YES) {
            NSLog(@"switch btn on!!!!!");
            self.personalChangeFrame = YES;
            [self.personalTableView reloadData];
        }
        else {
            self.personalChangeFrame = NO;
            [_postDic setObject:@"-1" forKey:@"personal_data_sw"];
        }
        [_mainScrollView setContentOffset:CGPointMake(0,_mainScrollView.contentSize.height-_mainScrollView.bounds.size.height) animated:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.mainScrollView.frame = CGRectMake(self.mainScrollView.frame.origin.x, self.mainScrollView.frame.origin.y, self.mainScrollView.frame.size.width,ScreenHeight-self.F_NAV_HEIGHT-keyBoardSize.height );
    keyBoardShow = NO;
    eidtTextFiled = YES;
    //_toolBar.imageBtn.hidden = YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    
//    self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
//    self.toolBar.hideBtn.hidden = NO;//显示完成按钮
//    self.toolBar.frame = CGRectMake(0, _contentView.size.height-TOP_VIEW_HEIGHT
//                                    , ScreenWidth,TOP_VIEW_HEIGHT );
//    [_contentView addSubview:self.toolBar];
//    [_contentView bringSubviewToFront:self.toolBar];//改变toolbar的位置
//    eidtTextFiled = NO;
    
    //_toolBar.imageBtn.hidden = NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)whichBtnSelectWithString:(NSString*)cost
{
    if ([cost isEqualToString:@"1"]) {
        _costTypeBtn2.selected = NO;
        _costTypeBtn3.selected = NO;
        _costTypeBtn4.selected = NO;
        _costTypeBtn1.selected = YES;
    }
    if ([cost isEqualToString:@"2"]) {
        _costTypeBtn1.selected = NO;
        _costTypeBtn3.selected = NO;
        _costTypeBtn4.selected = NO;
        _costTypeBtn2.selected = YES;
    }
    if ([cost isEqualToString:@"3"]) {
        _costTypeBtn2.selected = NO;
        _costTypeBtn1.selected = NO;
        _costTypeBtn4.selected = NO;
        _costTypeBtn3.selected = YES;
    }
    if ([cost isEqualToString:@"4"]) {
        _costTypeBtn2.selected = NO;
        _costTypeBtn3.selected = NO;
        _costTypeBtn1.selected = NO;
        _costTypeBtn4.selected = YES;
    }
}

- (void)selectCostTypeBtn:(UICostTypeButton *)btn
{
    btn.adjustsImageWhenHighlighted = NO;
    if (btn.selected == NO) {
        btn.selected = !btn.selected;
        if (btn == _costTypeBtn1) {
            costStr = @"1";
            _costTypeBtn2.selected = NO;
            _costTypeBtn3.selected = NO;
            _costTypeBtn4.selected = NO;
        }
        if (btn == _costTypeBtn2) {
            costStr = @"2";
            _costTypeBtn1.selected = NO;
            _costTypeBtn3.selected = NO;
            _costTypeBtn4.selected = NO;
        }
        if (btn == _costTypeBtn3) {
            _costTypeBtn2.selected = NO;
            _costTypeBtn1.selected = NO;
            _costTypeBtn4.selected = NO;
            costStr = @"3";
        }
        if (btn == _costTypeBtn4) {
            _costTypeBtn2.selected = NO;
            _costTypeBtn3.selected = NO;
            _costTypeBtn1.selected = NO;
            costStr = @"4";
        }
    }
}

- (void)selectMeetTypes:(UITypeButton*)btn
{
    btn.selected = !btn.selected;
    if (btn.tag == 51) {
        if (btn.selected == YES) {
            [meetTypeArr replaceObjectAtIndex:0 withObject:@"1"];
        }
        else {
            [meetTypeArr replaceObjectAtIndex:0 withObject:@"0"];
        }
    }
    if (btn.tag == 52) {
        if (btn.selected == YES) {
            [meetTypeArr replaceObjectAtIndex:1 withObject:@"2"];
        }
        else {
            [meetTypeArr replaceObjectAtIndex:1 withObject:@"0"];
        }
    }
    if (btn.tag == 53) {
        if (btn.selected == YES) {
            [meetTypeArr replaceObjectAtIndex:2 withObject:@"3"];
        }
        else {
            [meetTypeArr replaceObjectAtIndex:2 withObject:@"0"];
        }
    }
}

//- (NSDictionary *)defaultAttributes
//{
//    NSString *fontName = @"Helvetica";
//    CGFloat fontSize= 17.0f;
//    UIColor *color = [UIColor blackColor];
//    //UIColor *strokeColor = [UIColor whiteColor];
//    //CGFloat strokeWidth = 0.0;
//    CGFloat paragraphSpacing = 0.0;
//    CGFloat lineSpacing = 0.0;
//    //CGFloat minimumLineHeight=24.0f;
//    CTFontRef fontRef = CTFontCreateWithName((__bridge CFStringRef)fontName,
//                                             fontSize, NULL);
//    CTParagraphStyleSetting settings[] = {
//        { kCTParagraphStyleSpecifierParagraphSpacing, sizeof(CGFloat), &paragraphSpacing },
//        { kCTParagraphStyleSpecifierLineSpacing, sizeof(CGFloat), &lineSpacing },
//        // { kCTParagraphStyleSpecifierMinimumLineHeight, sizeof(CGFloat), &minimumLineHeight },
//    };
//    CTParagraphStyleRef paragraphStyle = CTParagraphStyleCreate(settings, ARRSIZE(settings));
//    //apply the current text style //2
//    /* NSDictionary* attrs = [NSDictionary dictionaryWithObjectsAndKeys:
//     (id)color.CGColor, kCTForegroundColorAttributeName,
//     (__bridge id)fontRef, kCTFontAttributeName,
//     (id)strokeColor.CGColor, (NSString *) kCTStrokeColorAttributeName,
//     (id)[NSNumber numberWithFloat: strokeWidth], (NSString *)kCTStrokeWidthAttributeName,
//     (__bridge id) paragraphStyle, (NSString *) kCTParagraphStyleAttributeName,
//     nil];
//     */
//    NSDictionary* attrs = [NSDictionary dictionaryWithObjectsAndKeys:
//                           (id)color.CGColor, kCTForegroundColorAttributeName,
//                           (__bridge id)fontRef, kCTFontAttributeName,
//                           //(id)strokeColor.CGColor, (NSString *) kCTStrokeColorAttributeName,
//                           //                           (id)[NSNumber numberWithFloat: strokeWidth], (NSString *)kCTStrokeWidthAttributeName,
//                           //(__bridge id) paragraphStyle, (NSString *) kCTParagraphStyleAttributeName,
//                           nil];
//    CFRelease(fontRef);
//    return attrs;
//}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

#pragma mark -
#pragma mark UITextViewDelegate

#pragma mark -
#pragma mark fastTextViewDelegate

- (BOOL)fastTextViewShouldBeginEditing:(FastTextView *)textView
{
    keyBoardShow = YES;
    eidtTextFiled = NO;
    self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
    self.toolBar.hideBtn.hidden = NO;//显示完成按钮
    self.toolBar.frame = CGRectMake(0, ScreenHeight-keyBoardSize.height-35, ScreenWidth,TOP_VIEW_HEIGHT );
    [self.view addSubview:self.toolBar];
    [self.view bringSubviewToFront:self.toolBar];//改变toolbar的位置
    return YES;
}

- (BOOL)fastTextViewShouldEndEditing:(FastTextView *)textView
{
    self.toolBar.delBtn.hidden = YES;//隐藏删除按钮
    self.toolBar.hideBtn.hidden = NO;//显示完成按钮
    self.toolBar.frame = CGRectMake(0, _contentView.size.height-TOP_VIEW_HEIGHT, ScreenWidth,TOP_VIEW_HEIGHT );
    [_contentView addSubview:self.toolBar];
    [_contentView bringSubviewToFront:self.toolBar];//改变toolbar的位置
    return YES;
}

- (void)fastTextViewDidBeginEditing:(FastTextView *)textView
{
    
}

- (void)fastTextViewDidChange:(FastTextView *)textView
{
    //UIView * view = _contentTextView.subviews.firstObject;
    //_contentTextView.frame = CGRectMake(_contentTextView.origin.x, _contentTextView.origin.y, ScreenWidth, view.size.height);
}

- (void)fastTextViewDidEndEditing:(FastTextView *)textView
{
    [self htmlStringWithAttachmentPath:(NSString *)textView.attributedString];
}

- (NSString *)htmlStringWithAttachmentPath:(NSString *)attachpath
{
    NSString *storeString = @"";
    if (_contentTextView.text.length == 0) {
        contentSepLb.hidden = NO;
    }
    else {
        contentSepLb.hidden = YES;
    }
    NSAttributedString *newAttrStr=_contentTextView.attributedString;
    NSMutableDictionary *textParagraphMap=[[NSMutableDictionary alloc]init];
    
    TextParagraph *textParagraph;
    NSRange longRange;
    unsigned int longPos = 0;
    while ((longPos < [newAttrStr length]) &&
           (textParagraph = [newAttrStr attribute:FastTextParagraphAttributeName atIndex:longPos longestEffectiveRange:&longRange inRange:NSMakeRange(0, [newAttrStr length])])) {
        
        NSLog(@"textParagraph %@",textParagraph);
        [textParagraphMap setValue:NSStringFromRange(longRange) forKey:textParagraph.key];
        
        longPos = longRange.location + longRange.length;
    }
    
    NSDictionary *effectiveAttributes;
    NSRange range;
    unsigned int pos = 0;
    [picMuArr removeAllObjects];
    while ((pos < [newAttrStr length]) &&
           (effectiveAttributes = [newAttrStr attributesAtIndex:pos effectiveRange:&range])) {
        
        NSString *plainString=[[newAttrStr attributedSubstringFromRange:range] string];
        
        //一下三个替换步骤不可错误！
        //替换img的魔术占位符
        unichar attachmentCharacter = FastTextAttachmentCharacter;
        plainString=[plainString stringByReplacingOccurrencesOfString:[NSString stringWithCharacters:&attachmentCharacter length:1] withString:@""];
        //编码html标签
        
        //替换\n为<br/>标签
        plainString=[plainString stringByReplacingOccurrencesOfString:@"\n" withString:@"<br>"];
        
        NSRange paragraphRange = NSMakeRange(NSNotFound, NSNotFound) ;
        TextParagraph *textParagraph=[effectiveAttributes objectForKey:FastTextParagraphAttributeName];
        
        if (textParagraph != nil) {
            NSString *rangstr= [textParagraphMap objectForKey: [MD5Util md5:[textParagraph description]]];
            paragraphRange=NSRangeFromString(rangstr);
        }
        if (paragraphRange.location != NSNotFound && paragraphRange.location == range.location) {
            storeString=[storeString stringByAppendingString:@"<p>"];
        }
        
        //附件处理
        id<FastTextAttachmentCell> attachmentcell = [effectiveAttributes objectForKey:FastTextAttachmentAttributeName];
        NSInteger ifile=1;
        if (attachmentcell && [attachmentcell isKindOfClass:[SlideAttachmentCell class]])
        {
            SlideAttachmentCell *slideCell = (SlideAttachmentCell *)attachmentcell;
            FileWrapperObject  *fileWrapper = slideCell.fileWrapperObject;
            if (fileWrapper != nil) {
                
                NSString *filepath = fileWrapper.filePath;
                
                NSString *name = fileWrapper.fileName;
                name = [name substringWithRange:NSMakeRange(name.length-3,3)];
                UIImage *attimg= [UIImage imageWithContentsOfFile:filepath];
                if ([name isEqualToString:@"jpg"]) {
                    [picMuArr addObject:attimg];
                }
                
                //NSString *newPath=[attachpath stringByAppendingPathComponent:fileWrapper.fileName];
                //NSError *error;
                //[[NSFileManager defaultManager] copyItemAtPath:filepath toPath:newPath error:&error];
                
                ifile++;
                
                if ([attachmentcell isKindOfClass:[SlideAttachmentCell class]]){
                    //SlideAttachmentCell *cell=(SlideAttachmentCell*) attachmentcell;
                    NSInteger thumbImageWidth=DEFAULT_thumbImageWidth;
                    NSInteger thumbImageHeight=DEFAULT_thumbImageHeight;
                    if (attimg != nil) {
                        CGSize size=[attimg sizeByScalingProportionallyToSize:CGSizeMake(thumbImageWidth, thumbImageHeight)];
                        thumbImageWidth=size.width;
                        thumbImageHeight=size.height;
                    }
                    storeString=[storeString stringByAppendingFormat:@"<img src=\"%@\" " ,fileWrapper.fileName];
                    storeString=[storeString stringByAppendingString:@"/>"];
                }
            }
        }
        else {
            //文本
            storeString=[storeString stringByAppendingFormat:@"%@", plainString];
        }
        if (paragraphRange.length != NSNotFound && (paragraphRange.location+paragraphRange.length) == (range.location+range.length)) {
            storeString=[storeString stringByAppendingString:@"</p>"];
        }
        pos = range.location + range.length;
    }
    NSLog(@"！！！！！！！%@",storeString);
    if (storeString.length != 0) {
        if (self.contentTextView.contentSize.height<70) {
            self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
            self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
        }
        else {
            self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
            self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
        }
        line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
        detailView.frame = CGRectMake(detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, detailView.size.width, detailView.size.height);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
        line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
        detailView.frame = CGRectMake(detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, detailView.size.width, detailView.size.height);
    }
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
    
    NSLog(@"%@",storeString);
    contentStr = storeString;
    return storeString;
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void)addSumarryWithContent:(NSString *)content
{
    content = [content stringByReplacingOccurrencesOfString:@"<br>" withString:@""];
    NSString *s = @"<(\\w+)\\s*src=\\\"(\\w+.*?)\\\"\\s*/>";
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:s
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:&error];
    
    NSArray *arrayOfAllMatches = [regex matchesInString:content options:0 range:NSMakeRange(0, [content length])];
    __block NSString *imageUrl;
    _contentTextView.text = content;
    for (int j = 0; j < arrayOfAllMatches.count; j++) {
        
    }
    
    NSInteger DLen = 0;
    NSMutableAttributedString *mutableAttributedString;
    for (NSTextCheckingResult *match in arrayOfAllMatches)
    {
        NSString* substringForMatch = [_contentTextView.attributedString.string substringWithRange:(NSRange){ match.range.location-DLen, match.range.length }];
        
        imageUrl = [self getImageUrl:substringForMatch];
        
        UITextRange *selectedTextRange = [FastIndexedRange rangeWithNSRange:(NSRange){ match.range.location-DLen, match.range.length }];
        
        if (!selectedTextRange) {
            UITextPosition *endOfDocument = [_contentTextView endOfDocument];
            selectedTextRange = [_contentTextView textRangeFromPosition:endOfDocument toPosition:endOfDocument];
        }
        UITextPosition *startPosition = [selectedTextRange start] ; // hold onto this since the edit will drop
        
        unichar attachmentCharacter = FastTextAttachmentCharacter;
        [_contentTextView replaceRange:selectedTextRange withText:[NSString stringWithFormat:@"\n%@\n",[NSString stringWithCharacters:&attachmentCharacter length:1]]];
        
        startPosition = [_contentTextView positionFromPosition:startPosition inDirection:UITextLayoutDirectionRight offset:1];
        UITextPosition *endPosition = [_contentTextView positionFromPosition:startPosition offset:1];
        selectedTextRange = [_contentTextView textRangeFromPosition:startPosition toPosition:endPosition];
        if (imageUrl.length != 0) {
            NSString *imageIndexs = [imageUrl substringWithRange:NSMakeRange(1, 1)];
            UIImage *image = [picCacheArr objectAtIndex:([imageIndexs integerValue]-1)];
            [picMuArr addObject:image];
            if(image){
                NSString *newfilename=[NSAttributedString scanAttachmentsForNewFileName:_contentTextView.attributedString];
                NSArray *_paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                NSString * _documentDirectory = [[NSString alloc] initWithString:[_paths objectAtIndex:0]];
                
                NSString *pngPath=[_documentDirectory stringByAppendingPathComponent:newfilename];
                UIImage *thumbimg=[image imageByScalingProportionallyToSize:CGSizeMake(1024,6000)];
                [UIImageJPEGRepresentation(thumbimg,0.7)writeToFile:pngPath atomically:YES];
                
                __block NSMutableAttributedString *mutableAttributedString=[_contentTextView.attributedString mutableCopy];
                
                NSUInteger st = ((FastIndexedPosition *)(selectedTextRange.start)).index;
                NSUInteger en = ((FastIndexedPosition *)(selectedTextRange.end)).index;
                //NSDictionary *dic = @{@"st":[NSString stringWithFormat:@"%lu",(unsigned long)st],@"en":[NSString stringWithFormat:@"%lu",(unsigned long)en],};
                //[strArr addObject:dic];
                if (en < st) {
                    return;
                }
                NSUInteger contentLength = [[_contentTextView.attributedString string] length];
                if (en > contentLength) {
                    en = contentLength; // but let's not crash
                }
                if (st > en)
                    st = en;
                NSRange cr = [[_contentTextView.attributedString string] rangeOfComposedCharacterSequencesForRange:(NSRange){ st, en - st }];
                if (cr.location + cr.length > contentLength) {
                    cr.length = ( contentLength - cr.location ); // but let's not crash
                }
                
                FileWrapperObject *fileWp = [[FileWrapperObject alloc] init];
                [fileWp setFileName:newfilename];
                [fileWp setFilePath:pngPath];
                
                SlideAttachmentCell *cell = [[SlideAttachmentCell alloc] initWithFileWrapperObject:fileWp] ;
                
                //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
                //cell.isNeedThumb=YES;
                CGFloat i;
                CGFloat imgW = image.size.width;
                CGFloat imgH = image.size.height;
                if (imgW < imgH) {
                    i = 320*image.size.width/image.size.height;
                }
                else {
                    i = image.size.height/image.size.width;
                }
                cell.thumbImageWidth=ScreenWidth ;
                cell.thumbImageHeight=200;
                //cell.txtdesc=@"幻灯片测试";
                UIColor *textColor = [UIColor colorWithHexString:@"1b9ecc"];
                UIFont *font = [UIFont systemFontOfSize:16];
                CTFontRef aFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
                if (!aFont) return;
                CTFontRef newFont = CTFontCreateCopyWithSymbolicTraits(aFont, 0.0, NULL, kCTFontItalicTrait, kCTFontBoldTrait);    //将默认黑体字设置为其它字体
                [mutableAttributedString removeAttribute:(NSString*)kCTFontAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString addAttribute:(NSString*)kCTFontAttributeName value:(__bridge id)newFont range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString removeAttribute:(NSString*)kCTForegroundColorAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)textColor.CGColor range:NSMakeRange(0, mutableAttributedString.string.length)];
                [mutableAttributedString addAttribute:FastTextAttachmentAttributeName value:cell range:cr];
                if (mutableAttributedString) {
                    _contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
                }
            }
            else{
                
            }
        }
        DLen += (match.range.length-3);
    }
    if (arrayOfAllMatches.count == 0) {
        mutableAttributedString = [_contentTextView.attributedString mutableCopy];
        UIColor *textColor = [UIColor colorWithHexString:@"1b9ecc"];
        UIFont *font = [UIFont systemFontOfSize:16];
        CTFontRef aFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
        if (!aFont) return;
        CTFontRef newFont = CTFontCreateCopyWithSymbolicTraits(aFont, 0.0, NULL, kCTFontItalicTrait, kCTFontBoldTrait);    //将默认黑体字设置为其它字体
        [mutableAttributedString removeAttribute:(NSString*)kCTFontAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
        [mutableAttributedString addAttribute:(NSString*)kCTFontAttributeName value:(__bridge id)newFont range:NSMakeRange(0, mutableAttributedString.string.length)];
        [mutableAttributedString removeAttribute:(NSString*)kCTForegroundColorAttributeName range:NSMakeRange(0, mutableAttributedString.string.length)];
        [mutableAttributedString addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)textColor.CGColor range:NSMakeRange(0, mutableAttributedString.string.length)];
        if (mutableAttributedString) {
            _contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
        }
    }
    
    if (self.contentTextView.contentSize.height < 70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
    detailView.frame = CGRectMake(detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, detailView.size.width, detailView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, _contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)_addAttachmentFromImage:(UIImage*)image
{
    NSString *key = [NSString stringWithFormat:@"a%ld.jpg",(long)imageId +1];
    imageId++;
    [self saveImageToDocument:image imageName:key withMeetingType:@"1"];
    NSData *data = UIImageJPEGRepresentation(image, 1);
    //NSFileWrapper *wrapper = [[NSFileWrapper alloc] initRegularFileWithContents:data];
    //wrapper.filename = [[rep url] lastPathComponent];
    UIImage *img=[UIImage imageWithData:data];
    [picMuArr addObject:img];
    //[self postPicViewList:img];
    NSString *newfilename=[NSAttributedString scanAttachmentsForNewFileName:_contentTextView.attributedString];
    
    NSArray *_paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString * _documentDirectory = [[NSString alloc] initWithString:[_paths objectAtIndex:0]];
    
    UIImage *thumbimg = [img imageByScalingProportionallyToSize:CGSizeMake(1024,6000)];
    
    NSString *pngPath = [_documentDirectory stringByAppendingPathComponent:newfilename];
    
    //[[AppDelegate documentDirectory] stringByAppendingPathComponent:@"tmp.jpg"];
    
    [UIImageJPEGRepresentation(thumbimg,0.7)writeToFile:pngPath atomically:YES];
    
    UITextRange *selectedTextRange = [_contentTextView selectedTextRange];
    if (!selectedTextRange) {
        UITextPosition *endOfDocument = [_contentTextView endOfDocument];
        selectedTextRange = [_contentTextView textRangeFromPosition:endOfDocument toPosition:endOfDocument];
    }
    UITextPosition *startPosition = [selectedTextRange start] ; // hold onto this since the edit will drop
    
    unichar attachmentCharacter = FastTextAttachmentCharacter;
    [_contentTextView replaceRange:selectedTextRange withText:[NSString stringWithFormat:@"\n%@\n",[NSString stringWithCharacters:&attachmentCharacter length:1]]];
    
    startPosition=[_contentTextView positionFromPosition:startPosition inDirection:UITextLayoutDirectionRight offset:1];
    UITextPosition *endPosition = [_contentTextView positionFromPosition:startPosition offset:1];
    selectedTextRange = [_contentTextView textRangeFromPosition:startPosition toPosition:endPosition];
    
    NSMutableAttributedString *mutableAttributedString = [_contentTextView.attributedString mutableCopy];
    
    NSUInteger st = ((FastIndexedPosition *)(selectedTextRange.start)).index;
    NSUInteger en = ((FastIndexedPosition *)(selectedTextRange.end)).index;
    //NSDictionary *dic = @{@"st":[NSString stringWithFormat:@"%lu",(unsigned long)st],@"en":[NSString stringWithFormat:@"%lu",(unsigned long)en],};
    //[strArr addObject:dic];
    if (en < st) {
        return;
    }
    NSUInteger contentLength = [[_contentTextView.attributedString string] length];
    if (en > contentLength) {
        en = contentLength; // but let's not crash
    }
    if (st > en)
        st = en;
    NSRange cr = [[_contentTextView.attributedString string] rangeOfComposedCharacterSequencesForRange:(NSRange){ st, en - st }];
    if (cr.location + cr.length > contentLength) {
        cr.length = ( contentLength - cr.location ); // but let's not crash
    }
    
    FileWrapperObject *fileWp = [[FileWrapperObject alloc] init];
    [fileWp setFileName:newfilename];
    [fileWp setFilePath:pngPath];
    
    SlideAttachmentCell *cell = [[SlideAttachmentCell alloc] initWithFileWrapperObject:fileWp] ;
    
    //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
    //cell.isNeedThumb=YES;
    CGFloat i;
    CGFloat imgW = img.size.width;
    CGFloat imgH = img.size.height;
    if (imgW < imgH) {
        i = 320*img.size.width/img.size.height;
    }
    else {
        i = img.size.height/img.size.width;
    }
    if(i*2 > 0.5) {
        
    }
    
    cell.thumbImageWidth = 200*img.size.width/img.size.height;
    cell.thumbImageHeight = 200*imgH/imgW;
    //cell.txtdesc=@"幻灯片测试";
    
    [mutableAttributedString addAttribute: FastTextAttachmentAttributeName value:cell  range:cr];
    
    //[mutableAttributedString addAttribute:fastTextAttachmentAttributeName value:cell  range:selectedTextRange];
    
    if (mutableAttributedString) {
        _contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
    }
    
    //[_editor setValue:attachment forAttribute:OAAttachmentAttributeName inRange:selectedTextRange];
    
    //[self htmlStringWithAttachmentPath:mutableAttributedString];
    
    if (self.contentTextView.contentSize.height < 70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
    detailView.frame = CGRectMake(detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, detailView.size.width, detailView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, _contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)_addAttachmentFromAsset:(ALAsset *)asset
{
    ALAssetRepresentation *rep = [asset defaultRepresentation];
    NSMutableData *data = [NSMutableData dataWithLength:[rep size]];
    NSError *error = nil;
    if ([rep getBytes:[data mutableBytes] fromOffset:0 length:[rep size] error:&error] == 0) {
        NSLog(@"error getting asset data %@", [error debugDescription]);
    }
    else {
        //NSFileWrapper *wrapper = [[NSFileWrapper alloc] initRegularFileWithContents:data];
        //wrapper.filename = [[rep url] lastPathComponent];
        UIImage *img=[UIImage imageWithData:data];
        NSString *key = [NSString stringWithFormat:@"a%d.png",(int)imageId +1];
        imageId++;
        [self saveImageToDocument:img imageName:key withMeetingType:@"1"];
        [picMuArr addObject:img];
        //[self postPicViewList:img];
        NSString *newfilename = [NSAttributedString scanAttachmentsForNewFileName:_contentTextView.attributedString];
        NSArray *_paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString * _documentDirectory = [[NSString alloc] initWithString:[_paths objectAtIndex:0]];
        
        UIImage *thumbimg = [img imageByScalingProportionallyToSize:CGSizeMake(1024,6000)];
        
        NSString *pngPath = [_documentDirectory stringByAppendingPathComponent:newfilename];
        
        //[[AppDelegate documentDirectory] stringByAppendingPathComponent:@"tmp.jpg"];
        
        
        [UIImageJPEGRepresentation(thumbimg,0.7)writeToFile:pngPath atomically:YES];
        
        UITextRange *selectedTextRange = [_contentTextView selectedTextRange];
        if (!selectedTextRange) {
            UITextPosition *endOfDocument = [_contentTextView endOfDocument];
            selectedTextRange = [_contentTextView textRangeFromPosition:endOfDocument toPosition:endOfDocument];
        }
        UITextPosition *startPosition = [selectedTextRange start] ; // hold onto this since the edit will drop
        
        unichar attachmentCharacter = FastTextAttachmentCharacter;
        [_contentTextView replaceRange:selectedTextRange withText:[NSString stringWithFormat:@"\n%@\n",[NSString stringWithCharacters:&attachmentCharacter length:1]]];
        
        startPosition=[_contentTextView positionFromPosition:startPosition inDirection:UITextLayoutDirectionRight offset:1];
        UITextPosition *endPosition = [_contentTextView positionFromPosition:startPosition offset:1];
        selectedTextRange = [_contentTextView textRangeFromPosition:startPosition toPosition:endPosition];
        
        NSMutableAttributedString *mutableAttributedString = [_contentTextView.attributedString mutableCopy];
        
        NSUInteger st = ((FastIndexedPosition *)(selectedTextRange.start)).index;
        NSUInteger en = ((FastIndexedPosition *)(selectedTextRange.end)).index;
        //NSDictionary *dic = @{@"st":[NSString stringWithFormat:@"%lu",(unsigned long)st],@"en":[NSString stringWithFormat:@"%lu",(unsigned long)en],};
        //[strArr addObject:dic];
        if (en < st) {
            return;
        }
        NSUInteger contentLength = [[_contentTextView.attributedString string] length];
        if (en > contentLength) {
            en = contentLength; // but let's not crash
        }
        if (st > en)
            st = en;
        NSRange cr = [[_contentTextView.attributedString string] rangeOfComposedCharacterSequencesForRange:(NSRange){ st, en - st }];
        if (cr.location + cr.length > contentLength) {
            cr.length = ( contentLength - cr.location ); // but let's not crash
        }
        
        if(isAddSlide) {
            
            FileWrapperObject *fileWp = [[FileWrapperObject alloc] init];
            [fileWp setFileName:newfilename];
            [fileWp setFilePath:pngPath];
            
            SlideAttachmentCell *cell = [[SlideAttachmentCell alloc] initWithFileWrapperObject:fileWp] ;
            
            //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
            //cell.isNeedThumb=YES;
            CGFloat i;
            CGFloat imgW = img.size.width;
            CGFloat imgH = img.size.height;
            if (imgW < imgH) {
                i = 320*img.size.width/img.size.height;
            }
            else {
                i = img.size.height/img.size.width;
            }
            if(i*2 > 0.5) {
                
            }
            cell.thumbImageWidth = 200*img.size.width/img.size.height;
            cell.thumbImageHeight = 200*imgH/imgW;
            //cell.txtdesc=@"幻灯片测试";
            [mutableAttributedString addAttribute: FastTextAttachmentAttributeName value:cell  range:cr];
            //[mutableAttributedString addAttribute:fastTextAttachmentAttributeName value:cell  range:selectedTextRange];
        }
        else {
            //ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] initWithFileWrapper:wrapper] ;
            ////ImageAttachmentCell *cell = [[ImageAttachmentCell alloc] init];
            //cell.isNeedThumb=TRUE;
            //cell.thumbImageWidth=200.0f;
            //cell.thumbImageHeight=200.0f;
            //[mutableAttributedString addAttribute: fastTextAttachmentAttributeName value:cell  range:cr];
        }
        
        if (mutableAttributedString) {
            _contentTextView.attributedString = (FastTextStorage *)mutableAttributedString;
        }
        
        //[_editor setValue:attachment forAttribute:OAAttachmentAttributeName inRange:selectedTextRange];
        //[self htmlStringWithAttachmentPath:mutableAttributedString];
    }
    
    if (self.contentTextView.contentSize.height < 70) {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width,70);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, 128);
    }
    else {
        self.contentTextView.frame = CGRectMake(self.contentTextView.origin.x, self.contentTextView.origin.y, self.contentTextView.contentSize.width, self.contentTextView.contentSize.height);
        self.contentView.frame = CGRectMake(self.contentView.origin.x, self.contentView.origin.y, self.contentView.size.width, self.contentTextView.contentSize.height+58);
    }
    line2.frame = CGRectMake(0, CGRectGetHeight(_contentView.frame) - 0.5, ScreenWidth, 0.5);
    detailView.frame = CGRectMake(detailView.origin.x, CGRectGetMaxY(_contentView.frame)+10, detailView.size.width, detailView.size.height);
    _mainScrollView.contentSize = CGSizeMake(ScreenWidth, CGRectGetMaxY(detailView.frame));
    
    self.toolBar.delBtn.hidden = NO;
    self.toolBar.hideBtn.hidden = YES;
    self.toolBar.frame = CGRectMake(0, _contentView.size.height-35, ScreenWidth, 35);
    [self.contentView addSubview:self.toolBar];
    [self.contentView bringSubviewToFront:self.toolBar];
}

- (void)getSelectedImage:(UIImage *)image
{
    [_contentTextView insertText:@" "];
    //image = [self imageWithImage:image scaledToSize: [self getImageSize:image.size]];
    [self _addAttachmentFromImage:image];
}

- (void)getSelectedPhoto:(NSMutableArray *)photos
{
    [_contentTextView insertText:@" "];
    for (ALAsset *asset in photos) {
        
        //CGImageRef posterImageRef = [asset thumbnail];
        //UIImage *selectedImage = [UIImage imageWithCGImage:posterImageRef];
        
        ALAssetRepresentation *posterImageRap = [asset defaultRepresentation];
        CGImageRef posterImageRef = [posterImageRap fullScreenImage];
        UIImage *selectedImage = [UIImage imageWithCGImage:posterImageRef];
        
        NSData * newData = UIImageJPEGRepresentation(selectedImage, 0.0001);
        UIImage * img = [UIImage imageWithData:newData];
        img = [self imageWithImage:img scaledToSize: [self getImageSize:img.size]];
        
        [self _addAttachmentFromImage:img];
    }
}

#pragma mark - ImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //[_contentTextView insertText:@" "];
    
    UIImage *selectedImage = nil;
    selectedImage = [info objectForKey:UIImagePickerControllerEditedImage];
    
    if (nil == selectedImage) {
        selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    
    // 保存图片到相册中
    SEL selectorToCall = @selector(imageWasSavedSuccessfully:didFinishSavingWithError:contextInfo:);
    UIImageWriteToSavedPhotosAlbum(selectedImage, self,selectorToCall, NULL);
    
    [self dismissViewControllerAnimated:NO completion:^{
        TOCropViewController *cropController = [[TOCropViewController alloc] initWithImage:selectedImage];
        //cropController.aspectRatio = CGSizeMake(1.0f, 1.0f);
        cropController.delegate = self;
        [self presentViewController:cropController animated:NO completion:nil];
    }];
    
    //[self _addAttachmentFromImage:selectedImage];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];
}

// 保存图片后到相册后，调用的相关方法，查看是否保存成功
- (void)imageWasSavedSuccessfully:(UIImage *)paramImage didFinishSavingWithError:(NSError *)paramError contextInfo:(void *)paramContextInfo{
    if (paramError == nil){
        NSLog(@"Image was saved successfully.");
    } else {
        NSLog(@"An error happened while saving the image.");
        NSLog(@"Error = %@", paramError);
    }
}

- (void)cropViewController:(TOCropViewController *)cropViewController didCropToImage:(UIImage *)image withRect:(CGRect)cropRect angle:(NSInteger)angle{
    
    [self getSelectedImage:image];
    
    [self dismissViewControllerAnimated:NO completion:^{
        
    }];
}

- (void)postImageWithImages:(NSArray *)arr
{
    UIImage * img = [picMuArr firstObject];
    NSData * data;
    
    [hud showCenterProgressWithText:[NSString stringWithFormat:@"正在上传图片%d/%d",imageIndex,imageCount]];
    //data = UIImageJPEGRepresentation(img, 0.0001);
    data = [Helper imageData:img];
    NSString * imageStr = [GTMBase64 stringByEncodingData:data];
    NSDictionary *dic = @{@"iospic":imageStr,@"iospic_type":@"jpg"};
    //NSDictionary *dic = @{@"ico_file":_imageStr};
    [MyDataService postUploadPicture:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
            NSLog(@"%@",[[data objectForKey:@"content"] class]);
            //NSString *urlKey = [NSString stringWithFormat:@"url%d",(int)arr.count];
            
            [picUrlMuArr addObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] ];
            
            [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
            [[DBManager sharedInstance] insertDataToPublicDB:[NSString stringWithFormat:@"%d",(int)arr.count]  valueKey:[NSString stringWithFormat:@"type_%d_imageCount",_type]];
            
            [picMuArr removeObjectAtIndex:0];
            imageIndex++;
            if (picMuArr.count != 0) {
                [self postImageWithImages:picMuArr];
            }
            
            if (picMuArr.count == 0) {
                
                NSString *content = [self rePlaceUrl:[_postDic objectForKey:@"summary"]];
                [_postDic setObject:content forKey:@"summary"];
                
                [hud hideProgress];
                [MyDataService postAddMeeting:_postDic callback:^(id data) {
                    NSLog(@"%@",data);
                    [hud hideProgress];
                    [[Dialog Instance] hideProgress];
                    if([[data objectForKey:@"code"]isEqualToString:@"200"] || [[data objectForKey:@"code"] objectForKey:@"201"])
                    {
                        [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"meeting_type_%d",(_type)]];
                        New_managerViewController *managerViewController = [[New_managerViewController alloc]init];
                        managerViewController.isCreate = YES;
                        managerViewController.meeting_id = [[data objectForKey:@"content"] objectForKey:@"insert_id"];
                        [_contentTextView removeFromSuperview];
                        [self.navigationController pushViewController:managerViewController animated:YES];
                    }
                }];
            }
            else {
                [hud showCenterProgressWithText:[NSString stringWithFormat:@"正在上传图片%d/%d",imageIndex,imageCount ]];
            }
            //NSDictionary *dic = @{@"url":[[data objectForKey:@"content"] objectForKey:@"icon_file"]};
            //[imageArr addObject:dic];
        }
        else {
            [hud hideProgress];
        }
    }];
}

//更改图片大小
- (CGSize)getImageSize:(CGSize)imageSize
{
    CGFloat num1 = (imageSize.width)/(imageSize.height);
    NSLog(@"%f",num1);
    CGFloat num = (imageSize.height)/(imageSize.width);
    NSLog(@"%f",num);
    CGFloat num2 = 1024/1024;
    CGRect cellImageFrame;
    if (imageSize.height > 1024) {
        if (num1 >= num2) {
            cellImageFrame = CGRectMake(0, (1024-1024*num)/2, 1024, 1024*num);
        }
        else {
            cellImageFrame = CGRectMake((1024-1024*num1)/2, 0, 1024*num1, 1024);
        }
    }
    else {
        if (num1 >= num2) {
            if (imageSize.width >= 1024) {
                cellImageFrame = CGRectMake(0, (1024-1024*num)/2, 1024, 1024*num);
            }
            else {
                cellImageFrame = CGRectMake((1024-imageSize.width)/2, (1024-imageSize.height)/2, imageSize.width ,imageSize.height);
            }
        }
        else {
            cellImageFrame = CGRectMake((1024-imageSize.width)/2, (1024-imageSize.height)/2, imageSize.width, imageSize.height);
        }
    }
    return CGSizeMake(cellImageFrame.size.width, cellImageFrame.size.height);
}

- (UIImage*)imageWithImage:(UIImage*)image scaledToSize:(CGSize)newSize
{
    // Create a graphics image context
    UIGraphicsBeginImageContext(newSize);
    
    // Tell the old image to draw in this new context, with the desired
    // new size
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    
    // Get the new image from the context
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // End the context
    UIGraphicsEndImageContext();
    
    // Return the new image.
    return newImage;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
