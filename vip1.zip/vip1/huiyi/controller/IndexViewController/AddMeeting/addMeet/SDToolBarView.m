//
//  SDToolBarView.m
//  huiyi
//
//  Created by songhongshuai on 15/1/6.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SDToolBarView.h"

@implementation SDToolBarView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        BackGround16Color(self, @"#f8f8f8");
        
        UILabel *sline = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
        BackGround16Color(sline, @"#c8c7cc");
        [self  addSubview:sline];
        
        _imageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _imageBtn.frame = CGRectMake(12, 7.5, 25, 20);
        _imageBtn.tag = 1000;
        [_imageBtn setImage:[UIImage imageNamed:@"pic"] forState:UIControlStateNormal];
        [_imageBtn addTarget:self action:@selector(SDBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_imageBtn];
        
        _delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _delBtn.frame = CGRectMake(ScreenWidth-35, 7.5, 35, 20);
        _delBtn.tag = 1001;
        [_delBtn setImage:[UIImage imageNamed:@"del"] forState:UIControlStateNormal];
        [_delBtn addTarget:self action:@selector(SDBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_delBtn];
        
        _hideBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _hideBtn.frame = CGRectMake(ScreenWidth-50, 7.5, 50, 20);
        _hideBtn.tag = 1002;
        _hideBtn.titleLabel.font = YHUI(14);
        _hideBtn.backgroundColor = [UIColor clearColor];
        [_hideBtn setTitle:@"完成" forState:UIControlStateNormal];
        [_hideBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_hideBtn addTarget:self action:@selector(SDBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_hideBtn];
        
        UILabel *eline = [[UILabel alloc]initWithFrame:CGRectMake(0 , frame.size.height-0.5, ScreenWidth, 0.5)];
        BackGround16Color(eline, @"#c8c7cc");
        [self  addSubview:eline];
    }
    return self;
}

- (void)SDBtnClicked:(UIButton *)btn
{
    if (btn.tag == 1000) {
        [self.delegate selectImage];
    }
    if (btn.tag == 1001) {
        [self.delegate delContent];
    }
    if (btn.tag == 1002) {
        [self.delegate HideKeyBoard];
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
