//
//  PluginCollectionViewCell.m
//  huiyi
//
//  Created by songhongshuai on 16/1/21.
//  Copyright © 2016年 shs. All rights reserved.
//

#import "PluginCollectionViewCell.h"
#import "UIOptionButton.h"
#import "UIButton+WebCache.h"
@interface PluginCollectionViewCell ()
@property (nonatomic,strong)UIOptionButton *pluginBtn;
@end

@implementation PluginCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

    }
    return self;
}
- (void)setPluginInfo:(gridInfo *)pluginInfo
{
    if (pluginInfo) {
        [self.contentView addSubview:self.pluginBtn];
    }
}
- (UIOptionButton *)pluginBtn
{
    if (!_pluginBtn) {
        _pluginBtn = [[UIOptionButton alloc]initWithFrame:CGRectMake(0, 0 , 80, 80)];
        _pluginBtn.center = self.contentView.center;
        [_pluginBtn sd_setImageWithURL:[NSURL URLWithString:self.pluginInfo.urlStr]forState:UIControlStateNormal];
        [_pluginBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_pluginBtn setTitle:self.pluginInfo.title forState:UIControlStateNormal];
        _pluginBtn.backgroundColor = [UIColor whiteColor];
    }
    return _pluginBtn;
}
@end
