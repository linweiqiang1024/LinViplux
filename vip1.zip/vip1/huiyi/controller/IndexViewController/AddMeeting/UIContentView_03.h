//
//  UIContentView_03.h
//  huiyi
//
//  Created by songhongshuai on 15/1/7.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SendMessageDelegate <NSObject>

- (void)sentMessage;

@end
@interface UIContentView_03 : UIView

@property (nonatomic,strong)UILabel *nameLB;
@property (nonatomic,strong)UIButton *mesBtn;
@property (nonatomic,strong)UIImageView *desImageView;
@property (nonatomic,strong)UILabel *contentLB;
@property (nonatomic,strong)UILabel *line;
@property (nonatomic,weak)id<SendMessageDelegate>delegate;
@end
