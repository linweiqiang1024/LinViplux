//
//  New_SignUpInfoViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-31.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
@interface New_SignUpInfoViewController : FatherViewController
{
    NSString *_meetID;
    NSString *_meetTitle;
    NSString *_blockID;
    BOOL _haveImage;//有没有海报图片
    NSString *_meet_type;//会议类型
}
//易企秀  NO   海报  YES
@property (nonatomic,copy)NSString* isPoster;
@property (nonatomic,strong)NSString *meetPoster_url;
@property (nonatomic,strong)NSString *meetID;
@property (nonatomic,strong)NSString *meetTitle;
@property (nonatomic,strong)NSString *blockID;
@property (nonatomic)BOOL isBack;
@property (nonatomic)BOOL haveImage;//有没有海报图片
@property (nonatomic,strong)NSString *meet_type;
//轮播图的 ScrollView
@property (nonatomic, retain) UIScrollView *imgContainer;
@property (nonatomic, retain) UIScrollView *wrapperScroll;
@property (nonatomic, strong) NSArray *photoArray;
@property (nonatomic, strong) NSMutableArray *photoMutableArray;

@property (nonatomic,strong)NSString *companyCode;
@property (nonatomic,strong)NSString *companyName;

@end
