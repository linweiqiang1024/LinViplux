//
//  New_myApplyListCell.h
//  huiyi
//
//  Created by 王振兴 on 15-2-10.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface New_myApplyListModel : NSObject
{
    

}
/**
 *  姓名
 */
@property(nonatomic,strong)NSString *name;
/**
 *  报名状态跟踪的下一层
 */
@property(nonatomic,strong)NSString *block_id;
/**
 *  yes：自己报名 no：代人报名
 */
@property(nonatomic)BOOL is_create;
/**
 *  报名时间
 */
@property(nonatomic,strong)NSString *partake_time;
/**
 *  报名人的uid
 */
@property(nonatomic,strong)NSString *user_id;
/**
 *  状态
 */
@property(nonatomic,strong)NSString * approved;

@end

@interface New_myApplyListCell : UITableViewCell
{
    UIImageView *_cellImageView;
    UILabel *_cellName;
    UILabel *_cellApplyTime;
    UIButton *_cellState;//报名状态
    NSString *_cellStateType;//报名的状态值
}
@property (nonatomic,strong)UIImageView *cellImageView;
@property (nonatomic,strong)UILabel *cellName;
@property (nonatomic,strong)UILabel *cellApplyTime;
@property (nonatomic,strong)UIButton *cellState;
@property (nonatomic,strong)NSString *cellStateType;
@end
