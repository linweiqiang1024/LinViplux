//
//  UIShareButton.h
//  huiyi
//
//  Created by songhongshuai on 14/11/12.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIShareButton : UIButton

@end
