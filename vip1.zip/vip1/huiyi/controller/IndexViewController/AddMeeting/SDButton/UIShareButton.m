//
//  UIShareButton.m
//  huiyi
//
//  Created by songhongshuai on 14/11/12.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "UIShareButton.h"

@implementation UIShareButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.titleLabel.font = YHUI(9);
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        // Initialization code
    }
    return self;
}
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, 0, 50, 50);
}
- (CGRect)titleRectForContentRect:(CGRect)contentRect{

    return CGRectMake(0, 50, self.frame.size.width, self.frame.size.height-50);
}

@end
