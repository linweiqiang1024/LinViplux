//
//  SignUpFieldsModel.m
//  huiyi
//
//  Created by qstx1 on 14-11-5.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "SignUpFieldsModel.h"

@implementation SignUpFieldsModel
@synthesize btnTag = _btnTag;
@synthesize selected = _selected;
@synthesize title = _title;


@end
