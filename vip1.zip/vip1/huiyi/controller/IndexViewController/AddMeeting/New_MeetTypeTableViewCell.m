//
//  New_MeetTypeTableViewCell.m
//  huiyi
//
//  Created by 林伟强 on 16/7/29.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "New_MeetTypeTableViewCell.h"

@interface New_MeetTypeTableViewCell () <UITextFieldDelegate>

@property (nonatomic, assign) CGFloat myViewBeginX;
@property (nonatomic, strong) UIPanGestureRecognizer *pan;

@end

@implementation New_MeetTypeTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    
    self.deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.deleteButton.frame = CGRectMake(ScreenWidth-70, 0, 70, 40);
    [self.deleteButton setBackgroundColor:[UIColor colorWithHexString:@"#FF4B30"]];
    [self.deleteButton setTitle:@"删除" forState:UIControlStateNormal];
    [self.deleteButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.deleteButton.titleLabel setFont:[UIFont systemFontOfSize:20]];
    [self.deleteButton addTarget:self action:@selector(deleteButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.deleteButton];
    
    self.myView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
    [self.myView setBackgroundColor: [UIColor whiteColor]];
    [self.contentView addSubview:self.myView];
    
    self.pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureAction:)];
    
    self.myImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 10, 20, 20)];
    [self.myImageView setContentMode:UIViewContentModeScaleAspectFit];
    [self.myView addSubview:self.myImageView];
    
    self.myTextField = [[UITextField alloc] initWithFrame:CGRectMake(44, 0, ScreenWidth-44, 40)];
    [self.myTextField setBackgroundColor:[UIColor clearColor]];
    [self.myTextField setFont:WORLD_FONT(14)];
    [self.myTextField setDelegate:self];
    [self.myTextField setClearsOnBeginEditing:NO];
    [self.myTextField setReturnKeyType:UIReturnKeyDone];
    [self.myTextField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.myView addSubview:self.myTextField];
    
    self.bottomLineView = [[UIImageView alloc] initWithFrame:CGRectMake(44, 39.5, ScreenWidth-44, 0.5)];
    [self.bottomLineView setBackgroundColor:[UIColor colorWithHexString:@"#E3E3E3"]];
    [self.myView addSubview:self.bottomLineView];
    
    self.addTagLabel = [[UILabel alloc] initWithFrame:CGRectMake(44, 0, ScreenWidth-44, 40)];
    [self.addTagLabel setHidden:YES];
    [self.addTagLabel setText:@"添加标签"];
    [self.addTagLabel setFont:WORLD_FONT(14)];
    [self.addTagLabel setTextColor:[UIColor colorWithHexString:@"#C6C6C6"]];
    [self.addTagLabel setTextAlignment:NSTextAlignmentLeft];
    [self.addTagLabel setBackgroundColor:[UIColor clearColor]];
    [self.myView addSubview:self.addTagLabel];
    
    self.myButton = [UIButton buttonWithType:UIButtonTypeCustom];;
    self.myButton.frame = CGRectMake(0, 0, 44, 40);
    [self.myButton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.myView addSubview:self.myButton];
}

- (void)reloadCellWith:(NSInteger)index
{
    [UIView animateWithDuration:0.25 animations:^{
        [self setView:self.myView offsetX:0];
    }];
    if (index != self.count - 1) {
        [self.myView addGestureRecognizer:self.pan];
    }
    else {
        NSString *customTag = [[NSUserDefaults standardUserDefaults] objectForKey:@"customTag"];
        if ([customTag isEqualToString:@"add"]) {
            [self.myView removeGestureRecognizer:self.pan];
        }
        else if ([customTag isEqualToString:@"delete"]) {
            [self.myView addGestureRecognizer:self.pan];
        }
    }
}

/**
 拖动手势的函数
 */
- (void)panGestureAction:(UIPanGestureRecognizer *)pan
{
    CGFloat y = [pan translationInView:self].y;
    
    if (self.sendPanBlock) {
        self.sendPanBlock(pan, y);
    }
    
    // 首先获取手势在屏幕的x轴的坐标
    CGFloat x = [pan translationInView:self].x;
    
    NSLog(@"%f", x);
    
    // 判定手势的状态
    if (pan.state == UIGestureRecognizerStateBegan)
    {
        _myViewBeginX = self.myView.frame.origin.x;
    }
    else if (pan.state == UIGestureRecognizerStateChanged)
    {
        if (self.myView.frame.origin.x <= 0 && self.myView.frame.origin.x >= -120) {
            if (_myViewBeginX + x > 0) {
                [self setView:self.myView offsetX:0];
            }
            else {
                [self setView:self.myView offsetX:_myViewBeginX + x];
            }
        }
    }
    else if (pan.state == UIGestureRecognizerStateEnded)
    {
        static CGFloat offsetX = 0;
        if (self.myView.frame.origin.x < -35) {
            offsetX = -70;
        }
        else if (self.myView.frame.origin.x >= -35 && self.myView.frame.origin.x < 0) {
            offsetX = 0;
        }
        else {
            offsetX = 0;
        }
        [UIView animateWithDuration:0.25 animations:^{
            [self setView:self.myView offsetX:offsetX];
        }];
    }
}

/**
 修改x轴的坐标
 */
- (void)setView:(UIView *)view offsetX:(CGFloat)x
{
    CGRect rect = view.frame;
    rect.origin.x = x;
    view.frame = rect;
}

#pragma makr - UITextField delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.25 animations:^{
        [self setView:self.myView offsetX:0];
    }];
    /*
    [textField becomeFirstResponder];
    if ([textField.text isEqualToString:@""]) {
        if (self.sendTextFieldBlock) {
            self.sendTextFieldBlock(textField);
        }
    }*/
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.25 animations:^{
        [self setView:self.myView offsetX:0];
    }];
    //[textField resignFirstResponder];
    textField.text = [self subStringWithBit:10 string:textField.text];
    //textField.text = [self subStringWithBit:10 withString:textField.text];
    if (self.sendBlock) {
        self.sendBlock(textField.tag, textField.text);
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
/*
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    // 汉字(字符)
    NSString *regex = @"[\u4e00-\u9fa5]";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    NSString *str = [string substringWithRange:range];
    
    if (string.length > 0) {
        if (![pred evaluateWithObject:str]) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入汉字且不可超过5个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alertView show];
            return NO;
        }
    }
    return YES;
}*/

- (void)buttonAction:(UIButton *)sender
{
    if (sender.tag == self.count-1+100) {
        NSString *customTag = [[NSUserDefaults standardUserDefaults] objectForKey:@"customTag"];
        if ([customTag isEqualToString:@"add"]) {
            if (self.sendButtonBlock) {
                self.sendButtonBlock(sender);
            }
        }
        else if ([customTag isEqualToString:@"delete"]) {
            [UIView animateWithDuration:0.25 animations:^{
                [self setView:self.myView offsetX:-70];
            }];
        }
    }
    else {
        [UIView animateWithDuration:0.25 animations:^{
            [self setView:self.myView offsetX:-70];
        }];
    }
    /*
    if (self.sendButtonBlock) {
        self.sendButtonBlock(sender);
    }*/
}

- (void)deleteButtonAction:(UIButton *)sender
{
    if (self.sendButtonBlock) {
        self.sendButtonBlock(sender);
    }
}

- (void)textFieldDidChange:(UITextField *)textField
{
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (NSString *)subStringWithBit:(int)numbers string:(NSString *)string{
    if ([self stringContainsEmoji:string]) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"不支持表情符号，请重新输入" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertView show];
        return @"";
    }
    
    NSMutableString *newName = [NSMutableString stringWithCapacity:0];
    NSMutableArray *strArr = [NSMutableArray arrayWithCapacity:0];
    int len = 0;
    for (int i = 0; i < string.length; i++) {
        NSRange rang = NSMakeRange(i, 1);
        NSString *str = [string substringWithRange:rang];
        [strArr addObject:str];
        
        if (strlen([str UTF8String]) == 3) {
            len+=2;
        }else{
            len+=1;
        }
        
        if (len > numbers) {
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入不超过10个字符（5个汉字）" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alertView show];
            break;
        }
        [newName appendString:str];
    }
    return newName;
}

- (NSString *)subStringWithBit:(int)numbers withString:(NSString *)string{
    // 汉字(字符)
    NSString *regex = @"[\u4e00-\u9fa5]";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    NSMutableString *newName = [NSMutableString stringWithCapacity:0];
    NSMutableArray *strArr = [NSMutableArray arrayWithCapacity:0];
    int len = 0;
    int newlen = 0;
    for (int i = 0; i<string.length; i++) {
        NSRange rang = NSMakeRange(i, 1);
        NSString *str = [string substringWithRange:rang];
        [strArr addObject:str];
        
        if (strlen([str UTF8String]) == 3) {
            if ([pred evaluateWithObject: str]) {
                len+=2;
                
                if (len>numbers) {
                    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入汉字且不可超过5个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                    [alertView show];
                    break;
                }
                
                [newName appendString:str];
            }
            else {
                newlen+=1;
            }
        }
        else {
            newlen+=1;
        }
    }
    if (newlen > 0) {
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"" message:@"请输入汉字且不可超过5个汉字" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertView show];
    }
    return newName;
}

//是否含有表情
- (BOOL)stringContainsEmoji:(NSString *)string
{
    __block BOOL returnValue = NO;
    
    [string enumerateSubstringsInRange:NSMakeRange(0, [string length])
                               options:NSStringEnumerationByComposedCharacterSequences
                            usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop) {
                                const unichar hs = [substring characterAtIndex:0];
                                if (0xd800 <= hs && hs <= 0xdbff) {
                                    if (substring.length > 1) {
                                        const unichar ls = [substring characterAtIndex:1];
                                        const int uc = ((hs - 0xd800) * 0x400) + (ls - 0xdc00) + 0x10000;
                                        if (0x1d000 <= uc && uc <= 0x1f77f) {
                                            returnValue = YES;
                                        }
                                    }
                                } else if (substring.length > 1) {
                                    const unichar ls = [substring characterAtIndex:1];
                                    if (ls == 0x20e3) {
                                        returnValue = YES;
                                    }
                                } else {
                                    if (0x2100 <= hs && hs <= 0x27ff) {
                                        returnValue = YES;
                                    } else if (0x2B05 <= hs && hs <= 0x2b07) {
                                        returnValue = YES;
                                    } else if (0x2934 <= hs && hs <= 0x2935) {
                                        returnValue = YES;
                                    } else if (0x3297 <= hs && hs <= 0x3299) {
                                        returnValue = YES;
                                    } else if (hs == 0xa9 || hs == 0xae || hs == 0x303d || hs == 0x3030 || hs == 0x2b55 || hs == 0x2b1c || hs == 0x2b1b || hs == 0x2b50) {
                                        returnValue = YES;
                                    }
                                }
                            }];
    
    return returnValue;
}

@end
