//
//  MyBGTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-10-29.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITypeButton.h"
#import "UICostTypeButton.h"

@protocol meetSelectDelegate <NSObject>

- (void)meetTypeChange:(UITypeButton *)btn;

@end
@interface MyBGTableViewCell : UITableViewCell

{
    UILabel *headLineLB;
    UILabel *endLineLB;
    UILabel *midLB;
    UILabel *_titleLB;
}
@property (nonatomic,strong)UILabel *titleLB;
@property (nonatomic,strong)UITypeButton *meetTypeBtn1;
@property (nonatomic,strong)UITypeButton *meetTypeBtn2;
@property (nonatomic,strong)UITypeButton *meetTypeBtn3;
@property (nonatomic,strong)UIImageView *moreInfoImageView;
@property (nonatomic,weak)id <meetSelectDelegate> delegate;
@property (nonatomic,strong)UICostTypeButton *costBtn;
@property (nonatomic)BOOL isHead;
@property (nonatomic)BOOL isEnd;
@property (nonatomic)BOOL haveMoreTitle;
@end
