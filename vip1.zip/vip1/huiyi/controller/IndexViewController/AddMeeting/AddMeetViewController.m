//
//  AddMeetViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-14.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "AddMeetViewController.h"
#import "RegistTextField.h"
#import "MWCommon.h"
#import "GTMBase64.h"
#import "MWPhotoBrowser.h"
@interface AddMeetViewController ()<UITextViewDelegate,UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,MWPhotoBrowserDelegate>
{
    UILabel *placeholder;
    CGSize _keySize;
    UISegmentedControl *_segmentedControl;
    UIScrollView *scrollView;
    CGPoint _currentPoint;
    UIView * backView;
    UIView *headview1;
    UIView *headview2;
    UIView *headview3;
    UIView *headview4;
    UIView *headview5;
    UIView *headview6;
    UIScrollView *imageScrollView;
    UITextView *detailsTextView;
    NSMutableArray *imageArr;
    NSString *_imageStr;
}
@end

@implementation AddMeetViewController

- (void)createNavRightBtn
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(ScreenWidth-80, _navheight+4, 80, 40);
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [rightbtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    rightbtn.titleLabel.font = YHUI_BOLD(16);
    [rightbtn setTitle:@"发布" forState:UIControlStateNormal];
    [self.view addSubview:rightbtn];
}
- (void)rightBtnClicked
{
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"AddMeetViewController"];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"AddMeetViewController"];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardShow:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.photos = [[NSArray alloc]init];
    self.thumbs = [[NSMutableArray alloc]initWithCapacity:0];
    self.titlelabel.text = @"填写会议信息";
    imageArr = [[NSMutableArray alloc]initWithCapacity:0];
    [self createNavRightBtn];
    BackGround16Color(self.view, @"#efeff4");
    
    scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT+(iphone6Plus?1.5:1), ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    scrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight+40);
    BackGround16Color(scrollView, @"#efeff4");
    [self.view addSubview:scrollView];
    
    headview1 = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 50)];
    BackGround16Color(headview1, @"#eefbfe");
    [scrollView addSubview:headview1];

    UILabel *headLB = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, ScreenWidth-20, 49.5)];
    headLB.backgroundColor = [UIColor clearColor];
    headLB.text = @"提示：发布违法，反动互动信息或冒用他人、组织名义发起互动将依据记录提交公安机关处理。";
    headLB.font = YHUI(14);
    headLB.lineBreakMode = NSLineBreakByWordWrapping;
    headLB.numberOfLines = 0;
    [headview1 addSubview:headLB];
    
    UILabel *headLine1LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLB.frame), ScreenWidth, 0.5)];
    BackGround16Color(headLine1LB, @"#c8c7cc");
    [headview1 addSubview:headLine1LB];
    
    headview2 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLine1LB.frame)+9, ScreenWidth, 81.5)];
    headview2.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:headview2];
    
    UILabel *headLine2LB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLine2LB, @"#c8c7cc");
    [headview2 addSubview:headLine2LB];
    
    RegistTextField *meetNameTF = [[RegistTextField alloc]initWithFrame:CGRectMake(17, CGRectGetMaxY(headLine2LB.frame) + 8, 300, 22)];
    BackGroundColor(meetNameTF, clearColor);
    meetNameTF.placeholder = @"输入活动主题";
    meetNameTF.tag = 110;
    meetNameTF.delegate = self;
    [meetNameTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    meetNameTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
    [headview2 addSubview:meetNameTF];
    
    UILabel *headLine3LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLine2LB.frame)+40, ScreenWidth, 0.5)];
    BackGround16Color(headLine3LB, @"#c8c7cc");
    [headview2 addSubview:headLine3LB];
    
    RegistTextField *meetTimeTF = [[RegistTextField alloc]initWithFrame:CGRectMake(17, CGRectGetMaxY(headLine3LB.frame) + 8, 300, 22)];
    BackGroundColor(meetTimeTF, clearColor);
    meetTimeTF.placeholder = @"报名截止日期";
    meetTimeTF.tag = 111;
    meetNameTF.delegate = self;
    [meetTimeTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    meetTimeTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
    [headview2 addSubview:meetTimeTF];
    
    UILabel *headLine4LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(headview2.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(headLine4LB, @"#c8c7cc");
    [headview2 addSubview:headLine4LB];
    
    //详情
    headview3 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headview2.frame)+9, ScreenWidth, 162.5)];
    headview3.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:headview3];
    
    UILabel *headLine5LB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLine5LB, @"#c8c7cc");
    [headview3 addSubview:headLine5LB];
    
    detailsTextView = [[UITextView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLine5LB.frame), ScreenWidth, 130.5)];

    detailsTextView.delegate = self;
    detailsTextView.font = YHUI(16);
    detailsTextView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    detailsTextView.backgroundColor = [UIColor clearColor];
    [headview3 addSubview:detailsTextView];
    
    placeholder = [[UILabel alloc]initWithFrame:CGRectMake(15, 10, 290, 22)];
    placeholder.textColor = [UIColor colorWithHexString:@"d3d3d3"];
    placeholder.text = @"活动详情，详细说明时间、地点、事件";
    placeholder.font = YHUI(16);
//    placeholder.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    placeholder.backgroundColor = [UIColor clearColor];
    [detailsTextView addSubview:placeholder];
    
    UILabel *headLine14LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(detailsTextView.frame), ScreenWidth, 0.5)];
    headLine14LB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    BackGround16Color(headLine14LB, @"#c8c7cc");
    [headview3 addSubview:headLine14LB];
    
    imageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLine14LB.frame), ScreenWidth , 0)];

    [imageScrollView setShowsHorizontalScrollIndicator:NO];
    [imageScrollView setShowsVerticalScrollIndicator:NO];
    imageScrollView.backgroundColor = [UIColor clearColor];
    for (int i = 0; i < 5; i++) {
        UIImageView * imageviews = [[UIImageView alloc]initWithFrame:CGRectMake(i*(10+60), 0, 60, 60)];
        imageviews.backgroundColor = [UIColor clearColor];
        imageviews.tag = 140+i ;
        imageviews.userInteractionEnabled = YES;
        UIGestureRecognizer  *oneFingeTwoTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getBigImages:)];
        // 点击次数
       
        [imageviews addGestureRecognizer:oneFingeTwoTaps];
        [imageScrollView addSubview:imageviews];
    }
    imageScrollView.contentSize = CGSizeMake(ScreenWidth+60, 60);
    [headview3 addSubview:imageScrollView];

    UILabel *headLine6LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(imageScrollView.frame), ScreenWidth, 0.5)];
    headLine6LB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

    BackGround16Color(headLine6LB, @"#c8c7cc");
    [headview3 addSubview:headLine6LB];
    
    
    
    backView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(imageScrollView.frame), ScreenWidth, 30.5)];
    backView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    backView.tag = 131;
    backView.userInteractionEnabled = YES;
    backView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];

    [headview3 addSubview:backView];
    
    
 
    
    UIButton *selecedImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    selecedImageBtn.frame = CGRectMake(3, CGRectGetHeight(backView.frame)-27, 58, 23);
    [selecedImageBtn setImage:[UIImage imageNamed:@"photo"] forState:UIControlStateNormal];
    selecedImageBtn.backgroundColor = [UIColor clearColor];
    [selecedImageBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    selecedImageBtn.tag = 122;
    selecedImageBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

    [backView addSubview:selecedImageBtn];
    
    
    UILabel *headLine7LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(headview3.frame)-0.5, ScreenWidth, 0.5)];
    headLine7LB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

    BackGround16Color(headLine7LB, @"#c8c7cc");
    [headview3 addSubview:headLine7LB];
    //地图标注
    headview4 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headview3.frame)+9, ScreenWidth, 41)];
    headview4.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

    headview4.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:headview4];
    
    UILabel *headLine8LB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLine8LB, @"#c8c7cc");
    [headview4 addSubview:headLine8LB];
    
    UIImageView *addrImageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 8, 20, 25)];
    addrImageView.image = [UIImage imageNamed:@"map"];
    [headview4 addSubview:addrImageView];
    
    
    RegistTextField *addressTF = [[RegistTextField alloc]initWithFrame:CGRectMake(40, 0.5, 250, 40)];
    BackGroundColor(addressTF, clearColor);
    addressTF.placeholder = @"请输入活动地址";
    addressTF.tag = 112;
    addressTF.delegate = self;
    [addressTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    addressTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
    [headview4 addSubview:addressTF];

    
    UIGestureRecognizer  *oneFingerOneTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(Gesture)];
    
    
    
    // Add the gesture to the view
    [headview4 addGestureRecognizer:oneFingerOneTaps];
    
    UIImageView *goImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-25, 12, 10, 17)];
    goImageView.image = [UIImage imageNamed:@"go_bg"];
    [headview4 addSubview:goImageView];

    UILabel *headLine9LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(headview4.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(headLine9LB, @"#c8c7cc");
    [headview4 addSubview:headLine9LB];
    //会议邦宣传
    headview5 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headview4.frame)+9, ScreenWidth, 41)];
    headview5.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:headview5];
    
    UILabel *headLine10LB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLine10LB, @"#c8c7cc");
    [headview5 addSubview:headLine10LB];
    
    UILabel *headLine11LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(headview5.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(headLine11LB, @"#c8c7cc");
    [headview5 addSubview:headLine11LB];

    UILabel *isAdLB = [[UILabel alloc]initWithFrame:CGRectMake(16, 0.5, 250, 40)];
    isAdLB.text = @"需要会议邦帮助宣传？";
    isAdLB.font = YHUI(16);
    
    isAdLB.backgroundColor = [UIColor clearColor];
    [headview5 addSubview:isAdLB];
    
    UIButton *isAdBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
    isAdBtn.frame = CGRectMake(ScreenWidth-28, CGRectGetMaxY(headLine10LB.frame)+10, 19, 19);
    [isAdBtn setImage:[UIImage imageNamed:@"select-cur"] forState:UIControlStateSelected];
    [isAdBtn setImage:[UIImage imageNamed:@"select"] forState:UIControlStateNormal];
    isAdBtn.backgroundColor = [UIColor clearColor];
    [isAdBtn addTarget:self action:@selector(adBtntnClicked:) forControlEvents:UIControlEventTouchUpInside];
    isAdBtn.tag = 122;
    [headview5 addSubview:isAdBtn];
    
    //会议邦宣传
    headview6 = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headview5.frame)+9, ScreenWidth, 145)];
    headview6.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:headview6];
    
    UILabel *headLine12LB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLine12LB, @"#c8c7cc");
    [headview6 addSubview:headLine10LB];
    
    UILabel *headLine13LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(headview6.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(headLine13LB, @"#c8c7cc");
    [headview6 addSubview:headLine13LB];
    
    UILabel *nameLB = [[UILabel alloc]initWithFrame:CGRectMake(18.5, 0.5, 250, 31)];
    nameLB.text = @"用户报名填写项";
    nameLB.font = YHUI(16);
    nameLB.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

    nameLB.backgroundColor = [UIColor clearColor];
    [headview6 addSubview:nameLB];
    NSArray *titleArr = [[NSArray alloc]initWithObjects:@"姓名",@"手机",@"单位",@"职位",@"行业",@"备注", nil];
    for (int i = 0; i < 6; i++) {
        UIButton *itemBtn  = [UIButton buttonWithType:UIButtonTypeCustom];
        if (i<2) {
            itemBtn.selected = YES;
        }
        itemBtn.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;

        [itemBtn setTitleColor:[UIColor colorWithHexString:@"#5c677e"] forState:UIControlStateSelected];
        [itemBtn setTitleColor:[UIColor colorWithHexString:@"#080808"] forState:UIControlStateNormal];
        [itemBtn setTitle:[titleArr objectAtIndex:i] forState:UIControlStateNormal];
        itemBtn.frame = CGRectMake( 25+(25+73)*(i%3), CGRectGetMaxY(nameLB.frame)+35*(i/3), 73, 25);
        [itemBtn setBackgroundImage:[UIImage imageNamed:@"seleced_btn"] forState:UIControlStateSelected];
        [itemBtn setBackgroundImage:[UIImage imageNamed:@"btn"] forState:UIControlStateNormal];
        itemBtn.titleLabel.font = YHUI(16);
        itemBtn.backgroundColor = [UIColor clearColor];
        [itemBtn addTarget:self action:@selector(itemBtntnClicked:) forControlEvents:UIControlEventTouchUpInside];
        itemBtn.tag = 130+i;
        [headview6 addSubview:itemBtn];
    }
    UILabel *tailDiscribeLB = [[UILabel alloc]initWithFrame:CGRectMake(15, CGRectGetHeight(headview6.frame)-51.5, ScreenWidth, 51)];
    tailDiscribeLB.text = @"选项不够用或需要更多报名类型？请发布完毕后，电脑上访问专业版管理后台配置报名选项";
    tailDiscribeLB.font = YHUI(14);
    tailDiscribeLB.numberOfLines = 0;
    tailDiscribeLB.lineBreakMode = NSLineBreakByCharWrapping;
    [headview6 addSubview:tailDiscribeLB];
    
//    UITableView *createMeetTV = [[UITableView alloc]initWithFrame:CGRectMake(0, _NAV_HEIGHT, ScreenWidth, 0)];
}
- (void)itemBtntnClicked:(UIButton *)btn
{
    if (btn.tag > 131) {
        if (btn.selected == YES) {
            btn.selected = NO;
        }else{
            btn.selected = YES;
        }
        
    }
}
- (void)adBtntnClicked:(UIButton *)btn
{
    if(btn.selected == YES){
        btn.selected = NO;
    }else{
        btn.selected = YES;
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([@"\n" isEqualToString:text] == YES)
    {
        [textView resignFirstResponder];
        
        
        return NO;
    }
    
    return YES;
}
- (void)getBigImages:(UIGestureRecognizer*)Gesture
{
    if (Gesture.self.view.tag-140<imageArr.count) {
        NSMutableArray *photos = [[NSMutableArray alloc] init];
        NSMutableArray *thumbs = [[NSMutableArray alloc] init];
        
        BOOL displayActionButton = NO;
        BOOL displaySelectionButtons = NO;
        BOOL displayNavArrows = NO;
        BOOL enableGrid = NO;
        BOOL startOnGrid = NO;
        for (int i = 0; i<imageArr.count; i++) {
            MWPhoto *photo = [MWPhoto photoWithImage:[imageArr objectAtIndex:i]];
            photo.caption = [NSString stringWithFormat:@"%d/%lu \n %@",i+1,(unsigned long)imageArr.count,[imageArr objectAtIndex:i]];
            [photos addObject:photo];
            
        }
        self.photos = photos;
        self.thumbs = thumbs;
        
        // Create browser
        MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
        browser.displayActionButton = displayActionButton;
        browser.displayNavArrows = displayNavArrows;
        browser.displaySelectionButtons = displaySelectionButtons;
        browser.alwaysShowControls = displaySelectionButtons;
        browser.navTitle = @"111";
        browser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
        browser.wantsFullScreenLayout = YES;
#endif
        browser.enableGrid = enableGrid;
        browser.startOnGrid = startOnGrid;
        browser.enableSwipeToDismiss = YES;
        [browser setCurrentPhotoIndex:0];
        // Show
        if (_segmentedControl.selectedSegmentIndex == 0) {
            // Push
            [self.navigationController pushViewController:browser animated:YES];
        } else {
            // Modal
            UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:browser];
            nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [self presentViewController:nc animated:YES completion:nil];
        }
        
        // Release
        
        // Deselect
        
        
        // Test reloading of data after delay
        double delayInSeconds = 3;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        });
    }
    
}
- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser {
    return self.photos.count;
}

- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index {
    if (index < self.photos.count)
        return [self.photos objectAtIndex:index];
    return nil;
}
- (void)Gesture
{
}

- (void)btnClicked:(UIButton *)btn
{
    if (btn.tag == 122) {
        UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:nil
                                      delegate:self
                                      cancelButtonTitle:@"取消"
                                      destructiveButtonTitle:@"照相"
                                      otherButtonTitles:@"相册",nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
        [actionSheet showInView:self.view];

    }
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (0 == buttonIndex) {
        //照相
        UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
        pickerController.delegate = self;
        pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        pickerController.allowsEditing = YES;
        [self presentViewController:pickerController animated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }];
    }
    else if (1 == buttonIndex) {
        //相册
        UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
        pickerController.delegate = self;
        pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        pickerController.allowsEditing = YES;
        [self presentViewController:pickerController animated:YES completion:nil];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    if (imageArr.count == 0) {
        headview3.frame = CGRectMake(headview3.frame.origin.x, headview3.frame.origin.y, ScreenWidth, CGRectGetHeight(headview3.frame)+0);
        imageScrollView.frame = CGRectMake(imageScrollView.frame.origin.x, imageScrollView.frame.origin.y, ScreenWidth, 0);
        
       
        [imageScrollView setNeedsLayout];
        
        backView.frame = CGRectMake(0,CGRectGetMaxY(imageScrollView.frame)+0.5, ScreenWidth, 30.5);
        headview4.frame = CGRectMake(0, CGRectGetMaxY(headview3.frame)+9, ScreenWidth, 41);
        headview5.frame = CGRectMake(0, CGRectGetMaxY(headview4.frame)+9, ScreenWidth, 41);
        headview6.frame = CGRectMake(0, CGRectGetMaxY(headview5.frame)+9, ScreenWidth, 145);
        scrollView.contentSize = CGSizeMake(0, scrollView.contentSize.height+60);
        
    }
     [picker dismissViewControllerAnimated:YES completion:^{
         
     }];

}
- (void)imagePickerController:(UIImagePickerController *)ipicker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [ipicker dismissViewControllerAnimated:NO completion:nil];
    
    UIImage *selectedImage =nil;
    selectedImage=[info objectForKey:UIImagePickerControllerEditedImage];
    if (nil == selectedImage) {
        selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    [imageArr addObject:selectedImage];
    if ( selectedImage == nil)
        return;
    // mySelfInfo *myself = (mySelfInfo*)[self.dataMutAry objectAtIndex:0];
    //_newHeadImage = selectedImage;
    NSData * data;
    data = UIImageJPEGRepresentation(selectedImage, 0.0001);
    
    if (data == nil) {
        data = UIImagePNGRepresentation(selectedImage);
    }
     int i = 0;//记录图片遍历的个数
  
    _imageStr = [GTMBase64 stringByEncodingData:data];


    for (UIView*view in [imageScrollView subviews]) {
       
        
        if (i<imageArr.count) {
            if ([view isKindOfClass:[UIImageView class]]) {
                UIImageView * imageview = (UIImageView *)view;
                imageview.image = imageArr[i];
            }
            i++;
        }
    }
    if (imageArr.count == 1) {
        imageScrollView.frame = CGRectMake(imageScrollView.frame.origin.x, imageScrollView.frame.origin.y, ScreenWidth, 60);
        
        [imageScrollView setNeedsLayout];
        headview3.frame = CGRectMake(headview3.frame.origin.x, headview3.frame.origin.y, ScreenWidth, CGRectGetHeight(headview3.frame)+60);
        backView.frame = CGRectMake(0,CGRectGetMaxY(imageScrollView.frame)+0.5, ScreenWidth, 30.5);
        [backView setNeedsLayout];
        
        [headview3 bringSubviewToFront:imageScrollView];
        [headview3 bringSubviewToFront:backView];
        headview4.frame = CGRectMake(0, CGRectGetMaxY(headview3.frame)+9, ScreenWidth, 41);
        headview5.frame = CGRectMake(0, CGRectGetMaxY(headview4.frame)+9, ScreenWidth, 41);
        headview6.frame = CGRectMake(0, CGRectGetMaxY(headview5.frame)+9, ScreenWidth, 145);
        scrollView.contentSize = CGSizeMake(0, scrollView.contentSize.height+60);

    }
    
    
    
    
    return ;
}
- (void)keyboardHide:(NSNotification*)notification {
    [UIView animateWithDuration:0.25 animations:^{
        scrollView.frame = CGRectMake(0, scrollView.frame.origin.y, ScreenWidth, scrollView.bounds.size.height+_keySize.height);
        _keySize = CGSizeMake(0, 0);
    }];

}
- (void)keyboardShow:(NSNotification*)notification {
    
    NSDictionary *userInfo = [notification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize size = [aValue CGRectValue].size;
    if (size.height != _keySize.height) {
        scrollView.frame = CGRectMake(0, scrollView.frame.origin.y, ScreenWidth, scrollView.bounds.size.height+_keySize.height);
    }
    _keySize = size;
    scrollView.frame = CGRectMake(0, scrollView.frame.origin.y, ScreenWidth, ScreenHeight -64-_keySize.height);

    
    //获取当前cell在tableview中的位置
//    if (_currentPoint.y<_keySize.height+44) {
//        <#statements#>
//    }
    scrollView.contentOffset = _currentPoint;
    
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    _currentPoint = CGPointMake(headview2.origin.x, CGRectGetMinY(headview2.frame));
}
- (void)textViewDidChange:(UITextView *)textView
{
    
    if (textView.text.length == 0) {
        placeholder.hidden = NO;
    }else{
        placeholder.hidden = YES;
    }
}

- (void)textViewDidBeginEditing:(UITextView *)textView {
    _currentPoint = CGPointMake(headview3.origin.x, CGRectGetMinY(headview3.frame));

    
}

- (void)textViewDidEndEditing:(UITextView *)textView {

}

- (void)leaveEditMode {
    [self.view endEditing:YES];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
//    [textField resignFirstResponder];
    return YES;
}
- (void)getInfo:(UITextField *)textFeild
{
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
