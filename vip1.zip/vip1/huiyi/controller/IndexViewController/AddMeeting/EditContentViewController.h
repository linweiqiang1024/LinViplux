//
//  EditContentViewController.h
//  huiyi
//
//  Created by qstx1 on 14-10-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@protocol ReContentDelegate <NSObject>

- (void)reContentFinish;

@end

@interface EditContentViewController : FatherViewController
@property (nonatomic, retain) NSArray *photos;
@property (nonatomic, strong) NSMutableArray *thumbs;
@property (nonatomic, strong) NSString *meeting_id;
@property (nonatomic ,strong) NSString *meeting_type;
@property (nonatomic ,strong) NSString *summary;
@property (nonatomic ,weak) id<ReContentDelegate>delegate;
@end
