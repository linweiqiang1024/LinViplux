//
//  UserInfoTableViewCell.h
//  huiyi
//
//  Created by qstx1 on 14-11-3.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserInfoTableViewCell : UITableViewCell
{
    UILabel *_nameLB;
    UILabel *_timeLB;
    UIImageView * _headImageView ;
    UILabel *_companyAndPosition;
    BOOL _isShowCompanyAndPostion;
}
@property (nonatomic,strong)UILabel *nameLB;
@property (nonatomic,strong)UILabel *timeLB;
@property (nonatomic,strong)UIImageView *headImageView ;
@property (nonatomic) BOOL isEnd;
@property (nonatomic,strong)UILabel *companyAndPosition;
@property (nonatomic)BOOL isShowCompanyAndPostion;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andIsShowCompany:(BOOL)isShowCompany;
@end
