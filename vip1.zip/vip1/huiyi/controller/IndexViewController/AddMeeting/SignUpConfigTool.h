//
//  SignUpConfigTool.h
//  huiyi
//
//  Created by songhongshuai on 15/7/30.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SignUpConfigTool : NSObject
@property (nonatomic,strong)NSDictionary *configDic;
@property (nonatomic,copy)NSString *meeting_id;
@property (nonatomic,strong) NSString *blockID;
@property (nonatomic,strong) NSString *signUpstate;
@property (nonatomic,strong)UIViewController *controller;
+ (SignUpConfigTool *)shareManager;
- (void)manageSubConfig;
- (void)manageSubConfigWithSameTicket:(NSInteger)ticketIndex;
- (void)manageConfig;
- (void)manageConfigWithSameTicket:(NSInteger)ticketIndex;
@end
