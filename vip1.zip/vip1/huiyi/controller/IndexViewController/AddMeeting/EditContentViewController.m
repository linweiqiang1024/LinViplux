//
//  EditContentViewController.m
//  huiyi
//
//  Created by qstx1 on 14-10-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "EditContentViewController.h"
#import "GTMBase64.h"
#import "MWCommon.h"
#import "MYWebImage.h"
#import "MWPhotoBrowser.h"
@interface EditContentViewController ()<UITextViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,MWPhotoBrowserDelegate>
{
    UITextView *detailsTextView;
    UILabel *placeholder;
    UIView *contentView;
    UIView *backView;
    NSInteger imageIndex;
    NSMutableDictionary *imageDic;
    UIScrollView *imageScrollView;
    NSMutableArray *imageArr;
    NSMutableDictionary *contentDic;
    UISegmentedControl *_segmentedControl;
}
@end

@implementation EditContentViewController

- (void)createNavRightBtn
{
    UIButton *rightbtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightbtn.frame = CGRectMake(240, _navheight+4, 80, 40);
    [rightbtn addTarget:self action:@selector(rightBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [rightbtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    rightbtn.titleLabel.font = YHUI_BOLD(16);
    [rightbtn setTitle:@"完成" forState:UIControlStateNormal];
    [self.view addSubview:rightbtn];
}
- (void)rightBtnClicked
{
    [[Dialog Instance] showProgress:self withLabel:@"加载中..."];
    [contentDic setObject:[imageDic JSONString] forKey:@"pic"];
    [MyDataService postModMeeting:contentDic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
            [_delegate reContentFinish];
            [[Dialog Instance] hideProgress];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createNavRightBtn];
    imageDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    imageArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    [imageArr addObjectsFromArray:_photos];
    
    contentDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    if (_summary.length!= 0) {
        [contentDic setObject:_summary forKey:@"summary"];
    }
    
    [contentDic setObject:_meeting_id forKey:@"meeting_id"];
    [self creatContentUI];
    [self getImageInfo];
    self.thumbs = [[NSMutableArray alloc]initWithCapacity:0];
    
    // Do any additional setup after loading the view.
}
- (void)deleteImage:(NSInteger)index
{
     NSString *urlKey = [NSString stringWithFormat:@"url%d",imageIndex];
    [imageDic removeObjectForKey:urlKey];
    [imageArr removeObjectAtIndex:imageIndex];
    [self getImageInfo];
    
}
- (void)creatContentUI
{
    BackGround16Color(self.view, @"#efeff4");
    contentView = [[UIView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT+14, ScreenWidth, 162.5)];
    contentView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:contentView];
    
    UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLineLB, @"#c8c7cc");
    [contentView addSubview:headLineLB];
    
    detailsTextView = [[UITextView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLineLB.frame), ScreenWidth, 130.5)];
    detailsTextView.text = self.summary;
    detailsTextView.delegate = self;
    detailsTextView.font = YHUI(16);
//    detailsTextView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    detailsTextView.backgroundColor = [UIColor clearColor];
    [contentView addSubview:detailsTextView];
    
    placeholder = [[UILabel alloc]initWithFrame:CGRectMake(15, 10, 290, 22)];
    placeholder.textColor = [UIColor colorWithHexString:@"d3d3d3"];
    placeholder.text = @"活动详情，详细说明时间、地点、事件";
    placeholder.font = YHUI(16);
    if (self.summary.length != 0) {
        placeholder.hidden = YES;
    }else{
        placeholder.hidden = NO;
    }
    //    placeholder.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    placeholder.backgroundColor = [UIColor clearColor];
    [detailsTextView addSubview:placeholder];
}

- (void)postNewMeetingInfo:(NSDictionary *)dic
{
    [[Dialog Instance] showProgress:self withLabel:@"加载中。。。"];
    [MyDataService postModMeeting:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
    
            [[Dialog Instance] hideProgress];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([@"\n" isEqualToString:text] == YES)
    {
        [textView resignFirstResponder];
        
        
        return NO;
    }
    
    return YES;
}
- (void)getBigImages:(UIGestureRecognizer*)Gesture
{
    imageIndex =  (Gesture.self.view.tag-140) ;
    if (Gesture.self.view.tag-140<imageArr.count) {
        NSMutableArray *photos = [[NSMutableArray alloc] init];
        NSMutableArray *thumbs = [[NSMutableArray alloc] init];
        
        BOOL displayActionButton = NO;
        BOOL displaySelectionButtons = NO;
        BOOL displayNavArrows = NO;
        BOOL enableGrid = NO;
        BOOL startOnGrid = NO;
        MWPhoto *photo = [MWPhoto photoWithURL:[NSURL URLWithString:[[imageArr objectAtIndex:Gesture.self.view.tag-140] objectForKey:@"url"]]];
        photo.caption = [NSString stringWithFormat:@"%d/%lu",Gesture.self.view.tag-140+1,(unsigned long)imageArr.count];
        [photos addObject:photo];
        for (int i = 0; i<imageArr.count; i++) {
           
            
        }
        self.photos = photos;
        self.thumbs = thumbs;
        
        // Create browser
        MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
        browser.rightNavButtonIsHiden = NO;
        browser.displayActionButton = displayActionButton;
        browser.displayNavArrows = displayNavArrows;
        browser.displaySelectionButtons = displaySelectionButtons;
        browser.alwaysShowControls = displaySelectionButtons;
        browser.navTitle = nil;
        browser.zoomPhotosToFill = YES;
#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_7_0
        browser.wantsFullScreenLayout = YES;
#endif
        browser.enableGrid = enableGrid;
        browser.startOnGrid = startOnGrid;
        browser.enableSwipeToDismiss = YES;
        [browser setCurrentPhotoIndex:0];
        // Show
        if (_segmentedControl.selectedSegmentIndex == 0) {
            // Push
            [self.navigationController pushViewController:browser animated:YES];
        } else {
            // Modal
            UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:browser];
            nc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
            [self presentViewController:nc animated:YES completion:nil];
        }
        
        // Release
        
        // Deselect
        
        
        // Test reloading of data after delay
        double delayInSeconds = 3;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        });
    }
    
}
- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser {
    return self.photos.count;
}

- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index {
    if (index < self.photos.count)
        return [self.photos objectAtIndex:index];
    return nil;
}
- (void)Gesture
{
    NSLog(@"Action: One finger, two taps");
}

- (void)btnClicked:(UIButton *)btn
{
    if (btn.tag == 122) {
        UIActionSheet *actionSheet = [[UIActionSheet alloc]
                                      initWithTitle:nil
                                      delegate:self
                                      cancelButtonTitle:@"取消"
                                      destructiveButtonTitle:@"照相"
                                      otherButtonTitles:@"相册",nil];
        actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
        [actionSheet showInView:self.view];
        
    }
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (0 == buttonIndex) {
        //照相
        UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
        pickerController.delegate = self;
        pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        pickerController.allowsEditing = YES;
        [self presentViewController:pickerController animated:YES completion:^{
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
        }];
    }
    else if (1 == buttonIndex) {
        //相册
        UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
        pickerController.delegate = self;
        pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        pickerController.allowsEditing = YES;
        [self presentViewController:pickerController animated:YES completion:nil];
    }
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    if (imageArr.count == 0) {
        contentView.frame = CGRectMake(contentView.frame.origin.x, contentView.frame.origin.y, ScreenWidth, CGRectGetHeight(contentView.frame)+0);
        imageScrollView.frame = CGRectMake(imageScrollView.frame.origin.x, imageScrollView.frame.origin.y, ScreenWidth, 0);
        
        
        [imageScrollView setNeedsLayout];
        
        backView.frame = CGRectMake(0,CGRectGetMaxY(imageScrollView.frame)+0.5, ScreenWidth, 30.5);

        contentView.frame = CGRectMake(0, self.F_NAV_HEIGHT+14, ScreenWidth, 162.5);
        
    }
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    
}
- (void)imagePickerController:(UIImagePickerController *)ipicker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [ipicker dismissViewControllerAnimated:NO completion:nil];
    
    UIImage *selectedImage =nil;
    selectedImage=[info objectForKey:UIImagePickerControllerEditedImage];
    if (nil == selectedImage) {
        selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    if ( selectedImage == nil)
        return;
    // mySelfInfo *myself = (mySelfInfo*)[self.dataMutAry objectAtIndex:0];
    //_newHeadImage = selectedImage;
    NSData * data;
    data = UIImageJPEGRepresentation(selectedImage, 0.0001);

    int i = 0;//记录图片遍历的个数
    NSString *_imageStr;
    _imageStr = [GTMBase64 stringByEncodingData:data];
    NSDictionary *dic = @{@"iospic":_imageStr,@"iospic_type":@"jpg"};
    //NSDictionary *dic = @{@"ico_file":_imageStr};
    [MyDataService postUploadPicture:dic callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
            NSLog(@"%@",[[data objectForKey:@"content"] class]);
            NSString *urlKey = [NSString stringWithFormat:@"url%d",imageDic.count];
            [imageDic setObject:[[data objectForKey:@"content"] objectForKey:@"icon_file"] forKey:urlKey];
            NSDictionary *dic = @{@"url":[[data objectForKey:@"content"] objectForKey:@"icon_file"]};
            [imageArr addObject:dic];
            [self getImageInfo];
        }
    }];
    return ;
}
- (void)getImageInfo
{
    
    [imageDic removeAllObjects];
    for (NSDictionary *dic in imageArr) {
        NSString *urlKey = [NSString stringWithFormat:@"url%d",[imageArr indexOfObject:dic]];
        [imageDic setObject:[dic objectForKey:@"url"] forKey:urlKey];
    }
    int imageViewHeight;
    if (imageDic.count != 0) {
        imageViewHeight = 60;
    }else{
        imageViewHeight = 0;
    }
     contentView.frame = CGRectMake(contentView.frame.origin.x, contentView.frame.origin.y, ScreenWidth, 162.5+imageViewHeight);
    UILabel *headLine14LB;
    [headLine14LB removeFromSuperview];
    headLine14LB = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(detailsTextView.frame), ScreenWidth, 0.5)];
    BackGround16Color(headLine14LB, @"#c8c7cc");
    [contentView addSubview:headLine14LB];
    
    [imageScrollView removeFromSuperview];
    imageScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(headLine14LB.frame), ScreenWidth , imageViewHeight)];
    [imageScrollView setShowsHorizontalScrollIndicator:NO];
    [imageScrollView setShowsVerticalScrollIndicator:NO];
    imageScrollView.backgroundColor = [UIColor clearColor];
    [contentView addSubview:imageScrollView];
    
    for (UIView *view in imageScrollView.subviews) {
        [view removeFromSuperview];
    }
    for (int i = 0; i < imageDic.count; i++) {
        NSString *urlKey = [NSString stringWithFormat:@"url%d",i];
        UIImageView * imageviews = [[UIImageView alloc]initWithFrame:CGRectMake(i*(10+60), 0, 60, 60)];
        [MYWebImage OneImageView:imageviews SetImageWithURL:[imageDic objectForKey:urlKey]PlaceHolderImageName:nil CacheOrNot:YES];
        imageviews.contentMode = UIViewContentModeScaleAspectFit;
        imageviews.backgroundColor = [UIColor clearColor];
        imageviews.tag = 140+i;
        imageviews.userInteractionEnabled = YES;
        UIGestureRecognizer  *oneFingeTwoTaps = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getBigImages:)];
        [imageviews addGestureRecognizer:oneFingeTwoTaps];
        [imageScrollView addSubview:imageviews];
    }
    
    imageScrollView.contentSize = CGSizeMake((10+60)*imageDic.count, 60);
//    [backView removeFromSuperview];
    if (!backView) {
        backView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(imageScrollView.frame), ScreenWidth, 30.5)];
        backView.tag = 131;
        backView.userInteractionEnabled = YES;
        backView.backgroundColor = [UIColor colorWithHexString:@"#f8f8f8"];
        [contentView addSubview:backView];
    }
    backView.frame = CGRectMake(0, CGRectGetMaxY(imageScrollView.frame), ScreenWidth, 30.5);
    UIButton *selecedImageBtn;
    if (!selecedImageBtn) {
        selecedImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        selecedImageBtn.frame = CGRectMake(3, CGRectGetHeight(backView.frame)-27, 58, 23);
        [selecedImageBtn setImage:[UIImage imageNamed:@"photo"] forState:UIControlStateNormal];
        selecedImageBtn.backgroundColor = [UIColor clearColor];
        [selecedImageBtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        selecedImageBtn.tag = 122;
        [backView addSubview:selecedImageBtn];

    }
    imageScrollView.contentSize = CGSizeMake((10+60)*imageDic.count, 60);
    
    

   
}
- (void)textViewDidChange:(UITextView *)textView
{
    
    if (textView.text.length == 0) {
        placeholder.hidden = NO;
    }else{
        placeholder.hidden = YES;
    }
    [contentDic setObject:textView.text forKey:@"summary"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
