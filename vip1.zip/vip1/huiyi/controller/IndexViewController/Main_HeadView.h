//
//  Main_HeadView.h
//  会议广场
//
//  Created by songhongshuai on 15/5/12.
//  Copyright (c) 2015年 songhongshuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MainHeadViewDelegate <NSObject>

- (void)MainViewBtnsClicked:(UIButton*)btn;

@end

@interface Main_HeadView : UIView
@property (nonatomic,weak) id <MainHeadViewDelegate>delegate;
@property (nonatomic)NSInteger btnIndex;
@property (nonatomic,strong)UIButton *selectedBtn;
@end
