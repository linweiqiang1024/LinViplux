//
//  IndexEndButton.h
//  
//
//  Created by songhongshuai on 15/10/16.
//
//

#import <UIKit/UIKit.h>

@interface IndexEndButton : UIView

@property (nonatomic,strong)UIImage *image;
@property (nonatomic,strong)UIImage *backGroundImage;
@property (nonatomic,strong)NSString *title;

@property (nonatomic,strong)UIImageView *imageView ;
@property (nonatomic,strong)UIImageView *backgruodImageView;
@property (nonatomic,strong)UILabel *titleLable;

@end
