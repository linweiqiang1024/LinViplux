//
//  JsInterface.m
//  huiyi
//
//  Created by songhongshuai on 16/4/5.
//  Copyright © 2016年 shs. All rights reserved.
//

#import "JsInterface.h"

@implementation JsInterface

- (void)jumpToMeeting:(NSString*)name :(NSString*)types :(NSString*)meeting_id:(NSString*)isyqx :(NSString*)yqx_url :(NSString*) posters_url :(NSString*)bmmun
{
    
}
@end
