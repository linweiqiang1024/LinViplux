//
//  LabelsView.m
//  ZHIHUIBang
//
//  Created by 王振兴 on 15/5/9.
//  Copyright (c) 2015年 王振兴. All rights reserved.
//

#import "LabelsView.h"
#define screenWidth [UIScreen mainScreen].bounds.size.width
#define screenHeight [UIScreen mainScreen].bounds.size.height

@interface LabelsView ()
@property (nonatomic,strong)UIButton *selectedBtn;
@end

@implementation LabelsView
@synthesize isyellow;

#define tagSpace            14.0f //每个按钮title两边的距离
#define tagFontSize         14.0f //每个按钮title的font
#define tagFontType         @"Helvetica-Light"
#define tagXSpace           9.0f //两个的按钮距离
#define tagMargin           19.0f //每行按钮距离两边的距离
#define tagHeight           22.0f //btn的高度
#define tagCornerRadius     10.0f
#define tagCloseButton      7.0f


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
            }
    [self addSubview:self.endView];
    return self;
}
- (UIView*)endView
{
    if (!_endView) {
        _endView = [[UIView alloc]initWithFrame:CGRectMake(0, self.height, self.frame.size.width, 32)];
        _endView.backgroundColor =[UIColor colorWithRed:239.0/255.0 green:239.0/255 blue:244.0/255 alpha:1.0];
        [self addSubview:_endView];
        [_endView addSubview:self.showMoreBtn];
        [_endView addSubview:self.descriptionLB];

    }
    return _endView;
}
//- (void)drawRect:(CGRect)rect
//{
//    UIBezierPath *bezierPath;
//
//    // Draw top line
//    bezierPath = [UIBezierPath bezierPath];
//    [bezierPath moveToPoint:CGPointMake(0.0, rect.size.height)];
//    [bezierPath addLineToPoint:CGPointMake(rect.size.width, rect.size.height)];
//    [[UIColor colorWithRed:200.0/255.0 green:199.0/255.0 blue:204.0/255.0 alpha:1.0] setStroke];
//    [bezierPath setLineWidth:1.0];
//    [bezierPath stroke];
//}

- (CGSize)getTagSize:(NSString *)title
{
    CGSize tSize = [title sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]}];
    
    return CGSizeMake(tagSpace + tSize.width + tagSpace, tagHeight);
}
- (void)setLabelsArray:(NSArray *)labelsArray{
    NSString *name = [[NSUserDefaults standardUserDefaults]objectForKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
    if (self) {
        
        int n = 0;
        float x = 19;
        float y = 14.0f;
        
        for (UIView *button in [self subviews]){
            if ([button isKindOfClass:[UIButton class]]) {
                 [button removeFromSuperview];
            }
           
        }
        for (int i = 0;i < labelsArray.count; i ++)
        {
            if (x + [self getTagSize:[labelsArray objectAtIndex:i]].width + tagMargin > [UIScreen mainScreen].bounds.size.width-tagMargin) {
                n = 0;
                x = tagMargin;
                y += [self getTagSize:[labelsArray objectAtIndex:i]].height + 21;
            }else{
                x += (n ? tagXSpace : 0.0f);
            }
            
            UIButton *tag = [UIButton buttonWithType:UIButtonTypeCustom];
            
            [tag addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
            tag.tag = i+10;
            [tag setTitleColor:[UIColor colorWithHexString:@"c2c2c2"] forState:UIControlStateNormal];
            [tag setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
            [tag.titleLabel setFont:[UIFont systemFontOfSize:14]];
            [tag setFrame:CGRectMake(x, y, [self getTagSize:[labelsArray objectAtIndex:i]].width, [self getTagSize:[labelsArray objectAtIndex:i]].height+10)];
            [tag setTitleColor:[UIColor colorWithHexString:@"#17b4eb"] forState:UIControlStateSelected];
            [tag setTitleColor:[UIColor colorWithHexString:@"#b3b3b4"] forState:UIControlStateNormal];
            
            if([name length]==0&&i==0){
                tag.selected = YES;
                self.descriptionLB.text=labelsArray[0];
            }
            UIImage *enSelectedImage = [UIImage imageNamed:@"brand_en_sel"];
            UIEdgeInsets edge=UIEdgeInsetsMake(0, 17, 0,17);
            enSelectedImage= [enSelectedImage resizableImageWithCapInsets:edge resizingMode:UIImageResizingModeStretch];
            
            UIImage *normolSelectedImage = [UIImage imageNamed:@"brand_seled"];
            normolSelectedImage= [normolSelectedImage resizableImageWithCapInsets:edge resizingMode:UIImageResizingModeStretch];
            
            UIImage *highLightImage = [UIImage imageNamed:@"brand_sel"];
            highLightImage= [highLightImage resizableImageWithCapInsets:edge resizingMode:UIImageResizingModeStretch];
            tag.backgroundColor = [UIColor clearColor];
            [tag setBackgroundImage:highLightImage forState:UIControlStateHighlighted];
            [tag setBackgroundImage:normolSelectedImage forState:UIControlStateNormal];
            [tag setBackgroundImage:enSelectedImage forState:UIControlStateSelected];

            [self addSubview:tag];
            [tag setTitle:[labelsArray objectAtIndex:i] forState:UIControlStateNormal];
            x += [self getTagSize:[labelsArray objectAtIndex:i]].width;
            n++;
            self.height = (y +2*tagHeight);
        }
    }
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *btn = (UIButton *)view;
            if ([name isEqualToString:labelsArray[btn.tag-10]]) {
                btn.selected = YES;
            }
        }
    }
    if (labelsArray.count != 0) {
         self.endView.frame = CGRectMake(0,self.height , self.frame.size.width, 32);
    }else{
         self.endView.frame = CGRectMake(0, 0, self.frame.size.width, 32);
    }
   
    
}
+ (CGSize)getTagSize:(NSString *)title
{
    CGSize tSize = [title sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14]}];
    
    return CGSizeMake(tagMargin + tSize.width + tagMargin, tagHeight);
}
+ (CGFloat)getHeight:(NSMutableArray *)titles{
    int n = 0;
    float x = 19;
    float y = 14.0f;
    
    for (int i = 0;i < titles.count; i ++)
    {
        if (x + [self getTagSize:[titles objectAtIndex:i]].width + tagMargin > [UIScreen mainScreen].bounds.size.width-tagMargin) {
            n = 0; x = 0; y += [self getTagSize:[titles objectAtIndex:i]].height + 11;
        }else{
            x += (n ? tagMargin : 0.0f);
        }
        x += [self getTagSize:[titles objectAtIndex:i]].width;
        
        n++;
    }
    return y + 2*tagMargin;
}
- (void)buttonPressed:(UIButton *)sender{
    //防止多次点击
    if (sender.selected == NO) {
        if ([_delegate respondsToSelector:@selector(LabelClicked:)]) {
            self.descriptionLB.text = sender.titleLabel.text;
            [_delegate LabelClicked:sender.tag-10];
        }
    }
    self.selectedBtn.selected = NO;
    sender.selected = YES;
    self.selectedBtn = sender;
    
}
- (UIButton*)showMoreBtn
{
    if (!_showMoreBtn) {
        _showMoreBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _showMoreBtn.frame = CGRectMake(screenWidth-70, self.frame.size.height-32, 65, self.frame.size.height) ;
        [_showMoreBtn setTitle:@"更多品牌" forState:UIControlStateNormal];
        [_showMoreBtn setTitleColor:[UIColor colorWithRed:23.0/255.0 green:180.0/255.0 blue:235.0/255.0 alpha:1.0] forState:UIControlStateNormal];
        _showMoreBtn.titleLabel.font = [UIFont systemFontOfSize:11.0];
        [_showMoreBtn addTarget:self action:@selector(showMoreOptions:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _showMoreBtn;
}

- (void)showMoreOptions:(UIButton *)btn
{
    if ([_delegate respondsToSelector:@selector(showMoreInfo:)]) {
        
        [_delegate showMoreInfo:btn];
        [UIView animateWithDuration:0.5 animations:^{
            
            // [self setNeedsDisplay];
        }];
        
    }

}

/**
 *  品牌
 *
 *  @return 显示品牌的lable
 */
- (UILabel*)descriptionLB
{
    if (!_descriptionLB) {
        _descriptionLB = [[UILabel alloc]initWithFrame:CGRectMake(5, 0, screenWidth-100,self.frame.size.height)];
        if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"options"]length]!=0) {
            NSString *name = [[NSUserDefaults standardUserDefaults]objectForKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
            _descriptionLB.text = name;
        }
        //        _descriptionLB.text = @"会议邦";
        _descriptionLB.textColor = [UIColor blackColor] ;
        _descriptionLB.font = [UIFont boldSystemFontOfSize:16];
        _descriptionLB.backgroundColor  = [UIColor clearColor];
    }
    return _descriptionLB;
}
- (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size
{
    CGRect rect = CGRectMake(0, 0, size.width, size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

@end
