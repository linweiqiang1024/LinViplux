//
//  New_indexViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/3/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"
#import <RongIMKit/RongIMKit.h>

@interface New_indexViewController : FatherViewController <RCIMReceiveMessageDelegate,UIAlertViewDelegate>

- (void)applyMyMeetingCount:(BOOL)isNotifition;
- (void)setupUntreatedApplyCount;

@end
