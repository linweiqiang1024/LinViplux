//
//  IndexModel.m
//  huiyi
//
//  Created by qstx1 on 14-6-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "IndexModel.h"
#import "NSString+Size.h"


@interface IndexModel ()
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;
@end

@implementation IndexModel
@synthesize meetAddress = _meetAddress,meetImageUrl = _meetImageUrl,meetName = _meetName,meetNTime = _meetNTime,meetSTime = _meetSTime,meet_id = _meet_id,meetBmnum = _meetBmnum,meetCnt = _meetCnt,meetNameHeight = _meetNameHeight,meetType = _meetType,haveImage = _haveImage,meetPic_list = _meetPic_list,meetShare = _meetShare,meetStatus = _meetStatus,meetCreate_time = _meetCreate_time,meetUpdate_time = _meetUpdate_time;


- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        if(dict){
            self.meetName = [dict objectForKey:@"name"];
            self.meetNewBmnum = dict[@"bmnum"];
            self.meetAddress = [dict objectForKey:@"location"];
            self.meetSTime = [dict objectForKey:@"begin_date"];
            self.meetNTime = [dict objectForKey:@"end_date"];
            self.meet_id = [dict objectForKey:@"meeting_id"];
            self.meetCnt = [dict objectForKey:@"cnt_reader"];
            self.meetBmnum = [dict objectForKey:@"bmtotal"];
            self.meetType = [dict objectForKey:@"type"];
            self.isPoster = [dict objectForKey:@"is_yqx"];
            self.yqx_url = [dict objectForKey:@"yqx_url"];
            self.meetPosters_url = [dict objectForKey:@"posters_url"];
            self.meetStatus = [dict objectForKey:@"meeting_status"];
            self.meetUpdate_time = [dict objectForKey:@"update_time"];
            if ([[dict objectForKey:@"img_url"] length]>0||[[dict objectForKey:@"pic_list"] count]>0) {//判断有没有海报图片
                self.haveImage = YES;
            }
            else{
                self.haveImage = NO;
            }
            NSArray *imageArray = [dict objectForKey:@"pic_list"];
            if ([imageArray count]>0) {
                
                NSMutableArray *imageUrls = [[NSMutableArray alloc]init];
                for (NSDictionary *imageDic in imageArray) {
                    NSString *imageUrl = [imageDic objectForKey:@"img_file"];
                    imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
                    [imageUrls addObject:imageUrl];
                }
                self.meetImageUrl = [imageUrls objectAtIndex:0];
                self.meetPic_list = imageUrls;
            }
            else if([[dict objectForKey:@"img_url"] length]>0){
                self.meetImageUrl = [dict objectForKey:@"img_url"];
                NSString *imageUrl = [dict objectForKey:@"img_url"];
                imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
                self.meetPic_list = [NSMutableArray arrayWithObjects:imageUrl, nil];
            }
            else{
                
            }
            
            CGSize nameSize = [self.meetName stringSizeWithFont:[UIFont boldSystemFontOfSize:17] constrainedToSize:CGSizeMake(203, 200)];
            self.meetNameHeight = nameSize.height;
            
        }
    }
    return self;
}
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}

@end
