//
//  SearchViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/6/3.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FristViewController.h"

@interface SearchViewController : FatherViewController

@end
