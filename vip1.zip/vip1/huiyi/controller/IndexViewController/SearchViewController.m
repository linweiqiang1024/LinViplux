//
//  SearchViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/6/3.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "SearchViewController.h"
#import "MySearchBar.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "New_SignUpInfoViewController.h"

@interface SearchViewController () <UISearchBarDelegate,UIWebViewDelegate>
{
    NSMutableArray * _indexDataArr;
    int _myPublishPage;
    NSString * selectedID;
}
@property (nonatomic, strong) MySearchBar * searchBar;
@property (nonatomic, strong) UIButton * rightBtn;
@property (nonatomic, strong) UIWebView * mainWebView;
@end

@implementation SearchViewController

///v2meeting/squareIndex"+ "?index=search" + "&from=app" + "&name=" + name;

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.titlelabel.text = @"查找";
    _myPublishPage = 1;
    _indexDataArr = [[NSMutableArray alloc]initWithCapacity:0];
    [self.view addSubview:self.rightBtn];
    [self.view addSubview:self.searchBar];
    [self.view addSubview:self.mainWebView];
    // Do any additional setup after loading the view.
}

- (void)searchBtnHite
{
    [self.view endEditing:YES];
    if (selectedID.length != 0) {
        [self loadWebViewWithIndex:@"search"];
    }
    else {
        self.rightBtn.enabled = NO;
    }
}

- (void)loadWebViewWithIndex:(NSString *)index
{
    /*
    NSURL * url;
    if ([COMPANY_ADDR length] == 0) {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://v2.huiyiabc.com/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",index,selectedID]];
    }
    NSString *urlstr = [NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",COMPANY_ADDR,index,selectedID];
    urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    url = [NSURL URLWithString:urlstr];*/
    
    /*
    NSURL * url;
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        NSString *urlstr = [NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",Base_COMPANY_ADDR,index,selectedID];
        urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        url = [NSURL URLWithString:urlstr];
    }
    else {
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"companyID"] isEqualToString:@"0"]) {
            NSString *urlstr = [NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",Base_COMPANY_ADDR,index,selectedID];
            urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            url = [NSURL URLWithString:urlstr];
        }
        else {
            NSString *urlstr = [NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",COMPANY_ADDR,index,selectedID];
            urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            url = [NSURL URLWithString:urlstr];
        }
    }*/
    
    NSURL * url;
    
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        NSString * urlstr = [NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",Base_COMPANY_ADDR,index,selectedID];
        urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        url = [NSURL URLWithString:urlstr];
    }
    else
    {
        NSMutableArray * datas = [NSMutableArray arrayWithArray:LoginCompanyArray];
        NSDictionary * model = [datas lastObject];
        NSString * companyCode = [model objectForKey:@"code"];
        if ([companyCode isEqualToString:@"huiyiabc"])
        {
            NSString * urlstr = [NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",Base_COMPANY_ADDR,index,selectedID];
            urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            url = [NSURL URLWithString:urlstr];
        }
        else
        {
            NSString * urlstr = [NSString stringWithFormat:@"http://%@.%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp&name=%@",companyCode,Base_COMPANY_ADDR,index,selectedID];
            urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            url = [NSURL URLWithString:urlstr];
        }
    }
    
    [self.mainWebView loadRequest:[NSURLRequest requestWithURL:url]];
}

- (UIWebView *)mainWebView
{
    if (!_mainWebView) {
        _mainWebView = [[UIWebView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.searchBar.frame) , ScreenWidth, ScreenHeight-CGRectGetMaxY(self.searchBar.frame))];
        _mainWebView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
        _mainWebView.delegate = self;
        if (@available(iOS 11.0, *))
        {
            _mainWebView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    return _mainWebView;
}

- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame = CGRectMake(ScreenWidth-60, 20, 44, 44);
        [_rightBtn addTarget:self action:@selector(searchBtnHite) forControlEvents:UIControlEventTouchUpInside];
        _rightBtn.backgroundColor = [UIColor clearColor];
        [_rightBtn setTitle:@"搜索" forState:UIControlStateNormal];
        [_rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = [UIFont systemFontOfSize:16];
    }
    return _rightBtn;
}

- (MySearchBar *)searchBar
{
    if (!_searchBar) {
        _searchBar = [[MySearchBar alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, 53)];
        _searchBar.delegate = self;
        _searchBar.placeholder = @"搜索您想要参加的会议/活动名称";
    }
    return _searchBar;
}

#pragma mark - UISearchBarDelegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self.view endEditing:YES];
    [self loadWebViewWithIndex:@"search"];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (searchText.length == 0) {
        self.rightBtn.enabled = NO;
    }
    else {
        self.rightBtn.enabled = YES;
    }
    selectedID = searchText;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if (navigationType == UIWebViewNavigationTypeLinkClicked) {
        return NO;
    }
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [[Dialog Instance] hiddenHSHUD];
    self.mainWebView.hidden = NO;
    //[webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitUserSelect='none';"];
    [webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitTouchCallout='none';"];
    JSContext *context = [self.mainWebView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    context[@"jumpToMeeting"] = ^(NSString *name,NSString * types,NSString * meeting_id,NSString * isyqx,NSString * yqx_url,NSString * posters_url,NSString * bmmun) {
        New_SignUpInfoViewController *signUpVC = [[New_SignUpInfoViewController alloc]init];
        self.hidesBottomBarWhenPushed = YES;
        [[NSNotificationCenter defaultCenter]postNotificationName:@"hidenTabar" object:nil];
        signUpVC.isPoster = isyqx;
        if ([isyqx isEqualToString:@"1"]) {
            signUpVC.meetPoster_url =yqx_url;
        }
        else {
            signUpVC.meetPoster_url =posters_url;
        }
        signUpVC.meetID = meeting_id;
        signUpVC.meet_type = types;
        signUpVC.meetTitle = name;
        [self.navigationController pushViewController:signUpVC animated:YES];
        
        NSLog(@"+++++++Begin Log+++++++%@",name);
//        NSArray *args = [JSContext currentArguments];
//
//        for (JSValue *jsVal in args) {
//            NSLog(@"%@", jsVal);
//        }
//
//        JSValue *this = [JSContext currentThis];
//        NSLog(@"this: %@",this);
//        NSLog(@"-------End Log-------");
    };
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [[Dialog Instance] showHSHUDWithController:self];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [[Dialog Instance] hiddenHSHUD];
    self.mainWebView.hidden = NO;
    if (![NetworkSingleten shared].isNetwork) {
        self.networkView.frame = CGRectMake(0, CGRectGetMaxY(self.searchBar.frame) , ScreenWidth, ScreenHeight-CGRectGetMaxY(self.searchBar.frame));
        [self.view addSubview:self.networkView];
    }
}

- (void)networkButtonAction
{
    [self.networkView removeFromSuperview];
    self.mainWebView.hidden = YES;
    [self loadWebViewWithIndex:@"search"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
