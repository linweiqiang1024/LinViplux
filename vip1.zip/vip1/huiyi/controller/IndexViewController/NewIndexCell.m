//
//  NewIndexCell.m
//  huiyi
//
//  Created by 林伟强 on 16/11/1.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "NewIndexCell.h"
#import "Helper.h"

@interface NewIndexCell ()
@property (nonatomic,strong)UIImageView *addressIcon;
@property (nonatomic,strong)UIImageView *timeIcon;
@property (nonatomic,strong)UIImageView *cellCntIcon;
@property (nonatomic,strong)UIImageView *cellBmnumIcon;
@property (nonatomic,strong)UILabel *cellCntLabel;
@property (nonatomic,strong)UILabel *cellBmnumLabel;
@property (nonatomic,strong)UIView *cellSeparateLine;
@end

@implementation NewIndexCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.contentView.backgroundColor = [UIColor whiteColor];
        self.selected = NO;
        [self.contentView addSubview:self.contentImageView];
        [self.contentView addSubview:self.nameLb];
        [self.contentView addSubview:self.addressIcon];
        [self.contentView addSubview:self.addressLb];
        [self.contentView addSubview:self.timeIcon];
        [self.contentView addSubview:self.timeLb];
        [self.contentView addSubview:self.cellCntIcon];
        [self.contentView addSubview:self.cellCntLabel];
        [self.contentView addSubview:self.cellCnt];
        [self.contentView addSubview:self.cellBmnumIcon];
        [self.contentView addSubview:self.cellBmnumLabel];
        [self.contentView addSubview:self.cellBmnum];
        [self.contentView addSubview:self.statusImageView];
        [self.contentView addSubview:self.cellNewApplyCount];
        [self.contentView addSubview:self.cellSeparateLine];
    }
    return self;
}
- (UIImageView *)statusImageView
{
    if (!_statusImageView) {
        _statusImageView = [[UIImageView alloc]initWithFrame:CGRectMake(120, 10, 27.5, 30.5)];
        _statusImageView.backgroundColor = [UIColor clearColor];
        //_statusImageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _statusImageView;
}
- (UIImageView *)contentImageView
{
    if (!_contentImageView) {
        _contentImageView = [[UIImageView alloc]initWithFrame:CGRectMake(12.5, 10, 135, 90)];
        _contentImageView.layer.cornerRadius = 4.0f;
        _contentImageView.layer.masksToBounds = YES;
        _contentImageView.contentMode = UIViewContentModeScaleAspectFill;
        _contentImageView.clipsToBounds = YES;
        _contentImageView.backgroundColor = [UIColor clearColor];
    }
    return _contentImageView;
}
- (UILabel *)nameLb
{
    if (!_nameLb) {
        _nameLb = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+8, 11, ScreenWidth-168, 16)];
        _nameLb.backgroundColor = [UIColor clearColor];
        _nameLb.font = [UIFont systemFontOfSize:15];
        _nameLb.numberOfLines = 0;
        _nameLb.textColor = [UIColor colorWithHexString:@"#000000"];
    }
    return _nameLb;
}
- (UIImageView *)addressIcon
{
    if (!_addressIcon) {
        _addressIcon = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+8, 51, 12, 12)];
        _addressIcon.backgroundColor = [UIColor clearColor];
        _addressIcon.image = [UIImage imageNamed:@"meetaddress"];
        _addressIcon.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _addressIcon;
}
- (UILabel *)addressLb
{
    if(!_addressLb){
        _addressLb = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+26, 51, ScreenWidth-CGRectGetMaxX(self.contentImageView.frame)-26, 12)];
        _addressLb.textColor = [UIColor colorWithHexString:@"#999999"];
        _addressLb.font = [UIFont systemFontOfSize:12];
        BackGroundColor(_addressLb, clearColor);
    }
    return _addressLb;
}
- (UIImageView *)timeIcon
{
    if (!_timeIcon) {
        _timeIcon = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+8, CGRectGetMaxY(self.addressIcon.frame)+6, 12, 12)];
        _timeIcon.backgroundColor = [UIColor clearColor];
        _timeIcon.image = [UIImage imageNamed:@"meettime"];
        _timeIcon.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _timeIcon;
}
- (UILabel *)timeLb
{
    if (!_timeLb) {
        _timeLb = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+26, CGRectGetMaxY(self.addressLb.frame)+6, ScreenWidth-CGRectGetMaxX(self.contentImageView.frame)-26, 12)];
        _timeLb.backgroundColor = [UIColor clearColor];
        _timeLb.font = [UIFont systemFontOfSize:12];
        _timeLb.textColor = [UIColor colorWithHexString:@"#999999"];
        _timeLb.backgroundColor = [UIColor clearColor];
    }
    return _timeLb;
}
- (UIImageView *)cellCntIcon
{
    if (!_cellCntIcon) {
        _cellCntIcon = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+8, CGRectGetMaxY(self.timeIcon.frame)+7, 12, 12)];
        _cellCntIcon.backgroundColor = [UIColor clearColor];
        _cellCntIcon.image = [UIImage imageNamed:@"meetread"];
        _cellCntIcon.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _cellCntIcon;
}
- (UILabel *)cellCntLabel
{
    if (!_cellCntLabel) {
        _cellCntLabel = [[UILabel alloc]init];
        _cellCntLabel.backgroundColor = [UIColor clearColor];
        _cellCntLabel.frame = CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+26, CGRectGetMaxY(self.timeIcon.frame)+7, 25, 12);
        _cellCntLabel.text = @"浏览";
        _cellCntLabel.textColor = [UIColor colorWithHexString:@"#999999"];
        _cellCntLabel.font = [UIFont systemFontOfSize:12];
    }
    return _cellCntLabel;
}
- (UILabel *)cellCnt
{
    if (!_cellCnt) {
        _cellCnt = [[UILabel alloc]init];
        _cellCnt.backgroundColor = [UIColor clearColor];
        _cellCnt.frame = CGRectMake(CGRectGetMaxX(self.cellCntLabel.frame)+5, CGRectGetMaxY(self.timeIcon.frame)+7, 40, 12);
        _cellCnt.textColor = [UIColor colorWithHexString:@"#999999"];
        _cellCnt.font = [UIFont systemFontOfSize:12];
    }
    return _cellCnt;
}
- (UIImageView *)cellBmnumIcon
{
    if (!_cellBmnumIcon) {
        _cellBmnumIcon = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.cellCnt.frame), CGRectGetMaxY(self.timeIcon.frame)+7, 12, 12)];
        _cellBmnumIcon.backgroundColor = [UIColor clearColor];
        _cellBmnumIcon.image = [UIImage imageNamed:@"meetapply"];
        _cellBmnumIcon.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _cellBmnumIcon;
}
- (UILabel *)cellBmnumLabel
{
    if (!_cellBmnumLabel) {
        _cellBmnumLabel = [[UILabel alloc]init];
        _cellBmnumLabel.backgroundColor = [UIColor clearColor];
        _cellBmnumLabel.frame = CGRectMake(CGRectGetMaxX(self.cellBmnumIcon.frame)+6, CGRectGetMaxY(self.timeIcon.frame)+7, 25, 12);
        _cellBmnumLabel.text = @"报名";
        _cellBmnumLabel.textColor = [UIColor colorWithHexString:@"#999999"];
        _cellBmnumLabel.font = [UIFont systemFontOfSize:12];
    }
    return _cellBmnumLabel;
}
- (UILabel *)cellBmnum
{
    if (!_cellBmnum) {
        _cellBmnum = [[UILabel alloc]init];
        _cellBmnum.backgroundColor = [UIColor clearColor];
        _cellBmnum.frame = CGRectMake(CGRectGetMaxX(self.cellBmnumLabel.frame)+5, CGRectGetMaxY(self.timeIcon.frame)+7, ScreenWidth-CGRectGetMaxX(self.cellBmnumLabel.frame)-5, 12);
        _cellBmnum.textColor = [UIColor colorWithHexString:@"#999999"];
        _cellBmnum.font = [UIFont systemFontOfSize:12];
    }
    return _cellBmnum;
}
- (UIButton *)cellNewApplyCount
{
    if (!_cellNewApplyCount) {
        _cellNewApplyCount = [UIButton buttonWithType:UIButtonTypeCustom];
        [_cellNewApplyCount setBackgroundImage:[UIImage imageNamed:@"new_apply_count"] forState:UIControlStateNormal];
        _cellNewApplyCount.frame = CGRectMake(134.5, 3, 20, 20);
        _cellNewApplyCount.adjustsImageWhenHighlighted = NO;
        [_cellNewApplyCount setTitle:@"12" forState:UIControlStateNormal];
        _cellNewApplyCount.titleLabel.font = [UIFont systemFontOfSize:10];
        _cellNewApplyCount.hidden = YES;
    }
    return _cellNewApplyCount;
}
- (UIView *)cellSeparateLine
{
    if (!_cellSeparateLine) {
        _cellSeparateLine = [[UIView alloc]init];
        _cellSeparateLine.frame = CGRectMake(0, 110-0.5, ScreenWidth, 0.5);
        _cellSeparateLine.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    }
    return _cellSeparateLine;
}
- (void)reloadView
{
    CGFloat width = [Helper widthOfString:self.nameLb.text font:[UIFont systemFontOfSize:15] height:16];
    if (width > ScreenWidth-168) {
        self.nameLb.frame = CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+8, 11, ScreenWidth-168, 36);
    }
    else {
        self.nameLb.frame = CGRectMake(CGRectGetMaxX(self.contentImageView.frame)+8, 11, ScreenWidth-168, 16);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
