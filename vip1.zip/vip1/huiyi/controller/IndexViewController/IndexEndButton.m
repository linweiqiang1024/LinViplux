//
//  IndexEndButton.m
//
//
//  Created by songhongshuai on 15/10/16.
//
//

#import "IndexEndButton.h"

@interface IndexEndButton ()
@property (nonatomic)CGFloat imgHeight ;
@property (nonatomic)CGFloat YSpace;
@property (nonatomic)CGFloat titleHeight;
@property (nonatomic)CGFloat YTitleSpace;
@end

@implementation IndexEndButton

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        if (ScreenHeight <= 568) {
            _imgHeight = 36;
            _YSpace = 14;
            _titleHeight = 12;
            _YTitleSpace = 54;
        }
        else {
            _imgHeight = (ScreenWidth/320)*36;
            _YSpace = (ScreenWidth/320)*14;
            _titleHeight = (ScreenWidth/320)*12;
            _YTitleSpace = (ScreenWidth/320)*54;
        }
    }
    return self;
}
- (void)setTitle:(NSString *)title
{
    if (title) {
        self.titleLable.text = title;
    }
}
- (void)setImage:(UIImage *)image
{
    if (image) {
        self.imageView.image = image;
    }
}
- (void)setBackGroundImage:(UIImage *)backGroundImage
{
    if (backGroundImage) {
        self.backgruodImageView.image = backGroundImage;
    }
}
- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.width/2-_imgHeight/2, _YSpace, _imgHeight, _imgHeight)];
        _imageView.backgroundColor = [UIColor clearColor];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imageView;
}
- (UIImageView *)backgruodImageView{
    if (!_backgruodImageView) {
        _backgruodImageView = [[UIImageView alloc]initWithFrame:self.bounds];
        _backgruodImageView.backgroundColor = [UIColor clearColor];
        _backgruodImageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _backgruodImageView;
}
- (UILabel *)titleLable
{
    if (!_titleLable) {
        _titleLable = [[UILabel alloc]initWithFrame:CGRectMake(0, _YTitleSpace, self.width, _titleHeight)];
        _titleLable.backgroundColor = [UIColor clearColor];
        _titleLable.textColor = [UIColor colorWithHexString:@"aeaeae"];
        _titleLable.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLable;
}
- (void)layoutSubviews
{
    [self addSubview:self.backgruodImageView];
    [self addSubview:self.imageView];
    [self addSubview:self.titleLable];
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end
