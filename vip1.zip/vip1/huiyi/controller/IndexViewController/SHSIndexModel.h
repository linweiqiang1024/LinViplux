//
//  SHSIndexModel.h
//
//  Created by songhongshuai  on 15/3/27
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface SHSIndexModel : NSObject <NSCoding, NSCopying>
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *state;
@property (nonatomic, strong) NSString *partaked;
@property (nonatomic, strong) NSString *imgUrl;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *meetingId;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *beginTime;
@property (nonatomic, strong) NSString *is_yqx;
@property (nonatomic, strong) NSString *yqx_url;
@property (nonatomic, strong) NSString *posters_url;

@property (nonatomic, strong) NSString *company_code;
@property (nonatomic, strong) NSString *company_fullname;
@property (nonatomic, strong) NSString *company_id;
@property (nonatomic, strong) NSString *company_logo;
@property (nonatomic, strong) NSString *company_name;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
