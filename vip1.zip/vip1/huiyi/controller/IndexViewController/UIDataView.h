//
//  UIDataView.h
//  huiyi
//
//  Created by songhongshuai on 15/3/30.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDataView : UIImageView
@property (nonatomic,strong)NSString *dateStr;
@property (nonatomic,strong)UILabel *dataLb;
@end
