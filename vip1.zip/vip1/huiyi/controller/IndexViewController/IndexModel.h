//
//  IndexModel.h
//  huiyi
//
//  Created by qstx1 on 14-6-20.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IndexModel : NSObject
{
    NSString *_meetName;
    NSString *_meetImageUrl;
    NSString *_meetSTime;
    NSString *_meetNTime;
    NSString *_meetAddress;
    NSString *_meetCnt;//点击次数
    NSString *_meetBmnum;//报名人数
    CGFloat _meetNameHeight;//会议名称的高度
    NSString *_meetType;//会议的类型
    BOOL _haveImage;
    NSMutableArray *_meetPic_list;//图片列表
    NSString *_meetShare;//分享的人数
    NSString *_meetStatus;//会议的发布状态
    NSString *_meetUpdate_time;//会议更新的时间
    NSString *_meetCreate_time;//会议创建的时间
}
@property (nonatomic,copy)NSString *meetName;
@property (nonatomic,copy)NSString *meetImageUrl;
@property (nonatomic,copy)NSString *meetSTime;
@property (nonatomic,copy)NSString *meetNTime;
@property (nonatomic,copy)NSString *meetAddress;
@property (nonatomic,copy)NSString *meet_id;
@property (nonatomic,copy)NSString *meetCnt;
@property (nonatomic,copy)NSString *meetBmnum;
@property (nonatomic,copy)NSString *meetNewBmnum;
@property (nonatomic,assign)CGFloat meetNameHeight;
@property (nonatomic,copy)NSString *meetType;
@property (nonatomic)BOOL haveImage;
@property (nonatomic,copy)NSString *isPoster;//1易企秀  0海报 空字符串没有 
@property (nonatomic,strong)NSMutableArray *meetPic_list;
@property (nonatomic,copy)NSString *meetShare;
@property (nonatomic,copy)NSString *meetStatus;
@property (nonatomic,copy)NSString *yqx_url;
@property (nonatomic,copy)NSString *meetPosters_url;//海报  易企秀网址
@property (nonatomic,copy)NSString *meetUpdate_time;//会议更新的时间
@property (nonatomic,copy)NSString *meetCreate_time;//会议创建的时间
- (instancetype)initWithDict:(NSDictionary *)dict;
@end
