//
//  IndexHeadView.m
//  huiyi
//
//  Created by songhongshuai on 15/3/23.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "IndexHeadView.h"

@implementation IndexHeadView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
