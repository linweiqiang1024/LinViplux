//
//  UIIndexEndButton.m
//  huiyi
//
//  Created by songhongshuai on 15/3/25.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIIndexEndButton.h"

@implementation UIIndexEndButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat imgHeight ;
    CGFloat HSpace;
    if (ScreenHeight <= 568) {
        imgHeight = 36;
        HSpace = 14;
    }
    else {
        imgHeight = (ScreenWidth/320)*36;
        HSpace = (ScreenWidth/320)*14;
    }
    
    return CGRectMake(ScreenWidth/4-imgHeight/2, HSpace, imgHeight, imgHeight);
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleHeight ;
    CGFloat HSpace;
    if (ScreenHeight <= 568) {
        titleHeight = 12;
        HSpace = 54;
    }
    else {
        titleHeight = (ScreenWidth/320)*12;
        HSpace = (ScreenWidth/320)*54;
    }
    
    return CGRectMake(0, HSpace, ScreenWidth/2, titleHeight);
}

@end
