//
//  UIDataView.m
//  huiyi
//
//  Created by songhongshuai on 15/3/30.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIDataView.h"

@interface UIDataView()
{
    UILabel *_dateSubLB;
    UIFont *dataFont ;
    UIFont *dateSubFont ;
    CGFloat DATESUBVIEWIDTH;
    CGFloat DATESUBVIEY;
}

@end

@implementation UIDataView

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self creatUI];
    }
    return self;
}
- (void)creatUI
{
    UIImage *img = [UIImage imageNamed:@"index_data_bg"];
    UIEdgeInsets edge = UIEdgeInsetsMake(30, 30, 30, 30);
    self.image = [img resizableImageWithCapInsets:edge resizingMode:UIImageResizingModeStretch];

    if (iPhone4||iPhone5) {
        dateSubFont = YHUI(12);
        dataFont = YHUI_BOLD(48/1.28);
        DATESUBVIEWIDTH = 30/1.28;
        DATESUBVIEY = 10;
    }
    if (iPhone6) {
        dateSubFont = YHUI(12);
        dataFont = YHUI_BOLD(46/1.1);
        DATESUBVIEWIDTH = 30/1.1;
        DATESUBVIEY = 10;
    }
    if (iphone6Plus) {
        dateSubFont = YHUI(12);
        dataFont = YHUI_BOLD(46);
        DATESUBVIEWIDTH = 30;
        DATESUBVIEY = 10;
    }
    
    _dataLb = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, self.width, self.height-DATESUBVIEWIDTH)];
    _dataLb.backgroundColor = [UIColor clearColor];
    _dataLb.font = dataFont;
    _dataLb.textAlignment = NSTextAlignmentCenter;
    _dataLb.textColor = [UIColor whiteColor];
    _dataLb.text = @"60";
    [self addSubview:_dataLb];
    
    
    
    _dateSubLB = [[UILabel alloc]initWithFrame:CGRectMake(0, self.height-DATESUBVIEWIDTH, self.width, DATESUBVIEWIDTH)];
    _dateSubLB.backgroundColor = [UIColor clearColor];
    _dateSubLB.font = dateSubFont;
    _dateSubLB.textAlignment = NSTextAlignmentCenter;
    _dateSubLB.textColor = [UIColor whiteColor];
    _dateSubLB.text = @"天后开始";
    [self addSubview:_dateSubLB];
    
}
- (void)setDateStr:(NSString *)dateStr
{
    UIFont *dateFont;
    if (iPhone6) {
        dateFont = YHUI(28);
    }
    if (iphone6Plus) {
        dateFont = YHUI(40);
    }
    if (iPhone4||iPhone5) {
        dateFont = YHUI(30);
    }
    if ([dateStr isEqualToString:@"0"]) {
        _dataLb.frame =CGRectMake(0, DATESUBVIEY , self.width, self.height-DATESUBVIEWIDTH);
        _dateSubLB.frame =CGRectMake(0, 0, 0, 0);
        _dataLb.font = dateFont;
        _dataLb.text = @"今天";
       
    }else{
         _dataLb.text = dateStr;
    }
   
}
@end
