//
//  SHSIndexModel.m
//
//  Created by songhongshuai  on 15/3/27
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "SHSIndexModel.h"
NSString *const kSHSIndexModelUserId = @"user_id";
NSString *const kSHSIndexModelPartaked = @"partaked";
NSString *const kSHSIndexModelState = @"state";
NSString *const kSHSIndexModelImgUrl = @"img_url";
NSString *const kSHSIndexModelTitle = @"title";
NSString *const kSHSIndexModelMeetingId = @"meeting_id";
NSString *const kSHSIndexModelBeginTime = @"begin_time";
NSString *const kSHSIndexModelType = @"type";
NSString *const kSHSIndexModelIs_yqx = @"is_yqx";
NSString *const kSHSIndexModelPosters_url = @"posters_url";
NSString *const kSHSIndexModelYqx_url = @"yqx_url";
NSString *const kSHSIndexModelCompany_code = @"company_code";
NSString *const kSHSIndexModelCompany_fullname = @"company_fullname";
NSString *const kSHSIndexModelCompany_id = @"company_id";
NSString *const kSHSIndexModelCompany_logo = @"company_logo";
NSString *const kSHSIndexModelCompany_name = @"company_name";
@interface SHSIndexModel ()



- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation SHSIndexModel

@synthesize userId = _userId;
@synthesize imgUrl = _imgUrl;
@synthesize title = _title;
@synthesize meetingId = _meetingId;
@synthesize type = _type;
@synthesize beginTime = _beginTime;
@synthesize state = _state;
@synthesize partaked = _partaked;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
        self.state = [self objectOrNilForKey:kSHSIndexModelState fromDictionary:dict];
        self.userId = [self objectOrNilForKey:kSHSIndexModelUserId fromDictionary:dict];
        self.partaked = [self objectOrNilForKey:kSHSIndexModelPartaked fromDictionary:dict];
        self.imgUrl = [self objectOrNilForKey:kSHSIndexModelImgUrl fromDictionary:dict];
        self.title = [self objectOrNilForKey:kSHSIndexModelTitle fromDictionary:dict];
        self.yqx_url = [self objectOrNilForKey:kSHSIndexModelYqx_url fromDictionary:dict];
        self.is_yqx = [self objectOrNilForKey:kSHSIndexModelIs_yqx fromDictionary:dict];
        self.posters_url = [self objectOrNilForKey:kSHSIndexModelPosters_url fromDictionary:dict];
        self.meetingId = [self objectOrNilForKey:kSHSIndexModelMeetingId fromDictionary:dict];
        self.type = [self objectOrNilForKey:kSHSIndexModelType fromDictionary:dict];
        self.beginTime = [self objectOrNilForKey:kSHSIndexModelBeginTime fromDictionary:dict];
        
        self.company_code = [self objectOrNilForKey:kSHSIndexModelCompany_code fromDictionary:dict];
        self.company_fullname = [self objectOrNilForKey:kSHSIndexModelCompany_fullname fromDictionary:dict];
        self.company_id = [self objectOrNilForKey:kSHSIndexModelCompany_id fromDictionary:dict];
        self.company_logo = [self objectOrNilForKey:kSHSIndexModelCompany_logo fromDictionary:dict];
        self.company_name = [self objectOrNilForKey:kSHSIndexModelCompany_name fromDictionary:dict];
    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.state forKey:kSHSIndexModelState];
    [mutableDict setValue:self.partaked forKey:kSHSIndexModelPartaked];
    [mutableDict setValue:self.imgUrl forKey:kSHSIndexModelImgUrl];
    [mutableDict setValue:self.is_yqx forKey:kSHSIndexModelIs_yqx];
    [mutableDict setValue:self.posters_url forKey:kSHSIndexModelPosters_url];
    [mutableDict setValue:self.yqx_url forKey:kSHSIndexModelYqx_url];
    [mutableDict setValue:self.title forKey:kSHSIndexModelTitle];
    [mutableDict setValue:self.meetingId forKey:kSHSIndexModelMeetingId];
    [mutableDict setValue:self.userId forKey:kSHSIndexModelUserId];
    [mutableDict setValue:self.type forKey:kSHSIndexModelType];
    [mutableDict setValue:self.beginTime forKey:kSHSIndexModelBeginTime];
    
    [mutableDict setValue:self.company_code forKey:kSHSIndexModelCompany_code];
    [mutableDict setValue:self.company_fullname forKey:kSHSIndexModelCompany_fullname];
    [mutableDict setValue:self.company_id forKey:kSHSIndexModelCompany_id];
    [mutableDict setValue:self.company_logo forKey:kSHSIndexModelCompany_logo];
    [mutableDict setValue:self.company_name forKey:kSHSIndexModelCompany_name];
    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    self.state = [aDecoder decodeObjectForKey:kSHSIndexModelState];
    self.partaked = [aDecoder decodeObjectForKey:kSHSIndexModelPartaked];
    self.yqx_url = [aDecoder decodeObjectForKey:kSHSIndexModelYqx_url];
    self.imgUrl = [aDecoder decodeObjectForKey:kSHSIndexModelImgUrl];
    self.title = [aDecoder decodeObjectForKey:kSHSIndexModelTitle];
    self.meetingId = [aDecoder decodeObjectForKey:kSHSIndexModelMeetingId];
    self.userId = [aDecoder decodeObjectForKey:kSHSIndexModelUserId];
    self.type = [aDecoder decodeObjectForKey:kSHSIndexModelType];
    self.beginTime = [aDecoder decodeObjectForKey:kSHSIndexModelBeginTime];
    self.is_yqx = [aDecoder decodeObjectForKey:kSHSIndexModelIs_yqx];
    self.posters_url = [aDecoder decodeObjectForKey:kSHSIndexModelPosters_url];
    
    self.company_code = [aDecoder decodeObjectForKey:kSHSIndexModelCompany_code];
    self.company_fullname = [aDecoder decodeObjectForKey:kSHSIndexModelCompany_fullname];
    self.company_id = [aDecoder decodeObjectForKey:kSHSIndexModelCompany_id];
    self.company_logo = [aDecoder decodeObjectForKey:kSHSIndexModelCompany_logo];
    self.company_name = [aDecoder decodeObjectForKey:kSHSIndexModelCompany_name];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_yqx_url forKey:kSHSIndexModelYqx_url];
    [aCoder encodeObject:_state forKey:kSHSIndexModelState];
    [aCoder encodeObject:_partaked forKey:kSHSIndexModelPartaked];
    [aCoder encodeObject:_imgUrl forKey:kSHSIndexModelImgUrl];
    [aCoder encodeObject:_title forKey:kSHSIndexModelTitle];
    [aCoder encodeObject:_meetingId forKey:kSHSIndexModelMeetingId];
    [aCoder encodeObject:_userId forKey:kSHSIndexModelUserId];
    [aCoder encodeObject:_type forKey:kSHSIndexModelType];
    [aCoder encodeObject:_beginTime forKey:kSHSIndexModelBeginTime];
    [aCoder encodeObject:_is_yqx forKey:kSHSIndexModelIs_yqx];
    [aCoder encodeObject:_posters_url forKey:kSHSIndexModelPosters_url];
    
    [aCoder encodeObject:_company_code forKey:kSHSIndexModelCompany_code];
    [aCoder encodeObject:_company_fullname forKey:kSHSIndexModelCompany_fullname];
    [aCoder encodeObject:_company_id forKey:kSHSIndexModelCompany_id];
    [aCoder encodeObject:_company_logo forKey:kSHSIndexModelCompany_logo];
    [aCoder encodeObject:_company_name forKey:kSHSIndexModelCompany_name];
}

- (id)copyWithZone:(NSZone *)zone
{
    SHSIndexModel *copy = [[SHSIndexModel alloc] init];
    
    if (copy) {
        copy.yqx_url = [self.yqx_url copyWithZone:zone];
        copy.state = [self.state copyWithZone:zone];
        copy.partaked = [self.partaked copyWithZone:zone];
        copy.imgUrl = [self.imgUrl copyWithZone:zone];
        copy.title = [self.title copyWithZone:zone];
        copy.meetingId = [self.meetingId copyWithZone:zone];
        copy.userId = [self.meetingId copyWithZone:zone];
        copy.type = [self.type copyWithZone:zone];
        copy.beginTime = [self.beginTime copyWithZone:zone];
        copy.is_yqx = [self.is_yqx copyWithZone:zone];
        copy.posters_url = [self.posters_url copyWithZone:zone];
        
        copy.company_code = [self.company_code copyWithZone:zone];
        copy.company_fullname = [self.company_fullname copyWithZone:zone];
        copy.company_id = [self.company_id copyWithZone:zone];
        copy.company_logo = [self.company_logo copyWithZone:zone];
        copy.company_name = [self.company_name copyWithZone:zone];
    }
    
    return copy;
}


@end
