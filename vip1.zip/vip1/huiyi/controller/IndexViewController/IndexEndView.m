//
//  IndexEndView.m
//  huiyi
//
//  Created by songhongshuai on 15/3/25.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "IndexEndView.h"
#import "UIIndexEndButton.h"
#import "IndexEndButton.h"

@implementation IndexEndView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        BackGroundColor(self, whiteColor);
        [self creatUI];
    }
    return self;
}

- (void)creatUI
{
    //横线
    UILabel *HorizontalLB = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth/2-1, 0, 1, self.height)];
    BackGround16Color(HorizontalLB, @"#c1c1c1");
    [self addSubview:HorizontalLB];
    
    //竖线
    UILabel *verticalLB = [[UILabel alloc]initWithFrame:CGRectMake(0, self.height/2-1, ScreenWidth, 1)];
    BackGround16Color(verticalLB, @"#c1c1c1");
    [self addSubview:verticalLB];
    
    CGFloat bgWidth;
    CGFloat bgHeight;
    UIFont *btnFont;
    if (ScreenHeight <= 568) {
        bgWidth  = 66;
        bgHeight = 80;
        btnFont = YHUI(12);
    }
    else {
        bgWidth  = (ScreenWidth/320)*66;
        bgHeight = (ScreenWidth/320)*80;
        btnFont = YHUI((ScreenWidth/320)*12);
    }
    
    //九宫格
    CGFloat btnWidth = ScreenWidth/2-1;
    CGFloat btnHeight = self.height/2;
    NSArray *imageArr = @[@"index_31",@"index_37",@"index_36",@"index_scan_icon",@"index_28"];
    NSArray *titleArr = @[@"发布活动",@"推荐给朋友",@"我的消息",@"扫一扫",@"随便看看"];
    for (int i = 0; i < 4; i++) {
        UIIndexEndButton *btn = [[UIIndexEndButton alloc]initWithFrame:CGRectMake(btnWidth*(i%2)+1, btnHeight*(i/2), btnWidth, btnHeight)];
        [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        btn.endViewHeight = self.height;
        btn.tag = i+200;
        [btn setTitleColor:[UIColor colorWithHexString:@"#aeaeae"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateSelected];
        btn.titleLabel.font = btnFont;
        btn.titleLabel.textAlignment = NSTextAlignmentCenter;
        [btn setImage:[UIImage imageNamed:[imageArr objectAtIndex:i]] forState:UIControlStateNormal];
        [btn setTitle:[titleArr objectAtIndex:i] forState:UIControlStateNormal];
        btn.backgroundColor = [UIColor clearColor];
        [self addSubview:btn];
    }
    
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(self.width/2-bgWidth/2, self.height/2-bgHeight/2, bgWidth, bgHeight)];
    bgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:bgView];
    
    IndexEndButton *centerbtn = [[IndexEndButton alloc]initWithFrame:CGRectMake(0, 0, bgWidth, bgHeight)];
    centerbtn.userInteractionEnabled = YES;
    //[centerbtn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClicked)];
    [centerbtn addGestureRecognizer:tapGesture];
    centerbtn.tag = 4+200;
    centerbtn.image = [UIImage imageNamed:[imageArr objectAtIndex:4]];
    centerbtn.title = [titleArr objectAtIndex:4];
    centerbtn.titleLable.font = btnFont;
    centerbtn.backgroundColor = [UIColor clearColor];
    [bgView addSubview:centerbtn];
    
    CGFloat MESBTNCOUNTWIDTH;
    CGFloat MESBTNCOUNTHEIGHT;
    CGFloat MESBTNCOUNTX;
    CGFloat MESBTNCOUNTY;
    CGFloat imgHeight;
    UIFont *MESBTNFONT;
    if (ScreenHeight <= 568) {
        imgHeight = 36;
        MESBTNCOUNTWIDTH = 26;
        MESBTNCOUNTHEIGHT = 18;
        MESBTNCOUNTX = ScreenWidth/4+imgHeight/2-10;
        MESBTNCOUNTY = self.height/2+10;
        MESBTNFONT = YHUI(10);
    }
    else {
        imgHeight = (ScreenWidth/320)*36;
        MESBTNCOUNTWIDTH = (ScreenWidth/320)*26;
        MESBTNCOUNTHEIGHT = (ScreenWidth/320)*18;
        MESBTNCOUNTX = ScreenWidth/4+imgHeight/2-(ScreenWidth/320)*10;
        MESBTNCOUNTY = self.height/2+(ScreenWidth/320)*10;
        MESBTNFONT = YHUI((ScreenWidth/320)*10);
    }

    _messageCount = [UIButton buttonWithType:UIButtonTypeCustom];
    _messageCount.frame = CGRectMake(MESBTNCOUNTX, MESBTNCOUNTY, MESBTNCOUNTWIDTH, MESBTNCOUNTHEIGHT);
    [_messageCount setBackgroundImage: [UIImage imageNamed:@"index_20"] forState:UIControlStateNormal];
    _messageCount.hidden = NO;
    _messageCount.adjustsImageWhenHighlighted = NO;
    _messageCount.tag = 222;
    [_messageCount setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _messageCount.titleLabel.font = MESBTNFONT;
    _messageCount.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_messageCount];
}

- (void)btnClicked:(UIIndexEndButton *)btn
{
    if ([_delegate respondsToSelector:@selector(endViewBtnClick:)]) {
        [_delegate endViewBtnClick:btn.tag];
    }
}

- (void)tapClicked
{
    if ([_delegate respondsToSelector:@selector(endViewBtnClick:)]) {
        [_delegate endViewBtnClick:204];
    }
}

@end
