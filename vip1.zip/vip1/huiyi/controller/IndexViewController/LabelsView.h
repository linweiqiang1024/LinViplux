//
//  LabelsView.h
//  ZHIHUIBang
//
//  Created by 王振兴 on 15/5/9.
//  Copyright (c) 2015年 王振兴. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LabelsDelegate <NSObject>

-(void)LabelClicked:(NSInteger)index;
-(void)showMoreInfo:(UIButton *)btn;
@end

@interface LabelsView : UIView
{
    
}
//@property (nonatomic,strong) NSMutableArray *labelsArray;//标签
@property (nonatomic) CGFloat height;
@property (nonatomic,weak)id<LabelsDelegate>delegate;
@property (nonatomic, assign)BOOL isyellow;
@property (nonatomic, assign)BOOL isShowMore;
@property (nonatomic, strong) NSArray *labelsArray;
@property(nonatomic,strong)UIButton *showMoreBtn;
@property(nonatomic,strong)UILabel *descriptionLB;
@property(nonatomic,strong)UIView *endView;
/*
  获取它自己的高度  titles  为标签数组
 */
+ (CGFloat)getHeight:(NSMutableArray *)titles;
@end
