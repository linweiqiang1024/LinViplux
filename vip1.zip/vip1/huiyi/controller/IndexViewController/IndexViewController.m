//
//  IndexViewController.m
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "IndexViewController.h"
#import "Main_HeadView.h"
#import <WebKit/WebKit.h>
#import "FristViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import "SearchViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "EasyJSWebView.h"
#import "JsInterface.h"
#import "New_SignUpInfoViewController.h"

@interface MeetSquareHeadView : UIView

@end

@implementation MeetSquareHeadView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) {
        
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    UIBezierPath * bezierPath;
    
    // Draw top line
    bezierPath = [UIBezierPath bezierPath];
    [bezierPath moveToPoint:CGPointMake(0.0, rect.size.height)];
    [bezierPath addLineToPoint:CGPointMake(rect.size.width, rect.size.height)];
    [[UIColor colorWithRed:200.0/255.0 green:199.0/255.0 blue:204.0/255.0 alpha:1.0] setStroke];
    [bezierPath setLineWidth:1.0];
    [bezierPath stroke];
}

@end

@interface IndexViewController () <MainHeadViewDelegate,UIScrollViewDelegate,UIWebViewDelegate,LabelsDelegate,TestJSExport>
{
    UIViewController * currentViewController;
    FristViewController * fristVC;
    SecondViewController * secondVC;
    ThirdViewController * thirdVC;
    MeetSquareHeadView * _head;
    NSMutableArray * _brandArr;
    UIButton * brandBtn;
    NSString * selectedID;//选中品牌的id
}
@property (nonatomic, strong) UIScrollView * mainScrollView;
@property (nonatomic, strong) UIView * mainView;
@property (nonatomic, strong) UIView * secondView;
@property (nonatomic, strong) UIView * thirdView;
@property (nonatomic, strong) UIWebView * mainWebView;
@property (nonatomic, strong) WKWebView * WKMainWebView;
@property (nonatomic, strong) MeetSquareHeadView * head;
@property (nonatomic, strong) LabelsView * optionView;

@property (nonatomic, strong) Main_HeadView * headView;

@property (nonatomic        ) BOOL headVIewIsOpen;
@property (nonatomic, strong) NSMutableArray * brandArr;

@property (nonatomic, strong) JSContext * jumpToMeeting;

@end

@implementation IndexViewController

- (NSMutableArray *)brandArr
{
    if (!_brandArr) {
        _brandArr = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _brandArr;
}

- (LabelsView *)optionView
{
    if (!_optionView) {
        _optionView = [[LabelsView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 32)];
        _optionView.delegate = self;
        _optionView.clipsToBounds = YES;
        _optionView.backgroundColor = [UIColor whiteColor];
    }
    return _optionView;
}

/*
- (WKWebView *)WKMainWebView
{
    if (!_WKMainWebView) {
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc]init];
        _WKMainWebView = [[WKWebView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.head.frame) , ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame)) configuration:config];
        _WKMainWebView.backgroundColor = [UIColor whiteColor];
    }
    return _WKMainWebView;
}*/

- (UIWebView *)mainWebView
{
    if (!_mainWebView) {
        _mainWebView = [[UIWebView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.head.frame) , ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame))];
        _mainWebView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
        _mainWebView.delegate = self;
        if (@available(iOS 11.0, *))
        {
            _mainWebView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    return _mainWebView;
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initializatio
    }
    return self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"IndexViewController"];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"IndexViewController"];
}

- (MeetSquareHeadView *)head
{
    if (!_head) {
        _head = [[MeetSquareHeadView alloc]initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, 45 )];
        _head.backgroundColor = [UIColor whiteColor];
    }
    return _head;
}

- (void)loadWebViewWithIndex:(NSString *)index
{
    NSURL * url;
    
    NSArray * LoginCompanyArray = [[NSUserDefaults standardUserDefaults] objectForKey:@"LOGIN_COMPANY_ARRAY"];
    if (!LoginCompanyArray.count)
    {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",Base_COMPANY_ADDR,index]];
    }
    else
    {
        NSMutableArray * datas = [NSMutableArray arrayWithArray:LoginCompanyArray];
        NSDictionary * model = [datas lastObject];
        NSString * companyCode = [model objectForKey:@"code"];
        if ([companyCode isEqualToString:@"huiyiabc"])
        {
            url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",Base_COMPANY_ADDR,index]];
        }
        else
        {
            url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@.%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",companyCode,Base_COMPANY_ADDR,index]];
        }
    }
    
    
    /*
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"auth_session"] length] == 0) {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",Base_COMPANY_ADDR,index]];
    }
    else {
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"companyID"] isEqualToString:@"0"]) {
            url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",Base_COMPANY_ADDR,index]];
        }
        else {
            url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",COMPANY_ADDR,index]];
        }
    }*/
    
    
    /*
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"companyAddr"] length] == 0) {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://v2.huiyiabc.com/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",index]];
    }
    else {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@/v2meeting/squareIndex?index=%@&from=app&app_name=huiyiapp",COMPANY_ADDR,index]];
    }*/
    
    //if (IOS8) {
    //    [self.WKMainWebView loadRequest:[NSURLRequest requestWithURL:url]];
    //}
    //else {
        [self.mainWebView loadRequest:[NSURLRequest requestWithURL:url]];
    //}
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self customizeAboveToolbar];
    //建立右边的发布会议按钮
    //[self createNavRightBtn];
    self.titlelabel.text = @"会议广场";
    self.view.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
    self.view.backgroundColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:244.0/255.0 alpha:1.0];
    [self.view addSubview:self.head];
    [self.head addSubview:self.headView];
    [self.view addSubview:self.mainView];
    [self.view addSubview:self.mainWebView];

    [self loadWebViewWithIndex:@"hot"];
    [self getNetOptions];
    
    //[self.mainScrollView addSubview:self.mainView];
    
    /*
    fristVC = [[FristViewController alloc]init];
    [self addChildViewController:fristVC];
    
    secondVC = [[SecondViewController alloc]init];
    [self addChildViewController:secondVC];
    
    thirdVC = [[ThirdViewController alloc]init];
    [self addChildViewController:thirdVC];

    [self.view addSubview:fristVC.view];
    
    [fristVC didMoveToParentViewController:self];
    
    currentViewController = fristVC;
    [self.mainView addSubview: fristVC.view];
    [self.secondView addSubview:secondVC.view];
    [self.thirdView addSubview:thirdVC.view];*/
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if (navigationType == UIWebViewNavigationTypeLinkClicked) {
        return NO;
    }
    return YES;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [[Dialog Instance] hiddenHSHUD];
    self.mainWebView.hidden = NO;
    //[webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitUserSelect='none';"];
    [webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitTouchCallout='none';"];
    JSContext *context = [self.mainWebView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    context[@"jumpToMeeting"] = ^(NSString * name,NSString * types,NSString * meeting_id,NSString * isyqx,NSString * yqx_url,NSString * posters_url,NSString * bmmun) {
        New_SignUpInfoViewController * signUpVC = [[New_SignUpInfoViewController alloc]init];
        self.hidesBottomBarWhenPushed = YES;
        [[NSNotificationCenter defaultCenter]postNotificationName:@"hidenTabar" object:nil];
        signUpVC.isPoster = isyqx;
        if ([isyqx isEqualToString:@"1"]) {
            signUpVC.meetPoster_url =yqx_url;
        }
        else {
            signUpVC.meetPoster_url =posters_url;
        }
        signUpVC.meetID = meeting_id;
        signUpVC.meet_type = types;
        signUpVC.meetTitle = name;
        [self.navigationController pushViewController:signUpVC animated:YES];

        NSLog(@"+++++++Begin Log+++++++%@",name);
//        NSArray *args = [JSContext currentArguments];
//        
//        for (JSValue *jsVal in args) {
//            NSLog(@"%@", jsVal);
//        }
//        
//        JSValue *this = [JSContext currentThis];
//        NSLog(@"this: %@",this);
//        NSLog(@"-------End Log-------");
    };
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [[Dialog Instance] showHSHUDWithController:self];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [[Dialog Instance]hiddenHSHUD];
    self.mainWebView.hidden = NO;
    if (![NetworkSingleten shared].isNetwork) {
        self.networkView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame) , ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame));
        [self.view addSubview:self.networkView];
    }
}

- (void)networkButtonAction
{
    [self.networkView removeFromSuperview];
    self.mainWebView.hidden = YES;
    [self MainViewBtnsClicked:self.headView.selectedBtn];
    [self getNetOptions];
}

- (void)getNetOptions
{
    [MyDataService postBrandList:nil callback:^(id data) {
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]){
                NSLog(@"%@",[data JSONString]);
                [self.brandArr addObjectsFromArray:[[[data objectForKey:@"content"] objectForKey:@"list"] objectForKey:@"lst"]];
                NSMutableArray * titleArr = [[NSMutableArray alloc]initWithCapacity:0];
                NSString * name = [[NSUserDefaults standardUserDefaults]objectForKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                for (NSDictionary * dic in self.brandArr) {
                    [titleArr addObject:[dic objectForKey:@"brand_name"]];
                    if ([dic[@"brand_name"]isEqualToString:name]) {
                        selectedID = dic[@"brand_id"];
                        self.optionView.descriptionLB.text = [dic objectForKey:@"brand_name"];
                    }
                }
                
                [self sort];
                if (self.brandArr.count != 0) {
                    if (selectedID.length == 0) {
                        selectedID = [self.brandArr[0]objectForKey:@"brand_id"];
                        NSMutableArray *titleArr = [[NSMutableArray alloc]initWithCapacity:0];
                        for (NSDictionary *dic in self.brandArr) {
                            [titleArr addObject:[dic objectForKey:@"brand_name"]];
                        }
                        [[NSUserDefaults standardUserDefaults]setObject:self.brandArr[0][@"brand_name"] forKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                        
                        self.optionView.labelsArray = titleArr;
                        //_optionView.hidden = NO;
                        self.optionView.descriptionLB.text = [self.brandArr[0]objectForKey:@"brand_name"];

                        self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, self.optionView.height+32 );
                    }
                    else
                    {
                        self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth,32 );
                    }
                }
                else
                {
                    self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth,32 );
                }
            }
        }
    }];
}

- (NSMutableArray *)sort
{
    int i,j;
    if (_brandArr.count > 0)
    {
        for (i = 0; i < _brandArr.count-1; i++)
        {
            for (j = i+1; j < _brandArr.count; j++) /*注意循环的上下限*/
            {
                NSString * sortStr = [_brandArr[i] objectForKey:@"sort"];
                NSString * nextSortStr = [_brandArr[j] objectForKey:@"sort"];
                if ([sortStr integerValue] < [nextSortStr integerValue])
                {
                    NSDictionary * temp= [NSDictionary dictionaryWithDictionary:_brandArr[i]];
                    [_brandArr replaceObjectAtIndex:i withObject:_brandArr[j]];
                    [_brandArr replaceObjectAtIndex:j withObject:temp];;
                }
            }
        }
    }
    return _brandArr;
}

#pragma mark ----labelsDelegate-----
- (void)LabelClicked:(NSInteger)index
{
    selectedID = [_brandArr[index]objectForKey:@"brand_id"];
    [self loadWebViewWithIndex:[NSString stringWithFormat:@"brand&brand_id=%@",selectedID]];
    [[NSUserDefaults standardUserDefaults]setObject:[_brandArr[index] objectForKey:@"brand_name"] forKey:[NSString stringWithFormat:@"%@options",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
    [UIView animateWithDuration:0.05 animations:^{
        self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, 32);
        self.optionView.labelsArray = @[];
        self.mainWebView.frame = CGRectMake(0, CGRectGetMaxY(self.optionView.frame), ScreenWidth, ScreenHeight-CGRectGetMaxY(self.optionView.frame));
        self.optionView.descriptionLB.text = [_brandArr[index]objectForKey:@"brand_name"];
        [self.optionView.showMoreBtn setTitle:@"更多品牌" forState:UIControlStateNormal];
    }];
}

- (void)showMoreInfo:(UIButton *)btn
{
    brandBtn = btn;
    _headVIewIsOpen = !_headVIewIsOpen;
    NSMutableArray * titleArr = [[NSMutableArray alloc]initWithCapacity:0];
    for (NSDictionary * dic in _brandArr) {
        [titleArr addObject:[dic objectForKey:@"brand_name"]];
    }
    [UIView animateWithDuration:0.05 animations:^{
        if (_headVIewIsOpen)
        {
            [btn setTitle:@"收起" forState:UIControlStateNormal];
            self.optionView.labelsArray = titleArr;
            //_optionView.hidden = NO;
            if (self.brandArr.count == 0)
            {
                self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, 32 );
            }
            else
            {
                self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, self.optionView.height+32);
            }
        }
        else
        {
            [btn setTitle:@"更多品牌" forState:UIControlStateNormal];
            self.optionView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, 32);
            self.optionView.labelsArray = @[];
            //_optionView.hidden = YES;
        }
        self.mainWebView.frame = CGRectMake(0, CGRectGetMaxY(self.optionView.frame), ScreenWidth, ScreenHeight-CGRectGetMaxY(self.optionView.frame));
    }];
}

- (void)MainViewBtnsClicked:(UIButton*)btn
{
    if (btn.tag == 3)
    {
        [self.view addSubview:self.optionView];
        self.mainWebView.frame = CGRectMake(0, CGRectGetMaxY(self.optionView.frame), ScreenWidth, ScreenHeight-CGRectGetMaxY(self.optionView.frame));
        if (selectedID.length != 0)
        {
            self.optionView.hidden = NO;
            [self loadWebViewWithIndex:[NSString stringWithFormat:@"brand&brand_id=%@",selectedID]];
        }
        else
        {
            self.optionView.hidden = YES;
            self.mainWebView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame));
            [self loadWebViewWithIndex:[NSString stringWithFormat:@"brand&brand_id=@"""]];
        }
    }
    else
    {
        [self.optionView removeFromSuperview];
        self.mainWebView.frame = CGRectMake(0, CGRectGetMaxY(self.head.frame), ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame));
    }
    
    if (btn.tag == 1)
    {
        [self loadWebViewWithIndex:@"hot"];
    }
    if (btn.tag == 2)
    {
        [self loadWebViewWithIndex:@"recent"];
    }
    
    /*
    if ((btn.tag == 1 && [currentViewController isKindOfClass:[FristViewController class]]) || (btn.tag == 2 && [currentViewController isKindOfClass:[SecondViewController class]]) || (btn.tag == 3 && [currentViewController isKindOfClass:[ThirdViewController class]])) {
        return;
    }
    _headView.btnIndex = btn.tag;
    UIViewController * oldViewController = currentViewController;
    if (btn.tag == 1) {
        self.mainScrollView.contentOffset = CGPointMake(0, 0);
        [self transitionFromViewController:currentViewController toViewController:fristVC duration:0 options:UIViewAnimationOptionTransitionNone animations:^{
        } completion:^(BOOL finished) {
            if (finished) {
                currentViewController = fristVC;
            } else {
                currentViewController = oldViewController;
            }
        }];
    }
    if (btn.tag == 2) {
        self.mainScrollView.contentOffset = CGPointMake(ScreenWidth, 0);
        [self transitionFromViewController:currentViewController toViewController:secondVC duration:0 options:UIViewAnimationOptionTransitionNone animations:^{
        } completion:^(BOOL finished) {
            if (finished) {
                currentViewController = secondVC;
            } else {
                currentViewController = oldViewController;
            }
        }];
    }
    if (btn.tag == 3) {
        self.mainScrollView.contentOffset = CGPointMake(ScreenWidth*2, 0);
        [self transitionFromViewController:currentViewController toViewController:thirdVC duration:0 options:UIViewAnimationOptionTransitionNone animations:^{
        } completion:^(BOOL finished) {
            if (finished) {
                currentViewController = thirdVC;
            } else {
                currentViewController = oldViewController;
            }
        }];
    }*/
}

- (UIScrollView *)mainScrollView
{
    if (!_mainScrollView) {
        _mainScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.head.frame)+10,ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame)-10)];
        _mainScrollView.contentSize = CGSizeMake(ScreenWidth*3, ScreenHeight-CGRectGetMaxY(self.head.frame)-10);
        _mainScrollView.pagingEnabled = YES;
        _mainScrollView.delegate = self;
        _mainScrollView.backgroundColor = [UIColor clearColor];
        if (@available(iOS 11.0, *))
        {
            _mainScrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
        else
        {
            self.automaticallyAdjustsScrollViewInsets = NO;
        }
    }
    return _mainScrollView;
}

- (UIView *)secondView
{
    if (!_secondView) {
        _secondView = [[UIView alloc]initWithFrame:CGRectMake(ScreenWidth, 0,ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame)-10)];
        _secondView.backgroundColor = [UIColor blackColor];
    }
    return _secondView;
}

- (UIView *)thirdView
{
    if (!_thirdView) {
        _thirdView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,ScreenWidth , ScreenHeight-CGRectGetMaxY(self.head.frame)-10)];
        _thirdView.backgroundColor = [UIColor blackColor];
    }
    return _thirdView;
}

- (UIView *)mainView
{
    if (!_mainView) {
        _mainView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.head.frame),ScreenWidth, ScreenHeight-CGRectGetMaxY(self.head.frame))];
        _mainView.backgroundColor = [UIColor clearColor];
    }
    return _mainView;
}

- (Main_HeadView *)headView
{
    if (!_headView) {
        _headView = [[Main_HeadView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 45)];
        _headView.delegate = self;
    }
    return _headView;
}

- (void)customizeAboveToolbar
{
    UIButton * rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rightBtn.frame = CGRectMake(ScreenWidth-50, 20, 44, 44);
    [rightBtn addTarget:self action:@selector(searchBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [rightBtn setImage:[UIImage imageNamed:@"search_icon"] forState:UIControlStateNormal];
    [self.view addSubview:rightBtn];
}

- (void)searchBtnClicked
{
    SearchViewController * searchVC = [[SearchViewController alloc]init];
    [self.navigationController pushViewController:searchVC animated:YES];
}

- (void)dealloc
{
    [[Dialog Instance] hideProgress];
    self.mainWebView.delegate = nil;
}

- (void)ReturnBtn
{
    if (_isMyPublish)
    {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
