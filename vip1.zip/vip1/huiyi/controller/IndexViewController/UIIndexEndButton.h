//
//  UIIndexEndButton.h
//  huiyi
//
//  Created by songhongshuai on 15/3/25.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIIndexEndButton : UIButton

@property (nonatomic)CGFloat endViewHeight;//页面高度

@end
