//
//  SecondViewController.m
//  会议广场
//
//  Created by songhongshuai on 15/5/12.
//  Copyright (c) 2015年 songhongshuai. All rights reserved.
//

#import "SecondViewController.h"
#import "MyNoneContentView.h"
#import "IndexCell.h"
#import "MJRefresh.h"
#import "IndexModel.h"
#import "UIImageView+WebCache.h"
#import "New_SignUpInfoViewController.h"
@interface SecondViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *_indexDataArr;
    int _myPublishPage;
}
@property (nonatomic,strong)MyNoneContentView *tableViewNoneView;
@property (nonatomic,strong)UITableView *secondTableView;
@property (nonatomic,strong)UIView *tableHeadView;

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navBGView.hidden = YES;
    _myPublishPage = 1;
    _indexDataArr = [[NSMutableArray alloc]initWithCapacity:0];
    [self creatSecondUI];
    // Do any additional setup after loading the view.
}
- (MyNoneContentView *)tableViewNoneView
{
    if (!_tableViewNoneView) {
        _tableViewNoneView = [[MyNoneContentView alloc]init];
        _tableViewNoneView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight-self.navlabel.frame.size.height);
        _tableViewNoneView.hidden = NO;
        _tableViewNoneView.noneLabel.text = @"暂无近期内容";
        //_tableViewNoneView.otherLabel.text = @"请浏览首页列表收藏活动";
    }
    return _tableViewNoneView;
}
- (UITableView *)secondTableView
{
    if (!_secondTableView) {
        _secondTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-45-64)];
        _secondTableView.delegate = self;
        _secondTableView.dataSource = self;
        _secondTableView.backgroundColor = [UIColor clearColor];
        _secondTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        [_secondTableView addHeaderWithTarget:self action:@selector(headerRereshing)];
        [_secondTableView addFooterWithTarget:self action:@selector(footerRereshing)];
        _secondTableView.headerPullToRefreshText = @"下拉可以刷新了";
        _secondTableView.headerReleaseToRefreshText = @"松开马上刷新了";
        _secondTableView.headerRefreshingText = @"正在帮你刷新中";
        _secondTableView.footerPullToRefreshText = @"上拉可以加载更多数据了";
        _secondTableView.footerReleaseToRefreshText = @"松开马上加载更多数据了";
        _secondTableView.footerRefreshingText = @"正在帮你加载中";
    }
    return _secondTableView;
}
- (UIView *)tableHeadView
{
    if (!_tableHeadView) {
        _tableHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 10)];
        _tableHeadView.backgroundColor = [UIColor clearColor];
    }
    return _tableHeadView;
}
- (void)creatSecondUI
{
    [self.view addSubview:self.secondTableView];
    self.secondTableView.tableHeaderView = self.tableHeadView;
    [self getDataFromDB];
}
- (void)getDataFromDB
{
    NSString *dataStr = [[DBManager sharedInstance] getPublicDBData:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
    if (dataStr.length != 0&&[[[dataStr JSONValue] objectForKey:@"content"]isKindOfClass:[NSDictionary class]]) {
        [self formateDate:[dataStr JSONValue]];
    }
    [self getMeetsData];
}

- (void)headerRereshing
{
    _myPublishPage = 1;
    [MyDataService postRecentMeetingList:@{@"page":@"1"} callback:^(id data) {
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                NSString *jsonGame = [data JSONString];
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [[DBManager sharedInstance] insertDataToPublicDB:jsonGame valueKey:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
                [self formateDate:data];
                
            }else if ([[data objectForKey:@"code"] isEqualToString:@"201"]){
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
                self.secondTableView.tableHeaderView = self.tableViewNoneView;
            }else{
                
            }
            
        }
        [self.secondTableView headerEndRefreshing];
    }];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
}
- (void)postMeetingMyPublishMeeting:(NSInteger)page{
    NSDictionary *dic = @{@"page":[NSString stringWithFormat:@"%ld",(long)page]};
    [MyDataService postRecentMeetingList:dic callback:^(id data) {
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                [self formateDate:data];
                [self.secondTableView footerEndRefreshing];
            }else if([[data objectForKey:@"code"] isEqualToString:@"201"]){
                self.secondTableView.footerRefreshingText = @"没有更多内容了";
                [self performSelector:@selector(endRefreshing) withObject:nil afterDelay:0.5];
            }
        }
    }];
    if (![DBManager reachInternet]) {
        [self.secondTableView footerEndRefreshing];
    }
}
- (void)endRefreshing
{
    [self.secondTableView footerEndRefreshing];
}
- (void)footerRereshing
{
    _myPublishPage = _myPublishPage+1;
    [self postMeetingMyPublishMeeting:_myPublishPage];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
}
// 刷新结束
- (void)getMeetsData
{
    [MyDataService postRecentMeetingList:@{@"page":@"1"} callback:^(id data) {
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [[DBManager sharedInstance] insertDataToPublicDB:[data JSONString] valueKey:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
                self.secondTableView.tableHeaderView = self.tableHeadView;
                [self formateDate:data];
            }
            if ([[data objectForKey:@"code"] isEqualToString:@"201"]) {
                [[DBManager sharedInstance] deleteToPublicOneData:[NSString stringWithFormat:@"%@RecentMeetingList",[[NSUserDefaults standardUserDefaults] objectForKey:@"login_company_code"]]];
                [_indexDataArr removeAllObjects];
                self.secondTableView.tableHeaderView = self.tableViewNoneView;
            }
        }
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 74;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _indexDataArr.count;
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"fristViewTableViewCell";
    IndexCell*cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell= [[IndexCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    IndexModel *index = (IndexModel *)[_indexDataArr objectAtIndex:indexPath.row];
    cell.nameLb.text = index.meetName;
    index.meetImageUrl = [index.meetImageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
    [cell.contentImageView sd_setImageWithURL:[NSURL URLWithString:index.meetImageUrl] placeholderImage:[UIImage imageNamed:[NSString stringWithFormat:@"index_meet_type_%@@2x",index.meetType]]];
    cell.timeLb.text = [NSString stringWithFormat:@"%@",[Dialog formatterToTime:index.meetSTime]];
    if([index.meetStatus isEqualToString:@"pending"])
    {
        cell.statusImageView.image = [UIImage imageNamed:@"meetstatus3"];
    }
    if([index.meetStatus isEqualToString:@"starting"]){
        cell.statusImageView.image = [UIImage imageNamed:@"meetstatus1"];
    }
    if([index.meetStatus isEqualToString:@"ended"]){
        cell.statusImageView.image = [UIImage imageNamed:@"meetstatus2"];
    }
    cell.cellBmnum.text = index.meetBmnum;
    cell.cellCnt.text = index.meetCnt;
    cell.addressLb.text = index.meetAddress;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    IndexModel *index = (IndexModel *)[_indexDataArr objectAtIndex:indexPath.row];
    New_SignUpInfoViewController *signUpVC = [[New_SignUpInfoViewController alloc]init];
    self.hidesBottomBarWhenPushed = YES;
    [[NSNotificationCenter defaultCenter]postNotificationName:@"hidenTabar" object:nil];
    signUpVC.isPoster = index.isPoster;
    if ([index.isPoster isEqualToString:@"1"]) {
        signUpVC.meetPoster_url =index.yqx_url;
    }else{
        signUpVC.meetPoster_url =index.meetPosters_url;
    }
    signUpVC.meetID = index.meet_id;
    signUpVC.meet_type = index.meetType;
    signUpVC.meetTitle = index.meetName;
    signUpVC.photoArray = index.meetPic_list;
    signUpVC.haveImage = index.haveImage;//判断有没有海报图片
    [self.navigationController pushViewController:signUpVC animated:YES];

}
- (void)formateDate:(NSDictionary *)jsonDic
{
    for (NSDictionary *dic in [[jsonDic objectForKey:@"content"] objectForKey:@"list"]) {
        IndexModel *indexmodel = [[IndexModel alloc]init];
        indexmodel.meetName = [dic objectForKey:@"name"];
        indexmodel.meetAddress = [dic objectForKey:@"location"];
        indexmodel.meetSTime = [dic objectForKey:@"begin_date"];
        indexmodel.meetNTime = [dic objectForKey:@"end_date"];
        indexmodel.meet_id = [dic objectForKey:@"meeting_id"];
        indexmodel.meetBmnum = [dic objectForKey:@"bmtotal"];
        indexmodel.meetCnt = [dic objectForKey:@"cnt_reader"];
        indexmodel.meetType = [dic objectForKey:@"type"];
        indexmodel.isPoster = [dic objectForKey:@"is_yqx"];
        indexmodel.yqx_url = [dic objectForKey:@"yqx_url"];
        indexmodel.meetPosters_url = [dic objectForKey:@"posters_url"];
        
        indexmodel.meetStatus = [dic objectForKey:@"meeting_status"];
        if ([[dic objectForKey:@"img_url"] length]>0||[[dic objectForKey:@"pic_list"] count]>0) {//判断有没有海报图片
            indexmodel.haveImage = YES;
        }
        else{
            indexmodel.haveImage = NO;
        }
        
        NSArray *imageArray = [dic objectForKey:@"pic_list"];
        if ([imageArray count]>0) {
            
            NSMutableArray *imageUrls = [[NSMutableArray alloc]init];
            for (NSDictionary *imageDic in imageArray) {
                NSString *imageUrl = [imageDic objectForKey:@"img_file"];
                imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
                [imageUrls addObject:imageUrl];
            }
            indexmodel.meetImageUrl = [imageUrls objectAtIndex:0];
            indexmodel.meetPic_list = imageUrls;
        }
        else if([[dic objectForKey:@"img_url"] length]>0){
            indexmodel.meetImageUrl = [dic objectForKey:@"img_url"];
            NSString *imageUrl = [dic objectForKey:@"img_url"];
            imageUrl = [imageUrl stringByReplacingOccurrencesOfString:@" " withString:@""];
            indexmodel.meetPic_list = [NSMutableArray arrayWithObjects:imageUrl, nil];
        }
        else{
            
        }
        CGSize nameSize = [indexmodel.meetName sizeWithFont:[UIFont boldSystemFontOfSize:17] constrainedToSize:CGSizeMake(203, 200) lineBreakMode:NSLineBreakByWordWrapping];
        indexmodel.meetNameHeight = nameSize.height;
        [_indexDataArr addObject:indexmodel];
    }
    if(_indexDataArr.count==0){
        self.secondTableView.tableHeaderView = self.tableViewNoneView;
    }else{
        self.secondTableView.tableHeaderView = self.tableHeadView;
    }
    
    [self.secondTableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
