//
//  NewIndexCell.h
//  huiyi
//
//  Created by 林伟强 on 16/11/1.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewIndexCell : UITableViewCell
{
    UILabel *_nameLb;
    UILabel *_timeLb;
    UILabel *_addressLb;
    UIImageView *_contentImageView;
    UILabel *_cellCnt;//阅读人数
    UILabel *_cellBmnum;//报名人数
    CGFloat _cellNameHeight;//报名的标题的高度
}

@property(nonatomic,strong) UILabel *nameLb;
@property(nonatomic,strong) UILabel *timeLb;
@property(nonatomic,strong) UILabel *addressLb;
@property(nonatomic,strong) UIImageView *contentImageView;
@property(nonatomic,strong) UIImageView *statusImageView;
@property(nonatomic,strong) UILabel *cellCnt;
@property(nonatomic,strong) UILabel *cellBmnum;
@property(nonatomic,strong) UIButton *cellNewApplyCount;
@property(nonatomic) CGFloat cellNameHeight;
- (void)reloadView;
@end
