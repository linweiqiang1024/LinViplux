//
//  ThirdViewController.h
//  会议广场
//
//  Created by songhongshuai on 15/5/12.
//  Copyright (c) 2015年 songhongshuai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LabelsView.h"
#import "FatherViewController.h"
@interface ThirdHeadView : UIView
{
    UILabel *_descriptionLB;
}
@property(nonatomic,strong)NSString *descripe;
@property(nonatomic,strong)UIButton *showMoreBtn;
@property(nonatomic,strong)UILabel *descriptionLB;

@end

@interface ThirdViewController : FatherViewController

@end
