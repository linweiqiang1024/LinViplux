
//
//  IndexMidView.m
//  huiyi
//
//  Created by songhongshuai on 15/3/25.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "IndexMidView.h"

@interface IndexMidView()
{
    UIFont *btnFont;//按钮字体大小
    CGFloat numHeight;//按钮lable上方最大高度
}
@property(nonatomic,strong)UILabel *creatNumLable;
@property(nonatomic,strong)UILabel *joinNumLable;
@property(nonatomic,strong)UILabel *storeNumLable;
@end

@implementation IndexMidView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        BackGroundColor(self, whiteColor);
        [self setBackgroundColor:[UIColor colorWithHexString:@"#17b4eb"]];
        [self creatUI];
    }
    return self;
}

- (void)creatUI
{
    //横线
    CGFloat LBY;
    CGFloat top;
    CGFloat countY;
    CGFloat MESBTNCOUNTWIDTH;
    CGFloat MESBTNCOUNTHEIGHT;
    CGFloat MESBTNCOUNTX;
    CGFloat MESBTNCOUNTY;
    UIFont  *MESBTNFONT;
    if (ScreenHeight <= 568) {
        LBY = 10;
        btnFont = YHUI(12);
        top = 30;
        countY = 10;
        numHeight = 25;
        MESBTNCOUNTWIDTH = 26;
        MESBTNCOUNTHEIGHT = 18;
        MESBTNCOUNTX = ScreenWidth/3-30;
        MESBTNCOUNTY = 10;
        MESBTNFONT = YHUI(10);
    }
    else {
        LBY = (ScreenWidth/320)*10;
        btnFont = YHUI((ScreenWidth/320)*12);
        top = (ScreenWidth/320)*30;
        countY = (ScreenWidth/320)*10;
        numHeight = (ScreenWidth/320)*25;
        MESBTNCOUNTWIDTH = (ScreenWidth/320)*26;
        MESBTNCOUNTHEIGHT = (ScreenWidth/320)*18;
        MESBTNCOUNTX = ScreenWidth/3-(ScreenWidth/320)*30;
        MESBTNCOUNTY = (ScreenWidth/320)*10;
        MESBTNFONT = YHUI((ScreenWidth/320)*10);
    }

    UILabel *verticalLB1 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth/3, LBY, 1, self.height-2*LBY)];
    BackGround16Color(verticalLB1, @"#ccedf8");
    [self addSubview:verticalLB1];
    
    UILabel *verticalLB2 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth/3*2, LBY, 1, self.height-2*LBY)];
    BackGround16Color(verticalLB2, @"#ccedf8");
    [self addSubview:verticalLB2];
    
    UIButton *createBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    createBtn.frame = CGRectMake(0, 0, ScreenWidth/3-1, self.height);
    createBtn.titleEdgeInsets = UIEdgeInsetsMake(top, 0, 0, 0);
    [createBtn setTitleColor:[UIColor colorWithHexString:@"#e6f2ff"] forState:UIControlStateNormal];
    createBtn.tag = 300;
    [createBtn addTarget:self action:@selector(midBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    createBtn.titleLabel.font = btnFont;
    [createBtn setTitle:@"我发布的" forState:UIControlStateNormal];
    [self addSubview:createBtn];
    
    UIButton *joinBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    joinBtn.frame = CGRectMake(CGRectGetMaxX(verticalLB1.frame),0, ScreenWidth/3-1, self.height);
    joinBtn.tag = 301;
    [joinBtn addTarget:self action:@selector(midBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    joinBtn.titleEdgeInsets = UIEdgeInsetsMake(top, 0, 0, 0);
    [joinBtn setTitleColor:[UIColor colorWithHexString:@"#e6f2ff"] forState:UIControlStateNormal];
    joinBtn.titleLabel.font = btnFont;
    [joinBtn setTitle:@"我参与的" forState:UIControlStateNormal];
    [self addSubview:joinBtn];
    
    UIButton *storeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    storeBtn.frame = CGRectMake(CGRectGetMaxX(verticalLB2.frame), 0, ScreenWidth/3-1, self.height);
    storeBtn.tag = 302;
    [storeBtn addTarget:self action:@selector(midBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    storeBtn.titleEdgeInsets = UIEdgeInsetsMake(top, 0, 0, 0);
    [storeBtn setTitleColor:[UIColor colorWithHexString:@"#e6f2ff"] forState:UIControlStateNormal];
    storeBtn.titleLabel.font = btnFont;
    [storeBtn setTitle:@"我收藏的" forState:UIControlStateNormal];
    [self addSubview:storeBtn];
    
    _creatNumLable = [[UILabel alloc]initWithFrame:CGRectMake(0, countY, ScreenWidth/3-1, numHeight)];
    _creatNumLable.textColor = [UIColor whiteColor];
    _creatNumLable.textAlignment = NSTextAlignmentCenter;
    _creatNumLable.backgroundColor = [UIColor clearColor];
    [self addSubview:_creatNumLable];
    
    _joinNumLable = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth/3, countY, ScreenWidth/3-1, numHeight)];
    _joinNumLable.textAlignment = NSTextAlignmentCenter;
    _joinNumLable.textColor = [UIColor whiteColor];
    _joinNumLable.backgroundColor = [UIColor clearColor];
    [self addSubview:_joinNumLable];

    _storeNumLable = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth/3*2, countY, ScreenWidth/3-1, numHeight)];
    _storeNumLable.textAlignment = NSTextAlignmentCenter;
    _storeNumLable.textColor = [UIColor whiteColor];
    _storeNumLable.backgroundColor = [UIColor clearColor];
    [self addSubview:_storeNumLable];
    
    _messageCount = [UIButton buttonWithType:UIButtonTypeCustom];
    _messageCount.frame = CGRectMake(MESBTNCOUNTX, MESBTNCOUNTY, MESBTNCOUNTWIDTH, MESBTNCOUNTHEIGHT);
    [_messageCount setBackgroundImage: [UIImage imageNamed:@"index_20"] forState:UIControlStateNormal];
    _messageCount.hidden = NO;
    _messageCount.adjustsImageWhenHighlighted = NO;
    _messageCount.tag = 222;
    [_messageCount setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _messageCount.titleLabel.font = MESBTNFONT;
    _messageCount.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_messageCount];
}
- (void)setCreatNum:(NSString *)creatNum
{
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:creatNum];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI_BOLD(numHeight) range:NSMakeRange(0,creatNum.length-1)];
    [tittle_str addAttribute:NSFontAttributeName value:btnFont range:NSMakeRange(creatNum.length-1,1)];
    _creatNumLable.attributedText = tittle_str;
}
- (void)setJoinNum:(NSString *)joinNum
{
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:joinNum];
    
    [tittle_str addAttribute:NSFontAttributeName value:YHUI_BOLD(numHeight) range:NSMakeRange(0,joinNum.length-1)];
    [tittle_str addAttribute:NSFontAttributeName value:btnFont range:NSMakeRange(joinNum.length-1,1)];
    _joinNumLable.attributedText = tittle_str;
}
- (void)setStoreNum:(NSString *)storeNum
{
    NSMutableAttributedString *tittle_str = [[NSMutableAttributedString alloc] initWithString:storeNum];
    [tittle_str addAttribute:NSFontAttributeName value:YHUI_BOLD(numHeight) range:NSMakeRange(0,storeNum.length-1)];
    [tittle_str addAttribute:NSFontAttributeName value:btnFont range:NSMakeRange(storeNum.length-1,1)];
    _storeNumLable.attributedText = tittle_str;
}
- (void)midBtnClick:(UIButton *)btn
{
    if ([_delegate respondsToSelector:@selector(midViewBtnClicked:)]) {
        [_delegate midViewBtnClicked:btn];
    }
}

@end
