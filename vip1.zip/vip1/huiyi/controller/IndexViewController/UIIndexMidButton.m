//
//  UIIndexMidButton.m
//  huiyi
//
//  Created by songhongshuai on 15/3/26.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#import "UIIndexMidButton.h"

@implementation UIIndexMidButton

@end
