//
//  IndexCell.h
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndexCell : UITableViewCell
{
    UILabel *_nameLb;
    UILabel *_timeLb;
    UILabel *_addressLb;
    UIImageView *_contentImageView;
    UILabel *_cellCnt;//阅读人数
    UILabel *_cellBmnum;//报名人数
    CGFloat _cellNameHeight;//报名的标题的高度
}

@property(nonatomic,strong) UILabel *nameLb;
@property(nonatomic,strong) UILabel *timeLb;
@property(nonatomic,strong) UILabel *addressLb;
@property(nonatomic,strong) UIImageView *contentImageView;
@property(nonatomic,strong) UIImageView *statusImageView;
@property(nonatomic,strong) UILabel *cellCnt;
@property(nonatomic,strong) UILabel *cellBmnum;
@property(nonatomic,strong) UIButton *cellNewApplyCount;
@property(nonatomic) CGFloat cellNameHeight;
@end
