//
//  Main_HeadView.m
//  会议广场
//
//  Created by songhongshuai on 15/5/12.
//  Copyright (c) 2015年 songhongshuai. All rights reserved.
//

#import "Main_HeadView.h"

#define screenWidth [UIScreen mainScreen].bounds.size.width
@interface Main_HeadView ()
{
    
}
@property (nonatomic,strong)UILabel *moveLB;

@end
@implementation Main_HeadView
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        [self creatUI];
    }
    return self;
}

- (void)creatUI{
    NSArray *titleArr = @[@"热门",@"近期",@"品牌"];
    for (int index = 0; index<3; index++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.tag = index+1;
        [btn setTitle:titleArr[index] forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor colorWithRed:11.0/255.0 green:137.0/255.0 blue:182.0/255.0 alpha:1.0] forState:UIControlStateSelected];
        [btn setTitleColor:[UIColor colorWithRed:179.0/255.0 green:179.0/255.0 blue:180.0/255.0 alpha:1.0] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont boldSystemFontOfSize:18];
        btn.frame = CGRectMake(0+index*self.frame.size.width/3, 0, self.frame.size.width/3, 42);
//        btn.backgroundColor = [UIColor yellowColor];
        [btn addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        if (index == 0) {
            btn.selected = YES;//默认第一个选中
            self.selectedBtn = btn;
        }
    }
    
    [self addSubview:self.moveLB];
}
- (UILabel*)moveLB
{
    if (!_moveLB) {
        _moveLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 42, screenWidth/3, 3)];
        _moveLB.backgroundColor = [UIColor colorWithRed:11.0/255.0 green:137.0/255.0 blue:182.0/255.0 alpha:1.0];
    }
    return _moveLB;
}
- (void)btnClicked:(UIButton *)btn
{
    if (![self.selectedBtn isEqual:btn]) {
        self.selectedBtn.selected = NO;
        btn.selected = YES;
        self.selectedBtn = btn;
        self.moveLB.frame = CGRectMake(screenWidth/3*(btn.tag-1), self.moveLB.frame.origin.y, screenWidth/3, 3);
        if ([_delegate respondsToSelector:@selector(MainViewBtnsClicked:)]) {
            [_delegate MainViewBtnsClicked:btn];
        }
    }

//    for (UIView *indexBtn in [self subviews]) {
//        if ([indexBtn isKindOfClass:[UIButton class]]&&indexBtn.tag !=btn.tag) {
//            UIButton *enSelecedBtn = (UIButton *)indexBtn;
//            enSelecedBtn.selected = NO;
//        }
//    }
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
