//
//  FriendsViewController.h
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendsViewController : UIViewController

@end
