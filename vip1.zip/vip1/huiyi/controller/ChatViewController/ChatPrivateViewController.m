//
//  ChatPrivateViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/5.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatPrivateViewController.h"
#import "ChatSetingHeaderView.h"
#import "ChatViewController.h"
#import "RCDRCIMDataSource.h"
#import "RCFriendsBookViewController/RCChatUserInfo.h"
#import "SevenSwitch.h"
#import "RCDataBaseManager.h"
#import "ChatSetingTableViewCell.h"
#import "FriendInfoViewController.h"
#import "RCDSelectPersonViewController.h"
@interface ChatPrivateViewController ()<UIActionSheetDelegate,ChatSettingTableViewHeaderDelegate,SevenSwitchChangeValueDelegate>
{
    __block NSMutableArray       *_usersParam;

}

@property (nonatomic,strong) UILabel              *titleView;
@property (nonatomic,strong) UIBarButtonItem      *leftButton;
@property (nonatomic,strong) UIButton             *leftBtn;
@property (nonatomic,strong) ChatSetingHeaderView *tableViewHeader;
@property (nonatomic,strong) UIView               *footView;
@property (nonatomic,strong) UIButton             *exitBtn;
@property (nonatomic,strong) NSArray              *dataSourceParam;
@end


@implementation ChatPrivateViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    [[RCIMClient sharedRCIMClient]getConversation:self.conversationType targetId:self.targetId];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.backgroundColor = [UIColor colorWithHexString:@"#f0eff5"];
    self.navigationItem.titleView = self.titleView;
    self.navigationItem.leftBarButtonItem = self.leftButton;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.tableFooterView = [UIView new];
    _usersParam = [[NSMutableArray alloc]initWithCapacity:0];
    [self getUserDetailInfo];
}


- (NSArray *)dataSourceParam
{
    if (!_dataSourceParam) {
        _dataSourceParam = [NSArray arrayWithObjects:@"置顶聊天", @"新消息提示", @"清空聊天记录", nil];
    }
    return _dataSourceParam;
}

- (UILabel *)titleView
{
    if (!_titleView) {
        _titleView = [[UILabel alloc]init];
        _titleView.frame = CGRectMake(100, 0, 120, 44);
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.text = @"设置";
        _titleView.textAlignment = NSTextAlignmentCenter;
        _titleView.font = [UIFont boldSystemFontOfSize:18];
        _titleView.textColor = [UIColor whiteColor];
    }
    
    return _titleView;
}
- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}

- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}

- (ChatSetingHeaderView *)tableViewHeader
{
    if (!_tableViewHeader) {
        _tableViewHeader = [[ChatSetingHeaderView alloc]init];
        _tableViewHeader.settingTableViewHeaderDelegate = self;
        _tableViewHeader.backgroundColor = [UIColor whiteColor];
    }
    return _tableViewHeader;
}

- (UIView *)footView
{
    if (!_footView) {
        _footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 80)];
        _footView.backgroundColor = [UIColor colorWithHexString:@"#f0eff5"];
    }
    return _footView;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)getUserDetailInfo{
    [[RCDRCIMDataSource shareInstance]getUserInfoWithUserId:self.targetId completion:^(RCUserInfo *userInfo) {
        RCChatUserInfo *info = [RCChatUserInfo new];
        info.selected = YES;
        info.userId = userInfo.userId;
        info.name = userInfo.name;
        info.portraitUri = userInfo.portraitUri;
        
        [_usersParam addObject:info];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.tableViewHeader.isAllowedDeleteMember = NO;
            self.tableViewHeader.isAllowedInviteMember = YES;
            self.tableViewHeader.users = _usersParam;
            self.tableView.tableHeaderView = self.tableViewHeader;
            [self.tableView reloadData];
        });
    }];    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43.5;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuseIdentifier = @"reuseIdentifierCell";
    ChatSetingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[ChatSetingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    }
    cell.delegate = self;
    cell.indexPath = indexPath;
    cell.nameLabel.text = self.dataSourceParam[indexPath.row];
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    if (indexPath.row == 0) {
        if ([[def objectForKey:[NSString stringWithFormat:@"%@_GroupConversationToTop",self.targetId]]isEqualToString:@"1"] ) {
            cell.switchBtn.on = YES;
        }else{
            cell.switchBtn.on = NO;
        }
    }
    if (indexPath.row == 1) {
        [[RCIMClient sharedRCIMClient] getConversationNotificationStatus:self.conversationType targetId:self.targetId success:^(RCConversationNotificationStatus nStatus) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (nStatus == DO_NOT_DISTURB) {
                    
                    cell.switchBtn.on = NO;
                }else{
                    cell.switchBtn.on = YES;
                }
            });
        } error:^(RCErrorCode status) {
            
        }];
    }
    if (indexPath.row == 2) {
        cell.switchBtn.hidden = YES;
        cell.endCell = YES;
    }else{
        cell.switchBtn.hidden = NO;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == self.dataSourceParam.count - 1) {
        UIActionSheet *sheet = [[UIActionSheet alloc]initWithTitle:@"是否清除记录" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles:nil];
        [sheet showInView:self.view];
    }
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        [self clearHistoryMessage];
    }
}
- (void)clearHistoryMessage {
    BOOL isClear = [[RCIMClient sharedRCIMClient] clearMessages:self.conversationType targetId:self.targetId];
    
    //清除消息之后回调操作，例如reload 会话列表
    if (self.clearHistoryCompletion) {
        self.clearHistoryCompletion(isClear);
    }
}
#pragma mark --SevenSwitchChangeValueDelegate--
//修改按钮状态
- (void)changeValueWithState:(BOOL)state IndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0){
        //置顶
        if (state) {
            [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:[NSString stringWithFormat:@"%@_GroupConversationToTop",self.targetId]];
            
        }else{
            [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:[NSString stringWithFormat:@"%@_GroupConversationToTop",self.targetId]];
            
        }
        [[RCIMClient sharedRCIMClient]setConversationToTop:self.conversationType targetId:self.targetId isTop:state];
        //        RCConversationModel *mode = [RCConversationModel alloc]ini
    }
    if(indexPath.row == 1){
        //消息提示
        [[RCIMClient sharedRCIMClient]setConversationNotificationStatus:self.conversationType targetId:self.targetId isBlocked:state success:^(RCConversationNotificationStatus nStatus) {
            BOOL enableNotification = NO;
            if (nStatus == NOTIFY) {
                enableNotification = YES;
            }
        } error:^(RCErrorCode status) {
            
        }];
    }
}
#pragma mark --ChatSettingTableViewHeaderDelegate--
//点击群成员的头像 ，添加，删除群成员
- (void)didTipHeaderClicked:(RCUserInfo *)userInfo IndexPath:(NSInteger)indexPath
{
    if (userInfo) {
        //跳转群成员详情页
        FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
        friendInfoVC.isChatInfo = YES;
        friendInfoVC.user_id = userInfo.userId;
        [self.navigationController pushViewController:friendInfoVC animated:YES];
    }else{
        if (self.tableViewHeader.isAllowedInviteMember&&self.tableViewHeader.isAllowedDeleteMember){
            if (indexPath == _usersParam.count) {
                //添加动作
            }
            if (indexPath == _usersParam.count + 1) {
                //删除动作
            }
        }
        if (self.tableViewHeader.isAllowedDeleteMember^self.tableViewHeader.isAllowedInviteMember) {
            if (self.tableViewHeader.isAllowedInviteMember) {
                //添加
                NSLog(@"创建讨论组");
                RCDSelectPersonViewController* selectPersonVC = [[RCDSelectPersonViewController alloc]init];
                [selectPersonVC setSeletedUsers:_usersParam];
                //设置回调
                selectPersonVC.clickDoneCompletion = ^(RCDSelectPersonViewController* selectPersonViewController, NSArray* selectedUsers) {
                    if (selectedUsers && selectedUsers.count) {
                        [_usersParam addObjectsFromArray:selectedUsers];
                        self.tableViewHeader.users = _usersParam;
                        [self createDiscussionOrInvokeMemberWithSelectedUsers:_usersParam Controller:selectPersonViewController];
                    }
                };
                [self.navigationController pushViewController:selectPersonVC animated:YES];

                
            }
            if (self.tableViewHeader.isAllowedDeleteMember) {
                //删除
                
                self.tableViewHeader.showDeleteTip = !self.tableViewHeader.showDeleteTip;
            }
        }
    }
    
    
}

#pragma mark - private method
- (void)createDiscussionOrInvokeMemberWithSelectedUsers:(NSArray*)selectedUsers Controller:(UIViewController *)vc
{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSUInteger _count = [selectedUsers count];
        if (_count > 1) {
            
            NSMutableString *discussionTitle = [NSMutableString string];
            NSMutableArray *userIdList = [NSMutableArray new];
            [userIdList addObject:[RCIMClient sharedRCIMClient].currentUserInfo.userId];
            ;
            [RCDDataSource getUserInfoWithUserId:[RCIMClient sharedRCIMClient].currentUserInfo.userId completion:^(RCUserInfo *userInfo) {
                
                [discussionTitle appendString:[NSString stringWithFormat:@"%@%@", userInfo.name,@","]];
                for (int i=0; i<_count; i++) {
                    RCUserInfo *_userInfo = (RCUserInfo *)selectedUsers[i];
                    [discussionTitle appendString:[NSString stringWithFormat:@"%@%@", _userInfo.name,@","]];
                    [userIdList addObject:_userInfo.userId];
                    if (i==_count-1) {
                        [[RCIMClient sharedRCIMClient] createDiscussion:discussionTitle userIdList:userIdList success:^(RCDiscussion *discussion) {
                            
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [discussionTitle deleteCharactersInRange:NSMakeRange(discussionTitle.length - 1, 1)];
                                self.titleView.text = discussionTitle;
                                ChatViewController  *chat =[[ChatViewController alloc]init];
                                chat.targetId                      = discussion.discussionId;
                                chat.userName                    = discussion.discussionName;
                                chat.conversationType              = ConversationType_DISCUSSION;
                                chat.title                         = discussionTitle;
                                [vc.navigationController  pushViewController:chat animated:YES];
                            });
                        } error:^(RCErrorCode status) {
                        }];

                    }
                }
            }];
        }
    });
}

////删除群成员
//- (void)deleteTipButtonClicked:(NSInteger )index
//{
//    [[Dialog Instance]showCenterProgressWithLabel:@"正在删除成员..."];
//    RCUserInfo *info = (RCUserInfo *)_usersParam[index];
//    
//    NSDictionary *params  = @{@"group_id":self.targetId,@"member_id":info.userId};
//    [MyDataService postPlatformContactCelgroupmember:params callback:^(id data) {
//        [[Dialog Instance] hideProgress];
//        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
//            if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
//                [_usersParam removeObjectAtIndex:index];
//                self.tableViewHeader.users = _usersParam;
//            }else {
//                
//            }
//        }
//    }];
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
