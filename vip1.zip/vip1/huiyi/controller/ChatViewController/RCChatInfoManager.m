//
//  RCChatInfoManager.m
//  huiyi
//
//  Created by songhongshuai on 15/12/7.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "RCChatInfoManager.h"
#import <RongIMLib/RCGroup.h>
#import <RongIMLib/RCUserInfo.h>
#import "RCDataBaseManager.h"

@implementation RCChatInfoManager
//根据id获取单个群组

+(instancetype)shareInstance{
    static RCChatInfoManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[RCChatInfoManager alloc]init];
    });
    return manager;
}

-(void)getGroupByID:(NSString *) groupID

   successCompletion:(void (^)(RCGroup *group)) completion{
    NSDictionary *dic = @{@"group_id":groupID};
    [MyDataService postPlatformContactGroupmembers:dic calllback:^(id data) {
        NSLog(@"data = %@",[data JSONString]);
        if ([data[@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey: @"code"] isEqualToString: @"200"]) {
                NSDictionary *info = [[data objectForKey:@"content"] objectForKey:@"groupinfo"];
                RCGroup *grouInfo = [[RCGroup alloc]initWithGroupId:groupID groupName:info[@"name"] portraitUri:info[@"ico_file"]];
                completion(grouInfo);
            }
        }
    }];
}
-(void) getUseInfoByID:(NSString *) userID
     successCompletion:(void (^)(RCUserInfo  *userInfo)) completion{
    NSString *userId = userID;
    if ([userId rangeOfString:@":"].location != NSNotFound) {
        
        userId = [[userId componentsSeparatedByString:@":"] objectAtIndex:0];
        
    }
    
    
    RCUserInfo *info = [[RCDataBaseManager shareInstance]getUserByUserId:userID];
    if (info) {
        completion(info);
    }else{
        [MyDataService postPlatformContactUserinfonew:@{@"user_id":userId} calllback:^(id data) {
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                    RCUserInfo *user = [RCUserInfo new];
                    user.userId = userID;
                    user.portraitUri = [[data objectForKey:@"content"] objectForKey:@"ico_url"];
                    user.name = [[data objectForKey:@"content"]  objectForKey:@"name"];
                    [[RCDataBaseManager shareInstance] insertUserToDB:user];
                    completion(user);
                }
            }
        }];
    }
}
- (UIImage *)imagesNamedFromCustomBundle:(NSString *)imgName
{
    NSString *bundlePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"RongCloud.bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *img_path = [bundle pathForResource:imgName ofType:@"png"];
    return [UIImage imageWithContentsOfFile:img_path];
}
@end
