//
//  ChatViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/12/2.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <RongIMKit/RongIMKit.h>



@interface ChatViewController : RCConversationViewController
@property (nonatomic,strong)NSString *chatUserName;
@property (nonatomic)BOOL fromSignView;
@property (nonatomic)BOOL fromGroupView;
@property (nonatomic)BOOL fromChatListView;

@end
