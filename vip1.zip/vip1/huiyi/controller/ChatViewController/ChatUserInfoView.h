//
//  ChatUserInfoView.h
//  huiyi
//
//  Created by songhongshuai on 15/12/3.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RongIMLib/RCUserInfo.h>

@protocol ChatUserInfoViewChoiceUersInfoDelegate <NSObject>

- (void)choiceUersInfo:(RCUserInfo *)uersInfo IndexPath:(NSInteger)indexPath;
- (void)delUsersIndex:(NSInteger)index;
@end

@interface ChatUserInfoView : UIView
@property (nonatomic ,strong) RCUserInfo *userInfo;
@property (nonatomic        ) BOOL       isAllowedDeleteMember;
@property (nonatomic        ) BOOL       isAllowedInviteMember;
@property (nonatomic        ) BOOL       isShowDelButton;
@property (nonatomic, weak) id<ChatUserInfoViewChoiceUersInfoDelegate>delegate;
@end
