//
//  GruopUserViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/12/9.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <RongIMKit/RongIMKit.h>

@interface GruopUserViewController : UIViewController
@property (nonatomic, assign) RCConversationType conversationType;
@property (nonatomic, strong) NSArray            *members;
@end
