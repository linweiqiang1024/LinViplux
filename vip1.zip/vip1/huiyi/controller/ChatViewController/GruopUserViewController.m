//
//  GruopUserViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/9.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "GruopUserViewController.h"
#import "RCDAddressBookTableViewCell.h"
#import "FriendInfoViewController.h"
#include "pinyin.h"

@interface GruopUserViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
@property (nonatomic,strong) UIBarButtonItem     *leftButton;
@property (nonatomic,strong) UIButton            *leftBtn;
@property (nonatomic,strong) UITableView         *tableView;
@property (nonatomic,strong) UIView              *tableHeadView;
@property (nonatomic,strong) UITextField         *userSearchBar;
@property (nonatomic,strong) NSMutableArray      *tempOtherArr;
@property (nonatomic,strong) NSMutableArray      *showDataList;
@property (nonatomic,strong) NSMutableDictionary *allMmembers;
@property (nonatomic,strong) NSArray             *allKeys;
@property (nonatomic,strong) NSArray             *keys;
@end

@implementation GruopUserViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];

}

- (void)keyboardWillShow:(NSNotification *)notification {
    NSDictionary* info = [notification userInfo];
    CGSize keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    [UIView animateWithDuration:1 animations:^{
        self.tableView.frame = CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y, self.tableView.frame.size.width,ScreenHeight- 64 - keyBoardSize.height-self.tableHeadView.height);
    }];
}

- (void)keyboardWillHide:(NSNotification *)notification{
    [UIView animateWithDuration:1 animations:^{
        self.tableView.frame = CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y, self.tableView.frame.size.width, ScreenHeight-64-CGRectGetMaxY(self.tableHeadView.frame));
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = self.leftButton;
    UIColor * color = [UIColor whiteColor];
    NSDictionary * dict = [NSDictionary dictionaryWithObject:color forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict ;
    if (self.conversationType == ConversationType_GROUP) {
        self.title = [NSString stringWithFormat:@"群成员"];
    }
    if (self.conversationType == ConversationType_DISCUSSION) {
        self.title = [NSString stringWithFormat:@"讨论组成员"];
    }
    [self.tableHeadView addSubview:self.userSearchBar];
    [self.view addSubview:self.tableHeadView];
    [self.view addSubview:self.tableView];
}

- (void)setMembers:(NSArray *)members
{
    if (members) {
        _members = members;
        _keys = @[@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",@"#"];
        _allKeys = [NSMutableArray new];
        self.allMmembers = [self sortedArrayWithPinYinDic:self.members];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
            
        });
    }
}

- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}

- (void)leftBarButtonItemPressed
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.tableHeadView.frame) , ScreenWidth, ScreenHeight-64-CGRectGetMaxY(self.tableHeadView.frame))];
        _tableView.sectionHeaderHeight = 22.f;
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.tableFooterView = [UIView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

- (UIView *)tableHeadView
{
    if (!_tableHeadView) {
        _tableHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0 , ScreenWidth, 54)];
        _tableHeadView.backgroundColor = [UIColor whiteColor];
    }
    return _tableHeadView;
}

- (UITextField *)userSearchBar
{
    if (!_userSearchBar) {
        _userSearchBar = [[UITextField alloc]initWithFrame:CGRectMake(0, 0 , ScreenWidth, 54)];
        _userSearchBar.delegate = self;
        _userSearchBar.contentMode = UIViewContentModeLeft;
        _userSearchBar.placeholder = @"搜索";
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40 , 16)];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.image = [UIImage imageNamed:@"icon-seach"];
        _userSearchBar.leftView = imageView;
        _userSearchBar.leftViewMode = UITextFieldViewModeAlways;
        _userSearchBar.returnKeyType = UIReturnKeyDone;
        _userSearchBar.keyboardType =  UIKeyboardTypeDefault;
        _userSearchBar.font = YHUI(16);
        [_userSearchBar addTarget:self action:@selector(searchTextChange:) forControlEvents:UIControlEventEditingChanged];
        _userSearchBar.clearButtonMode = UITextFieldViewModeWhileEditing;
        _userSearchBar.backgroundColor = [UIColor whiteColor];
    }
    return _userSearchBar;
}

//初始化
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    textField.text = @"";
    self.showDataList = [[NSMutableArray alloc]initWithArray:self.members];
    [self setMembers:_members];
    [self.tableView reloadData];
    [self.view endEditing:YES];
    return YES;
}
- (NSMutableArray *)showDataList
{
    if (!_showDataList) {
        _showDataList = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _showDataList;
}
- (NSMutableDictionary *)allMmembers
{
    if (!_allMmembers) {
        _allMmembers = [[NSMutableDictionary alloc]initWithCapacity:0];
    }
    return _allMmembers;
}
//搜索
- (void)searchTextChange:(UITextField *)textField
{
    if (textField.text!=nil && textField.text.length>0) {
        [self.showDataList removeAllObjects];
        for (RCUserInfo *info in self.members) {
            if ([info.name rangeOfString:textField.text options:NSCaseInsensitiveSearch].length >0 ) {
                [self.showDataList addObject:info];
            }
        }
    }else
    {
        self.showDataList = [NSMutableArray arrayWithArray:self.members];
    }
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        self.allMmembers = [self sortedArrayWithPinYinDic:self.showDataList];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
            
        });
    });
    
}

//override datasource
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellReuseIdentifier = @"RCDAddressBookTableViewCell";
    RCDAddressBookTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellReuseIdentifier];
    if (!cell) {
        cell = [[RCDAddressBookTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellReuseIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell setUserInteractionEnabled:YES];
    NSString *key = [self.allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [self.allMmembers objectForKey:key];
    RCUserInfo *user = (RCUserInfo *)arrayForKey[indexPath.row];
    if(user){
        cell.userInfo = user;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *key = [self.allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [self.allMmembers objectForKey:key];
    RCUserInfo *user = (RCUserInfo *)arrayForKey[indexPath.row];
    FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
    friendInfoVC.user_id = user.userId;
    friendInfoVC.isChatInfo = YES;
    [self.navigationController pushViewController:friendInfoVC animated:YES];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *key = [_allKeys objectAtIndex:section];
    NSArray *arr = [self.allMmembers objectForKey:key];
    return [arr count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [_allKeys count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55.f;
}
//pinyin index
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    return _allKeys;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSString *key = [_allKeys objectAtIndex:section];
    return key;
}



#pragma mark - 拼音排序

/**
 *  汉字转拼音
 *
 *  @param hanZi 汉字
 *
 *  @return 转换后的拼音
 */
-(NSString *) hanZiToPinYinWithString:(NSString *)hanZi
{
    if(!hanZi) return nil;
    NSString *pinYinResult=[NSString string];
    for(int j=0;j<hanZi.length;j++){
        NSString *singlePinyinLetter=[[NSString stringWithFormat:@"%c",pinyinFirstLetter([hanZi characterAtIndex:j])] uppercaseString];
        pinYinResult=[pinYinResult stringByAppendingString:singlePinyinLetter];
    }
    return pinYinResult;
}


/**
 *  根据转换拼音后的字典排序
 *
 *  @param pinyinDic 转换后的字典
 *
 *  @return 对应排序的字典
 */
-(NSMutableDictionary *) sortedArrayWithPinYinDic:(NSArray *) friends
{
    //    if(!friends) return nil;
    
    NSMutableDictionary *returnDic = [NSMutableDictionary new];
    _tempOtherArr = [NSMutableArray new];
    BOOL isReturn = NO;
    for (NSString *key in _keys) {
        if ([_tempOtherArr count]) {
            isReturn = YES;
        }
        NSMutableArray *tempArr = [NSMutableArray new];
        for (RCUserInfo *user in friends) {
            NSString *pyResult = [self hanZiToPinYinWithString:user.name];
            NSString *firstLetter = [pyResult substringToIndex:1];
            if ([firstLetter isEqualToString:key]){
                [tempArr addObject:user];
            }
            if(isReturn) continue;
            char c = [pyResult characterAtIndex:0];
            if (isalpha(c) == 0) {
                [_tempOtherArr addObject:user];
            }
        }
        if(![tempArr count]) continue;
        [returnDic setObject:tempArr forKey:key];
    }
    if([_tempOtherArr count])
        [returnDic setObject:_tempOtherArr forKey:@"#"];
        _allKeys = [[returnDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    return returnDic;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
