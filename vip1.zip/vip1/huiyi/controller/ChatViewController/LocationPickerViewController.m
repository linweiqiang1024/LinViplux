//
//  LocationPickerViewController.m
//  huiyi
//
//  Created by 王振兴 on 14-12-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "LocationPickerViewController.h"
#import "Dialog.h"
@interface LocationPickerViewController ()
@property (nonatomic, strong) BMKMapView *mapView;
@property (nonatomic, strong) BMKLocationService *locationService;
@property (nonatomic, strong) NSDate *firstTimeUserLocationUpdated;
@property (nonatomic, strong) CALayer *annotationLayer;
@property (nonatomic, strong) BMKPoiSearch *poiSearch;
@property (nonatomic, strong) BMKNearbySearchOption *nearBySearchOption;

@property (nonatomic, strong) BMKCloudSearch *cloudSearch;
@property (nonatomic, strong) BMKCloudNearbySearchInfo *cloudNearBySearchInfo;

@property (nonatomic, strong) BMKGeoCodeSearch *geoCodeSearch;
@property (nonatomic, strong) BMKReverseGeoCodeOption *geoCodeSearchOption;

@property (nonatomic, assign) BOOL userHasJumpToLocation;

@end

@implementation LocationPickerViewController
{
    NSMutableArray *_plistArray;
    UITableView *_tableView;
    NSIndexPath *_selectIndexPath;
}
- (instancetype)init {
    if (self = [super init]) {
        
    }
    return self;
}
#pragma mark 导航
- (void)customNav{
    UILabel *titleView = [[UILabel alloc]init];
    titleView.frame = CGRectMake(100, 0, 120, 44);
    titleView.backgroundColor = [UIColor clearColor];
    titleView.text = @"位置编辑";
    titleView.textAlignment = NSTextAlignmentCenter;
    titleView.font = [UIFont boldSystemFontOfSize:18];
    titleView.textColor = [UIColor whiteColor];
    self.navigationItem.titleView = titleView;
    
    UIButton *leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    leftBtn.frame = CGRectMake(0, 0, 44, 44);
    [leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
    [leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftButton = [[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    [leftButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.leftBarButtonItem = leftButton;
    
    UIButton *right = [UIButton buttonWithType:UIButtonTypeCustom];
    right.frame = CGRectMake(0, 0, 44, 44);
    [right setImageEdgeInsets:UIEdgeInsetsMake(0, 20, 0, 0)];
    [right addTarget:self action:@selector(rightBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    [right setTitle:@"完成" forState:UIControlStateNormal];
    [right setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc]initWithCustomView:right];
    [rightButton setTintColor:[UIColor whiteColor]];
    self.navigationItem.rightBarButtonItem = rightButton;

}
//返回
- (void)leftBarButtonItemPressed:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
//完成  （即发送按钮）
- (void)rightBarButtonItemPressed:(id)sender{
    if ([_plistArray count]==0) {
        [Dialog toastCenter:@"请选择位置"];
        return;
    }
    BMKPoiInfo *info = [_plistArray objectAtIndex:_selectIndexPath.row];
    [self.navigationController popViewControllerAnimated:YES];
    [self.delegate locationPicker:self didSelectLocation:[self.mapView centerCoordinate] locationName:info.name mapScreenShot:[self mapViewScreenShot]];
}
- (void)setNavigationBarState
{
    [self.navigationController setNavigationBarHidden:NO];
    [[UINavigationBar appearance] setBarTintColor:[UIColor colorWithHexString:@"#17b4EB"]];
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"navBGImage"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];


}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self setNavigationBarState];
//    self.navigationController.navigationBarHidden = NO;
   }
- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.locationService stopUserLocationService];
    self.locationService = nil;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setNavigationBarState];
    [self customNav];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(LocationSwitch:) name:@"locationSwitch" object:nil];
    _plistArray = [[NSMutableArray alloc]init];
    self.mapView = [[BMKMapView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, 280)];
    self.mapView.delegate = self;
    self.locationService = [[BMKLocationService alloc] init];
    self.locationService.delegate = self;
    [self.locationService startUserLocationService];
    [self.view addSubview:self.mapView];
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.mapView.frame), ScreenWidth, ScreenHeight-self.mapView.frame.size.height-64) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    NSString *filePath = [[NSBundle mainBundle].bundlePath stringByAppendingString:@"/RongCloud.bundle/map_annotation.png"];
    UIImage *image = [[UIImage alloc] initWithContentsOfFile:filePath];
    
    UIImageView *imageView = [[UIImageView alloc]initWithImage:image];
    imageView.frame = CGRectMake((self.mapView.frame.size.width-35)/2, (self.mapView.frame.size.height-35)/2-16, 35, 35);
    [self.view addSubview:imageView];
}



- (void)LocationSwitch:(NSNotification *)notifition{
    [self.locationService stopUserLocationService];
    self.locationService = nil;
}
- (void)setMapViewCoordinateRegion:(BMKCoordinateRegion)coordinateRegion animated:(BOOL)animated {
    BMKCoordinateRegion region;
    region.center = coordinateRegion.center;
    region.span.longitudeDelta = coordinateRegion.span.longitudeDelta;
    region.span.latitudeDelta = coordinateRegion.span.latitudeDelta;
    self.mapView.region = region;
}

- (void)userSelectPlaceMark:(id)placeMark {
    BMKPoiInfo *poiInfo = (BMKPoiInfo*)placeMark;
    self.userHasJumpToLocation = YES;
    [self.mapView setCenterCoordinate:poiInfo.pt];
}

- (void)beginFetchPoisOfCurrentLocation {
    [self fetchGeocoderPoi];
}

- (UIImage*)mapViewScreenShot {
    UIImage *mapScreenShot = [self.mapView takeSnapshot];
    UIGraphicsBeginImageContextWithOptions(self.mapView.frame.size, NO, 0.0);
    CGAffineTransform flipVertical = CGAffineTransformMake(
                                                           1, 0, 0, -1, 0, mapScreenShot.size.height
                                                           );
    CGContextConcatCTM(UIGraphicsGetCurrentContext(), flipVertical);
    CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, mapScreenShot.size.width, mapScreenShot.size.height), mapScreenShot.CGImage);
    
    NSString *filePath = [[NSBundle mainBundle].bundlePath stringByAppendingString:@"/RongCloud.bundle/map_annotation.png"];
    UIImage *imageAnnotation = [[UIImage alloc] initWithContentsOfFile:filePath];
    CGRect imageAnnotationFrame = CGRectMake(0, 0, 32, 32);
    imageAnnotationFrame.origin.y = mapScreenShot.size.height / 2;
    imageAnnotationFrame.origin.x = mapScreenShot.size.width / 2 - 16;
    CGContextDrawImage(UIGraphicsGetCurrentContext(), imageAnnotationFrame, imageAnnotation.CGImage);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    CGRect rect;
    rect.origin = CGPointZero;
    rect.size = image.size;
    rect.size.height *= image.scale;
    rect.size.width *= image.scale;
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], rect);
    image = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    return image;
}

- (void)dealloc {
    [self.locationService stopUserLocationService];
    self.locationService.delegate = nil;
}

- (void)onGetPoiResult:(BMKPoiSearch *)searcher result:(BMKPoiResult *)poiResult errorCode:(BMKSearchErrorCode)errorCode {
    //self.onComplete(poiResult.poiInfoList, NO, poiResult.pageNum < poiResult.pageIndex + 1 ? NO : YES, nil);
    //获取搜索结果
}
- (void)fetchGeocoderPoi {
    if (!self.geoCodeSearch) {
        self.geoCodeSearch = [[BMKGeoCodeSearch alloc] init];
        self.geoCodeSearchOption = [[BMKReverseGeoCodeOption alloc] init];
    }
    self.geoCodeSearch.delegate = self;
    self.geoCodeSearchOption.reverseGeoPoint = self.mapView.centerCoordinate;//取地图中心点坐标
    [self.geoCodeSearch reverseGeoCode:self.geoCodeSearchOption];//将地图中心点左边转换成地理坐标
    
}


- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error {
    //反地理编码 （获取到位置信息）
    [_plistArray removeAllObjects];
    _selectIndexPath = nil;
    [_plistArray addObjectsFromArray:result.poiList];
    
    [_tableView reloadData];
}

#pragma mark -
#pragma mark BMKLocationServiceDelegate
- (void)didUpdateUserLocation:(BMKUserLocation *)userLocation {
    if (!self.firstTimeUserLocationUpdated) {
        self.firstTimeUserLocationUpdated = [NSDate date];
    }
    if ([self.firstTimeUserLocationUpdated timeIntervalSinceNow] < -1.5) {
        [self.locationService stopUserLocationService];
        return;
    }
    
    BMKCoordinateRegion coordinateRegion;
    coordinateRegion.center = userLocation.location.coordinate;
    coordinateRegion.span.latitudeDelta = 0.01;
    coordinateRegion.span.longitudeDelta = 0.01 * self.mapView.frame.size.width / self.mapView.frame.size.height;
    [self setMapViewCoordinateRegion:coordinateRegion animated:YES];
    [self.mapView updateLocationData:userLocation];
    [self.mapView setCenterCoordinate:coordinateRegion.center animated:YES];//根据提供的经纬度为中心原点 以动画的形式移动到该区域
    [self.mapView setShowsUserLocation:YES];
}

#pragma mark -
#pragma mark BMKMapViewDelegate  当地图移动完后调用
- (void)mapView:(BMKMapView *)mapView regionDidChangeAnimated:(BOOL)animated {
    if (self.userHasJumpToLocation) {
        self.userHasJumpToLocation = NO;
        return;
    }
    NSLog(@"%f-%f",[self.mapView centerCoordinate].latitude,[self.mapView centerCoordinate].longitude);
    [self fetchGeocoderPoi];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_plistArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellName = @"cellName";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellName];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellName];
    }
    BMKPoiInfo *info = [_plistArray objectAtIndex:indexPath.row];
    NSLog(@"%d",indexPath.row);
    if (indexPath.row == _selectIndexPath.row) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    else{
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.selectionStyle = UITableViewRowAnimationNone;
    cell.textLabel.text = info.name;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    NSLog(@"%d-%d",indexPath.row,indexPath.section);
    NSLog(@"%d",cell.selected);
    _selectIndexPath = indexPath;
    NSLog(@"%d-%d",_selectIndexPath.row,_selectIndexPath.section);
    [tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
