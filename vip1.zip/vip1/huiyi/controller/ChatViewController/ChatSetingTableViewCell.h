//
//  ChatSetingTableViewCell.h
//  huiyi
//
//  Created by songhongshuai on 15/12/3.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SevenSwitch;
@protocol SevenSwitchChangeValueDelegate <NSObject>

- (void)changeValueWithState:(BOOL)state IndexPath:(NSIndexPath *)indexPath;

@end

@interface ChatSetingTableViewCell : UITableViewCell
@property (nonatomic ,strong) UIImageView *rightIconImageView;
@property (nonatomic ,strong) UILabel     * nameLabel;
@property (nonatomic ,strong) SevenSwitch * switchBtn;
@property (nonatomic ,assign) BOOL        endCell;
@property (nonatomic ,strong) NSIndexPath *indexPath;
@property (nonatomic,strong ) UILabel     *titleLabel;
@property (nonatomic ,weak) id <SevenSwitchChangeValueDelegate>delegate;
@end
