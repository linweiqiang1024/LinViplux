//
//  ReDiscussionNameViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/17.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ReDiscussionNameViewController.h"
#import <RongIMLib/RCIMClient.h>


@interface ReDiscussionNameViewController ()<UITextFieldDelegate>
@property (nonatomic,strong) UILabel         *titleView;
@property (nonatomic,strong) UIBarButtonItem *leftButton;
@property (nonatomic,strong) UIButton        *leftBtn;
@property (nonatomic,strong) UIBarButtonItem *rightButton;
@property (nonatomic,strong) UIButton        *rightBtn;

@property (nonatomic,strong)UILabel *discriptionLb;
@property (nonatomic,strong)UITextField *changeTitleTF;
@property (nonatomic,strong)UIView *backGroundView;
@end

@implementation ReDiscussionNameViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.changeTitleTF becomeFirstResponder];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    self.navigationItem.titleView = self.titleView;
    self.navigationItem.leftBarButtonItem = self.leftButton;
    self.navigationItem.rightBarButtonItem = self.rightButton;

    [self.view addSubview:self.discriptionLb];
    [self.view addSubview:self.backGroundView];
    [self.backGroundView addSubview:self.changeTitleTF];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)changeText:(UITextField *)textField
{
    if (textField.text.length == 0) {
        [self.rightBtn setEnabled:NO];
        [_rightBtn setTitleColor:[UIColor colorWithHexString:@"#bbe3f7"] forState:UIControlStateNormal];
    }else{
        [self.rightBtn setEnabled:YES];
        [_rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
}
- (UIView *)backGroundView
{
    if (!_backGroundView) {
        _backGroundView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.discriptionLb.frame) , ScreenWidth, 45)];
        _backGroundView.backgroundColor = [UIColor whiteColor];
    }
    return _backGroundView;
}
- (UILabel *)discriptionLb
{
    if (!_discriptionLb) {
        _discriptionLb = [[UILabel alloc]initWithFrame:CGRectMake(17, 12 , ScreenWidth-34, 27)];
        _discriptionLb.backgroundColor = [UIColor clearColor];
        _discriptionLb.font = YHUI(14);
        _discriptionLb.textColor = [UIColor colorWithHexString:@"#888888"];
        _discriptionLb.text = @"讨论组名称";
    }
    return _discriptionLb;
}
- (UITextField *)changeTitleTF
{
    if (!_changeTitleTF) {
        _changeTitleTF = [[UITextField alloc]initWithFrame:CGRectMake(17 ,0 , ScreenWidth-24, 45)];
        _changeTitleTF.backgroundColor = [UIColor clearColor];
        _changeTitleTF.placeholder = @"请输入讨论组名称";
        _changeTitleTF.delegate = self;
        _changeTitleTF.text = self.discussionName;
        _changeTitleTF.returnKeyType = UIReturnKeyDone;
        _changeTitleTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        [_changeTitleTF addTarget:self action:@selector(changeText:) forControlEvents:UIControlEventEditingChanged];
        _changeTitleTF.font = YHUI(16);
    }
    return _changeTitleTF;
}
- (UILabel *)titleView
{
    if (!_titleView) {
        _titleView = [[UILabel alloc]init];
        _titleView.frame = CGRectMake(100, 0, 120, 44);
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.text = @"讨论组名称";
        _titleView.textAlignment = NSTextAlignmentCenter;
        _titleView.font = [UIFont boldSystemFontOfSize:18];
        _titleView.textColor = [UIColor whiteColor];
    }
    
    return _titleView;
}
- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}
- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame = CGRectMake(0, 0, 44, 44);
        [_rightBtn setTitle:@"确定" forState:UIControlStateNormal];
        _rightBtn.titleLabel.font = YHUI(16);
        [_rightBtn addTarget:self action:@selector(rightBarButtonItemPressed) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightBtn;
}
- (void)leftBarButtonItemPressed
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)rightBarButtonItemPressed
{
    [[RCIMClient sharedRCIMClient]setDiscussionName:self.targetId name:self.changeTitleTF.text success:^{
         self.changeTitleCompletion(self.changeTitleTF.text);
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:YES];

        });
    } error:^(RCErrorCode status) {
        [Dialog toastCenter:@"设置失败"];
    }];
}
- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}

- (UIBarButtonItem *)rightButton
{
    if (!_rightButton) {
        _rightButton = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
        [_rightButton setTintColor:[UIColor whiteColor]];
    }
    return _rightButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
