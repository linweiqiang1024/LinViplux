//
//  RCDRCIMDelegateImplementation.m
//  RongCloud
//
//  Created by Liv on 14/11/11.
//  Copyright (c) 2014年 RongCloud. All rights reserved.
//

#import <RongIMLib/RongIMLib.h>
#import "RCFriendsBookViewController/RCChatUserInfo.h"
#import "RCDRCIMDataSource.h"
#import "FMDBManagers.h"
#import "RCDataBaseManager.h"
#import "RCChatInfoManager.h"
@interface RCDRCIMDataSource ()

@end

@implementation RCDRCIMDataSource

+ (RCDRCIMDataSource*)shareInstance
{
    static RCDRCIMDataSource* instance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
    
        instance = [[[self class] alloc] init];

    });
    return instance;
}


-(void) syncGroups
{
    [MyDataService postGroupList:@{@"page":@"1",@"count":@"10000"} callback:^(id data) {
        
        NSMutableArray *_appData = [[NSMutableArray alloc]init];
        if ([[data objectForKey: @"code"] isEqualToString: @"200"]) {
            if ([[data objectForKey:@"content"] isKindOfClass:[NSArray class]]) {
                [[RCDataBaseManager shareInstance]clearGroupsData];
                for (NSDictionary *dict in [data objectForKey:@"content"]) {
                    RCGroup *groupItem = [[RCGroup alloc] init];
                    groupItem.groupId = [dict objectForKey:@"group_id"];
                    groupItem.groupName = [dict objectForKey:@"name"];
                    groupItem.portraitUri = [dict objectForKey:@"ico_url"];
                    [_appData addObject:groupItem];
                    [[RCDataBaseManager shareInstance]insertGroupToDB:groupItem];
                }
            }
            [[NSNotificationCenter defaultCenter]postNotificationName:@"setupUnreadMessageCount" object:nil];
        }
        else if ([[data objectForKey: @"code"] isEqualToString: @"201"]) {
            [[RCDataBaseManager shareInstance]clearGroupsData];
        }
    }];
    //开发者调用自己的服务器接口获取所属群组信息，同步给融云服务器，也可以直接
    //客户端创建，然后同步
}
//获取我的好友列表
-(void)syncFriendList:(void (^)(id friends))completion
{
    [MyDataService postPeopleConnectionList:nil callback:^(id data) {
        NSString *code = [data objectForKey: @"code"];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([code isEqualToString: @"200"]) {
                [[RCDataBaseManager shareInstance] clearFriendsData];
                [[RCDataBaseManager shareInstance] CreateUserTable];
                NSLog(@"data=========%@",data);
                NSArray *contentArr = [data objectForKey:@"content"];
                NSMutableArray * userArr = [[NSMutableArray alloc]init];
                for (NSDictionary *indexDic in contentArr) {
                    for (NSDictionary *userDic in [indexDic objectForKey:@"list"] ) {
                        RCChatUserInfo *info = [[RCChatUserInfo alloc]init];
                        info.userId = userDic[@"ryuserid"];
                        info.name = userDic[@"name"];
                        info.portraitUri = userDic[@"ico_url"];
                        info.selected = NO;
                        [userArr addObject:info];
                        
                        RCUserInfo *userinfo = [[RCUserInfo alloc]initWithUserId:info.userId name:info.name portrait:info.portraitUri];
                        [[RCDataBaseManager shareInstance]insertFriendToDB:userinfo];
                    }
                }
                completion(userArr);
            }
        }
    }];
}

#pragma mark - GroupInfoFetcherDelegate

- (void)getGroupInfoWithGroupId:(NSString*)groupId completion:(void (^)(RCGroup*))completion
{
    if ([groupId length] == 0)
        return;
    [[RCChatInfoManager shareInstance]getGroupByID:groupId successCompletion:^(RCGroup *group) {
        completion(group);
    }];
}
//
#pragma mark - RCIMUserInfoDataSource
- (void)getUserInfoWithUserId:(NSString*)userId completion:(void (^)(RCUserInfo*))completion
{
    NSLog(@"getUserInfoWithUserId ----- %@", userId);
    NSString *locationUerId ;
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"login_company_code"] length]==0) {
        locationUerId = userId;
    }else{
        NSArray *array = [userId componentsSeparatedByString:@":"];
        locationUerId = array[0];
    }
   if (locationUerId == nil || [locationUerId length] == 0 )    {
       RCUserInfo *user = [RCUserInfo new];
       user.userId = userId;
        user.portraitUri = @"";
        user.name = @"";
        completion(user);
        return ;
    }
    RCUserInfo *userInfo = [[RCDataBaseManager shareInstance]getUserByUserId:userId];
    if (userInfo) {
        completion(userInfo);
    }else{
        [MyDataService postPlatformContactUserinfonew:@{@"user_id":locationUerId} calllback:^(id data) {
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                    RCUserInfo *user = [RCUserInfo new];
                    user.userId = data[@"content"][@"info"][@"ryuser_id"];
                    user.portraitUri = [[data objectForKey:@"content"] objectForKey:@"ico_url"];
                    user.name = data[@"content"][@"name"];
                    [[RCDataBaseManager shareInstance] insertUserToDB:user];
                    completion(user);
                }
            }
        }];
    }
}
//
#pragma mark - RCIMGroupUserInfoDataSource
/**
 *  获取群组内的用户信息。
 *  如果群组内没有设置用户信息，请注意：1，不要调用别的接口返回全局用户信息，直接回调给我们nil就行，SDK会自己巧用用户信息提供者；2一定要调用completion(nil)，这样SDK才能继续往下操作。
 *
 *  @param groupId  群组ID.
 *  @param completion 获取完成调用的BLOCK.
 */
- (void)getUserInfoWithUserId:(NSString *)userId inGroup:(NSString *)groupId
                   completion:(void (^)(RCUserInfo *userInfo))completion {
    //在这里查询该group内的群名片信息，如果能查到，调用completion返回。如果查询不到也一定要调用completion(nil)
    if ([groupId isEqualToString:@"22"] && [userId isEqualToString:@"30806"]) {
        completion([[RCUserInfo alloc] initWithUserId:@"30806" name:@"我在22群中的名片" portrait:nil]);
    } else {
        completion(nil);//融云demo中暂时没有实现，以后会添加上该功能。app也可以自己实现该功能。
    }
}
//
//- (void)cacheAllUserInfo:(void (^)())completion
//{
//    __block NSArray * regDataArray;
//    
//    [AFHttpTool getFriendsSuccess:^(id response) {
//        if (response) {
//            NSString *code = [NSString stringWithFormat:@"%@",response[@"code"]];
//            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
//                if ([code isEqualToString:@"200"]) {
//                    regDataArray = response[@"result"];
//                    for(int i = 0;i < regDataArray.count;i++){
//                        NSDictionary *dic = [regDataArray objectAtIndex:i];
//                        
//                        RCUserInfo *userInfo = [RCUserInfo new];
//                        NSNumber *idNum = [dic objectForKey:@"id"];
//                        userInfo.userId = [NSString stringWithFormat:@"%d",idNum.intValue];
//                        userInfo.portraitUri = [dic objectForKey:@"portrait"];
//                        userInfo.name = [dic objectForKey:@"username"];
//                        [[RCDataBaseManager shareInstance] insertUserToDB:userInfo];
//                    }
//                    completion();
//                }
//            });
//        }
//        
//    } failure:^(NSError *err) {
//        NSLog(@"getUserInfoByUserID error");
//    }];
//}
- (void)cacheAllGroup:(void (^)())completion
{
    
    [MyDataService postGroupList:@{@"page":@"1",@"count":@"10000"} callback:^(id data) {
        NSLog( @"data%@",data);
        if ([[data objectForKey: @"code"] isEqualToString: @"200"]) {
            if ([[data objectForKey:@"content"]isKindOfClass:[NSArray class]]) {
                for (NSDictionary *dict in [data objectForKey:@"content"]) {
                    NSLog(@"dic %@",dict);
                    RCGroup *groupItem = [[RCGroup alloc] init];
                    //[groupItem setValuesForKeysWithDictionary:dict];
                    groupItem.groupId = [dict objectForKey:@"group_id"];
                    groupItem.groupName = [dict objectForKey:@"name"];
                    groupItem.portraitUri = [dict objectForKey:@"ico_url"];
                    [[RCDataBaseManager shareInstance]insertGroupToDB:groupItem];
                }
                
                for(RCConversation *conversion in [[RCIMClient sharedRCIMClient]getConversationList:@[@(ConversationType_GROUP)]]){
                    if ([conversion.objectName isEqualToString:@"RC:ContactNtf"]||[conversion.objectName isEqualToString:@"RC:ProfileNtf"]||[conversion.objectName isEqualToString:@""]) {
                        [[RCIMClient sharedRCIMClient]removeConversation:conversion.conversationType targetId:conversion.targetId];//如果没有名字，清除改行列表
                        [[RCIMClient sharedRCIMClient]clearMessagesUnreadStatus:conversion.conversationType targetId:conversion.targetId];//如果没有名字清除改行的消息未读数量
                        [[RCIMClient sharedRCIMClient]clearMessages:conversion.conversationType targetId:conversion.targetId];//如果改行没有名字清除改行的聊天历史记录
                    }
                }
            }
        }
    }];
}
//
- (void)cacheAllFriends:(void (^)())completion
{
    
    [MyDataService postPeopleConnectionList:nil callback:^(id data) {
        NSString *code = [data objectForKey: @"code"];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([code isEqualToString: @"200"]) {
                [[RCDataBaseManager shareInstance]clearFriendsData];
                for(NSDictionary *sectionDic in [data objectForKey:@"content"]){
                    for(NSDictionary *dic in [sectionDic objectForKey:@"list"]){
                        RCUserInfo *info = [RCUserInfo new];
                        if (![[dic objectForKey:@"info"]isKindOfClass:[NSString class]]) {
                            info.portraitUri = dic[@"ico_url"];
                            info.name = dic[@"name"];
                            info.userId = dic[@"user_id"];
                            [[RCDataBaseManager shareInstance]insertFriendToDB:info];
                        }
                    }
                }
            }
            else if([code isEqualToString: @"201"]){
                [[RCDataBaseManager shareInstance]clearFriendsData];
            }
        }
    }];
}
//- (void)cacheAllData:(void (^)())completion
//{
//    __weak RCDRCIMDataSource *weakSelf = self;
//    [self cacheAllUserInfo:^{
//        [weakSelf cacheAllGroup:^{
//            [weakSelf cacheAllFriends:^{
//                [DEFAULTS setBool:YES forKey:@"notFirstTimeLogin"];
//                [DEFAULTS synchronize];
//                completion();
//            }];
//        }];
//    }];
//}
//
//- (NSArray *)getAllUserInfo:(void (^)())completion
//{
//    NSArray *allUserInfo = [[RCDataBaseManager shareInstance] getAllUserInfo];
//    if (!allUserInfo.count) {
//       [self cacheAllUserInfo:^{
//           completion();
//       }];
//    }
//    return allUserInfo;
//}
///*
// * 获取所有群组信息
// */
- (NSArray *)getAllGroupInfo:(void (^)())completion
{
    NSArray *allUserInfo = [[RCDataBaseManager shareInstance] getAllGroup];
    if (!allUserInfo.count) {
        [self cacheAllGroup:^{
            completion();
        }];
    }
    return allUserInfo;
}

- (NSArray *)getAllFriends:(void (^)())completion
{
    NSArray *allUserInfo = [[RCDataBaseManager shareInstance] getAllFriends];
    if (!allUserInfo.count) {
        [self cacheAllFriends:^{
            completion();
        }];
    }
    return allUserInfo;
}
@end
