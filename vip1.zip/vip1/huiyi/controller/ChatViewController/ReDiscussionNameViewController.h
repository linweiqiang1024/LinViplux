//
//  ReDiscussionNameViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/12/17.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^changeTitle)(NSString *title);
@interface ReDiscussionNameViewController : UIViewController
@property (nonatomic, copy) changeTitle       changeTitleCompletion;
@property (nonatomic, strong) NSString * targetId;
@property (nonatomic, strong) NSString * discussionName;
@end
