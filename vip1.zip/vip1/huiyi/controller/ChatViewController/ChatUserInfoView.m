//
//  ChatUserInfoView.m
//  huiyi
//
//  Created by songhongshuai on 15/12/3.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatUserInfoView.h"
#import "UIImageView+WebCache.h"
#import <RongIMLib/RCIMClient.h>
@interface ChatUserInfoView ()
@property (strong, nonatomic) UIImageView         *userImageView;
@property (strong, nonatomic) UILabel             *userNameLb;
@property (strong, nonatomic) UIButton            *delUserBtn;
@property (strong, nonatomic) UIGestureRecognizer *gestureRecognizer;

@end
@implementation ChatUserInfoView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        
        self.userInteractionEnabled = YES;
        [self addGestureRecognizer:self.gestureRecognizer];
        [self addSubview:self.userImageView];
        [self addSubview:self.userNameLb];
        [self addSubview:self.delUserBtn];
    }
    return self;
}
- (void)choiceUser
{
    if (_delegate&&[_delegate respondsToSelector:@selector(choiceUersInfo: IndexPath:)]) {
        self.delUserBtn.hidden = YES;//点击任何按钮都会隐藏删除按钮
        [_delegate choiceUersInfo:_userInfo IndexPath:self.tag];
    }
}
- (void)delUserBtnClicked
{
    if (_delegate&&[_delegate respondsToSelector:@selector(delUsersIndex:)]) {
        [_delegate delUsersIndex:self.tag];
    }
}
- (void)setIsShowDelButton:(BOOL)isShowDelButton
{
    if (![_userInfo.userId isEqualToString:[RCIMClient sharedRCIMClient].currentUserInfo.userId]) {
        if (isShowDelButton) {
            self.delUserBtn.hidden = NO;
        }else{
            self.delUserBtn.hidden = YES;
        }
    }else{
        self.delUserBtn.hidden = YES;
    }
    
}

- (void)setUserInfo:(RCUserInfo *)userInfo
{
    if (userInfo) {
        _userInfo = userInfo;
        self.userNameLb.text = userInfo.name;
        [self.userImageView sd_setImageWithURL:[NSURL URLWithString:userInfo.portraitUri] placeholderImage:[UIImage imageNamed:@"touxiang124"]];
    }
}
- (void)setIsAllowedDeleteMember:(BOOL)isAllowedDeleteMember
{
    if (isAllowedDeleteMember) {
        self.userImageView.image = [UIImage imageNamed:@"del_user"];
    }
}
- (void)setIsAllowedInviteMember:(BOOL)isAllowedInviteMember
{
    if (isAllowedInviteMember) {
        self.userImageView.image = [UIImage imageNamed:@"add_user"];
    }
}
- (UIGestureRecognizer *)gestureRecognizer
{
    if (!_gestureRecognizer) {
        _gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(choiceUser)];
    }
    return _gestureRecognizer;
}
- (UIImageView *)userImageView
{
    if (!_userImageView) {
        _userImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 5, 58, 58)];
        _userImageView.layer.cornerRadius = 4.0;
        _userImageView.backgroundColor = [UIColor clearColor];
        _userImageView.clipsToBounds = YES;
    }
    return _userImageView;
}

- (UILabel *)userNameLb
{
    if (!_userNameLb) {
        _userNameLb = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.userImageView.frame), 58, 20)];
        _userNameLb.backgroundColor = [UIColor clearColor];
        _userNameLb.textAlignment = NSTextAlignmentCenter;
        _userNameLb.font = YHUI(12);
        
    }
    return _userNameLb;
}

- (UIButton *)delUserBtn
{
    if (!_delUserBtn) {
        _delUserBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _delUserBtn.frame = CGRectMake(0, 0, 30, 30);
        [_delUserBtn setImage:[self imagesNamedFromCustomBundle:@"delete_member_tip@2x"] forState:UIControlStateNormal];
        [_delUserBtn setImageEdgeInsets:UIEdgeInsetsMake(-5, 5, 5, -5)];
        _delUserBtn.center = CGPointMake(self.frame.size.width-15, 15);
        _delUserBtn.hidden = YES;
        _delUserBtn.backgroundColor = [UIColor clearColor];
        [_delUserBtn addTarget:self action:@selector(delUserBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _delUserBtn;
}

- (UIImage *)imagesNamedFromCustomBundle:(NSString *)imgName
{
    NSString *bundlePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"RongCloud.bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *img_path = [bundle pathForResource:imgName ofType:@"png"];
    return [UIImage imageWithContentsOfFile:img_path];
}
@end
