//
//  IMUsrMeetingListModel.m
//
//  Created by songhongshuai  on 15/12/1
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import "IMUsrMeetingListModel.h"


NSString *const kIMUsrMeetingListModelMeetingId = @"meeting_id";
NSString *const kIMUsrMeetingListModelStatus = @"status";
NSString *const kIMUsrMeetingListModelBmnum = @"bmnum";
NSString *const kIMUsrMeetingListModelWebbaoming = @"webbaoming";
NSString *const kIMUsrMeetingListModelYqxUrl = @"yqx_url";
NSString *const kIMUsrMeetingListModelUserId = @"user_id";
NSString *const kIMUsrMeetingListModelImgUrl = @"img_url";
NSString *const kIMUsrMeetingListModelCnt = @"cnt";
NSString *const kIMUsrMeetingListModelPicList = @"pic_list";
NSString *const kIMUsrMeetingListModelEndDate = @"end_date";
NSString *const kIMUsrMeetingListModelIsYqx = @"is_yqx";
NSString *const kIMUsrMeetingListModelCity = @"city";
NSString *const kIMUsrMeetingListModelName = @"name";
NSString *const kIMUsrMeetingListModelOpenstatus = @"openstatus";
NSString *const kIMUsrMeetingListModelType = @"type";
NSString *const kIMUsrMeetingListModelCreateUserId = @"create_user_id";
NSString *const kIMUsrMeetingListModelWebedit = @"webedit";
NSString *const kIMUsrMeetingListModelPostersUrl = @"posters_url";
NSString *const kIMUsrMeetingListModelApproved = @"approved";
NSString *const kIMUsrMeetingListModelReceipted = @"receipted";
NSString *const kIMUsrMeetingListModelBeginDate = @"begin_date";


@interface IMUsrMeetingListModel ()

- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict;

@end

@implementation IMUsrMeetingListModel

@synthesize meetingId = _meetingId;
@synthesize status = _status;
@synthesize bmnum = _bmnum;
@synthesize webbaoming = _webbaoming;
@synthesize yqxUrl = _yqxUrl;
@synthesize userId = _userId;
@synthesize imgUrl = _imgUrl;
@synthesize cnt = _cnt;
@synthesize picList = _picList;
@synthesize endDate = _endDate;
@synthesize isYqx = _isYqx;
@synthesize city = _city;
@synthesize name = _name;
@synthesize openstatus = _openstatus;
@synthesize type = _type;
@synthesize createUserId = _createUserId;
@synthesize webedit = _webedit;
@synthesize postersUrl = _postersUrl;
@synthesize approved = _approved;
@synthesize receipted = _receipted;
@synthesize beginDate = _beginDate;


+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    self = [super init];
    
    // This check serves to make sure that a non-NSDictionary object
    // passed into the model class doesn't break the parsing.
    if(self && [dict isKindOfClass:[NSDictionary class]]) {
            self.meetingId = [self objectOrNilForKey:kIMUsrMeetingListModelMeetingId fromDictionary:dict];
            self.status = [self objectOrNilForKey:kIMUsrMeetingListModelStatus fromDictionary:dict];
            self.bmnum = [self objectOrNilForKey:kIMUsrMeetingListModelBmnum fromDictionary:dict];
            self.webbaoming = [self objectOrNilForKey:kIMUsrMeetingListModelWebbaoming fromDictionary:dict];
            self.yqxUrl = [self objectOrNilForKey:kIMUsrMeetingListModelYqxUrl fromDictionary:dict];
            self.userId = [self objectOrNilForKey:kIMUsrMeetingListModelUserId fromDictionary:dict];
            self.imgUrl = [self objectOrNilForKey:kIMUsrMeetingListModelImgUrl fromDictionary:dict];
            self.cnt = [self objectOrNilForKey:kIMUsrMeetingListModelCnt fromDictionary:dict];
            self.picList = [self objectOrNilForKey:kIMUsrMeetingListModelPicList fromDictionary:dict];
            self.endDate = [self objectOrNilForKey:kIMUsrMeetingListModelEndDate fromDictionary:dict];
            self.isYqx = [self objectOrNilForKey:kIMUsrMeetingListModelIsYqx fromDictionary:dict];
            self.city = [self objectOrNilForKey:kIMUsrMeetingListModelCity fromDictionary:dict];
            self.name = [self objectOrNilForKey:kIMUsrMeetingListModelName fromDictionary:dict];
            self.openstatus = [self objectOrNilForKey:kIMUsrMeetingListModelOpenstatus fromDictionary:dict];
            self.type = [self objectOrNilForKey:kIMUsrMeetingListModelType fromDictionary:dict];
            self.createUserId = [self objectOrNilForKey:kIMUsrMeetingListModelCreateUserId fromDictionary:dict];
            self.webedit = [self objectOrNilForKey:kIMUsrMeetingListModelWebedit fromDictionary:dict];
            self.postersUrl = [self objectOrNilForKey:kIMUsrMeetingListModelPostersUrl fromDictionary:dict];
            self.approved = [self objectOrNilForKey:kIMUsrMeetingListModelApproved fromDictionary:dict];
            self.receipted = [self objectOrNilForKey:kIMUsrMeetingListModelReceipted fromDictionary:dict];
            self.beginDate = [self objectOrNilForKey:kIMUsrMeetingListModelBeginDate fromDictionary:dict];

    }
    
    return self;
    
}

- (NSDictionary *)dictionaryRepresentation
{
    NSMutableDictionary *mutableDict = [NSMutableDictionary dictionary];
    [mutableDict setValue:self.meetingId forKey:kIMUsrMeetingListModelMeetingId];
    [mutableDict setValue:self.status forKey:kIMUsrMeetingListModelStatus];
    [mutableDict setValue:self.bmnum forKey:kIMUsrMeetingListModelBmnum];
    [mutableDict setValue:self.webbaoming forKey:kIMUsrMeetingListModelWebbaoming];
    [mutableDict setValue:self.yqxUrl forKey:kIMUsrMeetingListModelYqxUrl];
    [mutableDict setValue:self.userId forKey:kIMUsrMeetingListModelUserId];
    [mutableDict setValue:self.imgUrl forKey:kIMUsrMeetingListModelImgUrl];
    [mutableDict setValue:self.cnt forKey:kIMUsrMeetingListModelCnt];
    NSMutableArray *tempArrayForPicList = [NSMutableArray array];
    for (NSObject *subArrayObject in self.picList) {
        if([subArrayObject respondsToSelector:@selector(dictionaryRepresentation)]) {
            // This class is a model object
            [tempArrayForPicList addObject:[subArrayObject performSelector:@selector(dictionaryRepresentation)]];
        } else {
            // Generic object
            [tempArrayForPicList addObject:subArrayObject];
        }
    }
    [mutableDict setValue:[NSArray arrayWithArray:tempArrayForPicList] forKey:kIMUsrMeetingListModelPicList];
    [mutableDict setValue:self.endDate forKey:kIMUsrMeetingListModelEndDate];
    [mutableDict setValue:self.isYqx forKey:kIMUsrMeetingListModelIsYqx];
    [mutableDict setValue:self.city forKey:kIMUsrMeetingListModelCity];
    [mutableDict setValue:self.name forKey:kIMUsrMeetingListModelName];
    [mutableDict setValue:self.openstatus forKey:kIMUsrMeetingListModelOpenstatus];
    [mutableDict setValue:self.type forKey:kIMUsrMeetingListModelType];
    [mutableDict setValue:self.createUserId forKey:kIMUsrMeetingListModelCreateUserId];
    [mutableDict setValue:self.webedit forKey:kIMUsrMeetingListModelWebedit];
    [mutableDict setValue:self.postersUrl forKey:kIMUsrMeetingListModelPostersUrl];
    [mutableDict setValue:self.approved forKey:kIMUsrMeetingListModelApproved];
    [mutableDict setValue:self.receipted forKey:kIMUsrMeetingListModelReceipted];
    [mutableDict setValue:self.beginDate forKey:kIMUsrMeetingListModelBeginDate];

    return [NSDictionary dictionaryWithDictionary:mutableDict];
}

- (NSString *)description 
{
    return [NSString stringWithFormat:@"%@", [self dictionaryRepresentation]];
}

#pragma mark - Helper Method
- (id)objectOrNilForKey:(id)aKey fromDictionary:(NSDictionary *)dict
{
    id object = [dict objectForKey:aKey];
    return [object isEqual:[NSNull null]] ? nil : object;
}


#pragma mark - NSCoding Methods

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];

    self.meetingId = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelMeetingId];
    self.status = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelStatus];
    self.bmnum = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelBmnum];
    self.webbaoming = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelWebbaoming];
    self.yqxUrl = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelYqxUrl];
    self.userId = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelUserId];
    self.imgUrl = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelImgUrl];
    self.cnt = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelCnt];
    self.picList = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelPicList];
    self.endDate = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelEndDate];
    self.isYqx = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelIsYqx];
    self.city = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelCity];
    self.name = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelName];
    self.openstatus = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelOpenstatus];
    self.type = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelType];
    self.createUserId = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelCreateUserId];
    self.webedit = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelWebedit];
    self.postersUrl = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelPostersUrl];
    self.approved = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelApproved];
    self.receipted = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelReceipted];
    self.beginDate = [aDecoder decodeObjectForKey:kIMUsrMeetingListModelBeginDate];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{

    [aCoder encodeObject:_meetingId forKey:kIMUsrMeetingListModelMeetingId];
    [aCoder encodeObject:_status forKey:kIMUsrMeetingListModelStatus];
    [aCoder encodeObject:_bmnum forKey:kIMUsrMeetingListModelBmnum];
    [aCoder encodeObject:_webbaoming forKey:kIMUsrMeetingListModelWebbaoming];
    [aCoder encodeObject:_yqxUrl forKey:kIMUsrMeetingListModelYqxUrl];
    [aCoder encodeObject:_userId forKey:kIMUsrMeetingListModelUserId];
    [aCoder encodeObject:_imgUrl forKey:kIMUsrMeetingListModelImgUrl];
    [aCoder encodeObject:_cnt forKey:kIMUsrMeetingListModelCnt];
    [aCoder encodeObject:_picList forKey:kIMUsrMeetingListModelPicList];
    [aCoder encodeObject:_endDate forKey:kIMUsrMeetingListModelEndDate];
    [aCoder encodeObject:_isYqx forKey:kIMUsrMeetingListModelIsYqx];
    [aCoder encodeObject:_city forKey:kIMUsrMeetingListModelCity];
    [aCoder encodeObject:_name forKey:kIMUsrMeetingListModelName];
    [aCoder encodeObject:_openstatus forKey:kIMUsrMeetingListModelOpenstatus];
    [aCoder encodeObject:_type forKey:kIMUsrMeetingListModelType];
    [aCoder encodeObject:_createUserId forKey:kIMUsrMeetingListModelCreateUserId];
    [aCoder encodeObject:_webedit forKey:kIMUsrMeetingListModelWebedit];
    [aCoder encodeObject:_postersUrl forKey:kIMUsrMeetingListModelPostersUrl];
    [aCoder encodeObject:_approved forKey:kIMUsrMeetingListModelApproved];
    [aCoder encodeObject:_receipted forKey:kIMUsrMeetingListModelReceipted];
    [aCoder encodeObject:_beginDate forKey:kIMUsrMeetingListModelBeginDate];
}

- (id)copyWithZone:(NSZone *)zone
{
    IMUsrMeetingListModel *copy = [[IMUsrMeetingListModel alloc] init];
    
    if (copy) {

        copy.meetingId = [self.meetingId copyWithZone:zone];
        copy.status = [self.status copyWithZone:zone];
        copy.bmnum = [self.bmnum copyWithZone:zone];
        copy.webbaoming = [self.webbaoming copyWithZone:zone];
        copy.yqxUrl = [self.yqxUrl copyWithZone:zone];
        copy.userId = [self.userId copyWithZone:zone];
        copy.imgUrl = [self.imgUrl copyWithZone:zone];
        copy.cnt = [self.cnt copyWithZone:zone];
        copy.picList = [self.picList copyWithZone:zone];
        copy.endDate = [self.endDate copyWithZone:zone];
        copy.isYqx = [self.isYqx copyWithZone:zone];
        copy.city = [self.city copyWithZone:zone];
        copy.name = [self.name copyWithZone:zone];
        copy.openstatus = [self.openstatus copyWithZone:zone];
        copy.type = [self.type copyWithZone:zone];
        copy.createUserId = [self.createUserId copyWithZone:zone];
        copy.webedit = [self.webedit copyWithZone:zone];
        copy.postersUrl = [self.postersUrl copyWithZone:zone];
        copy.approved = [self.approved copyWithZone:zone];
        copy.receipted = [self.receipted copyWithZone:zone];
        copy.beginDate = [self.beginDate copyWithZone:zone];
    }
    
    return copy;
}


@end
