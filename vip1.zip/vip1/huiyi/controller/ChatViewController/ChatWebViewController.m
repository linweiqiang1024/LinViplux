//
//  ChatWebViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/14.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatWebViewController.h"
#import "NJKWebViewProgressView.h"
#import "NJKWebViewProgress.h"
@interface ChatWebViewController ()<UIWebViewDelegate,UIActionSheetDelegate,NJKWebViewProgressDelegate>

@property (nonatomic ,strong)NJKWebViewProgressView *progressView;
@property (nonatomic ,strong)NJKWebViewProgress *progressProxy;
@property (nonatomic ,strong)UIWebView *webView;
@property (nonatomic ,strong)UIButton *leftBtn;
@property (nonatomic ,strong)UIButton *rightBtn;
@property (nonatomic ,strong)UIBarButtonItem *leftButton;
@property (nonatomic ,strong)UIBarButtonItem *rightButton;
@end

@implementation ChatWebViewController

- (NJKWebViewProgress *)progressProxy
{
    if (!_progressProxy) {
        _progressProxy = [[NJKWebViewProgress alloc]init];
        _progressProxy.progressDelegate = self;
        _progressProxy.webViewProxyDelegate = self;
    }
    return _progressProxy;
}

- (NJKWebViewProgressView *)progressView
{
    if (!_progressView) {
        CGFloat progressBarHeight = 2.f;
        CGRect navigationBarBounds = self.navigationController.navigationBar.bounds;
        CGRect barFrame = CGRectMake(0, navigationBarBounds.size.height - progressBarHeight, navigationBarBounds.size.width, progressBarHeight);
        _progressView = [[NJKWebViewProgressView alloc]initWithFrame:barFrame];
    }
    return _progressView;
}
- (UIWebView *)webView
{
    if (!_webView) {
        _webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-64)];
        _webView.backgroundColor = [UIColor whiteColor];
        _webView.delegate = self.progressProxy;
    }
    return _webView;
}

- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame = CGRectMake(0, 0, 44, 44);
        [_rightBtn setTitle:@"..." forState:UIControlStateNormal];
        [_rightBtn addTarget:self action:@selector(rightBarButtonItemPressed) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _rightBtn;
}

- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}
- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}
- (UIBarButtonItem *)rightButton
{
    if (!_rightButton) {
        _rightButton = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
        [_rightButton setTintColor:[UIColor whiteColor]];
    }
    return _rightButton;
}
- (void)leftBarButtonItemPressed
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)rightBarButtonItemPressed
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"在Safari打开" otherButtonTitles:@"拷贝URL", nil];
    [actionSheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.url]];
            break;
        case 1:
        {
            UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
            pasteboard.string = self.url;
            [Dialog toastCenter:@"拷贝成功！"];
        }
            break;
        default:
            break;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar addSubview:self.progressView];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont systemFontOfSize:16]};
    self.navigationItem.leftBarButtonItem = self.leftButton;
    self.navigationItem.rightBarButtonItem = self.rightButton;
    [self.view addSubview:self.webView];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.url]]];
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    self.progressView.hidden = NO;
}
-(void)webViewProgress:(NJKWebViewProgress *)webViewProgress updateProgress:(float)progress
{
    [self.progressView setProgress:progress animated:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    self.progressView.hidden = YES;
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    self.progressView.hidden = YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
