//
//  ChatSetingTableViewCell.m
//  huiyi
//
//  Created by songhongshuai on 15/12/3.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatSetingTableViewCell.h"
#import "SevenSwitch.h"
@interface ChatSetingTableViewCell ()

@end

@implementation ChatSetingTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:self.nameLabel];
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.switchBtn];
        [self.contentView addSubview:self.rightIconImageView];
    }
    return self;
}
- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(110, 0, CGRectGetMinX(self.rightIconImageView.frame)-115, 43.5)];
        _titleLabel.hidden = YES;
        _titleLabel.textAlignment = NSTextAlignmentRight;
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.font = [UIFont systemFontOfSize:16];
        _titleLabel.textColor = [UIColor colorWithHexString:@"#888888"];

    }
    return _titleLabel;
}

- (UILabel *)nameLabel
{
    if (!_nameLabel) {
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(17, 0, ScreenWidth-67-34, 43.5)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont systemFontOfSize:18];
    }
    return _nameLabel;
}
- (SevenSwitch *)switchBtn
{
    if (!_switchBtn) {
        _switchBtn = [[SevenSwitch alloc]initWithFrame:CGRectMake(ScreenWidth-67, 6, 51, 31)];
        _switchBtn.onColor = [UIColor colorWithHexString:@"#4bda62"];
        [_switchBtn addTarget:self action:@selector(switchBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _switchBtn;
}
- (UIImageView *)rightIconImageView
{
    if (!_rightIconImageView) {
        _rightIconImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-23, 0, 8, 43)];
        _rightIconImageView.image = [UIImage imageNamed:@"right_go_icon"];
        _rightIconImageView.hidden = YES;
        _rightIconImageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _rightIconImageView;
}
- (void)switchBtnClicked:(SevenSwitch *)btn
{
    if (_delegate&&[_delegate respondsToSelector:@selector(changeValueWithState:IndexPath:)]) {
        [_delegate changeValueWithState:btn.on IndexPath:self.indexPath];
    }
}
- (void)setEndCell:(BOOL)endCell
{
    _endCell = endCell;
    [self setNeedsDisplay];
}
- (void)awakeFromNib {
    // Initialization code
}
- (void)drawRect:(CGRect)rect
{
    if (_endCell) {
        CGContextRef ref = UIGraphicsGetCurrentContext();
        CGContextSetLineWidth(ref, 0.5);
        [RGBCOLOR(217, 217, 217) set];
        CGContextMoveToPoint(ref, 0, rect.size.height-0.5);
        CGContextAddLineToPoint(ref, rect.size.width, rect.size.height-0.5);
        CGContextStrokePath(ref);
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
