//
//  LocationPickerViewController.h
//  huiyi
//
//  Created by 王振兴 on 14-12-30.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMapKit.h"
#import "FatherViewController.h"
@protocol LocationPickerViewDelegate <NSObject>
- (void)locationPicker:(UIViewController *)locationPicker didSelectLocation:(CLLocationCoordinate2D)location locationName:(NSString *)locationName mapScreenShot:(UIImage *)mapScreenShot;
@end
@interface LocationPickerViewController : UIViewController<BMKLocationServiceDelegate, BMKMapViewDelegate, BMKPoiSearchDelegate, BMKCloudSearchDelegate, BMKGeoCodeSearchDelegate,UITableViewDataSource,UITableViewDelegate>
{
    __weak id <LocationPickerViewDelegate> _delegate;
}
@property (nonatomic,weak)id <LocationPickerViewDelegate> delegate;
@end
