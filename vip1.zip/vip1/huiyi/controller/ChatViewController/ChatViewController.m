//
//  ChatViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/2.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatViewController.h"
#import "FriendInfoViewController.h"
#import "AllMapsViewController.h"
#import "RCDataBaseManager.h"
#import "ChatListViewController.h"
#import "ChatPrivateViewController.h"
#import "LocationPickerViewController.h"
#import "ChatSetViewController.h"
#import "ChatGroupSetViewController.h"
#import "ChatDiscussionSetViewController.h"
#import "ChatWebViewController.h"
#import "New_SignUpInfoViewController.h"
#import "NotificationCenterHeader.h"
#import "GroupListViewController.h"
#import <RongIMLib/RCIMClient.h>
#import "StrangerManager.h"
#import "Utils.h"
#import "RCDRCIMDataSource.h"



@interface ChatViewController ()<LocationPickerViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (nonatomic,strong) UILabel *titleView;
@property (nonatomic,strong) UIBarButtonItem *leftButton;
@property (nonatomic,strong) UIBarButtonItem *rightButton;
@property (nonatomic,strong) UIButton *leftBtn;
@property (nonatomic,strong) UIButton *rightBtn;
@property (nonatomic,strong) StrangerManager *strangerManager;
@end

@implementation ChatViewController
- (void)dealloc
{
    NSLog(@"ChatViewController dealloc");
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"ChatViewController"];
    [self setNavState];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"setupUnreadMessageCount" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(hideRightBtn) name:SELFISDELFROMDISCUSSION object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setRightBtn) name:SELFISADDDISCUSSION object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(addFriend) name:SELFISDELFROMDISCUSSION object:nil];
    
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[RCIMClient sharedRCIMClient] clearMessagesUnreadStatus:self.conversationType targetId:self.targetId];
    [MobClick endLogPageView:@"ChatViewController"];
   
}

- (StrangerManager *)strangerManager
{
    if (!_strangerManager) {
        NSArray *nibContents = [[NSBundle mainBundle] loadNibNamed:@"StrangerManager"owner:nil                                                               options:nil];
        _strangerManager = (StrangerManager*)[nibContents objectAtIndex:0];
        _strangerManager.frame = CGRectMake(0, 64, ScreenWidth, 44);
    }
    return _strangerManager;
}
- (void)setNavState
{
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    [self.navigationController setNavigationBarHidden:NO animated:NO];
    self.navigationController.navigationBar.translucent = NO ;
    [self.navigationController.navigationBar setBarTintColor:[UIColor colorWithHexString:@"#17b4eb"]];
//    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"navBGImage"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNavState];
    
    __weak typeof(self) weakSelf = self;
    [[RCDRCIMDataSource shareInstance]getUserInfoWithUserId:self.targetId completion:^(RCUserInfo *userInfo) {
        weakSelf.title = userInfo.name;
    }];
    [RCIMClient sharedRCIMClient].currentUserInfo.name = [[NSUserDefaults standardUserDefaults] objectForKey:@"name"];
    self.conversationMessageCollectionView.frame = CGRectMake(0, 64, ScreenWidth, ScreenHeight-64-44);
    [self.conversationMessageCollectionView setContentOffset:CGPointMake(0, self.conversationMessageCollectionView.contentSize.height) animated:NO];
    self.enableUnreadMessageIcon = YES;
    self.enableNewComingMessageIcon = YES;
    self.titleView.text = self.chatUserName;
    self.navigationItem.titleView = self.titleView;
    self.navigationItem.leftBarButtonItem = self.leftButton;
    [[RCIMClient sharedRCIMClient]getBlacklist:^(NSArray *blockUserIds) {
        NSLog(@"%@",blockUserIds);
    } error:^(RCErrorCode status) {
        
    }];
    if (self.conversationType == ConversationType_DISCUSSION) {
        [[RCIMClient sharedRCIMClient]getDiscussion:self.targetId success:^(RCDiscussion *discussion) {
            [discussion.memberIdList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSString *memberId = (NSString *)obj;
                if ([memberId isEqualToString:[RCIMClient sharedRCIMClient].currentUserInfo.userId]) {
                    weakSelf.rightBtn.hidden = NO;
                    *stop = YES;
                }else{
                    weakSelf.rightBtn.hidden = YES;
                }
            }];
        } error:^(RCErrorCode status) {
            
        }];
    }
    self.navigationItem.rightBarButtonItem = self.rightButton;
    if (self.conversationType == ConversationType_PRIVATE) {
        self.displayUserNameInCell = NO;//私聊不显示对方的昵称
        NSArray *friendArr = [[RCDataBaseManager shareInstance]getAllFriends];
        if (friendArr.count == 0) {
            [weakSelf creatStrangerManager];
        }
        RCUserInfo *info = [[RCDataBaseManager shareInstance]getFriendFromDB:self.targetId];
        if (!info^[[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"]isEqualToString:[Utils formatUserId:self.targetId]]) {
            [weakSelf creatStrangerManager];
        }
    }
    [self scrollToBottomAnimated:YES];
}
- (void)reloadManagerView
{
    __block BOOL isShield;
    __weak typeof(self) weakSelf = self;
    [[RCIMClient sharedRCIMClient]getBlacklistStatus:self.targetId success:^(int bizStatus) {
        if (bizStatus == 0) {
            isShield = YES;
            [weakSelf.strangerManager.shieldBtn setTitle:@"解除屏蔽" forState:UIControlStateNormal];
        }else{
            [weakSelf.strangerManager.shieldBtn setTitle:@"屏蔽此人" forState:UIControlStateNormal];
            isShield = NO;
        }
        [weakSelf.strangerManager.shieldBtn setNeedsDisplay];
    } error:^(RCErrorCode status) {
        
    }];

}
- (void)creatStrangerManager
{
    __weak typeof(self) weakSelf = self;
    [self reloadManagerView];
    [self.view addSubview:self.strangerManager];
    self.conversationMessageCollectionView.frame = CGRectMake(0, CGRectGetMaxY(self.strangerManager.frame), ScreenWidth, ScreenHeight-64-44-44);
    [self.view bringSubviewToFront:self.strangerManager];
    self.strangerManager.strangerManagerCompletion = ^(UIButton *btn){
        switch (btn.tag) {
            case 1:
            {
                [[RCIMClient sharedRCIMClient]getBlacklistStatus:weakSelf.targetId success:^(int bizStatus) {
                    if (bizStatus == 0) {//解除
                        [weakSelf setBlacklistStatus:bizStatus Param:@{@"user_id":weakSelf.targetId,@"switch":@"0"}];
                    }else{//添加
                        [weakSelf setBlacklistStatus:bizStatus Param:@{@"user_id":weakSelf.targetId,@"switch":@"1"}];

                    }
                } error:^(RCErrorCode status) {

                }];
            }
                break;
            case 2:
            {
                NSDictionary *params = @{@"user_id":[Utils formatUserId:weakSelf.targetId],@"msg":[NSString stringWithFormat:@"我是%@,想加您为好友",[[NSUserDefaults standardUserDefaults]objectForKey:@"name"]]};
                [MyDataService postPlatformContactAddfriend:params callback:^(id data) {
                    NSLog(@"%s : %@",__func__,data);
                    NSLog(@"%s : %@",__func__,[data JSONString]);
                    if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                        if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
                            [weakSelf sendNotifMessage:@"好友申请成功"];
                            [weakSelf.strangerManager.shieldBtn setTitle:@"屏蔽此人" forState:UIControlStateNormal];
                            [weakSelf.strangerManager.shieldBtn setNeedsDisplay];
                        }
                    }
                }];

            }
                break;
            default:
                break;
        }
    };

}
- (BOOL)hidesBottomBarWhenPushed{
    return YES;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    if (self.fromSignView) {
//        New_SignUpInfoViewController *signInfo = [[New_SignUpInfoViewController alloc]init];
        [self dismissViewControllerAnimated:YES completion:^{
            return ;
        }];
        
    }else{
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[ChatListViewController class]] ) {
            [self.navigationController popToViewController:vc animated:YES];
            return;
        }
//        if ([vc isKindOfClass:[New_SignUpInfoViewController class]]) {
//            [self.navigationController popToViewController:vc animated:YES];
//            return;
//        }
        if ([vc isKindOfClass:[GroupListViewController class]]) {
            [self.navigationController popToViewController:vc animated:YES];
            return;
        }
        
    }
    }
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)rightBarButtonItemPressed:(id)sender{
    __weak typeof(self) weakSelf = self;
    if (self.conversationType == ConversationType_GROUP) {
        ChatGroupSetViewController *setVC = [[ChatGroupSetViewController alloc]init];
        setVC.targetId = self.targetId;
        setVC.clearHistoryCompletion = ^(BOOL isSuccess) {
            if (isSuccess) {
                [weakSelf.conversationDataRepository removeAllObjects];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.conversationMessageCollectionView reloadData];
                });
            }
        };
        setVC.conversationType = self.conversationType;
        [self.navigationController pushViewController:setVC animated:YES];
    }
    if (self.conversationType == ConversationType_DISCUSSION) {
        ChatDiscussionSetViewController *setVC = [[ChatDiscussionSetViewController alloc]init];
        setVC.targetId = self.targetId;
        setVC.discussionTitle = self.chatUserName;
        setVC.clearHistoryCompletion = ^(BOOL isSuccess) {
            if (isSuccess) {
                [weakSelf.conversationDataRepository removeAllObjects];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.conversationMessageCollectionView reloadData];
                });
            }
        };
        setVC.changeTitleCompletion = ^(NSString *discussionName){
            dispatch_async(dispatch_get_main_queue(), ^{
                weakSelf.titleView.text = discussionName;
            });
        };
        setVC.disCussionOwnerInfo = [[RCIMClient sharedRCIMClient]currentUserInfo];
        setVC.conversationType = self.conversationType;
        [self.navigationController pushViewController:setVC animated:YES];
    }
    if (self.conversationType == ConversationType_PRIVATE) {
        ChatPrivateViewController *setVC = [[ChatPrivateViewController alloc]init];
        setVC.targetId = self.targetId;
        setVC.clearHistoryCompletion = ^(BOOL isSuccess) {
            if (isSuccess) {
                [weakSelf.conversationDataRepository removeAllObjects];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [weakSelf.conversationMessageCollectionView reloadData];
                });
            }
        };
        setVC.disCussionOwnerInfo = [[RCIMClient sharedRCIMClient]currentUserInfo];
        setVC.conversationType = self.conversationType;
        [self.navigationController pushViewController:setVC animated:YES];

    }
}
- (void)sendMessage:(RCMessageContent *)messageContent pushContent:(NSString *)pushContent
{
    [super sendMessage:messageContent pushContent:pushContent];
}
- (void)didTapCellPortrait:(NSString *)userId{
    if (self.conversationType == ConversationType_GROUP ||self.conversationType == ConversationType_PRIVATE|| self.conversationType == ConversationType_DISCUSSION) {
        FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
        friendInfoVC.user_id = userId;
        [self.navigationController pushViewController:friendInfoVC animated:YES];
    }
}
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    viewController.navigationItem.leftBarButtonItem.tintColor = [UIColor whiteColor];
    viewController.navigationItem.rightBarButtonItem.tintColor = [UIColor whiteColor];
}
/**
 *  点击pluginBoardView上item响应事件
 *
 *  @param pluginBoardView 功能模板
 *  @param tag             标记
 */
-(void)pluginBoardView:(RCPluginBoardView*)pluginBoardView clickedItemWithTag:(NSInteger)tag
{
    __weak typeof(self) weakSelf = self;
    switch (tag) {
            /*
        case PLUGIN_BOARD_ITEM_ALBUM_TAG:{
            UIImagePickerController *pickerController= [[UIImagePickerController alloc] init];
            [pickerController.navigationBar setTintColor:[UIColor whiteColor]];
            [pickerController.navigationBar setBackgroundImage:[UIImage imageNamed:@"navBGImage"] forBarMetrics:UIBarMetricsDefault];
            pickerController.delegate = self;
            pickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            pickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
            pickerController.allowsEditing = NO;
            [weakSelf presentViewController:pickerController animated:YES completion:nil];

        }
            break;
        case PLUGIN_BOARD_ITEM_LOCATION_TAG: {
            LocationPickerViewController *locationVC = [[LocationPickerViewController alloc]init];
            locationVC.delegate = self;
            [weakSelf.navigationController pushViewController:locationVC animated:YES];
        }
            break;*/
        default:
            [super pluginBoardView:pluginBoardView clickedItemWithTag:tag];
            break;
    }
    
}

/**
 *  点击消息内容
 *
 *  @param model 数据
 */
- (void)didTapMessageCell:(RCMessageModel *)model
{
    if ([model.objectName isEqualToString:@"RC:LBSMsg"]){
        RCLocationMessage *message = (RCLocationMessage *)model.content;
        AllMapsViewController *allMapVC = [[AllMapsViewController alloc]init];
        allMapVC.navTitle = message.locationName;
        allMapVC.latitude = message.location.latitude ;
        allMapVC.longitude = message.location.longitude;
        allMapVC.address = message.locationName;
        [self.navigationController pushViewController:allMapVC animated:YES];
        NSLog(@"%@",message);
    }else{
        [super didTapMessageCell:model];
    }
}
- (void)didTapUrlInMessageCell:(NSString *)url model:(RCMessageModel *)model
{
    ChatWebViewController *webController = [[ChatWebViewController alloc]init];
    webController.url = url;
    [self.navigationController pushViewController:webController animated:YES];
}
-(void)showPreviewPictureController:(RCMessage*)rcMessage{
    
    //    DemoPreviewViewController *temp=[[DemoPreviewViewController alloc]init];
    //    temp.rcMessage = rcMessage;
    //    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:temp];
    
    //导航和原有的配色保持一直
    //    UIImage *image= [self.navigationController.navigationBar backgroundImageForBarMetrics:UIBarMetricsDefault];
    //
    //    [nav.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    //
    //    [self presentViewController:nav animated:YES completion:nil];
}


- (void)locationPicker:(UIViewController *)locationPicker didSelectLocation:(CLLocationCoordinate2D)location locationName:(NSString *)locationName mapScreenShot:(UIImage *)mapScreenShot{
     RCLocationMessage *msessage = [RCLocationMessage messageWithLocationImage:mapScreenShot location:location locationName:locationName];
 
    [[RCIM sharedRCIM]sendMessage:self.conversationType targetId:self.targetId content:msessage pushContent:nil pushData:nil success:^(long messageId) {
        NSLog(@"%ld",messageId);
        [locationPicker.navigationController popViewControllerAnimated:YES];
    } error:^(RCErrorCode nErrorCode, long messageId) {
    }];
}


#pragma mark Camera View Delegate Methods
- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSLog(@"%@",[info objectForKey:UIImagePickerControllerOriginalImage]);
    ;
//    [super sendImageMessage:[RCImageMessage messageWithImageURI:[info objectForKey:UIImagePickerControllerReferenceURL]] pushContent:@""];
    [[RCIM sharedRCIM]sendImageMessage:self.conversationType targetId:self.targetId content:[RCImageMessage messageWithImage:[info objectForKey:UIImagePickerControllerOriginalImage]]  pushContent:nil pushData:nil progress:^(int progress, long messageId) {
        
    } success:^(long messageId) {
        NSLog(@"%ld",messageId);
    } error:^(RCErrorCode errorCode, long messageId) {
        NSLog(@"%ld",(long)errorCode);
    }];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}



#pragma mark ---- view -----
- (UILabel *)titleView
{
    if (!_titleView) {
        _titleView = [[UILabel alloc]init];
        _titleView.frame = CGRectMake(100, 0, 120, 44);
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.textAlignment = NSTextAlignmentCenter;
        _titleView.font = [UIFont boldSystemFontOfSize:18];
        _titleView.textColor = [UIColor whiteColor];
    }
    return _titleView;
}
- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}
- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame = CGRectMake(0, 0, 44, 44);
        if (self.conversationType == ConversationType_GROUP) {
            [_rightBtn setImage:[UIImage imageNamed:@"gourpicon"] forState:UIControlStateNormal];
        }
        else if(self.conversationType == ConversationType_PRIVATE){
            [_rightBtn setImage:[UIImage imageNamed:@"singleUserPhoto"] forState:UIControlStateNormal];
        }
        else if(self.conversationType == ConversationType_DISCUSSION){
            [_rightBtn setImage:[UIImage imageNamed:@"gourpicon"] forState:UIControlStateNormal];
        }
        [_rightBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 20, 0, 0)];
        [_rightBtn addTarget:self action:@selector(rightBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];

    }
    return _rightBtn;
}
- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}
- (UIBarButtonItem *)rightButton
{
    if (!_rightButton) {
        _rightButton = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
        [_rightButton setTintColor:[UIColor whiteColor]];
    }
    return _rightButton;
}
/**
 *  当自己被踢出讨论组后或加入讨论组后  隐藏和显示设置按钮
 */
- (void)hideRightBtn
{
    self.rightBtn.hidden = YES;
}
- (void)setRightBtn
{
    self.rightBtn.hidden = NO;
}
- (void)addFriend
{
    [UIView animateWithDuration:0.5 animations:^{
        self.strangerManager.frame = CGRectMake(0, 20, ScreenWidth, 44);
        self.conversationMessageCollectionView.frame = CGRectMake(0, 64, ScreenWidth, ScreenHeight-64-44);
    }];
}
- (void)sendNotifMessage:(NSString *)messageString
{
    __weak typeof(self) weakSelf = self;
    RCMessage *message = [[RCIMClient sharedRCIMClient]insertMessage:weakSelf.conversationType targetId:weakSelf.targetId senderUserId:[RCIMClient sharedRCIMClient].currentUserInfo.userId sendStatus:SentStatus_RECEIVED content:[RCInformationNotificationMessage notificationWithMessage:messageString extra:nil]];
        if (message) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf appendAndDisplayMessage:message];
            });
        }
}
- (void)setBlacklistStatus:(int)status Param:(NSDictionary *)param
{
    __weak typeof(self) weakSelf = self;
    [MyDataService postPlatformMessageShieldswitch:param callback:^(id data) {
        if ([data[@"code"]isEqualToString:@"200"]||[data[@"code"]isEqualToString:@"201"]) {
            if (status == 0) {
                [weakSelf.strangerManager.shieldBtn setTitle:@"屏蔽此人" forState:UIControlStateNormal];
               
                
                [[RCDRCIMDataSource shareInstance]getUserInfoWithUserId:weakSelf.targetId completion:^(RCUserInfo *userInfo) {
                    [weakSelf sendNotifMessage:[NSString stringWithFormat:@"您已解除屏蔽%@的消息",userInfo.name]];
                }];
            }else{
                [weakSelf.strangerManager.shieldBtn setTitle:@"解除屏蔽" forState:UIControlStateNormal];
                [weakSelf.strangerManager.shieldBtn setNeedsDisplay];
                [[RCDRCIMDataSource shareInstance]getUserInfoWithUserId:weakSelf.targetId completion:^(RCUserInfo *userInfo) {
                    [weakSelf sendNotifMessage:[NSString stringWithFormat:@"您已屏蔽%@的消息",userInfo.name]];
                }];
            }
        }else{
            
            [Dialog toast:data[@"code"]];
        }
    }];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
