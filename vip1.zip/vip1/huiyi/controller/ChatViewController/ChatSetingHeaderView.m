//
//  ChatSetingHeaderView.m
//  huiyi
//
//  Created by songhongshuai on 15/12/3.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatSetingHeaderView.h"
#import "ChatUserInfoView.h"

#define Identifier @"UICollectionViewCell"
#define SPACEX  15.0//左右边距
#define SPACEY  23.0//上下边距
#define MARGINY  13.0//左右间距
#define INFOWidth  63.0//view的长
#define INFOHeight  88.0//view的宽

@interface ChatSetingHeaderView ()<ChatUserInfoViewChoiceUersInfoDelegate>
@property (strong, nonatomic)  UIGestureRecognizer * gestureRecognizer;

@end

@implementation ChatSetingHeaderView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.frame = CGRectMake(0, 0, ScreenWidth, 200);
        self.backgroundColor = [UIColor whiteColor];
        self.clipsToBounds = YES;
        [self addGestureRecognizer:self.gestureRecognizer];
    }
    return self;
}
- (UIGestureRecognizer *)gestureRecognizer
{
    if (!_gestureRecognizer) {
        _gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hiddenDeleteTip)];
    }
    return _gestureRecognizer;
}
- (void)setUsers:(NSMutableArray *)users
{
    
    if (users) {
        _users = users;
        [self createUserInfoView:users];
        [self changViewFrame:users];
    }
}
- (void)hiddenDeleteTip
{
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[ChatUserInfoView class]]) {
            ChatUserInfoView *infoView = (ChatUserInfoView*)view;
            infoView.isShowDelButton = NO;
        }
    }

}
//删除按钮的隐藏 显示
- (void)setShowDeleteTip:(BOOL)showDeleteTip
{
    _showDeleteTip = showDeleteTip;
    int showCount;
    if (self.isAllowedInviteMember&&self.isAllowedDeleteMember) {
        showCount = 18;
        if (self.users.count<=showCount) {
            showCount = self.users.count;
        }
    }
    if ((self.isAllowedDeleteMember ^ self.isAllowedInviteMember )) {
        showCount = 19;
        if (self.users.count<=showCount) {
            showCount = self.users.count;
        }
    }
    if ((!self.isAllowedInviteMember)&&(!self.isAllowedDeleteMember)) {
        showCount = 20;
        if (self.users.count<=showCount) {
            showCount = self.users.count;
        }
    }
//    for (int idx = 0; idx < self.subviews.count; idx++) {
//        if (idx < self.users.count) {
//            
//            if
//        }
//    }
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[ChatUserInfoView class]]) {
            ChatUserInfoView *infoView = (ChatUserInfoView*)view;
            if (infoView.tag < showCount) {
                if ([infoView.userInfo.userId isEqualToString:self.creator.userId]) {
                    infoView.isShowDelButton = NO;
                }else{
                    infoView.isShowDelButton = showDeleteTip;
                }
            }else{
                infoView.isShowDelButton = NO;
            }
            
        }
    }
}
- (void)createUserInfoView:(NSArray *)param
{
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[ChatUserInfoView class]]) {
            [view removeFromSuperview];
        }
    }
    
    NSInteger gridCount ;
    NSMutableArray *mutableArr = [[NSMutableArray alloc]initWithCapacity:0];
    
    if (self.isAllowedInviteMember&&self.isAllowedDeleteMember) {
        if (param.count>=18) {
            gridCount = 20;
            [mutableArr addObjectsFromArray:[param objectsAtIndexes:[[NSIndexSet alloc ] initWithIndexesInRange:NSMakeRange (0, 18)]]];
        }else{
            gridCount = param.count+2;
            [mutableArr addObjectsFromArray:param];
        }
        
    }
    if ((self.isAllowedDeleteMember ^ self.isAllowedInviteMember )) {
        if (param.count>=19) {
            gridCount = 20;
            [mutableArr addObjectsFromArray:[param objectsAtIndexes:[[NSIndexSet alloc ] initWithIndexesInRange:NSMakeRange (0, 19)]]];
        }else{
            gridCount = param.count+1;
            [mutableArr addObjectsFromArray:param];
        }
    }
    if ((!self.isAllowedInviteMember)&&(!self.isAllowedDeleteMember)) {
        if (param.count>=20) {
            gridCount = 20;
            [mutableArr addObjectsFromArray:[param objectsAtIndexes:[[NSIndexSet alloc ] initWithIndexesInRange:NSMakeRange (0, 20)]]];
        }else{
            gridCount = param.count;
            [mutableArr addObjectsFromArray:param];
        }
    }
    
    [self makeInfoViewWithUsers:mutableArr Count:gridCount];
}

- (void)makeInfoViewWithUsers:(NSArray *)param Count:(int)maxIndex
{
    NSInteger perRowUers ;
    if (iphone6Plus) {
        perRowUers = 5;
    }else{
        perRowUers = 4;
    }
    CGFloat spaceX = 15.0;
    CGFloat spaceY = 18.0;//上下边距
    CGFloat marginY = 8.0;//左右间距
    CGFloat gridWidth = 68;//view的长
    CGFloat gridHeight = 88;//view的宽
    CGFloat marginX = (ScreenWidth-30-(gridWidth*perRowUers))/perRowUers;//左右间距
    for (NSInteger index = 0; index < maxIndex; index ++) {
        
        ChatUserInfoView *infoView = [[ChatUserInfoView alloc]initWithFrame:CGRectMake(spaceX+(index%perRowUers*(gridWidth+marginX)), spaceY + index/perRowUers*(gridHeight+marginY), gridWidth, gridHeight)];
        infoView.delegate = self;
        infoView.tag = index;
        if (index<param.count) {
            infoView.userInfo = param[index];
        }else{
            infoView.userInfo = nil;
            if (maxIndex == param.count+1) {
                if (self.isAllowedDeleteMember) {
                    infoView.isAllowedDeleteMember = self.isAllowedDeleteMember;
                }
                if (self.isAllowedInviteMember) {
                    infoView.isAllowedInviteMember = self.isAllowedInviteMember;
                }
            }
            if (maxIndex == param.count + 2) {
                if (index == param.count) {
                    infoView.isAllowedInviteMember = self.isAllowedInviteMember;
                }
                if (index == param.count + 1) {
                    infoView.isAllowedDeleteMember = self.isAllowedDeleteMember;
                }
            }
        }
        infoView.backgroundColor = [UIColor clearColor];
        [self addSubview:infoView];
    }
}

- (void)delUsersIndex:(NSInteger)index{
    if (_settingTableViewHeaderDelegate&&[_settingTableViewHeaderDelegate respondsToSelector:@selector(didTipHeaderClicked: IndexPath:)]) {
        [_settingTableViewHeaderDelegate deleteTipButtonClicked:index];
    }
}
- (void)choiceUersInfo:(RCUserInfo *)uersInfo IndexPath:(NSInteger)indexPath
{
    if (_settingTableViewHeaderDelegate&&[_settingTableViewHeaderDelegate respondsToSelector:@selector(didTipHeaderClicked: IndexPath:)]) {
        [_settingTableViewHeaderDelegate didTipHeaderClicked:uersInfo IndexPath:indexPath];
    }
}
- (void)changViewFrame:(NSArray *)users
{
    int maxNum;
    if (iphone6Plus) {
        maxNum = 5;
    }else{
        maxNum = 4;
    }
    int showCount;
    
    if (self.isAllowedInviteMember&&self.isAllowedDeleteMember) {
        showCount = 18;
        if (users.count<=showCount) {
            showCount = users.count;
        }
        if ((showCount + 2)%maxNum==0) {
            self.bounds = CGRectMake(0, 0, ScreenWidth, (showCount+2)/maxNum*INFOHeight+SPACEY*2);
        }else{
            self.bounds = CGRectMake(0, 0, ScreenWidth, ((showCount+2)/maxNum+1)*INFOHeight+SPACEY*2);
        }
    }
    if ((self.isAllowedDeleteMember ^ self.isAllowedInviteMember )) {
        showCount = 19;
        if (users.count<=showCount) {
            showCount = users.count;
        }
        if ((showCount + 1)%maxNum==0) {
            self.bounds = CGRectMake(0, 0, ScreenWidth, (showCount+1)/maxNum*INFOHeight+SPACEY*2);
        }else{
            self.bounds = CGRectMake(0, 0, ScreenWidth, ((showCount+1)/maxNum+1)*INFOHeight+SPACEY*2);
        }
    }
    if ((!self.isAllowedInviteMember)&&(!self.isAllowedDeleteMember)) {
        showCount = 20;
        if (users.count<=showCount) {
            showCount = users.count;
        }
        if (showCount%maxNum==0) {
            self.bounds = CGRectMake(0, 0, ScreenWidth, (showCount)/maxNum*INFOHeight+SPACEY*2);
        }else{
            self.bounds = CGRectMake(0, 0, ScreenWidth, (showCount/maxNum+1)*INFOHeight+SPACEY*2);
        }
    }

}

- (void)drawRect:(CGRect)rect
{
    CGContextRef ref = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(ref, 0.5);
    [RGBCOLOR(217,217,217)set];
//    CGContextSetRGBFillColor(ref, 217/255.0, 217/255.0, 217/255.0, 1.0);
    CGContextMoveToPoint(ref, 17, rect.size.height-0.5);
    CGContextAddLineToPoint(ref, rect.size.width, rect.size.height-0.5);
    CGContextStrokePath(ref);
}

@end
