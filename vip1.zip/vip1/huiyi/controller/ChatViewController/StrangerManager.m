//
//  StrangerManager.m
//  huiyi
//
//  Created by songhongshuai on 16/1/8.
//  Copyright © 2016年 shs. All rights reserved.
//

#import "StrangerManager.h"

@interface StrangerManager ()


@end

@implementation StrangerManager
- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        self.shieldBtn.adjustsImageWhenHighlighted = NO;
        self.addFriendBtn.adjustsImageWhenHighlighted = NO;
    }
    return self;
}

- (IBAction)ShieldBtnClicked:(id)sender {
    self.strangerManagerCompletion((UIButton*)sender);
}
- (IBAction)AddFriendBtnClicked:(id)sender {
    self.strangerManagerCompletion((UIButton*)sender);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
