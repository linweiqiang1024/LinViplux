//
//  ChatDiscussionSetViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/2.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatDiscussionSetViewController.h"
#import "RCDSelectPersonViewController.h"
#import "GruopUserViewController.h"
#import "ChatSetingHeaderView.h"
#import "RCDataBaseManager.h"
#import "SevenSwitch.h"
#import "RCChatUserInfo.h"
#import "RCChatInfoManager.h"
#import "RCDRCIMDataSource.h"
#import "ChatSetingTableViewCell.h"
#import "FriendInfoViewController.h"
#import "ChatListViewController.h"
#import "ReDiscussionNameViewController.h"
@interface ChatDiscussionSetViewController ()<UIActionSheetDelegate,ChatSettingTableViewHeaderDelegate,SevenSwitchChangeValueDelegate>
{
    __block NSMutableArray *_usersParam;

}
@property (nonatomic,strong) UILabel              *titleView;
@property (nonatomic,strong) UIBarButtonItem      *leftButton;
@property (nonatomic,strong) UIButton             *leftBtn;
@property (nonatomic,strong) ChatSetingHeaderView *tableViewHeader;
@property (nonatomic,strong) UIView               *footView;
@property (nonatomic,strong) UIButton             *exitBtn;
@property (nonatomic,strong) NSArray              *dataSourceParam;
@property (nonatomic       ) NSString             *creator;
@property (nonatomic       ) BOOL                 isOwner;
@end

@implementation ChatDiscussionSetViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _usersParam = [[NSMutableArray alloc]initWithCapacity:0];
    self.tableView.backgroundColor = [UIColor colorWithHexString:@"#f0eff5"];
    self.navigationItem.titleView = self.titleView;
    self.navigationItem.leftBarButtonItem = self.leftButton;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.footView addSubview:self.exitBtn];
    self.tableView.tableFooterView = self.footView;
    [[RCIMClient sharedRCIMClient] getDiscussion:self.targetId success:^(RCDiscussion* discussion) {
        if (discussion) {
            self.creator = discussion.creatorId;
            if([[self formatUserId:[RCIMClient sharedRCIMClient].currentUserInfo.userId] isEqualToString:[self formatUserId:discussion.creatorId]])
            {
                self.isOwner = YES;
                self.tableViewHeader.isAllowedDeleteMember = YES;
                self.tableViewHeader.isAllowedInviteMember = YES;
                
            }else{
                self.isOwner = NO;
                if (discussion.inviteStatus == 1) {
                    self.tableViewHeader.isAllowedInviteMember = NO;
                    self.tableViewHeader.isAllowedDeleteMember = NO;
                }else{
                    self.tableViewHeader.isAllowedInviteMember = YES;
                    self.tableViewHeader.isAllowedDeleteMember = NO;
                }
            }
            [self getDiscussionDetailInfo:discussion];
        }
    } error:^(RCErrorCode status){
        
    }];

    
    
   
}

- (void)getDiscussionDetailInfo:(RCDiscussion *)discussion{
    for (int i = 0; i < discussion.memberIdList.count; i++) {
        NSString * userId = discussion.memberIdList[i];
        
        [[RCChatInfoManager shareInstance]getUseInfoByID:userId successCompletion:^(RCUserInfo *userInfo) {
            RCChatUserInfo *info = [RCChatUserInfo new];
            info.selected = YES;
            info.userId = userInfo.userId;
            info.name = userInfo.name;
            info.portraitUri = userInfo.portraitUri;
            
            [_usersParam addObject:info];
            if (_usersParam.count == discussion.memberIdList.count) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.tableViewHeader.users = _usersParam;
                    self.tableView.tableHeaderView = self.tableViewHeader;
                    [self.tableView reloadData];
                });
            }
        }];
    }
}
#pragma mark --UITableViewDelegate--
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43.5;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return 20;
    }
    return 0;
}


#pragma mark --UITableViewDataSource--
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }else if (section == 1){
        if (self.isOwner) {
            return 5;
        }
        if (!self.isOwner) {
            return 4;
        }
    }
    return 0;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        GruopUserViewController *userVC = [[GruopUserViewController alloc]init];
        userVC.members = _usersParam;
        userVC.conversationType = self.conversationType;
        [self.navigationController pushViewController:userVC animated:YES];
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            ReDiscussionNameViewController *discussionNameViewController = [[ReDiscussionNameViewController alloc]init];
            discussionNameViewController.discussionName = self.discussionTitle;
            discussionNameViewController.targetId = self.targetId;
            discussionNameViewController.changeTitleCompletion = ^(NSString * discussionName){
                if (discussionName.length>0) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        _discussionTitle = discussionName;
                        self.changeTitleCompletion(discussionName);
                        [self.tableView reloadData];
                    });
                }
            };
            [self.navigationController pushViewController:discussionNameViewController animated:YES];
            
        }

        if (indexPath.row == self.dataSourceParam.count - 1) {
            UIActionSheet *sheet = [[UIActionSheet alloc]initWithTitle:@"是否清除记录" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles:nil];
            [sheet showInView:self.view];
        }
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuseIdentifier = @"reuseIdentifierCell";
    ChatSetingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[ChatSetingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    }
    cell.delegate = self;
    cell.indexPath = indexPath;
    if (indexPath.section == 0) {
        cell.nameLabel.text = [NSString stringWithFormat:@"全部成员(%ld)",(unsigned long)_usersParam.count];
        cell.switchBtn.hidden = YES;
        cell.rightIconImageView.hidden = NO;
    }
    if (indexPath.section == 1) {
        cell.nameLabel.text = self.dataSourceParam[indexPath.row];
        NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
        if (indexPath.row == 0) {
            cell.titleLabel.text = _discussionTitle;
            cell.titleLabel.hidden = NO;
            cell.switchBtn.hidden = YES;
            cell.rightIconImageView.hidden = NO;
        }
        if (self.isOwner) {
            if (indexPath.row == 1) {
                cell.titleLabel.hidden = NO;
                if ([[def objectForKey:[NSString stringWithFormat:@"%@_ConversationDiscussionToTop",self.targetId]]isEqualToString:@"1"] ) {
                    cell.switchBtn.on = YES;
                }else{
                    cell.switchBtn.on = NO;
                }
            }
            if (indexPath.row == 2) {
                cell.titleLabel.hidden = NO;
                [[RCIMClient sharedRCIMClient] getConversationNotificationStatus:self.conversationType targetId:self.targetId success:^(RCConversationNotificationStatus nStatus) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (nStatus == DO_NOT_DISTURB) {
                            cell.switchBtn.on = NO;
                        }else{
                            cell.switchBtn.on = YES;
                        }
                    });
                } error:^(RCErrorCode status) {
                    
                }];
            }
            if (indexPath.row == 3) {
                
                cell.titleLabel.hidden = NO;
                cell.switchBtn.hidden = NO;
                [[RCIMClient sharedRCIMClient]getDiscussion:self.targetId success:^(RCDiscussion *discussion) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (discussion.inviteStatus == 0) {
                            cell.switchBtn.on = YES;
                        }else{
                            cell.switchBtn.on = NO;
                        }
                       
                    });
                } error:^(RCErrorCode status) {
                    
                }];
            }
            if (indexPath.row == 4) {
                cell.titleLabel.hidden = NO;
                cell.switchBtn.hidden = YES;
                cell.endCell = YES;
            }
        }
        if (!self.isOwner) {
            if (indexPath.row == 0) {
                cell.switchBtn.hidden = YES;
            }
            if (indexPath.row == 1) {//置顶
                if ([[def objectForKey:[NSString stringWithFormat:@"%@_ConversationDiscussionToTop",self.targetId]]isEqualToString:@"1"] ) {
                    cell.switchBtn.on = YES;
                }else{
                    cell.switchBtn.on = NO;
                }
            }
            if (indexPath.row == 2) {//新消息提醒
                [[RCIMClient sharedRCIMClient] getConversationNotificationStatus:self.conversationType targetId:self.targetId success:^(RCConversationNotificationStatus nStatus) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (nStatus == DO_NOT_DISTURB) {
                            
                            cell.switchBtn.on = NO;
                        }else{
                            cell.switchBtn.on = YES;
                        }
                    });
                } error:^(RCErrorCode status) {
                    
                }];
            }
            if (indexPath.row == 3) {
                cell.switchBtn.hidden = YES;
                cell.endCell = YES;
            }
        }
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}


- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        [self clearHistoryMessage];
    }
}
- (void)clearHistoryMessage {
    BOOL isClear = [[RCIMClient sharedRCIMClient] clearMessages:self.conversationType targetId:self.targetId];
    
    //清除消息之后回调操作，例如reload 会话列表
    if (self.clearHistoryCompletion) {
        
        self.clearHistoryCompletion(isClear);
    }
}
#pragma mark --SevenSwitchChangeValueDelegate--
//修改按钮状态
- (void)changeValueWithState:(BOOL)state IndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 1){
        //置顶
        if (state) {
            [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:[NSString stringWithFormat:@"%@_ConversationDiscussionToTop",self.targetId]];
//            self.conversationType
        }else{
            [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:[NSString stringWithFormat:@"%@_ConversationDiscussionToTop",self.targetId]];
            
        }
        [[RCIMClient sharedRCIMClient]setConversationToTop:self.conversationType targetId:self.targetId isTop:state];
        //        RCConversationModel *mode = [RCConversationModel alloc]ini
    }
    if(indexPath.row == 2){
        //消息提示
        [[RCIMClient sharedRCIMClient]setConversationNotificationStatus:self.conversationType targetId:self.targetId isBlocked:state success:^(RCConversationNotificationStatus nStatus) {
        } error:^(RCErrorCode status) {
            
        }];

        
    }
    if (self.isOwner) {
        if (indexPath.row == 3) {
            [[RCIMClient sharedRCIMClient] setDiscussionInviteStatus:self.targetId isOpen:state success:^{
                //        DebugLog(@"设置成功");
            } error:^(RCErrorCode status) {
                
            }];
        }
    }
}
#pragma mark --ChatSettingTableViewHeaderDelegate--
//点击群成员的头像 ，添加，删除群成员
- (void)didTipHeaderClicked:(RCUserInfo *)userInfo IndexPath:(NSInteger)indexPath
{
    int showCount;
    if (userInfo) {
        //跳转群成员详情页
        FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
        friendInfoVC.isChatInfo = YES;
        friendInfoVC.user_id = userInfo.userId;
        [self.navigationController pushViewController:friendInfoVC animated:YES];
    }else{
        if (self.tableViewHeader.isAllowedInviteMember&&self.tableViewHeader.isAllowedDeleteMember){
            //讨论组主人可以邀请 删除
            showCount = 18;
            if (_usersParam.count<=showCount) {
                showCount = _usersParam.count;
            }
            if (indexPath == showCount) {
                //添加动作
                [self addDisCussionMember];
            }
            if (indexPath == showCount + 1) {
                //删除动作
                self.tableViewHeader.showDeleteTip = YES;
            }
        }
        if (self.tableViewHeader.isAllowedDeleteMember^self.tableViewHeader.isAllowedInviteMember) {
            //讨论组成员可以邀请不能删人
            if (self.tableViewHeader.isAllowedInviteMember) {
                //添加
                showCount = 19;
                if (_usersParam.count<=showCount) {
                    showCount = _usersParam.count;
                }
                if (indexPath == showCount)
                {
                    [self addDisCussionMember];
                }
            }
            
            if (self.tableViewHeader.isAllowedDeleteMember) {
                //删除
                
                self.tableViewHeader.showDeleteTip = YES;
            }
        }
    }
}
- (void)deleteDiscussionMemberWithUserInfo:(RCUserInfo *)userInfo
{
    
    if ([userInfo.userId isEqualToString:[RCIMClient sharedRCIMClient].currentUserInfo.userId]) {
        return;
    }
    
    [[RCIMClient sharedRCIMClient] removeMemberFromDiscussion:self.targetId
                                                       userId:userInfo.userId
                                                      success:^(RCDiscussion *discussion) {
                                                          NSLog(@"踢人成功");
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              self.tableViewHeader.showDeleteTip = NO;
                                                              
                                                              [_usersParam removeObject:userInfo];
                                                              [self refreshTabelHeaderView];
                                                              
                                                          });
                                                         
                                                      } error:^(RCErrorCode status) {
                                                          NSLog(@"踢人失败");
                                                      }];

}
- (void)addDisCussionMember
{
    RCDSelectPersonViewController* selectPersonVC = [[RCDSelectPersonViewController alloc] init];
    [selectPersonVC setSeletedUsers:_usersParam];
    //设置回调
    selectPersonVC.clickDoneCompletion = ^(RCDSelectPersonViewController* selectPersonViewController, NSArray* selectedUsers) {
        
        if (selectedUsers && selectedUsers.count) {
            __block NSMutableArray *newInfo = [[NSMutableArray alloc]initWithCapacity:0];
            NSMutableArray *tempInfoArr = [[NSMutableArray alloc]initWithCapacity:0];
            [newInfo addObjectsFromArray:selectedUsers];
            
            for (RCChatUserInfo *info in _usersParam) {
                for (RCChatUserInfo *newSelectedInfo in newInfo) {
                    if ([newSelectedInfo.userId isEqualToString:info.userId]) {
                        [tempInfoArr addObject:newSelectedInfo];
                    }
                }
            }
            [newInfo removeObjectsInArray:tempInfoArr];
            [_usersParam addObjectsFromArray:newInfo];
            self.tableViewHeader.users = _usersParam;
            [self invokeMemberWithSelectedUsers:newInfo];
        }
        [selectPersonViewController.navigationController popViewControllerAnimated:YES];
    };
    [self.navigationController pushViewController:selectPersonVC animated:YES];
}

- (void)invokeMemberWithSelectedUsers:(NSArray*)selectedUsers
{
    //    __weak RCDSettingViewController *weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        
            NSMutableArray *addIdList = [NSMutableArray new];
            for (RCUserInfo *user in selectedUsers) {
                [addIdList addObject:user.userId];
            }
            
            //加入讨论组
            if(addIdList.count != 0){
                
                [[RCIMClient sharedRCIMClient] addMemberToDiscussion:self.targetId userIdList:addIdList success:^(RCDiscussion *discussion) {
                    //刷新头部成员列表
                    [self refreshTabelHeaderView];
                } error:^(RCErrorCode status) {
                }];
            }
    });
}


//删除群成员
- (void)deleteTipButtonClicked:(NSInteger )index
{
    RCUserInfo * userInfo = _usersParam[index];
    [self deleteDiscussionMemberWithUserInfo:userInfo];
}
#pragma mark --UI--
- (NSArray *)dataSourceParam
{
    if (!_dataSourceParam) {
        if (self.isOwner) {
            _dataSourceParam = [NSArray arrayWithObjects:@"讨论组名称", @"置顶聊天", @"新消息提示", @"开放成员邀请",@"清空聊天记录", nil];
        }else{
            _dataSourceParam = [NSArray arrayWithObjects:@"讨论组名称", @"置顶聊天", @"新消息提示", @"清空聊天记录", nil];
        }
        
    }
    return _dataSourceParam;
}

- (UILabel *)titleView
{
    if (!_titleView) {
        _titleView = [[UILabel alloc]init];
        _titleView.frame = CGRectMake(100, 0, 120, 44);
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.text = @"设置";
        _titleView.textAlignment = NSTextAlignmentCenter;
        _titleView.font = [UIFont boldSystemFontOfSize:18];
        _titleView.textColor = [UIColor whiteColor];
    }
    return _titleView;
}
- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}

- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}

- (ChatSetingHeaderView *)tableViewHeader
{
    if (!_tableViewHeader) {
        _tableViewHeader = [[ChatSetingHeaderView alloc]init];
        _tableViewHeader.settingTableViewHeaderDelegate = self;
        _tableViewHeader.backgroundColor = [UIColor whiteColor];
    }
    return _tableViewHeader;
}
- (UIButton *)exitBtn
{
    if (!_exitBtn) {
        _exitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _exitBtn.frame = CGRectMake(10, 20, ScreenWidth-20, 41);
        [_exitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_exitBtn setTitle:@"删除并退出" forState:UIControlStateNormal];
        [_exitBtn setBackgroundColor:[UIColor colorWithHexString:@"#eb504f"]];
        [_exitBtn addTarget:self action:@selector(exitDiscussion) forControlEvents:UIControlEventTouchUpInside];
    }
    return _exitBtn;
}

- (void)exitDiscussion
{
    [[RCIMClient sharedRCIMClient]quitDiscussion:self.targetId success:^(RCDiscussion *discussion) {
        [[RCIMClient sharedRCIMClient]removeConversation:ConversationType_DISCUSSION targetId:self.targetId];
        dispatch_async(dispatch_get_main_queue(), ^{
            for (UIViewController *vc in self.navigationController.viewControllers) {
                if ([vc isKindOfClass:[ChatListViewController class]] ) {
                    [self.navigationController popToViewController:vc animated:YES];
                }
            }
            
        });
    } error:^(RCErrorCode status) {
        if (status == NOT_IN_DISCUSSION) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [Dialog toastCenter:@"您不在该讨论组中"];
            });
        }
    }];
}
- (UIView *)footView
{
    if (!_footView) {
        _footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 80)];
        _footView.backgroundColor = [UIColor colorWithHexString:@"#f0eff5"];
    }
    return _footView;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)refreshTabelHeaderView{
     [[RCChatInfoManager shareInstance]getUseInfoByID:self.creator successCompletion:^(RCUserInfo *userInfo) {
         dispatch_async(dispatch_get_main_queue(), ^{
             self.tableViewHeader.users = _usersParam;
             self.tableViewHeader.creator = userInfo;
             self.tableView.tableHeaderView = self.tableViewHeader;
             [self.tableView reloadData];
         });

     }];
}

- (NSString*)formatUserId:(NSString *)userId
{
    if ([userId rangeOfString:@":"].location != NSNotFound) {
        
        userId = [[userId componentsSeparatedByString:@":"] objectAtIndex:0];
        
    }
    return userId;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
