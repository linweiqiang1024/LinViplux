//
//  ChatDiscussionSetViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/12/2.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <RongIMKit/RongIMKit.h>

@interface ChatDiscussionSetViewController : UITableViewController

/**
 *  定义block
 *
 *  @param isSuccess isSuccess description
 */
typedef void (^clearHistory)(BOOL isSuccess);
typedef void (^changeTitle)(NSString *title);
@property (nonatomic, assign) RCConversationType conversationType;
/** 目标ID，如讨论组ID, 群ID, 聊天室ID */
@property (nonatomic, strong) NSString           *discussionTitle;
@property (nonatomic, strong) NSString           *targetId;
@property (nonatomic, strong) RCUserInfo         *disCussionOwnerInfo;
/**
 *  清除历史消息后，会话界面调用roload data
 */
@property (nonatomic, copy  ) changeTitle       changeTitleCompletion;
@property (nonatomic, copy  ) clearHistory       clearHistoryCompletion;
@end
