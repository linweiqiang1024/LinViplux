//
//  ChatWebViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/12/14.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatWebViewController : UIViewController
@property (nonatomic,strong)NSString *url;

@end
