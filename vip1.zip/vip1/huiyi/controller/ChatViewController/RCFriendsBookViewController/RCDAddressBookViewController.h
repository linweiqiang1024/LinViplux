//
//  RCDAddressBookViewController.h
//  RongCloud
//
//  Created by Liv on 14/11/11.
//  Copyright (c) 2014年 RongCloud. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "RCSelectPersonViewController.h"

@interface RCDAddressBookViewController : UIViewController


@property (nonatomic, strong) NSArray *keys;
@property (nonatomic, strong) NSMutableDictionary *allFriends;
@property (nonatomic,strong) NSArray *allKeys;

@property (nonatomic,strong) NSArray *seletedUsers;
@property (nonatomic,strong) NSMutableArray *friends;

@property (nonatomic,assign) BOOL hideSectionHeader;
@property (nonatomic,strong) UITableView *tableView;
@end
