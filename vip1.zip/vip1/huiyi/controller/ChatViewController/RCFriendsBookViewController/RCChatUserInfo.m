//
//  RCChatUserInfo.m
//  huiyi
//
//  Created by songhongshuai on 15/12/8.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "RCChatUserInfo.h"

@implementation RCChatUserInfo

@end
