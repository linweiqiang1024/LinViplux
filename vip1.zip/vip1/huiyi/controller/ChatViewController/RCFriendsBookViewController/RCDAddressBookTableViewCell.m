//
//  RCDAddressBookTableViewCell.m
//  RCloudMessage
//
//  Created by Liv on 15/3/13.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDAddressBookTableViewCell.h"
#import "UIImageView+WebCache.h"


@interface RCDAddressBookTableViewCell ()
@property (strong, nonatomic) UILabel *lblName;
@property (strong, nonatomic) UIImageView *imgvAva;
@end

@implementation RCDAddressBookTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.imgvAva];
        [self.contentView addSubview:self.lblName];
    }
    return self;
}

- (void)setUserInfo:(RCUserInfo *)userInfo
{
    if (userInfo) {
        [self.imgvAva sd_setImageWithURL:[NSURL URLWithString:userInfo.portraitUri] placeholderImage:[UIImage imageNamed:@"touxiang80"]];
        self.lblName.text = userInfo.name;
    }
}


- (UIImageView *)imgvAva
{
    if (!_imgvAva) {
        _imgvAva = [[UIImageView alloc]initWithFrame:CGRectMake(10, 7, 36, 36)];
        _imgvAva.backgroundColor = [UIColor whiteColor];
        _imgvAva.clipsToBounds = YES;
        _imgvAva.layer.cornerRadius = 4.f;
    }
    return _imgvAva;
}

- (UILabel *)lblName
{
    if (!_lblName) {
        _lblName = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.imgvAva.frame)+10, 0, ScreenWidth-CGRectGetMaxX(self.imgvAva.frame)-10, 55)];
        _lblName.font = YHUI(16);
        _lblName.backgroundColor = [UIColor clearColor];
    }
    return _lblName;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
