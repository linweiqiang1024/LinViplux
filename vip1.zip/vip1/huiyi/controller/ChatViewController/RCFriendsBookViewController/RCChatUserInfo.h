//
//  RCChatUserInfo.h
//  huiyi
//
//  Created by songhongshuai on 15/12/8.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <RongIMLib/RCUserInfo.h>

@interface RCChatUserInfo : RCUserInfo
@property (nonatomic) BOOL selected;

@end
