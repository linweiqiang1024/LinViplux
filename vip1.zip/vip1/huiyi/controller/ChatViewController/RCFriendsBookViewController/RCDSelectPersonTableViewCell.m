//
//  RCDSelectPersonTableViewCell.m
//  RCloudMessage
//
//  Created by Liv on 15/3/27.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDSelectPersonTableViewCell.h"
#import <RongIMLib/RCUserInfo.h>
#import "UIImageView+WebCache.h"
@interface RCDSelectPersonTableViewCell()
@property (strong, nonatomic) UIImageView *ivSelected;
@property (strong, nonatomic) UIImageView *ivAva;
@property (strong, nonatomic) UILabel     *lblName;
@end

@implementation RCDSelectPersonTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.ivSelected];
        [self.contentView addSubview:self.ivAva];
        [self.contentView addSubview:self.lblName];
    }
    return self;
}
- (void)setUserInfo:(RCUserInfo *)userInfo
{
    if (userInfo) {
        [self.ivAva sd_setImageWithURL:[NSURL URLWithString:userInfo.portraitUri] placeholderImage:[UIImage imageNamed:@"touxiang80"]];
        self.lblName.text = userInfo.name;
        
    }
}
- (UIImageView *)ivSelected
{
    if (!_ivSelected){
        _ivSelected = [[UIImageView alloc]initWithFrame:CGRectMake(9, 17 , 24, 24)];
        _ivSelected.backgroundColor = [UIColor whiteColor];
    }
    return _ivSelected;
}

- (UIImageView *)ivAva
{
    if (!_ivAva) {
        _ivAva = [[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.ivSelected.frame)+14, 7, 36, 36)];
        _ivAva.backgroundColor = [UIColor whiteColor];
        _ivAva.clipsToBounds = YES;
        _ivAva.layer.cornerRadius = 4.f;
    }
    return _ivAva;
}

- (UILabel *)lblName
{
    if (!_lblName) {
        _lblName = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(self.ivAva.frame)+10, 0, ScreenWidth-CGRectGetMaxX(self.ivSelected.frame)-10, 55)];
        _lblName.font = YHUI(16);
        _lblName.backgroundColor = [UIColor clearColor];
    }
    return _lblName;
}
-(void)awakeFromNib
{
    [super awakeFromNib];
}

-(void)setSelected:(BOOL)selected
{
    [super setSelected:selected];
    if (selected) {
        self.ivSelected.image = [self imagesNamedFromCustomBundle:@"selectFile"];
    }else{
        self.ivSelected.image = [self imagesNamedFromCustomBundle:@"unselect"];
    }
}
- (UIImage *)imagesNamedFromCustomBundle:(NSString *)imgName
{
    NSString *bundlePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"RongCloud.bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    NSString *img_path = [bundle pathForResource:imgName ofType:@"png"];
    return [UIImage imageWithContentsOfFile:img_path];
}
@end
