//
//  RCDSelectPersonViewController.m
//  RCloudMessage
//
//  Created by Liv on 15/3/27.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import "RCDSelectPersonViewController.h"
#import "RCDSelectPersonTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "RCDRCIMDataSource.h"
#import "ChatViewController.h"
#import "RCChatUserInfo.h"
#import "RCDataBaseManager.h"


@interface RCDSelectPersonViewController ()
@property (nonatomic,strong) NSMutableArray *newSelectedUsers;
@property (nonatomic,strong) UIButton *rightBtn;
@property (nonatomic,strong) UIBarButtonItem *rightButton;
@end

@implementation RCDSelectPersonViewController


-(void)viewDidLoad
{
    [super viewDidLoad];
    UIColor * color = [UIColor whiteColor];
    //这里我们设置的是颜色，还可以设置shadow等，具体可以参见api
    NSDictionary * dict = [NSDictionary dictionaryWithObject:color forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict ;
    self.title = @"选择联系人";
    //控制多选
    self.tableView.allowsMultipleSelection = YES;
    
    //rightBarButtonItem click event
    self.navigationItem.rightBarButtonItem = self.rightButton;
}
- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame = CGRectMake(0, 10, 65, 24);
        [_rightBtn.layer setCornerRadius:2.0f];
        [_rightBtn.layer setMasksToBounds:YES];
        [_rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_rightBtn setBackgroundImage:[self creatImageWithColol:RGBCOLOR(100, 198, 81) Size:_rightBtn.frame.size] forState:UIControlStateNormal];
        //[_rightBtn setBackgroundImage:[self creatImageWithColol:RGBCOLOR(110,152,112) Size:_rightBtn.frame.size] forState:UIControlStateSelected];
        [_rightBtn setTitle:@"确定" forState:UIControlStateNormal];
        [_rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //[_rightBtn setTitleColor:[UIColor colorWithHexString:@"#81ad82"] forState:UIControlStateSelected];
        _rightBtn.titleLabel.font = YHUI(16);
        [_rightBtn addTarget:self action:@selector(rightBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _rightBtn;
}
- (UIImage *)creatImageWithColol:(UIColor *)color Size:(CGSize)imageSize
{
    UIGraphicsBeginImageContextWithOptions(imageSize, 0, [UIScreen mainScreen].scale);
    [color set];
    UIRectFill(CGRectMake(0, 0, imageSize.width, imageSize.height));
    UIImage *pressedColorImg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return pressedColorImg;
}

- (void)rightBarButtonItemPressed:(id)btn
{
    NSArray *indexPaths = [self.tableView indexPathsForSelectedRows];
    //没有选择新的成员  只有单聊的2人不能创建讨论组
    if (_newSelectedUsers.count<=0){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"您尚未选择其他联系人!" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        return;
    }
    
    //get seleted users
    NSMutableArray *seletedUsers = [NSMutableArray new];
    for (NSIndexPath *indexPath in indexPaths) {
        NSString *key = [self.allKeys objectAtIndex:indexPath.section];
        NSArray *arrayForKey = [self.allFriends objectForKey:key];
        RCChatUserInfo *user = arrayForKey[indexPath.row];
//        user.selected = YES;
        RCUserInfo * info = [RCUserInfo new];
        info.name = user.name;
        info.userId = user.userId;
        info.portraitUri = user.portraitUri;
        [[RCIM sharedRCIM]refreshUserInfoCache:info withUserId:user.userId];
        [seletedUsers addObject:user];
    }
    //excute the clickDoneCompletion
    if (self.clickDoneCompletion) {
        self.clickDoneCompletion(self,self.newSelectedUsers);
    }
}
- (UIBarButtonItem *)rightButton
{
    if (!_rightButton) {
        _rightButton = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
        [_rightButton setTintColor:[UIColor whiteColor]];
    }
    return _rightButton;
}
- (NSMutableArray *)newSelectedUsers
{
    if (!_newSelectedUsers) {
        _newSelectedUsers = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _newSelectedUsers;
}
//override delegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55.f;
}


//override datasource
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellReuseIdentifier = @"RCDAddressBookSelectedCell";
    RCDSelectPersonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellReuseIdentifier];
    if (!cell) {
        cell = [[RCDSelectPersonTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellReuseIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell setUserInteractionEnabled:YES];
    NSString *key = [self.allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [self.allFriends objectForKey:key];
    
    RCChatUserInfo *user = (RCChatUserInfo *)arrayForKey[indexPath.row];
    if(user){
        cell.userInfo = user;
    }
    //设置选中状态
//    for (RCChatUserInfo *userInfo in self.seletedUsers) {
//        if ([user.userId isEqualToString:userInfo.userId]||userInfo.selected == YES) {
//            [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionBottom];
//            [cell setUserInteractionEnabled:NO];
//        }
//    }
//    if (user.selected == YES) {
//        [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionBottom];
//        [cell setUserInteractionEnabled:NO];
//    }
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return NO;
}

//override delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    RCDSelectPersonTableViewCell *cell = (RCDSelectPersonTableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
    NSString *key = [self.allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [self.allFriends objectForKey:key];
    RCChatUserInfo *user = arrayForKey[indexPath.row];
//    user.selected = YES;
    [self.friends enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        RCChatUserInfo *info = (RCChatUserInfo *)obj;
        if ([info.userId isEqualToString: user.userId]) {
//            info.selected = YES;
            [self.friends replaceObjectAtIndex:idx withObject:info];
        }
    }];
    [self.newSelectedUsers addObject:user];
    if (self.newSelectedUsers.count==0) {
        [self.rightBtn setTitle:@"确定" forState:UIControlStateNormal];
    }else{
        if (self.newSelectedUsers.count > 99) {
            [self.rightBtn setTitle:@"确定(99+)" forState:UIControlStateNormal ];
        }else{
            [self.rightBtn setTitle:[NSString stringWithFormat:@"确定(%ld)",(unsigned long)self.newSelectedUsers.count] forState:UIControlStateNormal ];
        }
    }
    [cell setSelected:YES];
    
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    RCDSelectPersonTableViewCell *cell = (RCDSelectPersonTableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
    NSString *key = [self.allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [self.allFriends objectForKey:key];
    RCChatUserInfo *user = (RCChatUserInfo *)arrayForKey[indexPath.row];
//    user.selected = NO;
    [self.newSelectedUsers enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        RCChatUserInfo *info = (RCChatUserInfo *)obj;
        if ([info.userId isEqualToString: user.userId]) {
            [self.newSelectedUsers removeObject:obj];
            if (self.newSelectedUsers.count==0) {
                [self.rightBtn setTitle:@"确定" forState:UIControlStateNormal];
            }else{
                if (self.newSelectedUsers.count >99) {
                    [self.rightBtn setTitle:@"确定(99+)" forState:UIControlStateNormal ];
                }else{
                    [self.rightBtn setTitle:[NSString stringWithFormat:@"确定(%ld)",(unsigned long)self.newSelectedUsers.count] forState:UIControlStateNormal];
                }
            }
        }
    }];
    [cell setSelected:NO];
}

@end
