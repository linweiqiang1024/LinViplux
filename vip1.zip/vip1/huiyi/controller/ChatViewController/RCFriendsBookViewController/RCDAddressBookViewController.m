//
//  RCDAddressBookViewController.m
//  RongCloud
//
//  Created by Liv on 14/11/11.
//  Copyright (c) 2014年 RongCloud. All rights reserved.
//

#import "RCDAddressBookViewController.h"
#import "UIImageView+WebCache.h"
#import <RongIMLib/RongIMLib.h>
#import <objc/runtime.h>
#import "RCDRCIMDataSource.h"
#import "pinyin.h"
#include <ctype.h>
#import "MySearchBar.h"
#import "RCChatUserInfo.h"
#import "RCDataBaseManager.h"
#import "FriendInfoViewController.h"
#import "RCDAddressBookTableViewCell.h"
@interface RCDAddressBookViewController ()<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>
{
    __block BOOL _isFreind;
}
//#字符索引对应的user object
@property (nonatomic,strong) NSMutableArray *tempOtherArr;
@property (nonatomic,strong) NSMutableArray *showDataList;
@property (nonatomic,strong) UIView         *tableHeadView;
@property (nonatomic,strong) UITextField    * userSearchBar;
@property (nonatomic,strong) UIButton *leftBtn;
@property (nonatomic,strong) UIBarButtonItem *leftButton;


@end

@implementation RCDAddressBookViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.tintColor = [UIColor blueColor];

    
}
- (void)dealloc{
    NSLog(@"aaaaaa");
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBar.translucent = NO ;
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.shadowImage = [[UIImage alloc] init];
//    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont boldSystemFontOfSize:18]};
    self.title = @"人脉";

    self.navigationItem.leftBarButtonItem = self.leftButton;
    [self.tableHeadView addSubview:self.userSearchBar];
    [self.view addSubview:self.tableHeadView];
    [self.view addSubview:self.tableView];
    self.tableView.sectionIndexBackgroundColor = [UIColor clearColor];
    [self getAllData];
}
- (void)leftBarButtonItemPressed:(UIButton *)btn
{
    if (self.navigationController.childViewControllers.count == 1) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.tableHeadView.frame) , ScreenWidth, ScreenHeight-64-CGRectGetMaxY(self.tableHeadView.frame))];
        _tableView.sectionHeaderHeight = 22.f;
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.tableFooterView = [UIView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}
- (UIView *)tableHeadView
{
    if (!_tableHeadView) {
        _tableHeadView = [[UIView alloc]initWithFrame:CGRectMake(0, 0 , ScreenWidth, 54)];
        _tableHeadView.backgroundColor = [UIColor whiteColor];
    }
    return _tableHeadView;
}

- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}

- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}

- (UITextField *)userSearchBar
{
    if (!_userSearchBar) {
        _userSearchBar = [[UITextField alloc]initWithFrame:CGRectMake(0, 0 , ScreenWidth, 54)];
        _userSearchBar.delegate = self;
        _userSearchBar.contentMode = UIViewContentModeLeft;
        _userSearchBar.placeholder = @"搜索";
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40 , 16)];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.image = [UIImage imageNamed:@"icon-seach"];
        _userSearchBar.leftView = imageView;
        _userSearchBar.leftViewMode = UITextFieldViewModeAlways;
        _userSearchBar.returnKeyType = UIReturnKeyDone;
        _userSearchBar.keyboardType =  UIKeyboardTypeDefault;
        _userSearchBar.font = YHUI(16);
        [_userSearchBar addTarget:self action:@selector(searchTextChange:) forControlEvents:UIControlEventEditingChanged];
        _userSearchBar.clearButtonMode = UITextFieldViewModeWhileEditing;
        _userSearchBar.backgroundColor = [UIColor whiteColor];
    }
    return _userSearchBar;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    textField.text = @"";
     self.showDataList = [NSMutableArray arrayWithArray:_friends];
    [self.view endEditing:YES];
    return YES;
}
- (NSMutableArray *)showDataList
{
    if (!_showDataList) {
        _showDataList = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _showDataList;
}

- (void)searchTextChange:(UITextField *)textField
{
    if (textField.text!=nil && textField.text.length>0) {
        [self.showDataList removeAllObjects];
        for (RCChatUserInfo *info in _friends) {
            if ([info.name rangeOfString:textField.text options:NSCaseInsensitiveSearch].length >0 ) {
                [self.showDataList addObject:info];
            }
        }
    }
    else
    {
        self.showDataList = [NSMutableArray arrayWithArray:_friends];
    }
    _allFriends = [self sortedArrayWithPinYinDic:self.showDataList];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
        
    });
}


//删除已选中用户
-(void) removeSelectedUsers:(NSArray *) selectedUsers
{
    for (RCChatUserInfo *user in selectedUsers) {
        
        [_friends enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            RCChatUserInfo *userInfo = obj;
            if ([user.userId isEqualToString:userInfo.userId]) {
                [_friends removeObject:obj];
            }
            
        }];
    }

}


/**
 *  initial data
 */
-(void) getAllData
{
    _keys = @[@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z",@"#"];
    _allFriends = [NSMutableDictionary new];
    _allKeys = [NSMutableArray new];
    _friends = [NSMutableArray arrayWithArray:[[RCDataBaseManager shareInstance]getAllFriends ] ];
    //缓存
//    [_friends addObjectsFromArray:[[RCDataBaseManager shareInstance]getAllFriends]];
    for (int index = 0; index < _friends.count; index++) {
        RCChatUserInfo *info = (RCChatUserInfo *)_friends[index];
        for (RCChatUserInfo *selectedInfo in self.seletedUsers) {
            //是好友  创建时必须多于2个人
            if ([info.userId isEqualToString:selectedInfo.userId]) {
//                info.selected = YES;
                [_friends replaceObjectAtIndex:index withObject:info];
                _isFreind = YES;
            }else{
                //不是好友创建时 必须多于1个人
                _isFreind = NO;
            }
        }
        
    }
    self.hideSectionHeader = NO;
    
    _allFriends = [self sortedArrayWithPinYinDic:_friends];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });


    [RCDDataSource syncFriendList:^(NSMutableArray * result) {
        [_friends removeAllObjects];
            _friends=result;
            for (int index = 0; index < _friends.count; index++) {
                RCChatUserInfo *info = (RCChatUserInfo *)_friends[index];
                for (RCChatUserInfo *selectedInfo in self.seletedUsers) {
                    //是好友  创建时必须多于2个人
                    if ([info.userId isEqualToString:selectedInfo.userId]) {
//                        info.selected = YES;
                        [_friends replaceObjectAtIndex:index withObject:info];
                        _isFreind = YES;
                    }else{
                        //不是好友创建时 必须多于1个人
                        _isFreind = NO;
                    }
                }
                
            }
            self.hideSectionHeader = NO;

            _allFriends = [self sortedArrayWithPinYinDic:_friends];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDataSource

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reusableCellWithIdentifier = @"RCDAddressBookCell";
    RCDAddressBookTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reusableCellWithIdentifier];
    if (!cell) {
        cell = [[RCDAddressBookTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reusableCellWithIdentifier];
    }
    NSString *key = [_allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [_allFriends objectForKey:key];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    RCChatUserInfo *user = arrayForKey[indexPath.row];
    if(user){
        cell.userInfo = user;
    }
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *key = [self.allKeys objectAtIndex:indexPath.section];
    NSArray *arrayForKey = [self.allFriends objectForKey:key];
    RCChatUserInfo *user = arrayForKey[indexPath.row];
    FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
    friendInfoVC.user_id = user.userId;
    [self.navigationController pushViewController:friendInfoVC animated:YES];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *key = [self.allKeys objectAtIndex:indexPath.section];
        NSArray *arrayForKey = [self.allFriends objectForKey:key];
        __block NSMutableArray *lastParam = [[NSMutableArray alloc]initWithCapacity:0];
        [lastParam addObjectsFromArray:arrayForKey];
        RCChatUserInfo *user = arrayForKey[indexPath.row];
        NSDictionary *params;
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"] length]==0) {
            params = @{@"user_id":@" ",@"friend_id":user.userId};
        }
        else{
            params = @{@"user_id":[[NSUserDefaults standardUserDefaults] objectForKey:@"user_id"],@"friend_id":user.userId};
        }
        [[Dialog Instance]showCenterProgressWithLabel:@"删除中..."];
        [MyDataService postPlatformContactDelfriend:params callback:^(id data) {
            [[Dialog Instance]hideProgress];
            NSLog(@"%@",[data JSONString]);
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
                if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
                    [tableView beginUpdates];
                    [lastParam removeObject:user];
                    [self.allFriends setObject:lastParam forKey:key];
                    [tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
                    [tableView  endUpdates];
                    
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                        [[RCDataBaseManager shareInstance]deleteFriendFromDB:user.userId];
                    });
                }
            }
            
        }];
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *key = [_allKeys objectAtIndex:section];
    
    NSArray *arr = [_allFriends objectForKey:key];

    return [arr count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    
    return [_allKeys count];
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55.f;
}
//pinyin index
- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    
    if (self.hideSectionHeader) {
        return nil;
    }
    return _allKeys;
    
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    NSString *key = [_allKeys objectAtIndex:section];
    return key;
}



#pragma mark - 拼音排序

/**
 *  汉字转拼音
 *
 *  @param hanZi 汉字
 *
 *  @return 转换后的拼音
 */
-(NSString *) hanZiToPinYinWithString:(NSString *)hanZi
{
    if(!hanZi) return nil;
    NSString *pinYinResult=[NSString string];
    for(int j=0;j<hanZi.length;j++){
        NSString *singlePinyinLetter=[[NSString stringWithFormat:@"%c",pinyinFirstLetter([hanZi characterAtIndex:j])] uppercaseString];
        pinYinResult=[pinYinResult stringByAppendingString:singlePinyinLetter];
        
    }
    
    return pinYinResult;

}


/**
 *  根据转换拼音后的字典排序
 *
 *  @param pinyinDic 转换后的字典
 *
 *  @return 对应排序的字典
 */
-(NSMutableDictionary *) sortedArrayWithPinYinDic:(NSArray *) friends
{
    NSMutableDictionary *returnDic = [NSMutableDictionary new];
    _tempOtherArr = [NSMutableArray new];
    BOOL isReturn = NO;
    
    for (NSString *key in _keys) {
        
        if ([_tempOtherArr count]) {
            isReturn = YES;
        }
        
        NSMutableArray *tempArr = [NSMutableArray new];
        for (RCChatUserInfo *user in friends) {
            
            NSString *pyResult = [self hanZiToPinYinWithString:user.name];
            NSString *firstLetter = [pyResult substringToIndex:1];
            if ([firstLetter isEqualToString:key]){
                [tempArr addObject:user];
            }
            
            if(isReturn) continue;
            char c = [pyResult characterAtIndex:0];
            if (isalpha(c) == 0) {
                [_tempOtherArr addObject:user];
            }
        }
        if(![tempArr count]) continue;
        [returnDic setObject:tempArr forKey:key];
        
    }
    if([_tempOtherArr count])
        [returnDic setObject:_tempOtherArr forKey:@"#"];
    
    
    _allKeys = [[returnDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        
        return [obj1 compare:obj2 options:NSNumericSearch];
    }];
    
    return returnDic;
}
@end
