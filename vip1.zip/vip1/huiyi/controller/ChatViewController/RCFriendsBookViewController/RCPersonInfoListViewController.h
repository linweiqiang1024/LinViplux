//
//  RCPersonInfoListViewController.h
//  huiyi
//
//  Created by songhongshuai on 16/1/14.
//  Copyright © 2016年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface RCPersonInfoListViewController : UIViewController

@end
