//
//  IMUsrMeetingListModel.h
//
//  Created by songhongshuai  on 15/12/1
//  Copyright (c) 2015 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface IMUsrMeetingListModel : NSObject <NSCoding, NSCopying>

@property (nonatomic, strong) NSString *meetingId;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *bmnum;
@property (nonatomic, strong) NSString *webbaoming;
@property (nonatomic, strong) NSString *yqxUrl;
@property (nonatomic, strong) NSString *userId;
@property (nonatomic, strong) NSString *imgUrl;
@property (nonatomic, strong) NSString *cnt;
@property (nonatomic, strong) NSArray *picList;
@property (nonatomic, strong) NSString *endDate;
@property (nonatomic, strong) NSString *isYqx;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *openstatus;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *createUserId;
@property (nonatomic, strong) NSString *webedit;
@property (nonatomic, strong) NSString *postersUrl;
@property (nonatomic, strong) NSString *approved;
@property (nonatomic, strong) NSString *receipted;
@property (nonatomic, strong) NSString *beginDate;

+ (instancetype)modelObjectWithDictionary:(NSDictionary *)dict;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)dictionaryRepresentation;

@end
