//
//  ChatListViewController.h
//  
//
//  Created by songhongshuai on 15/11/26.
//
//

#import <RongIMKit/RongIMKit.h>

@interface ChatListViewController : RCConversationListViewController

@end
