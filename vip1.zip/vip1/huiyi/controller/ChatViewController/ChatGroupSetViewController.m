//
//  ChatGroupSetViewController.m
//  huiyi
//
//  Created by songhongshuai on 15/12/2.
//  Copyright © 2015年 shs. All rights reserved.
//

#import "ChatGroupSetViewController.h"
#import "ChatSetingHeaderView.h"
#import "SevenSwitch.h"
#import "Utils.h"
#import "GroupListViewController.h"
#import "ChatListViewController.h"
#import "GruopUserViewController.h"
#import <RongIMLib/RCGroup.h>
#import "RCDataBaseManager.h"
#import "ChatSetingTableViewCell.h"
#import "FriendInfoViewController.h"
#import "New_SignUpInfoViewController.h"
@interface ChatGroupSetViewController ()<UIActionSheetDelegate,ChatSettingTableViewHeaderDelegate,SevenSwitchChangeValueDelegate,UIAlertViewDelegate>
@property (nonatomic,strong) UILabel              *titleView;
@property (nonatomic,strong) UIBarButtonItem      *leftButton;
@property (nonatomic,strong) UIButton             *leftBtn;
@property (nonatomic,strong) ChatSetingHeaderView *tableViewHeader;
@property (nonatomic,strong) UIView               *footView;
@property (nonatomic,strong) UIButton             *exitBtn;
@property (nonatomic,strong) NSArray              *dataSourceParam;
@property (nonatomic,strong) NSMutableArray       *usersParam;
@end

@implementation ChatGroupSetViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.backgroundColor = [UIColor colorWithHexString:@"#f0eff5"];
    self.navigationItem.titleView = self.titleView;
    self.navigationItem.leftBarButtonItem = self.leftButton;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.footView addSubview:self.exitBtn];
    self.tableView.tableFooterView = self.footView;
    [self getGroupDetailInfo];
}

- (NSMutableArray *)usersParam
{
    if (!_usersParam) {
        _usersParam = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _usersParam;
}
- (NSArray *)dataSourceParam
{
    if (!_dataSourceParam) {
        _dataSourceParam = [NSArray arrayWithObjects:@"置顶聊天", @"新消息提示", @"清空聊天记录", nil];
    }
    return _dataSourceParam;
}

- (UILabel *)titleView
{
    if (!_titleView) {
        _titleView = [[UILabel alloc]init];
        _titleView.frame = CGRectMake(100, 0, 120, 44);
        _titleView.backgroundColor = [UIColor clearColor];
        _titleView.text = @"设置";
        _titleView.textAlignment = NSTextAlignmentCenter;
        _titleView.font = [UIFont boldSystemFontOfSize:18];
        _titleView.textColor = [UIColor whiteColor];
        
    }
    return _titleView;
}
- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 44, 44);
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [_leftBtn addTarget:self action:@selector(leftBarButtonItemPressed:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _leftBtn;
}

- (UIBarButtonItem *)leftButton
{
    if (!_leftButton) {
        _leftButton = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
        [_leftButton setTintColor:[UIColor whiteColor]];
    }
    return _leftButton;
}

- (ChatSetingHeaderView *)tableViewHeader
{
    if (!_tableViewHeader) {
        _tableViewHeader = [[ChatSetingHeaderView alloc]init];
        _tableViewHeader.settingTableViewHeaderDelegate = self;
        _tableViewHeader.backgroundColor = [UIColor whiteColor];
    }
    return _tableViewHeader;
}
- (UIButton *)exitBtn
{
    if (!_exitBtn) {
        _exitBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _exitBtn.frame = CGRectMake(10, 20, ScreenWidth-20, 41);
        [_exitBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_exitBtn setTitle:@"删除并退出" forState:UIControlStateNormal];
        [_exitBtn setBackgroundColor:[UIColor colorWithHexString:@"#eb504f"]];
        [_exitBtn addTarget:self action:@selector(quitGruop) forControlEvents:UIControlEventTouchUpInside];
    }
    return _exitBtn;
}
- (UIView *)footView
{
    if (!_footView) {
        _footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 80)];
        _footView.backgroundColor = [UIColor colorWithHexString:@"#f0eff5"];
    }
    return _footView;
}
-(void)leftBarButtonItemPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)backToListView
{
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if ([vc isKindOfClass:[ChatListViewController class]] ) {
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshGroupList" object:nil];
                [self.navigationController popToViewController:vc animated:YES];
                return ;
            }
        }
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if ([vc isKindOfClass:[GroupListViewController class]]||[vc isKindOfClass:[New_SignUpInfoViewController class]] ) {
                [[NSNotificationCenter defaultCenter]postNotificationName:@"refreshGroupList" object:nil];
                [self.navigationController popToViewController:vc animated:YES];
                return;
            }
        }
    });
}
#pragma mark --UIAlertViewDelegate--
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"%ld",(long)buttonIndex);
    if (buttonIndex==1&&alertView.tag == 100) {
        if ([self.disGroupOwnerInfo.userId isEqualToString:[RCIMClient sharedRCIMClient].currentUserInfo.userId]) {
            [[Dialog Instance]showCenterProgressWithLabel:@"删群中..."];
            [MyDataService postPlatformContactOvergroup:@{@"group_id":self.targetId} callback:^(id data) {
                [[Dialog Instance]hideProgress];
                if ([data[@"code"]isEqualToString:@"200"]||[data[@"code"]isEqualToString:@"201"]) {
//                    [[RCIMClient sharedRCIMClient]removeConversation:ConversationType_GROUP targetId:self.targetId];
                    [self backToListView];
                }
            }];
        }else{
            [[Dialog Instance]showCenterProgressWithLabel:@"退群中..."];
            [MyDataService postPlatformContactLeavegroup:@{@"group_id":self.targetId} callback:^(id data) {
                [[Dialog Instance]hideProgress];
                if ([data[@"code"]isEqualToString:@"200"]||[data[@"code"]isEqualToString:@"201"]) {
//                    [[RCIMClient sharedRCIMClient]removeConversation:ConversationType_GROUP targetId:self.targetId];
                    [self backToListView];
                }
            }];
            
        }
    }
}
#pragma mark --退出群
- (void)quitGruop
{
    UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"提示！" message:@"是否退出并删除群" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alertView.tag = 100;
    [alertView show];

}
- (void)getGroupDetailInfo{
    NSLog(@"%@",self.targetId);
    NSDictionary *dic = @{@"group_id":self.targetId};
    [[Dialog Instance]showCenterProgressWithText:@"加载中"];
    [MyDataService postPlatformContactGroupmembers:dic calllback:^(id data) {
        [[Dialog Instance]hideProgress];
        NSLog(@"data = %@",[data JSONString]);
        if ([[data objectForKey: @"code"] isEqualToString: @"200"]) {
            if ([data[@"content"][@"members"]isKindOfClass:[NSArray class]]) {
                for(NSDictionary *sectionDic in [[data objectForKey:@"content"] objectForKey:@"members"]){
                    for(NSDictionary *dic in [sectionDic objectForKey:@"list"]){
                        RCUserInfo *useinfo = [RCUserInfo new];
                        useinfo.userId = [dic objectForKey:@"user_id"];
                        useinfo.name = [dic objectForKey:@"name"];
                        useinfo.portraitUri = [dic objectForKey:@"ico_url"];
                        [self.usersParam addObject:useinfo];
                    }
                }
                NSString *groupOwner = data[@"content"][@"groupinfo"][@"user_id"];
                self.disGroupOwnerInfo = [[RCDataBaseManager shareInstance]getUserByUserId:groupOwner];
                NSLog(@"%@",[RCIMClient sharedRCIMClient].currentUserInfo.userId);
                NSString *currentUserId;
                if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"login_company_code"] length]==0) {
                    currentUserId = [RCIMClient sharedRCIMClient].currentUserInfo.userId;
                }else{
                    currentUserId = [[[RCIMClient sharedRCIMClient].currentUserInfo.userId componentsSeparatedByString:@":"] objectAtIndex:0];
                }
                if ([currentUserId isEqualToString:groupOwner]) {
                    self.tableViewHeader.isAllowedDeleteMember = NO;
                }else
                    self.tableViewHeader.isAllowedDeleteMember = NO;
                self.tableViewHeader.isAllowedInviteMember = NO;
                self.tableViewHeader.users = self.usersParam;
                self.tableView.tableHeaderView = self.tableViewHeader;
                [self.tableView reloadData];
            }
        }
    }];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 43.5;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }else if (section == 1){
        return 3;
    }else
        return 0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return 20;
    }
    return 0;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuseIdentifier = @"reuseIdentifierCell";
    ChatSetingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[ChatSetingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    }
    cell.delegate = self;
    cell.indexPath = indexPath;
    if (indexPath.section == 0) {
        cell.nameLabel.text = [NSString stringWithFormat:@"全部群成员(%ld)",(unsigned long)self.usersParam.count];
        cell.switchBtn.hidden = YES;
        cell.rightIconImageView.hidden = NO;
    }
    if (indexPath.section == 1) {
        cell.nameLabel.text = self.dataSourceParam[indexPath.row];
        NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
        if (indexPath.row == 0) {//置顶
            if ([[def objectForKey:[NSString stringWithFormat:@"%@_GroupConversationToTop",self.targetId]]isEqualToString:@"1"] ) {
                cell.switchBtn.on = YES;
            }else{
                cell.switchBtn.on = NO;
            }
        }
        if (indexPath.row == 1) {//消息
            [[RCIMClient sharedRCIMClient] getConversationNotificationStatus:self.conversationType targetId:self.targetId success:^(RCConversationNotificationStatus nStatus) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (nStatus == DO_NOT_DISTURB) {
                        cell.switchBtn.on = YES;
                    }else{
                        cell.switchBtn.on = NO;
                    }
                });
            } error:^(RCErrorCode status) {
            }];
        }
        if (indexPath.row == 2) {
            cell.switchBtn.hidden = YES;
            cell.endCell = YES;
        }else{
            cell.switchBtn.hidden = NO;
        }
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        GruopUserViewController *userVC = [[GruopUserViewController alloc]init];
        userVC.members = _usersParam;
        userVC.conversationType = self.conversationType;
        [self.navigationController pushViewController:userVC animated:YES];
    }
    if (indexPath.row == self.dataSourceParam.count - 1) {
        UIActionSheet *sheet = [[UIActionSheet alloc]initWithTitle:@"是否清除记录" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"确定" otherButtonTitles:nil];
        [sheet showInView:self.view];
    }
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        [self clearHistoryMessage];
    }
}
- (void)clearHistoryMessage {
    BOOL isClear = [[RCIMClient sharedRCIMClient] clearMessages:self.conversationType targetId:self.targetId];
    
    //清除消息之后回调操作，例如reload 会话列表
    if (self.clearHistoryCompletion) {
        self.clearHistoryCompletion(isClear);
    }
}
#pragma mark --SevenSwitchChangeValueDelegate--
//修改按钮状态
- (void)changeValueWithState:(BOOL)state IndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0){
        //置顶
        if (state) {
            [[NSUserDefaults standardUserDefaults]setObject:@"1" forKey:[NSString stringWithFormat:@"%@_GroupConversationToTop",self.targetId]];

        }else{
            [[NSUserDefaults standardUserDefaults]setObject:@"0" forKey:[NSString stringWithFormat:@"%@_GroupConversationToTop",self.targetId]];

        }
        [[RCIMClient sharedRCIMClient]setConversationToTop:self.conversationType targetId:self.targetId isTop:state];
//        RCConversationModel *mode = [RCConversationModel alloc]ini
    }
    if(indexPath.row == 1){
        //消息提示
        [[RCIMClient sharedRCIMClient]setConversationNotificationStatus:self.conversationType targetId:self.targetId isBlocked:state success:^(RCConversationNotificationStatus nStatus) {
        } error:^(RCErrorCode status) {
        }];
    }
}
#pragma mark --ChatSettingTableViewHeaderDelegate--
//点击群成员的头像 ，添加，删除群成员
- (void)didTipHeaderClicked:(RCUserInfo *)userInfo IndexPath:(NSInteger)indexPath
{
    if (userInfo) {
        //跳转群成员详情页
        FriendInfoViewController *friendInfoVC = [[FriendInfoViewController alloc]init];
        friendInfoVC.isChatInfo = YES;
        friendInfoVC.user_id = userInfo.userId;
        [self.navigationController pushViewController:friendInfoVC animated:YES];
    }else{
        if (self.tableViewHeader.isAllowedInviteMember&&self.tableViewHeader.isAllowedDeleteMember){
            if (indexPath == self.usersParam.count) {
                //添加动作
            }
            if (indexPath == self.usersParam.count + 1) {
                //删除动作
            }
        }
        if (self.tableViewHeader.isAllowedDeleteMember^self.tableViewHeader.isAllowedInviteMember) {
            if (self.tableViewHeader.isAllowedInviteMember) {
                //添加
                
            }
            if (self.tableViewHeader.isAllowedDeleteMember) {
                //删除
                
                self.tableViewHeader.showDeleteTip = !self.tableViewHeader.showDeleteTip;
            }
        }
    }
    
    
}
//删除群成员
- (void)deleteTipButtonClicked:(NSInteger )index
{
    [[Dialog Instance]showCenterProgressWithLabel:@"正在删除成员..."];
    RCUserInfo *info = (RCUserInfo *)self.usersParam[index];
    NSString *member_id = [Utils formatUserId:info.userId];
    NSDictionary *params  = @{@"group_id":self.targetId,@"member_id":member_id};
    [MyDataService postPlatformContactCelgroupmember:params callback:^(id data) {
        [[Dialog Instance] hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self.usersParam removeObjectAtIndex:index];
                    self.tableViewHeader.users = self.usersParam;
                });
            }else {
                [Dialog toastCenter:data[@"code"]];
            }
        }
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
