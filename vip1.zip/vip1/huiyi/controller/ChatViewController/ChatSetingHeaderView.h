//
//  ChatSetingHeaderView.h
//  huiyi
//
//  Created by songhongshuai on 15/12/3.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
@class RCUserInfo;
@class ChatSetingHeaderView;

@protocol ChatSettingTableViewHeaderDelegate <NSObject>

@optional
/**
 *  设置选中item的回调操作
 *
 *  @param settingTableViewHeader   settingTableViewHeader description
 *  @param indexPathForSelectedItem indexPathForSelectedItem description
 *  @param users users description
 */
- (void)settingTableViewHeader:(ChatSetingHeaderView *)settingTableViewHeader
       indexPathOfSelectedItem:(NSIndexPath *)indexPathOfSelectedItem
            allTheSeletedUsers:(NSArray *)users;

/**
 *  点击删除的回调
 *
 *  @param indexPath 点击索引
 */
- (void)deleteTipButtonClicked:(NSInteger )index;

/**
 *  点击头像的回调
 *
 *  @param userId 用户id
 */
- (void)didTipHeaderClicked:(RCUserInfo *)userInfo IndexPath:(NSInteger)indexPath;

@end

@interface ChatSetingHeaderView : UIView

/**
 *  showDeleteTip
 */
@property (nonatomic, assign) BOOL                               showDeleteTip;

/**
 *  isAllowedDeleteMember
 */
@property (nonatomic, assign) BOOL                               isAllowedDeleteMember;

/**
 *  isAllowedInviteMember
 */
@property (nonatomic, assign) BOOL                               isAllowedInviteMember;

/**
 *  call back
 */
@property (weak, nonatomic  ) id<ChatSettingTableViewHeaderDelegate> settingTableViewHeaderDelegate;
/**
 *  contains the RCUserInfo
 */
@property (strong, nonatomic) NSMutableArray                     *users;
@property (strong, nonatomic) RCUserInfo                         *creator;
@end
