//
//  ShowUserLocationViewController.h
//  huiyi
//
//  Created by songhongshuai on 15/12/2.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "BMapKit.h"
@interface ShowUserLocationViewController : UIViewController
@property(nonatomic, assign) CLLocationCoordinate2D location;

@end
