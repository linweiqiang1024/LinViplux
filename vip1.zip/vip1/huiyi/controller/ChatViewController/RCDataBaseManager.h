//
//  RCDataBaseManager.h
//  RCloudMessage
//
//  Created by 杜立召 on 15/6/3.
//  Copyright (c) 2015年 RongCloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <RongIMKit/RongIMKit.h>


@interface RCDataBaseManager : NSObject

+ (RCDataBaseManager*)shareInstance;

// 创建用户存储表
- (void)CreateUserTable;

// 添加普通账号缓存
- (void)insertUserIDToDB:(NSString*)userId PassWord:(NSString *)passWord;
// 获取普通账号缓存列表
- (NSArray *)getUserIDList;
// 移除普通账号的缓存
- (void)removeLoginUserID:(NSString *)userId;

// 添加手机账号的缓存
- (void)insertPhoneNumToDB:(NSString*)phoneNum;
// 获取手机账号缓存列表
- (NSArray *)getPhoneNumList;
// 移除普通账号的缓存
- (void)removePhoneNum:(NSString *)phoneNum;

// 添加企业号的缓存
- (void)insertCompanyCodeToDB:(NSString*)companyCode;
// 获取企业号缓存列表
- (NSArray *)getCompanyCodeList;
// 移除企业号的缓存
- (void)removeCompanyCode:(NSString *)companyCode;

// 添加讨论组成员信息
- (void)insertDisCussionUserToDB:(RCUserInfo*)user DiscussionId:(NSString *)discussionId;
// 获取讨论组成员列表
- (NSArray *)getUserListWithDiscussionId:(NSString *)discussionId;
// 清空讨论组缓存数据
- (void)clearDiscussionUsersData;

// 添加黑名单列表
- (void)insertBlackListToDB:(RCUserInfo*)user;
// 获取黑名单列表
- (NSArray *)getBlackList;
// 移除黑名单列表
- (void)removeBlackList:(NSString *)userId;
// 清空黑名单缓存数据
- (void)clearBlackListData;

// 添加用户信息
- (void)insertUserToDB:(RCUserInfo*)user;
// 获取用户信息
- (RCUserInfo*)getUserByUserId:(NSString*)userId;
// 获取所有用户信息
- (NSArray *)getAllUserInfo;
// 删除用户信息
- (void)deleteUserFromDB:(NSString *)userId;

// 存储群组信息
- (void)insertGroupToDB:(RCGroup *)group;
// 获取群组信息
- (RCGroup*)getGroupByGroupId:(NSString*)groupId;
// 获取所有群组信息
- (NSArray *)getAllGroup;
// 删除群组信息
- (void)deleteGroupsDataFromDB:(RCGroup *)group;
// 清空群组缓存数据
- (void)clearGroupsData;

// 存储好友信息
- (void)insertFriendToDB:(RCUserInfo *)friends;
// 获取所有好友信息
// RCUserInfo
- (NSArray *)getAllFriends;
// 获取好友信息
- (RCUserInfo *)getFriendFromDB:(NSString *)userId;
// 清空好友缓存数据
- (void)clearFriendsData;
// 删除好友信息
- (void)deleteFriendFromDB:(NSString *)userId;

@end
