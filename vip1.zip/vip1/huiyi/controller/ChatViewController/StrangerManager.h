//
//  StrangerManager.h
//  huiyi
//
//  Created by songhongshuai on 16/1/8.
//  Copyright © 2016年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  按钮点击
 *
 *  @param tag 1 屏蔽 ，2 添加
 */
typedef void (^strangerManager)(UIButton *btn);
@interface StrangerManager : UIView
@property (weak, nonatomic) IBOutlet UIButton *shieldBtn;
@property (weak, nonatomic) IBOutlet UIButton *addFriendBtn;
@property (nonatomic,copy)strangerManager strangerManagerCompletion;
@end
