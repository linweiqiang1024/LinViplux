//
//  RCChatInfoManager.h
//  huiyi
//
//  Created by songhongshuai on 15/12/7.
//  Copyright © 2015年 shs. All rights reserved.
//

#import <Foundation/Foundation.h>

@class RCGroup;
@class RCUserInfo;
@interface RCChatInfoManager : NSObject
+(instancetype)shareInstance;
//根据id获取单个群组
-(void) getGroupByID:(NSString *) groupID
   successCompletion:(void (^)(RCGroup *group)) completion;
-(void) getUseInfoByID:(NSString *) userID
   successCompletion:(void (^)(RCUserInfo  *userInfo)) completion;
- (UIImage *)imagesNamedFromCustomBundle:(NSString *)imgName;
@end
