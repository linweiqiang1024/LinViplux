//
//  ChatListViewController.m
//  
//
//  Created by songhongshuai on 15/11/26.
//
//

#import "ChatListViewController.h"
#import "MyNoneContentView.h"
#import "RCChatUserInfo.h"
#import "RCDRCIMDataSource.h"
#import "ChatViewController.h"
#import "RCDSelectPersonViewController.h"


@interface ChatListViewController ()
@property (nonatomic,strong) MyNoneContentView *tableViewNoneView;
@property (nonatomic,strong)UIButton *leftBtn;
@property (nonatomic,strong)UIButton *rightBtn;


@property (nonatomic,strong)NSMutableArray * usersParam;

@end

@implementation ChatListViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (NSMutableArray *)usersParam{
    if (!_usersParam) {
        _usersParam = [NSMutableArray arrayWithCapacity:0];
    }
    return _usersParam;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [[UINavigationBar appearance] setBarTintColor:[UIColor colorWithHexString:@"#17b4EB"]];
    [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"navBGImage"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
//    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont boldSystemFontOfSize:18]};
    self.title = @"消息";
    self.conversationListTableView.tableFooterView = [[UIView alloc]init];
    [self setDisplayConversationTypes:@[@(ConversationType_PRIVATE),@(ConversationType_DISCUSSION), @(ConversationType_GROUP)]];
    self.emptyConversationView.backgroundColor = [UIColor whiteColor];
    self.emptyConversationView.frame = CGRectMake(0, 64, ScreenWidth, ScreenHeight-64);
    [self.emptyConversationView addSubview:self.tableViewNoneView];
    [self.navigationItem.rightBarButtonItem.customView setHidden:YES];
    UIBarButtonItem *leftBtnItem = [[UIBarButtonItem alloc]initWithCustomView:self.leftBtn];
    self.navigationItem.leftBarButtonItem = leftBtnItem;
    UIBarButtonItem *rightBtnItem = [[UIBarButtonItem alloc]initWithCustomView:self.rightBtn];
    self.navigationItem.rightBarButtonItem = rightBtnItem;
}
-(void)onSelectedTableRow:(RCConversationModelType)conversationModelType conversationModel:(RCConversationModel *)model atIndexPath:(NSIndexPath *)indexPath
{
    ChatViewController *_conversationVC = [[ChatViewController alloc] init];
    _conversationVC.conversationType = model.conversationType;
    _conversationVC.targetId = model.targetId;
    _conversationVC.userName = model.conversationTitle;
    _conversationVC.chatUserName = model.conversationTitle;
//    _conversationVC.conversation = model;
    _conversationVC.unReadMessage = model.unreadMessageCount;
    [self.navigationController pushViewController:_conversationVC animated:YES];
    
}
- (void)addChatMember{
    [self.usersParam removeAllObjects];
    RCChatUserInfo *info = [RCChatUserInfo new];
    info.selected = YES;
    info.userId = [RCIMClient sharedRCIMClient].currentUserInfo.userId;
    info.name = [RCIMClient sharedRCIMClient].currentUserInfo.name;
    info.portraitUri = [RCIMClient sharedRCIMClient].currentUserInfo.portraitUri;
    [self.usersParam addObject:info];
    
    RCDSelectPersonViewController* selectPersonVC = [[RCDSelectPersonViewController alloc]init];
    [selectPersonVC setSeletedUsers:self.usersParam];
    //设置回调
    selectPersonVC.clickDoneCompletion = ^(RCDSelectPersonViewController* selectPersonViewController, NSArray* selectedUsers) {
        if (selectedUsers && selectedUsers.count) {
            if (selectedUsers.count == 1) {
                
            }
            [self.usersParam addObjectsFromArray:selectedUsers];
            [self createDiscussionOrInvokeMemberWithSelectedUsers:self.usersParam Controller:selectPersonViewController];
        }
    };
    [self.navigationController pushViewController:selectPersonVC animated:YES];
}

#pragma mark - private method
- (void)createDiscussionOrInvokeMemberWithSelectedUsers:(NSArray*)selectedUsers Controller:(UIViewController *)vc
{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSUInteger _count = [selectedUsers count];
        NSMutableString *discussionTitle = [NSMutableString string];
        if (_count > 2) {
            NSMutableArray *userIdList = [NSMutableArray new];
            [RCDDataSource getUserInfoWithUserId:[RCIMClient sharedRCIMClient].currentUserInfo.userId completion:^(RCUserInfo *userInfo) {
                for (int i=0; i<_count; i++) {
                    RCUserInfo *_userInfo = (RCUserInfo *)selectedUsers[i];
                    [discussionTitle appendString:[NSString stringWithFormat:@"%@%@", _userInfo.name,@","]];
                    [userIdList addObject:_userInfo.userId];
                    if (i==_count-1) {
                        [discussionTitle replaceCharactersInRange:NSMakeRange(discussionTitle.length-1, 1) withString:@" "];
                        [[RCIMClient sharedRCIMClient] createDiscussion:discussionTitle userIdList:userIdList success:^(RCDiscussion *discussion) {
                            
                            dispatch_async(dispatch_get_main_queue(), ^{
                                [discussionTitle deleteCharactersInRange:NSMakeRange(discussionTitle.length - 1, 1)];
//                                self.titleView.text = discussionTitle;
                                ChatViewController  *chat =[[ChatViewController alloc]init];
                                chat.targetId                      = discussion.discussionId;
                                chat.chatUserName                    = discussion.discussionName;
                                chat.conversationType              = ConversationType_DISCUSSION;
                                chat.title                         = discussionTitle;
                                [vc.navigationController  pushViewController:chat animated:YES];
                            });
                        } error:^(RCErrorCode status) {
                        }];
                        
                    }
                }
            }];
        }else if(selectedUsers.count == 2 ){
            for (RCChatUserInfo *userInfo in selectedUsers) {
                
                
                RCUserInfo *_userInfo = (RCUserInfo *)userInfo;
                if (![_userInfo.userId isEqualToString:[RCIMClient sharedRCIMClient].currentUserInfo.userId ]) {
                    ChatViewController* chat = [[ChatViewController alloc]init];
                    chat.targetId = _userInfo.userId;
                    chat.conversationType = ConversationType_PRIVATE;
                    chat.chatUserName = _userInfo.name;
                    [vc.navigationController  pushViewController:chat animated:YES];
                }
            }
        }
    });
}


- (void)backClick{
    [self.navigationController popViewControllerAnimated:YES];
}
- (UIButton *)leftBtn
{
    if (!_leftBtn) {
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _leftBtn.frame = CGRectMake(0, 0, 33, 30);
        if (IOS7) {
            _leftBtn.imageEdgeInsets = UIEdgeInsetsMake((30-20.5)/2-2, -19, 0, 0);
        }
        [_leftBtn setImage:[UIImage imageNamed:@"backImage"] forState:UIControlStateNormal];
        [_leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_leftBtn addTarget:self action:@selector(backClick) forControlEvents:UIControlEventTouchUpInside];
        _leftBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    }
    return _leftBtn;
}
- (UIButton *)rightBtn
{
    if (!_rightBtn) {
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _rightBtn.frame = CGRectMake(0, 0, 33, 30);
        [_rightBtn setImage:[UIImage imageNamed:@"add_chat_meb"] forState:UIControlStateNormal];
        [_rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_rightBtn addTarget:self action:@selector(addChatMember) forControlEvents:UIControlEventTouchUpInside];
        _rightBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    }
    return _rightBtn;
}
- (MyNoneContentView*)tableViewNoneView
{
    if (!_tableViewNoneView) {
        _tableViewNoneView = [[MyNoneContentView alloc]init];
        _tableViewNoneView.frame = CGRectMake(0, 0, ScreenWidth,ScreenHeight-64);
        _tableViewNoneView.backgroundColor = [UIColor whiteColor];
        _tableViewNoneView.imageView.image = [UIImage imageNamed:@"no_message"];
        _tableViewNoneView.noneLabel.text = @"还没有消息哦";
        _tableViewNoneView.otherLabel.text = @"快去跟你的伙伴聊一聊";//副标题
    }
    return _tableViewNoneView;
}
- (void)refreshConversationTableViewIfNeeded
{
    [super refreshConversationTableViewIfNeeded];
}
@end
