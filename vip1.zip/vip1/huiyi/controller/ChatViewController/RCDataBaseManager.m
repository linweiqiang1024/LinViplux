//
//  RCDataBaseManager.m
//  RCloudMessage
//
//  Created by 杜立召 on 15/6/3.
//  Copyright (c) 2015年 dlz. All rights reserved.
//

#import "RCDataBaseManager.h"
#import "DBHelper.h"

@implementation RCDataBaseManager

static NSString * const discussionUsersTableName = @"DISCUSSIONUSERTABLE";
static NSString * const userTableName = @"USERTABLE";
static NSString * const groupTableName = @"GROUPTABLEV2";
static NSString * const friendTableName = @"FRIENDTABLE";
static NSString * const blackTableName = @"BLACKTABLE";
static NSString * const userIdName = @"USERIDTABLE";
static NSString * const phoneNumName = @"USERPHONETABLE";
static NSString * const companyCodeName = @"COMPANYCODETABLE";

+ (RCDataBaseManager*)shareInstance
{
    static RCDataBaseManager* instance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        instance = [[[self class] alloc] init];
        [instance CreateUserTable];
    });
    return instance;
}

// 创建用户存储表
- (void)CreateUserTable
{
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return;
    }
    [queue inDatabase:^(FMDatabase *db) {
        
        if (![DBHelper isTableOK:userIdName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE USERIDTABLE (id integer PRIMARY KEY autoincrement, password text,userid text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_usernum ON USERIDTABLE(userid);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK:phoneNumName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE USERPHONETABLE (id integer PRIMARY KEY autoincrement, phonenum text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_phonenum ON USERPHONETABLE(phonenum);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK:companyCodeName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE COMPANYCODETABLE(id integer PRIMARY KEY autoincrement, companycode text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_companycode ON COMPANYCODETABLE(companycode);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK: userTableName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE USERTABLE (id integer PRIMARY KEY autoincrement, userid text,name text, portraitUri text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_userid ON USERTABLE(userid);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK: discussionUsersTableName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE DISCUSSIONUSERTABLE (id integer PRIMARY KEY autoincrement, userid text,name text, portraitUri text, discussionId text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_discussionId ON DISCUSSIONUSERTABLE(discussionId);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK: groupTableName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE GROUPTABLEV2 (id integer PRIMARY KEY autoincrement, groupId text,name text, portraitUri text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_groupid ON GROUPTABLEV2(groupId);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK: friendTableName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE FRIENDTABLE (id integer PRIMARY KEY autoincrement, userid text,name text, portraitUri text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_friendId ON FRIENDTABLE(userid);";
            [db executeUpdate:createIndexSQL];
        }
        
        if (![DBHelper isTableOK: blackTableName withDB:db]) {
            NSString *createTableSQL = @"CREATE TABLE BLACKTABLE (id integer PRIMARY KEY autoincrement, userid text,name text, portraitUri text)";
            [db executeUpdate:createTableSQL];
            NSString *createIndexSQL=@"CREATE unique INDEX idx_blackId ON BLACKTABLE(userid);";
            [db executeUpdate:createIndexSQL];
        }
    }];
}

// 添加普通账号的缓存
- (void)insertUserIDToDB:(NSString*)userId PassWord:(NSString *)passWord
{
    NSString *insertSql = @"REPLACE INTO USERIDTABLE (password, userid) VALUES (?, ?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,passWord,userId];
    }];
}

// 获取普通账号缓存列表
- (NSArray *)getUserIDList
{
    NSMutableArray *allBlackList = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:[NSString stringWithFormat:@"SELECT * FROM USERIDTABLE"]];
        while ([rs next]) {
            [allBlackList addObject:@{@"usernum":[rs stringForColumn:@"userid"],@"password":[rs stringForColumn:@"password"]}];
        }
        [rs close];
    }];
    return allBlackList;
}

// 移除普通账号的缓存
- (void)removeLoginUserID:(NSString *)userId
{
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue == nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:@"DELETE FROM USERIDTABLE WHERE userid=?",[NSString stringWithFormat:@"%@",userId]];
    }];
}

// 添加手机账号的缓存
- (void)insertPhoneNumToDB:(NSString*)phoneNum
{
    NSString *insertSql = @"REPLACE INTO USERPHONETABLE (phonenum) VALUES (?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,phoneNum];
    }];
}

// 获取手机账号缓存列表
- (NSArray *)getPhoneNumList
{
    NSMutableArray *allBlackList = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:[NSString stringWithFormat:@"SELECT * FROM USERPHONETABLE"]];
        while ([rs next]) {
            [allBlackList addObject:[rs stringForColumn:@"phonenum"]];
        }
        [rs close];
    }];
    return allBlackList;
}

// 移除手机账号的缓存
- (void)removePhoneNum:(NSString *)phoneNum
{
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:@"DELETE FROM USERPHONETABLE WHERE phonenum=?",phoneNum];
    }];
}

// 添加企业号的缓存
- (void)insertCompanyCodeToDB:(NSString*)companyCode
{
    NSString *insertSql = @"REPLACE INTO COMPANYCODETABLE (companycode) VALUES (?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,companyCode];
    }];
}

// 获取企业号缓存列表
- (NSArray *)getCompanyCodeList
{
    NSMutableArray *allBlackList = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:[NSString stringWithFormat:@"SELECT * FROM COMPANYCODETABLE"]];
        while ([rs next]) {
            [allBlackList addObject:[rs stringForColumn:@"companycode"]];
        }
        [rs close];
    }];
    return allBlackList;
}

// 移除企业号的缓存
- (void)removeCompanyCode:(NSString *)companyCode
{
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:@"DELETE FROM COMPANYCODETABLE WHERE companycode=?",companyCode];
    }];
}

// 添加讨论组成员信息
- (void)insertDisCussionUserToDB:(RCUserInfo*)user DiscussionId:(NSString *)discussionId
{
    NSString *insertSql = @"REPLACE INTO DISCUSSIONUSERTABLE (userid, name, portraitUri, discussionId) VALUES (?, ?, ?, ?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,user.userId,user.name,user.portraitUri,discussionId];
    }];
}

// 获取讨论组成员列表
- (NSArray *)getUserListWithDiscussionId:(NSString *)discussionId{
    NSMutableArray *allBlackList = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:[NSString stringWithFormat:@"SELECT * FROM DISCUSSIONUSERTABLE where discussionId = %@",discussionId]];
        while ([rs next]) {
            RCUserInfo *model = [[RCUserInfo alloc] init];
            model.userId = [rs stringForColumn:@"userid"];
            model.name = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
            [allBlackList addObject:model];
        }
        [rs close];
    }];
    return allBlackList;
}

// 清空讨论组缓存数据
- (void)clearDiscussionUsersData
{
    NSString *deleteSql = @"DELETE FROM DISCUSSIONUSERTABLE";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 添加黑名单列表
- (void)insertBlackListToDB:(RCUserInfo*)user{
    NSString *insertSql = @"REPLACE INTO BLACKTABLE (userid, name, portraitUri) VALUES (?, ?, ?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,user.userId,user.name,user.portraitUri];
    }];
}

// 获取黑名单列表
- (NSArray *)getBlackList{
    NSMutableArray *allBlackList = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM BLACKTABLE"];
        while ([rs next]) {
            RCUserInfo *model = [[RCUserInfo alloc] init];
            model.userId = [rs stringForColumn:@"userid"];
            model.name = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
            [allBlackList addObject:model];
        }
        [rs close];
    }];
    return allBlackList;
}

// 移除黑名单列表
- (void)removeBlackList:(NSString *)userId{
    NSString *deleteSql =[NSString stringWithFormat: @"DELETE FROM BLACKTABLE WHERE userid=%@",userId];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 清空黑名单缓存数据
- (void)clearBlackListData
{
    NSString *deleteSql = @"DELETE FROM BLACKTABLE";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 添加用户信息
- (void)insertUserToDB:(RCUserInfo*)user
{
    NSString *insertSql = @"REPLACE INTO USERTABLE (userid, name, portraitUri) VALUES (?, ?, ?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,user.userId,user.name,user.portraitUri];
    }];
}

// 获取用户信息
- (RCUserInfo*)getUserByUserId:(NSString*)userId
{
    __block RCUserInfo *model = nil;
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM USERTABLE where userid = ?",userId];
        while ([rs next]) {
            model = [[RCUserInfo alloc] init];
            model.userId = [rs stringForColumn:@"userid"];
            model.name = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
        }
        [rs close];
    }];
    return model;
}

// 获取所有用户信息
- (NSArray *)getAllUserInfo
{
    NSMutableArray *allUsers = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM USERTABLE"];
        while ([rs next]) {
            RCUserInfo *model;
            model = [[RCUserInfo alloc] init];
            model.userId = [rs stringForColumn:@"userid"];
            model.name = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
            [allUsers addObject:model];
        }
        [rs close];
    }];
    return allUsers;
}

// 删除用户信息
- (void)deleteUserFromDB:(NSString *)userId
{
    NSString *deleteSql =[NSString stringWithFormat: @"DELETE FROM USERTABLE WHERE userid=%@",userId];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 存储群组信息
- (void)insertGroupToDB:(RCGroup *)group
{
    if(group == nil || [group.groupId length]<1)
    {
        return;
    }
    NSString *insertSql = @"REPLACE INTO GROUPTABLEV2 (groupId, name,portraitUri) VALUES (?,?,?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,group.groupId, group.groupName,group.portraitUri];
    }];
}

// 获取群组信息
- (RCGroup*)getGroupByGroupId:(NSString*)groupId
{
    __block RCGroup *model = nil;
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM GROUPTABLEV2 where groupId = ?",groupId];
        while ([rs next]) {
            model = [[RCGroup alloc] init];
            model.groupId = [rs stringForColumn:@"groupId"];
            model.groupName = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
        }
        [rs close];
    }];
    return model;
}

// 获取所有群组信息
- (NSArray *)getAllGroup
{
    NSMutableArray *allUsers = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM GROUPTABLEV2 ORDER BY groupId"];
        while ([rs next]) {
            RCGroup *model;
            model = [[RCGroup alloc] init];
            model.groupId = [rs stringForColumn:@"groupId"];
            model.groupName = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
            [allUsers addObject:model];
        }
        [rs close];
    }];
    for (int i = 0; i < allUsers.count/2.0; i++) {
        [allUsers exchangeObjectAtIndex:i withObjectAtIndex:allUsers.count-1-i];
    }
    return allUsers;
}

// 删除群组信息
- (void)deleteGroupsDataFromDB:(RCGroup *)group
{
    NSString *deleteSql =[NSString stringWithFormat: @"DELETE FROM GROUPTABLEV2 WHERE groupId=%@",group.groupId];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 清空群组缓存数据
-(void)clearGroupsData
{
    NSString *deleteSql = @"DELETE FROM GROUPTABLEV2";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 存储好友信息
- (void)insertFriendToDB:(RCUserInfo *)friend
{
    NSString *insertSql = @"REPLACE INTO FRIENDTABLE (userid, name, portraitUri) VALUES (?, ?, ?)";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:insertSql,friend.userId, friend.name, friend.portraitUri];
    }];
}

// 获取所有好友信息
// RCUserInfo
- (NSArray *)getAllFriends
{
    NSMutableArray *allUsers = [NSMutableArray new];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM FRIENDTABLE"];
        while ([rs next]) {
            RCUserInfo *model;
            model = [[RCUserInfo alloc] init];
            model.userId = [rs stringForColumn:@"userid"];
            model.name = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
            [allUsers addObject:model];
        }
        [rs close];
    }];
    return allUsers;
}

// 获取好友信息
- (RCUserInfo *)getFriendFromDB:(NSString *)userId
{
    __block RCUserInfo *model = nil;
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    [queue inDatabase:^(FMDatabase *db) {
        FMResultSet *rs = [db executeQuery:@"SELECT * FROM FRIENDTABLE where userid = ?",userId];
        while ([rs next]) {
            model = [[RCUserInfo alloc] init];
            model.userId = [rs stringForColumn:@"userid"];
            model.name = [rs stringForColumn:@"name"];
            model.portraitUri = [rs stringForColumn:@"portraitUri"];
        }
        [rs close];
    }];
    return model;
}

// 清空好友缓存数据
- (void)clearFriendsData
{
    NSString *deleteSql = @"DELETE FROM FRIENDTABLE";
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

// 删除好友信息
- (void)deleteFriendFromDB:(NSString *)userId;
{
    NSString *deleteSql =[NSString stringWithFormat: @"DELETE FROM FRIENDTABLE WHERE userid=%@",userId];
    FMDatabaseQueue *queue = [DBHelper getDatabaseQueue];
    if (queue==nil) {
        return ;
    }
    [queue inDatabase:^(FMDatabase *db) {
        [db executeUpdate:deleteSql];
    }];
}

@end
