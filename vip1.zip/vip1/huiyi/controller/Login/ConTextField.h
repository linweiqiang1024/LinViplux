//
//  ConTextField.h
//  huiyi
//
//  Created by qstx1 on 14-6-24.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConTextField : UITextField

@end
