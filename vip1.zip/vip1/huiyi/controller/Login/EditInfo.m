//
//  EditInfo.m
//  ChannelFive
//
//  Created by qstx2 on 14-1-3.
//  Copyright (c) 2014年 jxz. All rights reserved.
//

#import "EditInfo.h"

@implementation EditInfo

+ (NSString *)getPlistPath {
    //获取路径对象
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //获取完整路径
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *plistPath = [documentsDirectory stringByAppendingPathComponent:@"editInfo.plist"];
    return plistPath;
}

+ (NSString *)getPlistPaths {
    //获取路径对象
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    //获取完整路径
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *plistPath = [documentsDirectory stringByAppendingPathComponent:@"editInfos.plist"];
    return plistPath;
}

+ (NSMutableDictionary *)plistData {
    NSString *path = [self getPlistPath];
    NSMutableDictionary *dictplist = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
    if (![[NSFileManager defaultManager]fileExistsAtPath:path]) {
        dictplist = [[NSMutableDictionary alloc ] init];
        //设置属性值
        //消息开关
        [dictplist setObject:@"on" forKey:@"message"];
        //首页中的类型缓存（数据库中存不了，暂时就存这里了）
        [dictplist setObject:@"" forKey:@"typeString"];
        //登陆后的cookies
        //[dictplist setObject:@"" forKey:@"cookies"];
        //写入文件
        [dictplist writeToFile:path atomically:YES];
    }
    return dictplist;
}

+ (void)DictWriteToSetCenterPlist:(NSMutableDictionary *)applist {
    [applist writeToFile:[self getPlistPath] atomically:YES];
}

@end
