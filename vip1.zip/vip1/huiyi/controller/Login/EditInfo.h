//
//  EditInfo.h
//  ChannelFive
//
//  Created by qstx2 on 14-1-3.
//  Copyright (c) 2014年 jxz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EditInfo : NSObject

+ (NSMutableDictionary *)plistData;
+ (void)DictWriteToSetCenterPlist:(NSMutableDictionary *)applist;

@end
