//
//  FindPassWordViewController.m
//  huiyi
//
//  Created by 林伟强 on 16/11/8.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "FindPassWordViewController.h"
#import "Helper.h"
#import "NSString+URL.h"

@interface FindPassWordViewController () <UITextFieldDelegate>

@property (nonatomic, strong) UIScrollView   *myScrollView;
@property (nonatomic, strong) UIView         *midBgView;
@property (nonatomic, strong) UITextField    *verifyTF;
@property (nonatomic, strong) UITextField    *phoneTF;
@property (nonatomic, strong) UITextField    *codeTF;
@property (nonatomic, strong) UITextField    *passwordTF;
@property (nonatomic, strong) UITextField    *repasswordTF;
@property (nonatomic, strong) UIImageView    *verifyImage;
@property (nonatomic, strong) UIButton       *codeBtn;
@property (nonatomic, strong) UIButton       *submitButton;
@property (nonatomic, strong) UIFont         *placeholderFont;
@property (nonatomic, assign) CGSize          keyBoardSize;
@property (nonatomic, assign) BOOL            isCountdown;

@property (nonatomic, strong) NSMutableDictionary *codeMuDic;
@property (nonatomic, strong) NSMutableDictionary *completeInfoMuDic;

@property (nonatomic, strong) NSString * auth_session;

@end

@implementation FindPassWordViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void)keyboardWillShow:(NSNotification *)notification
{
    NSDictionary* info = [notification userInfo];
    self.keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    self.myScrollView.frame = CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT-self.keyBoardSize.height);
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    NSDictionary* info = [notification userInfo];
    self.keyBoardSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    self.myScrollView.frame = CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT);
}

// 初始化方法
- (instancetype)init
{
    if (self = [super init]) {
        
        [self creatData];
    }
    return self;
}

// 初始化数据元
- (void)creatData
{
    if ([UIScreen mainScreen].bounds.size.width == 320) {
        self.placeholderFont = [UIFont systemFontOfSize:15.0];
    }
    else {
        self.placeholderFont = [UIFont systemFontOfSize:16.0];
    }
    
    self.codeMuDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [self.codeMuDic setObject:@"" forKey:@"company_code"];
    
    self.completeInfoMuDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [self.completeInfoMuDic setObject:@"" forKey:@"company_code"];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.titlelabel.text = @"找回密码";
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    
    self.myScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT)];
    self.myScrollView.contentSize = CGSizeMake(ScreenWidth, 359);
    self.myScrollView.showsHorizontalScrollIndicator = NO;
    self.myScrollView.showsVerticalScrollIndicator = NO;
    [self.myScrollView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:self.myScrollView];
    
    [self createView];
}

- (void)createView
{
    self.midBgView = [[UIView alloc] initWithFrame:CGRectMake(15, 15, ScreenWidth-30, 225)];
    [self.midBgView setBackgroundColor:[UIColor whiteColor]];
    [self.midBgView.layer setCornerRadius:2.0];
    [self.midBgView.layer setMasksToBounds:YES];
    [self.myScrollView addSubview:self.midBgView];
    
    self.verifyTF = [[UITextField alloc] initWithFrame:CGRectMake(15, 0, self.midBgView.frame.size.width-30-78, 44.5)];
    [self.verifyTF setDelegate:self];
    [self.verifyTF setTag:105];
    [self.verifyTF setFont:self.placeholderFont];
    [self.verifyTF setPlaceholder:@"请输入附加码"];
    [self.verifyTF setReturnKeyType:UIReturnKeyDone];
    [self.verifyTF setBackgroundColor:[UIColor clearColor]];
    [self.verifyTF setClearButtonMode:UITextFieldViewModeWhileEditing];
    [self.verifyTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    [self.midBgView addSubview:self.verifyTF];
    
    self.verifyImage = [[UIImageView alloc]initWithFrame:CGRectMake(self.midBgView.frame.size.width-15-78, 7.5, 78, 30)];
    [self.verifyImage setBackgroundColor:[UIColor clearColor]];
    [self.verifyImage setUserInteractionEnabled:YES];
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    [self.verifyImage addGestureRecognizer:singleTap];
    [self.midBgView addSubview:self.verifyImage];
    
    [self.midBgView addSubview:[self creatLineView:CGRectMake(15, CGRectGetMaxY(self.verifyTF.frame), self.midBgView.frame.size.width-30, 0.5)]];
    
    self.phoneTF = [[UITextField alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(self.verifyTF.frame)+0.5, self.midBgView.frame.size.width-30-78, 44.5)];
    [self.phoneTF setDelegate:self];
    [self.phoneTF setTag:101];
    [self.phoneTF setFont:self.placeholderFont];
    [self.phoneTF setPlaceholder:@"请输入常用邮箱/手机号"];
    [self.phoneTF setReturnKeyType:UIReturnKeyDone];
    [self.phoneTF setBackgroundColor:[UIColor clearColor]];
    [self.phoneTF setClearButtonMode:UITextFieldViewModeWhileEditing];
    [self.phoneTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    [self.midBgView addSubview:self.phoneTF];
    
    self.codeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.codeBtn setFrame:CGRectMake(self.midBgView.frame.size.width-15-78, 45+7.5, 78, 30)];
    [self.codeBtn setBackgroundImage:[self creatImageWithColol:RGBCOLOR(23,180,235) Size:self.codeBtn.frame.size] forState:UIControlStateNormal];
    [self.codeBtn setBackgroundImage:[self creatImageWithColol:RGBCOLOR(206,206,206) Size:self.codeBtn.frame.size] forState:UIControlStateDisabled];
    [self.codeBtn.layer setCornerRadius:2.0];
    [self.codeBtn.layer setMasksToBounds:YES];
    [self.codeBtn setEnabled:NO];
    [self.codeBtn setTitle:@"发送验证码" forState:UIControlStateNormal];
    [self.codeBtn setTitleColor:[UIColor colorWithHexString:@"#ffffff"] forState:UIControlStateNormal];
    [self.codeBtn.titleLabel setFont:YHUI(13)];
    [self.codeBtn addTarget:self action:@selector(codeBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.midBgView addSubview:self.codeBtn];
    
    [self.midBgView addSubview:[self creatLineView:CGRectMake(15, CGRectGetMaxY(self.phoneTF.frame), self.midBgView.frame.size.width-30, 0.5)]];
    
    self.codeTF = [[UITextField alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(self.phoneTF.frame)+0.5, self.midBgView.frame.size.width-30, 44.5)];
    [self.codeTF setDelegate:self];
    [self.codeTF setTag:102];
    [self.codeTF setFont:self.placeholderFont];
    [self.codeTF setPlaceholder:@"请输入验证码"];
    [self.codeTF setReturnKeyType:UIReturnKeyDone];
    [self.codeTF setBackgroundColor:[UIColor clearColor]];
    [self.codeTF setClearButtonMode:UITextFieldViewModeWhileEditing];
    [self.codeTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    [self.midBgView addSubview:self.codeTF];
    
    [self.midBgView addSubview:[self creatLineView:CGRectMake(15, CGRectGetMaxY(self.codeTF.frame), self.midBgView.frame.size.width-30, 0.5)]];
    
    self.passwordTF = [[UITextField alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(self.codeTF.frame)+0.5, self.midBgView.frame.size.width-30, 44.5)];
    [self.passwordTF setDelegate:self];
    [self.passwordTF setTag:103];
    [self.passwordTF setFont:self.placeholderFont];
    [self.passwordTF setPlaceholder:@"请设置新密码(6~16位，区分大小写)"];
    [self.passwordTF setSecureTextEntry:YES];
    [self.passwordTF setReturnKeyType:UIReturnKeyDone];
    [self.passwordTF setBackgroundColor:[UIColor clearColor]];
    [self.passwordTF setClearButtonMode:UITextFieldViewModeWhileEditing];
    [self.passwordTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    [self.midBgView addSubview:self.passwordTF];
    
    [self.midBgView addSubview:[self creatLineView:CGRectMake(15, CGRectGetMaxY(self.passwordTF.frame), self.midBgView.frame.size.width-30, 0.5)]];
    
    self.repasswordTF = [[UITextField alloc] initWithFrame:CGRectMake(15, CGRectGetMaxY(self.passwordTF.frame)+0.5, self.midBgView.frame.size.width-30, 44.5)];
    [self.repasswordTF setDelegate:self];
    [self.repasswordTF setTag:104];
    [self.repasswordTF setFont:self.placeholderFont];
    [self.repasswordTF setPlaceholder:@"请确认新密码"];
    [self.repasswordTF setSecureTextEntry:YES];
    [self.repasswordTF setReturnKeyType:UIReturnKeyDone];
    [self.repasswordTF setBackgroundColor:[UIColor clearColor]];
    [self.repasswordTF setClearButtonMode:UITextFieldViewModeWhileEditing];
    [self.repasswordTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    [self.midBgView addSubview:self.repasswordTF];
    
    self.submitButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.submitButton setFrame:CGRectMake(15,  CGRectGetMaxY(self.midBgView.frame)+30, ScreenWidth-30, 52)];
    [self.submitButton setBackgroundImage:[self creatImageWithColol:RGBCOLOR(23,180,235) Size:self.submitButton.frame.size] forState:UIControlStateNormal];
    [self.submitButton setBackgroundImage:[self creatImageWithColol:RGBCOLOR(206,206,206) Size:self.submitButton.frame.size] forState:UIControlStateDisabled];
    [self.submitButton.layer setCornerRadius:2.0];
    [self.submitButton.layer setMasksToBounds:YES];
    [self.submitButton setEnabled:NO];
    [self.submitButton setTitle:@"提交" forState:UIControlStateNormal];
    [self.submitButton setTitleColor:[UIColor colorWithHexString:@"#ffffff"] forState:UIControlStateNormal];
    [self.submitButton.titleLabel setFont:[UIFont systemFontOfSize:20.0]];
    [self.submitButton addTarget:self action:@selector(submitAction) forControlEvents:UIControlEventTouchUpInside];
    [self.myScrollView addSubview:self.submitButton];
    
    [self loadVerifyImage];
}

- (UIView *)creatLineView:(CGRect)rect
{
    UIView *lineView = [[UIView alloc] initWithFrame:rect];
    [lineView setBackgroundColor:[UIColor colorWithHexString:@"c7c7c7"]];
    return lineView;
}

- (void)handleSingleTap:(UIGestureRecognizer *)gestureRecognizer
{
    [self loadVerifyImage];
}

- (void)loadVerifyImage
{
    self.auth_session = [[NSUserDefaults standardUserDefaults] objectForKey:@"unlogin_auth_session"];
    
    if (self.auth_session.length == 0)
    {
        [MyDataService getAuthSession:nil callback:^(id data) {
            NSLog(@"%@",data);
            if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]])
            {
                if ([[data objectForKey:@"code"] isEqualToString:@"200"])
                {
                    NSString * auth_session = [[data objectForKey:@"content"] objectForKey:@"auth_session"];
                    [[NSUserDefaults standardUserDefaults] setObject:auth_session forKey:@"unlogin_auth_session"];
                    self.auth_session = auth_session;
                    
                    NSString * urlString = [Base_CODE stringByAppendingString:[NSString stringWithFormat:@"platform/v2sso/getVerifyImage?auth_session=%@", [self.auth_session URLEncodedString]]];
                    //[self.loginDynamicPhoneView.verifyImage sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:nil];
                    
                    NSURL * imageUrl = [NSURL URLWithString:urlString];
                    UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:imageUrl]];
                    self.verifyImage.image = image;
                }
            }
            else
            {
                if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                    [Dialog toastCenter:[data objectForKey:@"error"]];
                }
            }
        }];
    }
    else
    {
        NSString * urlString = [Base_CODE stringByAppendingString:[NSString stringWithFormat:@"platform/v2sso/getVerifyImage?auth_session=%@", [self.auth_session URLEncodedString]]];
        //[self.loginDynamicPhoneView.verifyImage sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:nil];
        
        NSURL * imageUrl = [NSURL URLWithString:urlString];
        UIImage * image = [UIImage imageWithData:[NSData dataWithContentsOfURL:imageUrl]];
        self.verifyImage.image = image;
    }
}

- (void)codeBtnClicked
{
    [self.view endEditing:YES];
    
    if (self.verifyTF.text.length == 0) {
        [Dialog toastCenter:@"请输入附加码"];
    }
    else if (self.phoneTF.text.length == 0) {
        [Dialog toastCenter:@"请输入邮箱/手机号"];
    }
    else if (![Helper justEmail:self.phoneTF.text] && ![Helper justMobile:self.phoneTF.text]) {
        [Dialog toastCenter:@"邮箱/手机号格式错误"];
    }
    else {
        [self.codeMuDic setObject:self.verifyTF.text forKey:@"verify_code"];
        [self.codeMuDic setObject:self.auth_session forKey:@"auth_session"];
        [self.codeMuDic setObject:self.phoneTF.text forKey:@"email"];
        [self.codeMuDic setObject:@"pwd" forKey:@"send_type"];
        [self sendmail];
    }
}

- (void)sendmail
{
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    
    [MyDataService pwdregsendMail:self.codeMuDic callback:^(id data) {
        [[Dialog Instance] hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"] || [[data objectForKey:@"code"] isEqualToString:@"201"]) {
                [Dialog toastCenter:@"验证码已发送"];
                __block int timeout = 45; //倒计时时间
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
                dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
                dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
                dispatch_source_set_event_handler(_timer, ^{
                    if(timeout <= 0) { //倒计时结束，关闭
                        dispatch_source_cancel(_timer);
                        //dispatch_release(_timer);
                        dispatch_async(dispatch_get_main_queue(), ^{
                            //设置界面的按钮显示 根据自己需求设置
                            [self.codeBtn setTitle:@"发送验证码" forState:UIControlStateNormal];
                            [self.codeBtn setEnabled:YES];
                            self.isCountdown = NO;
                        });
                    }
                    else {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            //设置界面的按钮显示 根据自己需求设置
                            [self.codeBtn setTitle:[NSString stringWithFormat:@"重新获取(%d)",timeout] forState:UIControlStateNormal];
                            [self.codeBtn setEnabled:NO];
                            self.isCountdown = YES;
                        });
                        timeout--;
                    }
                });
                dispatch_resume(_timer);
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
                [self loadVerifyImage];
            }
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
        }
    }];
}

- (void)submitAction
{
    [self.view endEditing:YES];
    
    if (self.codeTF.text.length == 0) {
        [Dialog toastCenter:@"请输入验证码"];
    }
    else {
        [self.completeInfoMuDic setObject:self.phoneTF.text forKey:@"email"];
        [self.completeInfoMuDic setObject:self.codeTF.text forKey:@"captcha"];
        
        if ([Helper justMobile:self.phoneTF.text]){
            [self.completeInfoMuDic setObject:@"1" forKey:@"type"];
        }
        else {
            [self.completeInfoMuDic setObject:@"2" forKey:@"type"];
        }
        
        if (![Helper justEmail:[self.completeInfoMuDic objectForKey:@"email"]] && ![Helper justMobile:[self.completeInfoMuDic objectForKey:@"email"]]) {
            [Dialog toastCenter:@"邮箱/手机号格式错误"];
            return;
        }
        if ([[self.completeInfoMuDic objectForKey:@"password"] length] == 0) {
            [Dialog toastCenter:@"密码不能为空"];
            return;
        }
        if ([[self.completeInfoMuDic objectForKey:@"password"] length] > 16 || [[self.completeInfoMuDic objectForKey:@"password"] length] < 6) {
            [Dialog toastCenter:@"请输入6~16位密码"];
            return;
        }
        if (![[self.completeInfoMuDic objectForKey:@"password"] isEqualToString:[self.completeInfoMuDic objectForKey:@"rePassword"]]) {
            [Dialog toastCenter:@"两次密码不一致"];
            return;
        }
        else {
            [self completeInfo];
        }
    }
}

- (void)completeInfo
{
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    [MyDataService reSetPWD:self.completeInfoMuDic callback:^(id data) {
        [[Dialog Instance] hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"]isEqualToString:@"200"]||[[data objectForKey:@"code"]isEqualToString:@"201"]){
                [Dialog toastCenter:@"修改成功"];
                /*
                [self dismissViewControllerAnimated:YES completion:^{
                    
                }];*/
                [self.navigationController popViewControllerAnimated:YES];
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
            }
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
        }
    }];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return YES;
}

- (void)getInfo:(UITextField *)textField
{
    if (textField.tag == 101) {
        if (self.isCountdown) {
            [self.codeBtn setEnabled:NO];
        }
        else {
            if ([textField text].length) {
                [self.codeBtn setEnabled:YES];
            }
            else {
                [self.codeBtn setEnabled:NO];
            }
        }
    }
    if (textField.tag == 102) {
        [self.completeInfoMuDic setObject:textField.text forKey:@"captcha"];
    }
    if (textField.tag == 103) {
        [self.completeInfoMuDic setObject:textField.text forKey:@"password"];
    }
    if (textField.tag == 104) {
        [self.completeInfoMuDic setObject:textField.text forKey:@"rePassword"];
    }
    
    if (self.phoneTF.text.length && self.codeTF.text.length && self.passwordTF.text.length && self.repasswordTF.text.length) {
        [self.submitButton setEnabled:YES];
    }
    else {
        [self.submitButton setEnabled:NO];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
