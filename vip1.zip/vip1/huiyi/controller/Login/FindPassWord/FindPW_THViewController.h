//
//  FindPW_THViewController.h
//  huiyi
//
//  Created by songhongshuai on 14/11/27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@interface FindPW_THViewController : FatherViewController
{
    NSString * _email;
}
@property (nonatomic,strong)NSString * email;
@property (nonatomic,strong)NSString * captcha;
@end
