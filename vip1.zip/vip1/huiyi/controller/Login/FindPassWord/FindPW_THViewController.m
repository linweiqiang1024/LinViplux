//
//  FindPW_THViewController.m
//  huiyi
//
//  Created by songhongshuai on 14/11/27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "FindPW_THViewController.h"
#import "RegistTextField.h"

@interface FindPW_THViewController () <UITextFieldDelegate>
{
    NSMutableDictionary *_completeInfoMuDic;
}
@end

@implementation FindPW_THViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _completeInfoMuDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [_completeInfoMuDic setObject:@"" forKey:@"user_id"];
    [_completeInfoMuDic setObject:self.captcha forKey:@"captcha"];
    [_completeInfoMuDic setObject:@"" forKey:@"mobile_phone"];
    [_completeInfoMuDic setObject:_email forKey:@"email"];
    if ([self validateMobile:_email]) {
        [_completeInfoMuDic setObject:@"1" forKey:@"type"];
    }
    else {
        [_completeInfoMuDic setObject:@"2" forKey:@"type"];
    }
    BackGround16Color(self.view, @"#efeff4");
    self.titlelabel.text = @"重置密码";
    
    UIView *infoView = [[UIView alloc]initWithFrame:CGRectMake(0, 13+self.F_NAV_HEIGHT, ScreenWidth, 76)];
    BackGroundColor(infoView, whiteColor);
    [self.view addSubview:infoView];
    
    UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLineLB, @"#c8c7cc");
    [infoView addSubview:headLineLB];
    
    RegistTextField *passWordTF = [[RegistTextField alloc]initWithFrame:CGRectMake(17, 8 , ScreenWidth-20, 22)];
    BackGroundColor(passWordTF, clearColor);
    passWordTF.placeHolderFont=14;
    passWordTF.placeholder = @"请输入密码(6~16位数，区分大小写)";
    passWordTF.secureTextEntry = YES;
    passWordTF.tag = 104;
    passWordTF.delegate = self;
    [passWordTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    passWordTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
    [infoView addSubview:passWordTF];
    
    UILabel *headHLineLB = [[UILabel alloc]initWithFrame:CGRectMake(17, CGRectGetMaxY(passWordTF.frame)+8, ScreenWidth, 0.5)];
    BackGround16Color(headHLineLB, @"#c8c7cc");
    [infoView addSubview:headHLineLB];
    
    RegistTextField *againPassWordTF = [[RegistTextField alloc]initWithFrame:CGRectMake(17, CGRectGetMaxY(headHLineLB.frame) + 8, ScreenWidth-20, 22)];
    againPassWordTF.placeholder = @"再次输入密码";
    againPassWordTF.tag = 105;
    passWordTF.delegate = self;
    againPassWordTF.placeHolderFont=14;
    againPassWordTF.secureTextEntry = YES;
    [againPassWordTF addTarget:self action:@selector(getInfo:) forControlEvents:UIControlEventEditingChanged];
    againPassWordTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
    [infoView addSubview:againPassWordTF];
    
    UILabel *endLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0,CGRectGetHeight(infoView.frame)-0.5, ScreenWidth, 0.5)];
    BackGround16Color(endLineLB, @"#c8c7cc");
    [infoView addSubview:endLineLB];
    
    UIButton * RegistBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    RegistBtn.frame = CGRectMake((ScreenWidth-295)/2.0f, CGRectGetMaxY(infoView.frame)+19, 295, 36);
    [RegistBtn setBackgroundImage:[UIImage imageNamed:@"next_btn_bg"] forState:UIControlStateNormal];
    //    [RegistBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [RegistBtn setTitle:@"立即重置" forState:UIControlStateNormal];
    RegistBtn.tag = 106;
    [RegistBtn addTarget:self action:@selector(registBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:RegistBtn];

    // Do any additional setup after loading the view.
}

- (void)ReturnBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder] ;
    return YES;
}

- (void)completeInfo
{
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    [MyDataService reSetPWD:_completeInfoMuDic callback:^(id data) {
        [[Dialog Instance] hideProgress];
        if ([[data objectForKey:@"code"]isEqualToString:@"200"]||[[data objectForKey:@"code"]isEqualToString:@"201"]){
            [self dismissViewControllerAnimated:YES completion:^{
            
            }];
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
            }
        }
    }];
}

- (void)registBtnClicked:(UIButton *)btn
{
    if([[_completeInfoMuDic objectForKey:@"password"]length]==0)
    {
        [Dialog toastCenter:@"密码不能为空"];
        return;
    }
    if (![[_completeInfoMuDic objectForKey:@"password"] isEqualToString:[_completeInfoMuDic objectForKey:@"rePassword"]])
    {
        [Dialog toastCenter:@"两次密码不一致"];
    }
    else
    {
        [self completeInfo];
    }
}

- (void)getInfo:(UITextField *)TextField
{
    if (TextField.tag == 104) {
        [_completeInfoMuDic setObject:TextField.text forKey:@"password"];
    }
    if (TextField.tag == 105) {
        [_completeInfoMuDic setObject:TextField.text forKey:@"rePassword"];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
