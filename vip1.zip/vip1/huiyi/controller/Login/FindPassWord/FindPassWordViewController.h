//
//  FindPassWordViewController.h
//  huiyi
//
//  Created by 林伟强 on 16/11/8.
//  Copyright © 2016年 linweiqiang. All rights reserved.
//

#import "FatherViewController.h"

@interface FindPassWordViewController : FatherViewController

@end
