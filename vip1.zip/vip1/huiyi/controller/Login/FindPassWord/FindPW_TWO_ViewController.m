//
//  FindPW_TWO_ViewController.m
//  huiyi
//
//  Created by songhongshuai on 14/11/27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "FindPW_TWO_ViewController.h"
#import "RegistTextField.h"
#import "FindPW_THViewController.h"

@interface FindPW_TWO_ViewController () <UITextFieldDelegate>
{
    RegistTextField *_reCodeTF;
    NSString * _captcha; // 验证码
    NSMutableDictionary *_codeMuDic;
    UIButton *codeBtn;
}
@end

@implementation FindPW_TWO_ViewController

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"FindPW_TWO_ViewController"];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"registInfoDismiss" object:nil];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self sendmail];
    [MobClick beginLogPageView:@"FindPW_TWO_ViewController"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registInfoDismiss) name:@"registInfoDismiss" object:nil];
}

- (void)registInfoDismiss
{
    [self.view endEditing:YES];
    if (self.childViewControllers.count>0) {
        [[self.childViewControllers objectAtIndex:0] removeFromParentViewController];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _codeMuDic = [[NSMutableDictionary alloc]initWithCapacity:0];
    [_codeMuDic setObject:_userName forKey:@"email"];
    [_codeMuDic setObject:@"" forKey:@"mobile_phone"];
    [_codeMuDic setObject:@"2" forKey:@"type"];// 1：手机号   2邮箱
    [_codeMuDic setObject:@"" forKey:@"user_id"];
    
    self.titlelabel.text = @"输入验证码";
    //    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registInfoDismiss) name:@"registInfoDismiss" object:nil];
    self.view.backgroundColor = [UIColor colorWithHexString:@"#efeff4"];
    UILabel *remindLB = [[UILabel alloc]initWithFrame:CGRectMake(15, self.F_NAV_HEIGHT + 5, ScreenWidth-30, 30)];
    remindLB.text = [NSString stringWithFormat:@"验证码已发送%@，请查看",_userName];
    remindLB.backgroundColor = [UIColor clearColor];
    remindLB.font = YHUI(13);
    remindLB.textColor  = [UIColor blackColor];
    [self.view addSubview:remindLB];
    
    UIView *codeView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(remindLB.frame), ScreenWidth, 46)];
    codeView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:codeView];
    
    UILabel *headLineLB = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 0.5)];
    BackGround16Color(headLineLB, @"#c8c7cc");
    [codeView addSubview:headLineLB];
    
    UILabel *endline = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(codeView.frame)-0.5, ScreenWidth, 0.5)];
    endline.backgroundColor = [UIColor colorWithHexString:@"#c8c7cc"];
    [codeView addSubview:endline];
    
    _reCodeTF = [[RegistTextField alloc]initWithFrame:CGRectMake(15, 12, ScreenWidth-148, 22)];
    _reCodeTF.placeholder = @"请输入验证码";
    _reCodeTF.delegate = self;
    [_reCodeTF addTarget:self action:@selector(getReCode:) forControlEvents:UIControlEventEditingChanged];
    _reCodeTF.clearButtonMode = UITextFieldViewModeUnlessEditing;
    [codeView addSubview:_reCodeTF];
    
    codeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    codeBtn.frame = CGRectMake(ScreenWidth-133, 9, 126, 28.5);
    codeBtn.backgroundColor = [UIColor colorWithHexString:@"#828282"];
    [codeBtn setTitle:@"发送验证码" forState:UIControlStateNormal];
    codeBtn.titleLabel.font = YHUI(13);
    //    [codeBtn setBackgroundImage:[UIImage imageNamed:@"hqyzm"] forState:UIControlStateNormal];
    [codeBtn addTarget:self action:@selector(codeViewBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    codeBtn.tag = 101;
    [codeView addSubview:codeBtn];
    
    UIButton * nextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    nextBtn.frame = CGRectMake(15, CGRectGetMaxY(codeView.frame)+22.5, ScreenWidth-30, 36);
    [nextBtn setBackgroundImage:[UIImage imageNamed:@"next_btn_bg"] forState:UIControlStateNormal];
    [nextBtn setTitle:@"下一步" forState:UIControlStateNormal];
    nextBtn.tag = 102;
    [nextBtn addTarget:self action:@selector(codeViewBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:nextBtn];
    
    // Do any additional setup after loading the view.
}

- (void)sendmail
{
    [self.view endEditing:YES];
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    NSDictionary *dic = @{@"email":_userName};
    [MyDataService sendMail:dic callback:^(id data) {
        [[Dialog Instance] hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]||[[data objectForKey:@"code"] isEqualToString:@"201"]) {
                __block int timeout=45; //倒计时时间
                dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
                dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
                dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
                dispatch_source_set_event_handler(_timer, ^{
                    if(timeout<=0){ //倒计时结束，关闭
                        dispatch_source_cancel(_timer);
                        //dispatch_release(_timer);
                        dispatch_async(dispatch_get_main_queue(), ^{
                            //设置界面的按钮显示 根据自己需求设置
                            [codeBtn setTitle:@"发送验证码" forState:UIControlStateNormal];
                            [codeBtn setTitleColor:[UIColor whiteColor]  forState:UIControlStateNormal];
                            codeBtn.userInteractionEnabled = YES;
                            [codeBtn setAlpha:1.0];
                            
                        });
                    }
                    else {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            //设置界面的按钮显示 根据自己需求设置
                            [codeBtn setTitle:[NSString stringWithFormat:@"%d秒",timeout] forState:UIControlStateNormal];
                            [codeBtn setTitleColor:[UIColor blackColor]  forState:UIControlStateNormal];
                            codeBtn.userInteractionEnabled = NO;
                            [codeBtn setAlpha:0.4];
                        });
                        timeout--;
                    }
                });
                dispatch_resume(_timer);
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
            }
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
        }
    }];
}

- (void)captchaCode
{
    [[Dialog Instance] showCenterProgressWithLabel:@"加载中..."];
    [MyDataService captchaMail:_codeMuDic callback:^(id data) {
        [[Dialog Instance] hideProgress];
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]]) {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"]) {
                if ([[[data objectForKey:@"content"] objectForKey:@"state"] isEqualToString:@"1"]) {
                    FindPW_THViewController *recodeVC = [[FindPW_THViewController alloc]init];
                    recodeVC.email = _userName;
                    recodeVC.captcha = [_codeMuDic objectForKey:@"captcha"];
                    [self addChildViewController:recodeVC];
                    [self.view addSubview:recodeVC.view];
                    [self.navigationController pushViewController:recodeVC animated:YES];
//                    [recodeVC.view  setFrame:CGRectMake(ScreenWidth, 0, ScreenWidth,recodeVC.view.frame.size.height  )];
//                    [UIView beginAnimations:nil context:nil];
//                    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
//                    [UIView setAnimationDuration:0.2];
//                    [recodeVC.view setFrame:CGRectMake(0, 0, ScreenWidth , recodeVC.view.frame.size.height )];
//                    [UIView commitAnimations];
                }
            }
            else {
                NSString *error = [data objectForKey:@"msg"];
                if (error != nil) {
                    [Dialog toastCenter:error];
                }
            }
        }
        else {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
        }
    }];
}

- (void)codeViewBtnClicked:(UIButton *)btn
{
    if (btn.tag == 101) {
        [self sendmail];
    }
    if (btn.tag == 102) {
        [self nextview];
    }
}

- (void)nextview
{
    if (_reCodeTF.text.length == 0) {
        [Dialog toastCenter:@"请输入验证码"];
    }
    else {
        [self.view endEditing:YES];
        [self captchaCode];
    }
}

- (void)getReCode:(UITextField*)textfield
{
    [_codeMuDic setObject:textfield.text forKey:@"captcha"];//验证码
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)ReturnBtn
{
    [self.navigationController popViewControllerAnimated:YES];
//    [self.view  setFrame:CGRectMake(0, 0, ScreenWidth,self.view.frame.size.height  )];
//    [UIView beginAnimations:nil context:nil];
//    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
//    [UIView setAnimationDuration:0.2];
//    [self.view setFrame:CGRectMake(ScreenWidth, 0, ScreenWidth , self.view.frame.size.height )];
//    [UIView commitAnimations];
//    [[NSNotificationCenter defaultCenter] postNotificationName:@"secondTypeDismiss" object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
@end
