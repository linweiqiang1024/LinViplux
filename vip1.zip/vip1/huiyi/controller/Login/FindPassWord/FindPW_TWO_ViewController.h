//
//  FindPW_TWO_ViewController.h
//  huiyi
//
//  Created by songhongshuai on 14/11/27.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FatherViewController.h"

@interface FindPW_TWO_ViewController : FatherViewController
{
    NSString *_userName;
    NSString *_user_id;
    BOOL _isEamil;
}
@property (strong,nonatomic)NSString *userName;
@property (strong,nonatomic)NSString *user_id;
@property (nonatomic)BOOL isEamil;
@end
