//
//  ConTextField.m
//  huiyi
//
//  Created by qstx1 on 14-6-24.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "ConTextField.h"

@implementation ConTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawPlaceholderInRect:(CGRect)rect
{
    //CGContextRef context = UIGraphicsGetCurrentContext();
    //CGContextSetFillColorWithColor(context, [UIColor yellowColor].CGColor);
    
    [[UIColor colorWithHexString:@"#D1D1D1"] setFill];
    [[self placeholder] drawInRect:rect withFont:[UIFont systemFontOfSize:16]];
}

//- (CGRect)placeholderRectForBounds:(CGRect)bounds
//
//{
//    
//    CGRect placeHolderF;
//    
//    if (IOS7) {
//        
//        placeHolderF = CGRectMake(bounds.origin.x, bounds.origin.y, bounds.size.width, bounds.size.height);
//        
//    }else
//        
//    {
//        
//        placeHolderF = CGRectMake(bounds.origin.x, bounds.origin.y+5, bounds.size.width, bounds.size.height);
//        
//    }
//    
//    return placeHolderF;
//    
//}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
