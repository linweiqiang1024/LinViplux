//
//  AppDelegate.m
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "AppDelegate.h"
#import "XHUtility.h"
#import "MobClick.h"
#import "DateFormat.h"
#import "BMKMapManager.h"
#import "SDImageCache.h"
#import "MessageListIpa.h"
#import "RCDRCIMDataSource.h"
#import <ShareSDK/ShareSDK.h>
#import "RCDataBaseManager.h"
#import "NetworkSingleten.h"

//腾讯开放平台（对应QQ和QQ空间）SDK头文件

#import "WXApi.h"
#import "WeiboSDK.h"

#import <UIKit/UIKit.h>
#import "GuidanceViewController.h"
#import "LoginViewController.h"
#import "OpenLoginTool.h"
#import  <libNBSAppAgent/NBSAppAgent.h>
#import "FMDBManagers.h"

//使用DEMO注意：更换appkey，一定要更换对应的连接token，如果token未做变化，默认会从融云测试环境获取，照成appkey和token不一致

@implementation AppDelegate
{
    MessageListIpa *_ipa;
    BOOL _appIsActive;
    BOOL _isBefore;//是否在前台
    BMKMapManager *_mapManager;
    
    BOOL _isFirst;//是不是第一次运行
}

#pragma mark otherDelegate

- (void)getCustomTabBarVC:(UIViewController *)vc
{
    
}

- (id)init
{
    if(self = [super init]) {
        _scene = WXSceneSession;
    }
    return self;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return [ShareSDK handleOpenURL:url wxDelegate:self]||[WXApi handleOpenURL:url delegate:self]||[TencentOAuth HandleOpenURL:url];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    
    return  [ShareSDK handleOpenURL:url
                        sourceApplication:sourceApplication
                               annotation:annotation
                               wxDelegate:self]||[WXApi handleOpenURL:url delegate:self]||[TencentOAuth HandleOpenURL:url];
}

- (id)getWeiChatInfo:(NSString *)urlStr
{
    NSURLRequest *request = [[NSURLRequest alloc]initWithURL:[NSURL URLWithString:urlStr] cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    //第三步，连接服务器
    NSData *received = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    id ret = [NSJSONSerialization JSONObjectWithData:received options:NSJSONReadingMutableContainers error:nil];
    return ret;
}

#pragma mark - 微信代理

- (void)onResp:(BaseResp*)resp
{
    //NSLog( @"%@",resp);
    //就这么简单，到这里就完成了，str就是请求得到的结果
}

- (void)onReq:(BaseReq *)req
{
    //NSLog( @"%@",req);
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[RCIM sharedRCIM]initWithAppKey:RONGCLOUD_IM_APPKEY];
    
    [application setStatusBarStyle:UIStatusBarStyleLightContent];
    
    /**
     * 推送处理1
     */
    if ([application respondsToSelector:@selector(registerUserNotificationSettings:)]) {
        //注册推送, 用于iOS8以及iOS8之后的系统
        UIUserNotificationSettings *settings = [UIUserNotificationSettings
                                                settingsForTypes:(UIUserNotificationTypeBadge |
                                                                  UIUserNotificationTypeSound |
                                                                  UIUserNotificationTypeAlert)
                                                categories:nil];
        [application registerUserNotificationSettings:settings];
    } else {
        //注册推送，用于iOS8之前的系统
        UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge |
        UIRemoteNotificationTypeAlert |
        UIRemoteNotificationTypeSound;
        [application registerForRemoteNotificationTypes:myTypes];
    }

    [RCIM sharedRCIM].globalConversationPortraitSize = CGSizeMake(46, 46);
    [RCIM sharedRCIM].globalMessageAvatarStyle = RC_USER_AVATAR_RECTANGLE;
    //设置用户信息源和群组信息源
    [RCIM sharedRCIM].userInfoDataSource = RCDDataSource;
    [RCIM sharedRCIM].groupInfoDataSource = RCDDataSource;
    //设置接收消息代理
    [RCIM sharedRCIM].showUnkownMessage = YES;
    [RCIM sharedRCIM].showUnkownMessageNotificaiton = YES;
    
    //开启输入状态监听
    [RCIM sharedRCIM].enableTypingStatus = YES;
    
    //开启发送已读回执（只支持单聊）
    [RCIM sharedRCIM].enableReadReceipt = YES;
    
    [ShareSDK registerApp:ShareSDK_APPID];//字符串ShareSDK_APPID为您的ShareSDK的AppKey
    [self initializePlat];
    [[SDImageCache sharedImageCache] setMaxCacheAge:30*24*60*60];//图片缓存策略 1月
    _mapManager = [[BMKMapManager alloc]init];
    // 如果要关注网络及授权验证事件，请设定generalDelegate参数
    BOOL ret =[_mapManager start:BaiduMap_APP_KEY generalDelegate:nil];
    if (!ret) {
        
    }
    NSString *appLaunchOptions = [NSString stringWithFormat: @"%@",[launchOptions JSONString]];
    
    if (![appLaunchOptions isEqual:@"(null)"]) {
        NSMutableDictionary *dic = [EditInfo plistData];
        [dic setObject:appLaunchOptions forKey:@"message"];
        [EditInfo DictWriteToSetCenterPlist:dic];
    }
    
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"udid"]) {
        
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setObject:[XHUtility generateUuidString] forKey:@"udid"];
        [[NSUserDefaults standardUserDefaults]synchronize];//保存到disk
    }
    
    if (!COMPANY_ADDR) {
        [[NSUserDefaults standardUserDefaults]setObject:Base_COMPANY_ADDR forKey:@"companyAddr"];
    }
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self createContentWindow];

    if ([[UIApplication sharedApplication] enabledRemoteNotificationTypes] == UIRemoteNotificationTypeNone) {
        [[OpenLoginTool sharedManager]defaultLogin];
    }
    
    [[RCDataBaseManager shareInstance] CreateUserTable];
    [NetworkSingleten monitorNetworkState];
    
    [self getAuthSession];
    
    return YES;
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"]) {
        
    }
    else if ([identifier isEqualToString:@"answerAction"]) {
        
    }
}

- (void)initializePlat
{
    id log = [[TencentOAuth alloc]initWithAppId:Ten_APPID andDelegate:self];
    NSLog(@"%@",log);
    [ShareSDK connectQQWithQZoneAppKey:Ten_APPID
                     qqApiInterfaceCls:[QQApiInterface class]
                       tencentOAuthCls:[TencentOAuth class]];
    
    [ShareSDK connectQZoneWithAppKey:Ten_APPID
                           appSecret:Ten_APPKEY
                   qqApiInterfaceCls:[QQApiInterface class]
                     tencentOAuthCls:[TencentOAuth class]];

    //微信
    [ShareSDK connectWeChatWithAppId:@"wx66a432fa42aa6daf"
                           appSecret:AppSecret
                           wechatCls:[WXApi class]];
    //新浪微博
    [ShareSDK connectSinaWeiboWithAppKey:SINA_APPKEY
                               appSecret:SINA_AppSecret
                             redirectUri:@"https://api.weibo.com/oauth2/default.html"];
    
    //连接短信分享
    [ShareSDK connectSMS];
    
    //拷贝
    [ShareSDK connectCopy];
}

- (UIImage *)createImageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return theImage;
}

- (void)alertView:(UIAlertView *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (actionSheet.tag == 1) {
        if (buttonIndex == 1)
        {
            NSString *iTunesLink = @"https://itunes.apple.com/cn/app/id910780108?mt=8";//download;
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
        }
        if (buttonIndex==0) {
            if(actionSheet.tag == 1)
            {
                NSString *iTunesLink = @"https://itunes.apple.com/cn/app/id910780108?mt=8";//download;
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:iTunesLink]];
            }
        }
    }
    else {
        if ([actionSheet cancelButtonIndex] != buttonIndex) {
            UITextField *nameTextField = [actionSheet textFieldAtIndex:0];
            if(nameTextField.text.length > 0)
            {
                
            }
        }
    }
}

- (void)_loadRootViewController
{
    [self loginStateChange:nil];
}

#pragma mark  建立正常情况下的window
- (void)createContentWindow
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [self _loadRootViewController];
    
    //友盟
    [MobClick startWithAppkey:@"53ab8f9456240b97d200814a" reportPolicy:(ReportPolicy) REALTIME channelId:nil];
    [MobClick setAppVersion:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
    [MobClick checkUpdate];
    [MobClick setLogEnabled:YES];
    
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
}

/**
 * 推送处理2
 */
//注册用户通知设置
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    // register to receive notifications
    [application registerForRemoteNotifications];
}

/**
 * 推送处理3
 */
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString * token = [[[[deviceToken description] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""] stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    [[RCIMClient sharedRCIMClient] setDeviceToken:token];
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"注册推送失败"
                                                    message:error.description
                                                   delegate:nil
                                          cancelButtonTitle:@"确定"
                                          otherButtonTitles:nil];
    [alert show];
    [[OpenLoginTool sharedManager]defaultLogin];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    
}

//接受服务器推回来的消息
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    // 处理推送消息(程序在后台或者在打开状态接到通知后要回调的方法)
    
    if (userInfo) {
        if ([userInfo objectForKey:@"objectName"]!=nil) {
            //如果不是加群的通知和好友方面的通知，才做审核界面的跳转，和消息界面的跳转
            if (![[userInfo objectForKey:@"objectName"] isEqualToString:@"RC:ContactNtf"]) {
                //这里跳转到消息列表界面
            }
            else{
                //这里跳转到好友列表界面
            }
        }
        else{
            [AppUtil shareAppUtil].isNotifition  = YES;
            [AppUtil shareAppUtil].appIsActive = NO;
            if (_ipa) {
                _ipa = nil;
            }
            _ipa = [[MessageListIpa alloc]init];
            _ipa.ipaUser_id = [[userInfo objectForKey:@"aps"] objectForKey:@"chat_id"];
            _ipa.ipaUser_type = [[userInfo objectForKey:@"aps"] objectForKey:@"chat_type"];
            //_ipa.ipaBadge = [[userInfo objectForKey:@"aps"] objectForKey:@"badge"];
            _ipa.ipaIco_url = [[userInfo objectForKey:@"aps"] objectForKey:@"ico_url"];
            _ipa.ipaNotice_sw = [[userInfo objectForKey:@"aps"] objectForKey:@"notice_sw"];
            _ipa.ipaMsg_type = [[userInfo objectForKey:@"aps"] objectForKey:@"msg_type"];
            _ipa.ipaShield_sw = [[userInfo objectForKey:@"aps"] objectForKey:@"shield_sw"];
            _ipa.ipaState = [[userInfo objectForKey:@"aps"] objectForKey:@"state"];
            _ipa.ipaName = [[userInfo objectForKey:@"aps"] objectForKey:@"chat_name"];
            if (_isBefore) {
                [AppUtil shareAppUtil].isNotifition = NO;
                if ([[NSString stringWithFormat:@"%@",_ipa.ipaUser_type] isEqualToString:@"4"]) {
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"checkFriendNumber" object:nil];
                }
                _ipa = nil;
            }
        }
    }
    else {
        [AppUtil shareAppUtil].isNotifition = NO;
    }
}

//如果是新报名的推送通知 刷新
- (void)getNewApplyCount:(BOOL)isNotifition
{
    
}

//融云的也可以实现本地推送  ，当程序未关闭的时候是走的本地推送
- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
}

- (void)applicationWillTerminate:(UIApplication *)application
{

}

#pragma mark - private

- (void)loginStateChange:(NSNotification *)notification
{
    //判断登录状态
    _indexViewVC = [[New_indexViewController alloc] init];
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:_indexViewVC];
    
//    if(!_isFirst){
//        [nav setNavigationBarHidden:YES];
//    }
//    _isFirst = YES;
    
    if ([UIDevice currentDevice].systemVersion.floatValue >= 7.0) {

        if (IOS7) {
            [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"navBGImage"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
        }
        else {
            [[UINavigationBar appearance] setBackgroundImage:[UIImage imageNamed:@"xian1"] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
        }
        [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:RGBACOLOR(0, 0, 0, 1), NSForegroundColorAttributeName, [UIFont fontWithName:@"HelveticaNeue-CondensedBlack" size:18.0], NSFontAttributeName, nil]];
    }
    self.window.rootViewController = nav;
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [UIApplication sharedApplication].applicationIconBadgeNumber = [[RCIMClient sharedRCIMClient] getTotalUnreadCount];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"applicationDidEnterBackground" object:nil];
    _isBefore = NO;
    [AppUtil shareAppUtil].isShowInWindow = _isBefore;
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    _isBefore = YES;
    [self getNewApplyCount:NO];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

- (void)getAuthSession
{
    [MyDataService getAuthSession:nil callback:^(id data) {
        NSLog(@"%@",data);
        if ([[data objectForKey:@"code"] isKindOfClass:[NSString class]])
        {
            if ([[data objectForKey:@"code"] isEqualToString:@"200"])
            {
                NSString * auth_session = [[data objectForKey:@"content"] objectForKey:@"auth_session"];
                [[NSUserDefaults standardUserDefaults] setObject:auth_session forKey:@"unlogin_auth_session"];
            }
        }
        else
        {
            if ([[data objectForKey:@"error_code"] isEqualToString:@"001"] || [[data objectForKey:@"error_code"] isEqualToString:@"002"]) {
                [Dialog toastCenter:[data objectForKey:@"error"]];
            }
        }
    }];
}

@end
