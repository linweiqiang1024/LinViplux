//
//  AppDelegate.h
//  huiyi
//
//  Created by qstx1 on 14-6-18.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WXApi.h"
#import "New_indexViewController.h"
#import <RongIMLib/RongIMLib.h>
//rongCloud end
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate,WXApiDelegate,TencentSessionDelegate>
{
    enum WXScene _scene;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIWindow *notifitionWindow;
@property (strong, nonatomic) New_indexViewController *indexViewVC;
-(void)_loadRootViewController;
@end
