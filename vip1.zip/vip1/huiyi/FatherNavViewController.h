//
//  FatherNavViewController.h
//  
//
//  Created by songhongshuai on 15/10/30.
//
//

#import <UIKit/UIKit.h>

@interface FatherNavViewController : UINavigationController

@end
