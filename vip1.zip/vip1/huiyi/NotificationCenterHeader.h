//
//  NotificationCenterHeader.h
//  huiyi
//
//  Created by songhongshuai on 15/10/26.
//  Copyright (c) 2015年 shs. All rights reserved.
//

#ifndef huiyi_NotificationCenterHeader_h
#define huiyi_NotificationCenterHeader_h

#define IndexViewToDetailsFailureKey  @"IndexViewToDetailsFailure"
#define IndexViewToDetailsKey         @"IndexViewToDetails"

#define IndexViewChangeCompanyIconKey @"IndexViewChangeCompanyIcon"
#define SELFISDELFROMDISCUSSION       @"selfIsDelFromDiscussion"
#define SELFISADDDISCUSSION           @"selfIsAddDiscussion"
#define ADDFRIENDNOTIFICATION         @"addFriendNotification"


#define RELOADMYMEETINGINFO           @"reloadMyMeetingInfo"

#define RELOADCHECKINFOVIEWS          @"reloadCheckInfoViews"

#define NOTIFICATIONUNREADNUM         @"notificationAddFriendUnreadNum"

#endif
