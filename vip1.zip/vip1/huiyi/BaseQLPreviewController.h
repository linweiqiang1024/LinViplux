//
//  BaseQLPreviewController.h
//  
//
//  Created by songhongshuai on 15/11/2.
//
//

#import "FatherViewController.h"
#import <QuickLook/QuickLook.h>

@protocol BaseQLPreviewDelegate <NSObject>

- (id)previewControl:(QLPreviewController *)previewController previewItemAtIndex:(NSInteger)idx;

@end

@interface BaseQLPreviewController : FatherViewController

@property (nonatomic,weak) id<BaseQLPreviewDelegate>delegate;
//文件属性
@property (nonatomic, strong) NSString *fileTempName;
@property (nonatomic, strong) NSString *fileName;
@property (nonatomic, strong) NSString *fileType;
@property (nonatomic, strong) NSString *realName;
@property (nonatomic,strong ) NSString *urlString;
@property (nonatomic        ) BOOL     state;
@end
