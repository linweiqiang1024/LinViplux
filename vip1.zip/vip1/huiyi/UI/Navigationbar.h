//
//  Navigationbar.h
//  HuiyiDemo
//
//  Created by WLX  on 14-6-20.
//  Copyright (c) 2014年 WLX . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Navigationbar : UIView
-(id)initWithNavigationbarMtitle:(NSString *)title  background:(NSString *)bgd rightbtn:(NSString *)rightbtn rightbtnImage:(NSString *)rbtnImage rbtnClass:(id)className sel:(SEL)sel leftbtn:(NSString *)leftbtn leftbtnImage:(NSString *)lbtnImage;
@end
