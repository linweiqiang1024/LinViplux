//
//  MyControl.h
//  huiyi
//
//  Created by WLX  on 14-7-9.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyControl : UIControl
@property (nonatomic,strong) UIImageView *btnIm;
@end
