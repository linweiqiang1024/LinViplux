//
//  Mybtn.h
//  huiyi
//
//  Created by WLX  on 14-8-19.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContectionListModel.h"
@interface Mybtn : UIButton
@property (nonatomic,retain)ContectionListModel *acceptAdd;
@end
