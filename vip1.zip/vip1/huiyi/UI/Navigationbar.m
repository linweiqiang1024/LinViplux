//
//  Navigationbar.m
//  HuiyiDemo
//
//  Created by WLX  on 14-6-20.
//  Copyright (c) 2014年 WLX . All rights reserved.
//

#import "Navigationbar.h"
#import "MyControl.h"
@implementation Navigationbar

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
//UILabel * testlable = [[UILabel alloc]initWithFrame:CGRectMake(10,20,200,20)];
//
//NSString * tstring =@"UILabel  ios7 与ios7之前实现自适应撑高的方法,文本的内容长度不一，我们需要根据内容的多少来自动换行处理。在IOS7下要求font，与breakmode与之前设置的完全一致sizeWithFont:font constrainedToSize:size lineBreakMode:NSLineBreakByCharWrapping";
//
//testlable.numberOfLines =2;
//
//UIFont * tfont = [UIFont systemFontOfSize:14];
//
//testlable.font = tfont;
//
//testlable.lineBreakMode =NSLineBreakByTruncatingTail ;
//
//testlable.text = tstring ;
//[testlable setBackgroundColor:[UIColor redColor]];
//
//[self.view addSubview:testlable];
//
////高度估计文本大概要显示几行，宽度根据需求自己定义。 MAXFLOAT 可以算出具体要多高
//
//CGSize size =CGSizeMake(300,60);
//
//// label可设置的最大高度和宽度
////    CGSize size = CGSizeMake(300.f, MAXFLOAT);
//
////    获取当前文本的属性
//
//NSDictionary * tdic = [NSDictionary dictionaryWithObjectsAndKeys:tfont,NSFontAttributeName,nil];
//
////ios7方法，获取文本需要的size，限制宽度
//
//CGSize  actualsize =[tstring boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin  attributes:tdic context:nil].size;
//
//// ios7之前使用方法获取文本需要的size，7.0已弃用下面的方法。此方法要求font，与breakmode与之前设置的完全一致
////    CGSize actualsize = [tstring sizeWithFont:font constrainedToSize:size lineBreakMode:NSLineBreakByCharWrapping];
////   更新UILabel的frame
//
//
//testlable.frame =CGRectMake(10,20, actualsize.width, actualsize.height);

-(id)initWithNavigationbarMtitle:(NSString *)title  background:(NSString *)bgd rightbtn:(NSString *)rightbtn rightbtnImage:(NSString *)rbtnImage rbtnClass:(id)className sel:(SEL)sel leftbtn:(NSString *)leftbtn leftbtnImage:(NSString *)lbtnImage {

    if (self ==[super init]) {
        UIImageView * bac = [[UIImageView alloc] init];
        
        bac.frame = CGRectMake(0, 0,320 ,IOS7 ? 64:44);
        bac.image = [UIImage imageNamed:bgd];
        [self addSubview:bac];
        UILabel *labTitlel = [[UILabel alloc] init];
        labTitlel.text = title;
        labTitlel.font = [UIFont boldSystemFontOfSize:16];
        labTitlel.textColor = [UIColor colorWithHexString:@"#ffffff"];
        if (IOS7) {
            CGSize size =CGSizeMake(300,44);
            NSDictionary *tdic = [NSDictionary dictionaryWithObjectsAndKeys:labTitlel.font,NSFontAttributeName, nil];
            CGSize actuasize = [labTitlel.text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin attributes:tdic context:nil].size;
            labTitlel.frame = CGRectMake((320-actuasize.width)/2, 7, actuasize.width, 64);
        
        }else{
        
            CGSize actuasize = [labTitlel.text sizeWithFont:labTitlel.font constrainedToSize:CGSizeMake(320, 44)];
            labTitlel.frame = CGRectMake((320-actuasize.width)/2, 0, actuasize.width, 44);

        }
        
        labTitlel.backgroundColor = [UIColor clearColor];
        [self addSubview:labTitlel];
//        UIImageView *btnIm = [[UIImageView alloc] initWithFrame:CGRectMake(12.5, IOS7 ? 30:10, 12, 20)];
//        btnIm.userInteractionEnabled = YES;
//        btnIm.image = [UIImage imageNamed:rbtnImage];
//        [self addSubview:btnIm];
        MyControl *leftControl = [[MyControl alloc] initWithFrame:CGRectMake(0, IOS7 ? 20:0, 50, 44)];
        leftControl.tag = 1;
        leftControl.btnIm.image = [UIImage imageNamed:rbtnImage];
        //leftControl.backgroundColor = [UIColor redColor];
        [leftControl addTarget:className action:sel forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:leftControl];

//        UIButton *rbtn = [UIButton buttonWithType:UIButtonTypeCustom];
//        rbtn.frame = CGRectMake(0, IOS7 ? 20:0, 50, 44);
//        rbtn.tag= 1;
//        [rbtn addTarget:className action:sel forControlEvents:UIControlEventTouchUpInside];
//        //[rbtn setTitle:rightbtn forState:UIControlStateNormal];
//        rbtn.titleLabel.font = [UIFont systemFontOfSize:15];
//        //[rbtn setImage:[UIImage imageNamed:rbtnImage] forState:UIControlStateNormal];
//        //[rbtn setBackgroundImage:[UIImage imageNamed:rbtnImage] forState:UIControlStateNormal];
//        [btnIm addSubview:rbtn];
        
//        UILabel *lbleft = [[UILabel alloc] initWithFrame:CGRectMake(24, labTitlel.frame.origin.y, labTitlel.frame.size.width, labTitlel.frame.size.height)];
//        lbleft.text = rightbtn;
//        lbleft.font = [UIFont boldSystemFontOfSize:12.0];
//        lbleft.textColor = [UIColor whiteColor];
//        lbleft.backgroundColor = [UIColor clearColor];
//        [self addSubview:lbleft];
        UIButton *lbtn = [UIButton buttonWithType:UIButtonTypeCustom];
        lbtn.frame = CGRectMake(272, IOS7 ? 30:10, 40, 20);
        [lbtn addTarget:className action:sel forControlEvents:UIControlEventTouchUpInside];
        [lbtn setTitle:leftbtn forState:UIControlStateNormal];
        lbtn.titleLabel.font = [UIFont boldSystemFontOfSize:17];
        lbtn.tag = 2;
        [lbtn setImage:[UIImage imageNamed:lbtnImage] forState:UIControlStateNormal];
        [self addSubview:lbtn];

    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
