//
//  MyControl.m
//  huiyi
//
//  Created by WLX  on 14-7-9.
//  Copyright (c) 2014年 shs. All rights reserved.
//

#import "MyControl.h"

@implementation MyControl

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.btnIm = [[UIImageView alloc] initWithFrame:CGRectMake(12.5, 10, 12, 20)];
        self.btnIm.userInteractionEnabled = YES;
        [self addSubview:self.btnIm];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
