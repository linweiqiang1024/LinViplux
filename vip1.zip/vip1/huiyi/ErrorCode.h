//
//  ErrorCode.h
//  huiyi
//
//  Created by songhongshuai on 16/4/25.
//  Copyright © 2016年 shs. All rights reserved.
//

#ifndef ErrorCode_h
#define ErrorCode_h
//签到失败错误world
#define CHECK_IN_ERROR01 @"签到失败!"
#define CHECK_IN_ERROR02 @"签到失败(计点签到不允许重复签)"
//失败描述
#define CHECK_IN_DES_ERROR01 @"有两位或者以上参会者的手机号后4位信息相同，请输入11位手机号！"
#define CHECK_IN_DES_ERROR02 @"手机号信息不存在，请查证后重新输入！"
#define CHECK_IN_DES_ERROR03 @"此参会用户已签过了，计点签到不允许重复签！"
#define CHECK_IN_DES_ERROR04 @"手机号后4位信息不存在，请查证后重新输入！"

#endif /* ErrorCode_h */
