//
//  BaseQLPreviewController.m
//  
//
//  Created by songhongshuai on 15/11/2.
//
//

#import "BaseQLPreviewController.h"
#import <QuickLook/QuickLook.h>

@interface BaseQLPreviewController ()<QLPreviewControllerDataSource,QLPreviewControllerDelegate>

@end

@implementation BaseQLPreviewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.titlelabel.text = self.fileName;

    QLPreviewController *previewController = [[QLPreviewController alloc] init];
    [UINavigationBar appearance].hidden = YES;
    previewController.navigationController.navigationBar.translucent = NO;
    previewController.title = self.fileName;
    previewController.dataSource = self;
    previewController.delegate = self;
    [self.view addSubview:previewController.view];
    previewController.view.frame = FRAME(0, self.F_NAV_HEIGHT, ScreenWidth, ScreenHeight-self.F_NAV_HEIGHT);
}
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)previewController
{
    return 1;
}

- (void)previewControllerDidDismiss:(QLPreviewController *)controller
{
    // if the preview dismissed (done button touched), use this method to post-process previews
}

- (id)previewController:(QLPreviewController *)previewController previewItemAtIndex:(NSInteger)idx
{
    NSURL *fileURL = nil;
    if ([self checkfile:[NSString stringWithFormat:@"%@.%@",_realName,_fileType]]) {
        NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentDir = [documentPaths objectAtIndex:0];
        NSString *userFolder = [documentDir stringByAppendingPathComponent:[[NSUserDefaults standardUserDefaults] objectForKey:@"auth_session"]];
        NSString *path = [userFolder stringByAppendingPathComponent:[NSString stringWithFormat:@"download/%@.%@",_realName,_fileType]];
        NSData *fileData = [NSData dataWithContentsOfFile:path];
        //判断是UNICODE编码
        NSString *isUNICODE = [[NSString alloc] initWithData:fileData encoding:NSUTF8StringEncoding];
        
        //还是ANSI编码
        NSString *isANSI = [[NSString alloc] initWithData:fileData encoding:-2147482062];
        
        if (isUNICODE) {
            
            NSString *retStr = [[NSString alloc]initWithCString:[isUNICODE UTF8String] encoding:NSUTF8StringEncoding];
            
            NSData *data = [retStr dataUsingEncoding:NSUTF16StringEncoding];
            
            [data writeToFile:path atomically:YES];
        }
        else if(isANSI){
            
            NSData *data = [isANSI dataUsingEncoding:NSUTF16StringEncoding];
            [data writeToFile:path atomically:YES];
        }
        fileURL = [NSURL fileURLWithPath:path];
    }
    return fileURL;
}

//查找所要下载的文件download中是否已经存在
- (BOOL)checkfile:(NSString *)fileName{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //在这里获取应用程序Documents文件夹里的文件及文件夹列表
    NSArray *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirs = [documentPath objectAtIndex:0];
    NSString *userFolder = [documentDirs stringByAppendingPathComponent:[[NSUserDefaults standardUserDefaults] objectForKey:@"auth_session"]];
    NSString *downloadDir = [NSString stringWithFormat:@"%@/%@",userFolder,@"download"];
    NSLog(@"documentDir = %@",documentDirs);
    NSError *error = nil;
    NSArray *fileList = [[NSArray alloc] init];
    //fileList便是包含有该文件夹下所有文件的文件名及文件夹名的数组
    fileList = [fileManager contentsOfDirectoryAtPath:downloadDir error:&error];
    for (NSString *file in fileList)
    {
        if ([file isEqualToString:[NSString stringWithFormat:@"%@.%@",self.realName,_fileType]]) {
            return YES;
        }
    }
    return NO;
}
//查找所要下载的文件在临时文件中是否存在
- (BOOL)checkTempFile:(NSString *)fileTempName{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //在这里获取应用程序Documents文件夹里的文件及文件夹列表
    NSArray *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirs = [documentPath objectAtIndex:0];
    NSString *userFolder = [documentDirs stringByAppendingPathComponent:[[NSUserDefaults standardUserDefaults] objectForKey:@"auth_session"]];
    NSString *downloadDir = [NSString stringWithFormat:@"%@/%@",userFolder,@"temp"];
    NSLog(@"documentDir = %@",documentDirs);
    NSError *error = nil;
    NSArray *fileList = [[NSArray alloc] init];
    //fileList便是包含有该文件夹下所有文件的文件名及文件夹名的数组
    fileList = [fileManager contentsOfDirectoryAtPath:downloadDir error:&error];
    for (NSString *file in fileList)
    {
        if ([file isEqualToString:[NSString stringWithFormat:@"%@.%@",fileTempName,_fileType]]) {
            return YES;
        }
    }
    return NO;
}

- (void)backBtn:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
