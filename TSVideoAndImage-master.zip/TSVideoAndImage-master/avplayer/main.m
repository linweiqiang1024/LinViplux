//
//  main.m
//  avplayer
//
//  Created by Feng on 2018/6/30.
//  Copyright © 2018年 Feng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
